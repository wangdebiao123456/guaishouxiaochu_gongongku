 
const {ccclass, property} = cc._decorator;

@ccclass
export default class shouzhiZhiyingDlg extends cc.Component {
 
    m_call_func = null;

     onLoad () {
        var middle_node:cc.Node = cc.find("mask/middle/center",this.node);
        middle_node.on("click",this.OnBtn_Tuichu.bind(this));
     }

     OnBtn_Tuichu()
     {
         if(this.m_call_func)
         {
             this.m_call_func();
         }

         this.node.destroy();
     }
     

    Init(pos:cc.Vec2, guideNode:cc.Node,callback,stip)
    {
        this.node.active = true;
        if (stip) {
          //  this.Tip.string = stip;
        }
        this.m_call_func = callback;

        
       // this.changeMiddleWidth(guideNode);

       
        

        var iw1 =  guideNode.width;
        var ih1 =  guideNode.height;


        var my_effect_node:cc.Node = cc.find("effect",this.node);
        var my_finger_node:cc.Node = cc.find("finger",this.node);


        my_effect_node.setPosition(pos);
        my_finger_node.setPosition(pos);
        this.handAction();

        var middle_node:cc.Node = cc.find("mask/middle/center",this.node);
  
        middle_node.width = iw1;
        middle_node.height = ih1;
        middle_node.setPosition(pos);


        var top_head_node:cc.Node = cc.find("mask/middle/top",this.node);
        top_head_node.width = iw1;
        top_head_node.x = pos.x;
        top_head_node.y = pos.y + ih1/2;


        
        var botom_node:cc.Node = cc.find("mask/middle/bottom",this.node);
        botom_node.width = iw1;
        botom_node.x = pos.x;
        botom_node.y = pos.y - ih1/2;

        

        var my_left_node:cc.Node = cc.find("mask/left",this.node);
        my_left_node.x =  pos.x - iw1/2;
        
        var my_right_node:cc.Node = cc.find("mask/right",this.node);
        my_right_node.x =  pos.x + iw1/2;
        
    }
    changeMiddleWidth(guideNode)
    {

    }
    handAction() {
        var finger_node:cc.Node = cc.find("finger",this.node);

        let time = 0.6;
        cc.tween(finger_node)
            .repeatForever(
                cc.tween()
                    .to(time, {scale: 0.8 * 0.5})
                    .to(time, {scale: 0.5})
            )
            .start();
    }



}
