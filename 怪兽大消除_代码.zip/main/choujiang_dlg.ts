import BaseUIUtils from "../comfuncs/BaseUIUtils";
import BundleLoadUtils from "../comfuncs/BundleLoadUtils";
import ComFunc from "../comfuncs/ComFunc";
import SoundManager from "../comfuncs/SoundManager";
import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import GlobalGameMng from "../Mng/GlobalGameMng";
import WMap from "../WDT/WMap";
import choujiang_reward_dlg from "./choujiang_reward_dlg";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class choujiang_dlg extends cc.Component {

    

    m_reward_config =
    { 
        "1": {
            "type":1,
            "sub_type":1,
            "c": 150,   
            "sname":"金币",
            "weight": 40
  
        },
        "2": {
            "type":1,
            "sub_type":1,
            "c": 300,  
            "sname":"金币",
            "weight": 10
        },
        "3": {
            "type":1,
            "sub_type":5,
            "c": 500,  
            "sname":"钻石",
            "weight": 20
        },
        "4": {
            "type":1,
            "sub_type":5,
            "c": 150,  
            "sname":"钻石",
            "weight": 40
 
        },
        "5": {
            "type":1,
            "sub_type":5,
            "c": 300,  
            "sname":"钻石",
            "weight": 30
        },
        "6": {
            "type":1,
            "sub_type":6,
            "c": 1,  
            "sname":"锤子",
            "weight": 40
        },
        "7": {
            "type":1,
            "sub_type":6,
            "c": 3,  
            "sname":"锤子",
            "weight": 30
        },
        "8": {
            "type":2,
            
            "sname":"超值礼包" ,
            "weight": 40
        },
        "9": {
            "type":3,
            
            "sname":"豪华礼包" ,
            "weight": 40
        }
    }

    m_b_choujianging = false;
    
    m_cb = null;

  
     
    @property(cc.Prefab)
    choujiang_item: cc.Prefab = null;


    @property(cc.Prefab)
    choujiang_reward_dlg: cc.Prefab = null;
 
    
    m_all_choujiang_item_list = [];


    m_randed_list = [];

    m_kaijiang_index = 0;

    targetSelectIndex =0;
    lightTimes = 0;

    selectIndex = 1;
    lastSelectNode =  null;


    m_index_target_mode_map = new WMap();


    m_find_kaijiang_info = null;
    
    onLoad () 
    {

        var bk_btn = cc.find("bk",this.node);
        bk_btn.on("click",this.OnBtnExit.bind(this));
     

        
 

        var freeBtn = cc.find("panel/menu/freeBtn",this.node);
        freeBtn.on("click",this.OnBtnFreeGet.bind(this));


        var videoBtn = cc.find("panel/menu/videoBtn",this.node);
        videoBtn.on("click",this.OnBtnVideoGet.bind(this));

   
 
        SoundManager.GetInstance().Pause_Background_Music();
    }
    FD_Timer()
    {
        this.Refresh_All_Info();
    }

    Find_Libao_Type_Choujiang_Index(itype)
    { 
        for(var ff=0;ff<this.m_all_choujiang_item_list.length;ff++)
        {
            var ff_info  = this.m_all_choujiang_item_list[ff];
            var ff_type = ff_info.type;

            if(ff_type  == itype)
            {
                return ff_info.index;
            }
            
        }

        return 0;
    }
    Find_Choujiang_Index_By_BZCard(ibingzhong)
    {
        var ibz_kapi_ikndex = ibingzhong + 100;
        for(var ff=0;ff<this.m_all_choujiang_item_list.length;ff++)
        {
            var ff_info  = this.m_all_choujiang_item_list[ff];
            var ff_type = ff_info.type;

            if(ff_type  == ibz_kapi_ikndex)
            {
                return ff_info.index;
            }
            
        }

        return 0;
    }

    Get_Rand_CJ_Index()
    {
        var all_w = 0;
        var left_item_list = [];
        for(var ff=0;ff<this.m_all_choujiang_item_list.length;ff++)
        {
            var ff_info  = this.m_all_choujiang_item_list[ff];
            var ff_type = ff_info.type;

            var ff_weight = ff_info.weight; 
            if(ff_type  == 1)
            {
                left_item_list.push(ff_info); 
                all_w += ff_weight;
            }
        }

        var irand1 = all_w*Math.random();


        var left_add = 0;
         for(var ff=0;ff<left_item_list.length;ff++)
        {
            var ff_info  = left_item_list[ff];
            var ff_weight = ff_info.weight; 
            left_add += ff_weight;

            if(left_add >= irand1)
            {

                return ff_info.index;
            }

        }

        
        return left_item_list[0].index;
    }
    Find_Kaijiang_Index() 
    {
        var luckdrwinfo = GlobalGameMng.GetInstance().Get_LuckDraw_Save_Data();

        var icurcount = luckdrwinfo.cjcount;

        var ichoujiangindex = 0;


        if(icurcount == 9)
        {
            ichoujiangindex = this.Find_Libao_Type_Choujiang_Index(3);
        }
        else  if(icurcount == 4)
        {
            ichoujiangindex = this.Find_Libao_Type_Choujiang_Index(2);
        }else{
            ichoujiangindex = this.Get_Rand_CJ_Index();
        }

 

        return ichoujiangindex
    }


    Real_Start_Choujiang()
    {
       
        this.m_b_choujianging = true;

        this.Refresh_All_Info();
        //var freeBtn = cc.find("panel/menu/freeBtn",this.node);
        //freeBtn.active = false;

      //  var videoBtn = cc.find("panel/menu/videoBtn",this.node);
       // videoBtn.active = false;



        var findindex = this.Find_Kaijiang_Index() ;

        this.m_kaijiang_index = findindex;

         
        for(var ff=0;ff<this.m_all_choujiang_item_list.length;ff++)
        {
            var ff_inf = this.m_all_choujiang_item_list[ff];
            if(ff_inf.index == findindex)
            {
                this.m_find_kaijiang_info = ff_inf;
            }
        }

        this.setKaijiangIndex(findindex);

        SoundManager.GetInstance().Play_Effect("com/btn");

    }

    OnBtnVideoGet()
    {
        if(this.m_b_choujianging)
        {
            return;
        }


        var self = this; 
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node,
            ()=>
            {
            
            },
            
            "视频开始抽奖",(bsuc)=>
        {
            if(!bsuc)
            {
            
                return;
            }


            self.Real_Start_Choujiang();
 
        });
 
      
    }
    OnBtnFreeGet()
    {
        if(this.m_b_choujianging)
        {
            return;
        }
        var luckdrwinfo = GlobalGameMng.GetInstance().Get_LuckDraw_Save_Data();
        var icurcount = luckdrwinfo.cjcount;

        if(icurcount >= 10)
        {
            return;
        }


        var bfirst = luckdrwinfo.bfirst;

        var ineed_eplase_sec =  this.Get_Elepase_Need_Sec(bfirst);

        var curday_last_luckdraw_finished_elapse_sec = GlobalGameMng.GetInstance().m_curday_last_luckdraw_finished_elapse_sec;


        if(curday_last_luckdraw_finished_elapse_sec  < ineed_eplase_sec)
        {
            BaseUIUtils.ShowTipTxtDlg( "未到抽奖时间",this.node);
            return;
        }


        this.Real_Start_Choujiang();
 

    }

    setKaijiangIndex(t) 
    {
        this.targetSelectIndex = t,
        this.lightTimes = t   + 3 * this.m_all_choujiang_item_list.length;
        this.scheduleOnce(this.playDrawAPrizeAction, 0.1)
    
    }
    playDrawAPrizeAction () 
    {
        
        SoundManager.GetInstance().Pause_Background_Music();
        this.schedule(this.drawAPrizeAction, 0.1)
    }
    drawAPrizeAction () 
    {


        if (this.lightTimes <= 2){
            this.schedule(this.drawAPrizeAction, 1)
        } 
        else if (this.lightTimes <= 5){
            this.schedule(this.drawAPrizeAction, 0.8)
        } else if (this.lightTimes <= 6){
            this.schedule(this.drawAPrizeAction, 0.3)
        } else if (this.lightTimes <= 10){
            this.schedule(this.drawAPrizeAction, 0.2)
        } 

        
        var self = this;

        if(this.selectIndex === this.targetSelectIndex && this.lightTimes <= 1)
         {
            this.unschedule(this.drawAPrizeAction);

            if(this.lastSelectNode)
            {
                this.lastSelectNode.active = false;
            }
        
            
            var sel_node = this.m_index_target_mode_map.getData( this.selectIndex);

            var sel_select_node = sel_node.getChildByName("select");

            sel_select_node.active = true;
            this.lastSelectNode = sel_select_node;
       
         

            this.scheduleOnce( () =>{
                self.FD_CJ_Animate_End()
            }, 1);
            
            return;
        }



        if(this.lastSelectNode)
        {
            this.lastSelectNode.active = false;
        }
    
        var sel_node = this.m_index_target_mode_map.getData( this.selectIndex);
        var sel_select_node = sel_node.getChildByName("select");
        sel_select_node.active = true;
        this.lastSelectNode = sel_select_node;
   
     
        this.updateSelectIndex();
        this.lightTimes--;

        
        SoundManager.GetInstance().Play_Effect("com/btn",0.1);

    }
    updateSelectIndex () 
    {
        this.selectIndex++;

        if(this.selectIndex > this.m_all_choujiang_item_list.length)
        {
            this.selectIndex = 1;
        } 
    }

    On_Lingqu_Jianli(ibeishu)
    {
        this.m_b_choujianging = false;
        var itype = this.m_find_kaijiang_info.type;
        var sub_type = this.m_find_kaijiang_info.sub_type;
        var kaijiang_c = this.m_find_kaijiang_info.c;
     
        var reward = [
            {
                "t":sub_type,
                "c":kaijiang_c
            }
        ];


        if(itype == 2)
        {
            reward = [
                {
                    "t":1,
                    "c":200
                },
                {
                    "t":6,
                    "c":3
                }
            ];
        }
        else if(itype == 3)
        {
            reward = [
                {
                    "t":5,
                    "c":600
                },
                {
                    "t":6,
                    "c":6
                }
            ];
        }



        GlobalGameMng.GetInstance().On_LuckDraw_CJ_End( );
 


        GlobalGameMng.GetInstance().Add_DaojuType_Count_List(reward,ibeishu);
        GlobalGameMng.GetInstance().Save_Game_Basic_Info();

        var self = this;
        ComFunc.Open_Get_Daoju_Award_Dlg(this.node, reward, ibeishu, ()=>
        {
            self.m_b_choujianging = false;

 
          
        });


       /*
        var itype = this.m_find_kaijiang_info.type;
        var c = this.m_find_kaijiang_info.c;


        var realc = c*ibeishu;

        var reward = [
            {
                "t":itype,
                "c":realc
            }
        ];

 
        GlobalGameMng.GetInstance().On_LuckDraw_CJ_End( );
 


        GlobalGameMng.GetInstance().Add_DaojuType_Count_List(reward,1);
        GlobalGameMng.GetInstance().Save_Game_Basic_Info();

        var self = this;
        ComFunc.Open_Get_Daoju_Award_Dlg(this.node, reward, 1, ()=>
        {
            self.m_b_choujianging = false;

 
          
        });
        */
      
         

    }
    FD_CJ_Animate_End()
    {
        //首先，弹出抽奖提示对话框
  

        var pnode = cc.instantiate(this.choujiang_reward_dlg);

        var self = this;
        var choujiang_reward_dlg:choujiang_reward_dlg = pnode.getComponent("choujiang_reward_dlg");
        choujiang_reward_dlg.SetInitData(
            { 
                kaijianginfo:this.m_find_kaijiang_info,
                cb:(ibeishu)=>
                {
                    self.On_Lingqu_Jianli(ibeishu);

                }

            }
        );

        this.node.addChild(pnode,20);
    
    }
    On_Yingdao_Finished_Exit()
    {
        this.node.destroy();
        if(this.m_cb)
        {
            this.m_cb(0);
        }
    }
    OnBtnExit()
    {
        if(this.m_b_choujianging)
        {
            return;
        }

         
        this.node.destroy();
        if(this.m_cb)
        {
            this.m_cb(0);
        }

        SoundManager.GetInstance().Play_Effect('com/btn');
    }

    SetInitData(paradata)
    {
        this.m_cb = paradata.cb; 
      
    

        for(var ff=1;ff<=9;ff++)
        {
            var ff_info  = this.m_reward_config[""+ff];

            this.m_all_choujiang_item_list.push(ff_info);
        }


        ComFunc.RandomArray(this.m_all_choujiang_item_list);


        this.InitAll_Choujiang_Items();

        this.Refresh_All_Info();
        
        this.schedule(this.FD_Timer.bind(this),0.3);
 
    }


    Get_Elepase_Need_Sec(bfirst)
    {
        var ineed_eplase_sec =  ComFunc.Get_Choujiang_Mianfei_Need_Sec();
        
 

        return ineed_eplase_sec;
    }


    Refresh_All_Info()
    {
        var tip1_node = cc.find("panel/cjtip/tip1",this.node);
        var tip2_node = cc.find("panel/cjtip/tip2",this.node);
 


        var videoBtn = cc.find("panel/menu/videoBtn",this.node);
        var freeBtn = cc.find("panel/menu/freeBtn",this.node);
        var tipBtn = cc.find("panel/menu/tipBtn",this.node);


        var freebtn_label = freeBtn.getChildByName("label");

        var freeLabel = cc.find("panel/menutip/freeLabel",this.node);
        var ctip = cc.find("panel/menutip/ctip",this.node);
        var coutDown_label = cc.find("panel/menutip/ctip/coutDown",this.node);


        

        if(this.m_b_choujianging)
        {
            freeBtn.getComponent(cc.Button).interactable = false;

            videoBtn.getComponent(cc.Button).interactable = false;
           
         
        }else{
            freeBtn.getComponent(cc.Button).interactable = true;

            videoBtn.getComponent(cc.Button).interactable = true;
           
        }


 
        {

          
            var choujiang_info = GlobalGameMng.GetInstance().Get_LuckDraw_Save_Data();

          


            var ineed_eplase_sec = this.Get_Elepase_Need_Sec(choujiang_info.bfirst);
            var cjcount = choujiang_info.cjcount;
            var last_cj_day = choujiang_info.last_cj_day;
            var curday_last_luckdraw_finished_elapse_sec = GlobalGameMng.GetInstance().m_curday_last_luckdraw_finished_elapse_sec;


            

            if(cjcount >= 10)
            {
                freeBtn.active = false;

                videoBtn.active = false;
                tipBtn.active = true;
    
                freeLabel.active = false;
    
                ctip.active = false;
            }
            else
            {
                if(curday_last_luckdraw_finished_elapse_sec >= ineed_eplase_sec)
                {
                    freeBtn.active = true;

                    videoBtn.active = false;
                    tipBtn.active = false;
        
                    freeLabel.active = true;
        
                    ctip.active = false;
        
                    freebtn_label.getComponent(cc.Label).string = "免费抽奖("+cjcount+"/10)";


                }
                else
                {
                    freeBtn.active = false;

                    videoBtn.active = true;
                    tipBtn.active = false;
        
                    freeLabel.active = false;
        
                    ctip.active = true;
        
                    var ileftsec = Math.ceil(ineed_eplase_sec - curday_last_luckdraw_finished_elapse_sec);
                    coutDown_label.getComponent(cc.Label).string = ComFunc.FormatLeftSecStr(ileftsec);



                    var videbtn_label=  videoBtn.getChildByName("label");
                    videbtn_label.getComponent(cc.Label).string = "立即获取("+cjcount+"/10)";

                }



            }

        }

        
        
    }
    InitAll_Choujiang_Items()
    {

        var centermain = cc.find("panel/centermain",this.node);
        

        for(var ff=0;ff<9;ff++)
        {
            var pnode = cc.instantiate(this.choujiang_item);
            centermain.addChild(pnode,10);

            var iy = Math.floor(ff/3);
            var ix =  ff - iy*3;

            var marign = 180;

            var posx = -1*marign + ix*marign;
            var posy =  260 - iy*marign;
            pnode.setPosition(posx,posy);



            var ff_rewardinfo = this.m_all_choujiang_item_list[ff];

            ff_rewardinfo["index"] = ff+1;

            this.m_index_target_mode_map.putData( ff_rewardinfo.index , pnode);

            
            var specialBg = pnode.getChildByName("specialBg");
            var com_bk = pnode.getChildByName("bk");

            if(ff_rewardinfo.bspecial)
            {
                specialBg.active = true;
                com_bk.active = false;
            }else{
                specialBg.active = false;
                com_bk.active = true;
            }

             var wupinginfo = pnode.getChildByName("com_wuping");
             var libao1 = pnode.getChildByName("libao1");
             var libao2 = pnode.getChildByName("libao2");

            var c_node = wupinginfo.getChildByName("c");
            var icon_node = wupinginfo.getChildByName("icon");
          
            
           
                wupinginfo.active = true;

                var ff_type = ff_rewardinfo.type;
                var ff_sub_type = ff_rewardinfo.sub_type;
                var ff_c = ff_rewardinfo.c;

                 

                if(ff_type == 2)
                {
                    libao1.active = true;
                    libao2.active = false;
                    wupinginfo.active = false;
                }
                else   if(ff_type == 3)
                {
                    libao1.active = false;
                    libao2.active = true;
                    wupinginfo.active = false;
                }
                else{
                    libao1.active = false;
                    libao2.active = false;
                    wupinginfo.active = true;

                     var ff_siconname = GlobalGameMng.GetInstance().Get_Aawrd_Daoju_Icon(ff_sub_type);

                     c_node.getComponent(cc.Label).string = "x"+ff_c;

                     BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("resources",icon_node,ff_siconname,{width:65,height:65})

                }

         



        }
    }

  


   
    
}
