import BaseUIUtils from "../comfuncs/BaseUIUtils";
import ClientLogUtils from "../comfuncs/ClientLogUtils";
import SoundManager from "../comfuncs/SoundManager";
import fanpaiXiaoXiaoMng from "../fanpaixiaoxiaole/fanpaiXiaoXiaoMng";
import FlayBirdGameMng from "../flapybirdgame/FlayBirdGameMng";
import LianLianKanGameMng from "../lianliankan/LianLianKanGameMng";
import MishiTaoTouMng from "../mishitaotou/MishiTaoTouMng";
import GSXC_Game_Mng from "../Mng/GSXC_Game_Mng";
import YYGKCreateMng from "../Mng/YYGKCreateMng";
import PaoPaoLongMng from "../paopaolonggame/paopaolong/PaoPaoLongMng";
import HutuiAppInfoMng from "../PlatForm/HutuiAppInfoMng";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import PlatFormMng from "../PlatForm/PlatFormMng";
import ZhanghaoMng from "../PlatForm/ZhanghaoMng";
import WMap from "../WDT/WMap"; 
import YidongDongwuMng from "../yidongdongwuxiaochu/YidongDongwuMng";
import GlobalGameMng from "../Mng/GlobalGameMng";
import ComFunc from "../comfuncs/ComFunc";
import ComCodeFuncMng from "../Mng/ComCodeFuncMng";
import MyLocalStorge from "../WDT/MyLocalStorge";
import GlobalData from "../huamukuai/GlobalData";
import HMK_GK_Mng from "../huamukuai/HMK_GK_Mng";
import PreLoadResMng from "../comfuncs/PreLoadResMng";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng"; 
import GlobalConfig from "../pingpinggame/GlobalConfig";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class main extends cc.Component {

    @property(cc.Prefab)
    more_wanfa:cc.Prefab = null;
    
    @property(cc.Prefab)
    qiandaoSign:cc.Prefab = null;
   
    @property(cc.Prefab)
    show_get_jiangli:cc.Prefab = null;
    
    
    
    m_last_tuijian_change_tick = 0;
    m_tuijianwe_dest_info_map = new WMap();

    m_prev_game_type = 0;

    m_last_show_bottom_tip_tick = 0;


    m_last_enter_game_btn_click_tick = 0;
    m_game_banner_arr = [];


    m_process_gamebtn_caidan_mode=  1;

    
    m_dating_last_from_subgame_type  = 0;
    m_dating_last_from_subgame_level  = 0;

    onLoad () 
    {
     
        this.m_prev_game_type=  MiddleGamePlatformAction.GetInstance().m_cur_in_subgame_type;
        
        var chuangguangmoshibtn = cc.find("bottoms/chuanguangmoshi",this.node);
        var chuangguangmoshibtn2 = cc.find("bottoms2/chuanguangmoshi",this.node);
        var chuangguangmoshibtn3 = cc.find("bottoms3/chuanguangmoshi",this.node);
         
        chuangguangmoshibtn.on("click",this.OnBtnChuangGuangMoshi.bind(this))
        chuangguangmoshibtn2.on("click",this.OnBtnChuangGuangMoshi.bind(this))
        chuangguangmoshibtn3.on("click",this.OnBtnChuangGuangMoshi.bind(this));
      
        var prebanem1 = "preab/common/show_get_jiangli";
        ComFunc.Set_Preb_Name_Node(prebanem1,this.show_get_jiangli)
        
     //   chuangguangmoshibtn.runAction(cc.repeatForever(cc.sequence(cc.scaleTo(0.5,1.1),cc.scaleTo(0.5,1.05))))
      //  chuangguangmoshibtn2.runAction(cc.repeatForever(cc.sequence(cc.scaleTo(0.5,1.1),cc.scaleTo(0.5,1.05))))
      //  chuangguangmoshibtn3.runAction(cc.repeatForever(cc.sequence(cc.scaleTo(0.5,1.1),cc.scaleTo(0.5,1.05))))
      
      var guaishouxiaoxiao_btn = cc.find("bottoms/guaishouxiaoxiao",this.node);
    

      guaishouxiaoxiao_btn.on("click",this.OnBtn_GuaishouXiaoxiao.bind(this))

 

      var huaduoxiaoxiao_btn = cc.find("bottoms/huaduoxiaoxiao",this.node);
    

      huaduoxiaoxiao_btn.on("click",this.OnBtn_HuaduoXiaoxiao.bind(this))

        var meiritiaozhan_btn = cc.find("bottoms/meiritiaozhan",this.node);
        var meiritiaozhan_btn2 = cc.find("bottoms2/meiritiaozhan",this.node);
        var meiritiaozhan_btn3 = cc.find("bottoms3/meiritiaozhan",this.node); 


        meiritiaozhan_btn.on("click",this.OnBtn_Meiri_ChaoNan.bind(this))
        meiritiaozhan_btn2.on("click",this.OnBtn_Meiri_ChaoNan.bind(this))
        meiritiaozhan_btn3.on("click",this.OnBtn_Meiri_ChaoNan.bind(this))
     
        var guaishouduobi_btn = cc.find("bottoms/guaishouduobi",this.node);
        var guaishouduobi_btn2 = cc.find("bottoms2/guaishouduobi",this.node);
        var guaishouduobi_btn3 = cc.find("bottoms3/guaishouduobi",this.node);


        guaishouduobi_btn.on("click",this.OnBtnFlapyBirdMode.bind(this))
        guaishouduobi_btn2.on("click",this.OnBtnFlapyBirdMode.bind(this))
        guaishouduobi_btn3.on("click",this.OnBtnFlapyBirdMode.bind(this))

 
        var guaishoutiaoyue_btn = cc.find("bottoms/guaishoutiaoyue",this.node);
        var guaishoutiaoyue_btn2 = cc.find("bottoms2/guaishoutiaoyue",this.node);
        var guaishoutiaoyue_btn3 = cc.find("bottoms3/guaishoutiaoyue",this.node);
        
        guaishoutiaoyue_btn.on("click",this.OnBtnFangkuaiTiaoyue.bind(this))
        guaishoutiaoyue_btn2.on("click",this.OnBtnFangkuaiTiaoyue.bind(this))
        guaishoutiaoyue_btn3.on("click",this.OnBtnFangkuaiTiaoyue.bind(this))

      //  var guaishouzhipai_btn = cc.find("bottoms/guaishouzhipai",this.node);
       // guaishouzhipai_btn.on("click",this.OnBtnZhizhuZhipai.bind(this))


        var paopaolonggame_btn = cc.find("bottoms/paopaolonggame",this.node);
        var paopaolonggame_btn2 = cc.find("bottoms2/paopaolonggame",this.node);
        var paopaolonggame_btn3 = cc.find("bottoms3/paopaolonggame",this.node);
        
        paopaolonggame_btn.on("click",this.OnBtnPaopaolong.bind(this))
        paopaolonggame_btn2.on("click",this.OnBtnPaopaolong.bind(this))
        paopaolonggame_btn3.on("click",this.OnBtnPaopaolong.bind(this))

 
       var eluosifangkuai = cc.find("bottoms/eluosifangkuai",this.node);
       var eluosifangkuai2 = cc.find("bottoms2/eluosifangkuai",this.node);
       var eluosifangkuai3 = cc.find("bottoms3/eluosifangkuai",this.node);
       
        eluosifangkuai.on("click",this.OnBtnELuoSiFangkuai.bind(this))
        eluosifangkuai2.on("click",this.OnBtnELuoSiFangkuai.bind(this))
        eluosifangkuai3.on("click",this.OnBtnELuoSiFangkuai.bind(this))


        var fanpaixiaoxiaole = cc.find("bottoms/fanpaixiaoxiaole",this.node);
        var fanpaixiaoxiaole2 = cc.find("bottoms2/fanpaixiaoxiaole",this.node);
        var fanpaixiaoxiaole3 = cc.find("bottoms3/fanpaixiaoxiaole",this.node);
        
        fanpaixiaoxiaole.on("click",this.OnBtnFanpaiXiaoxiaoLe.bind(this))
        fanpaixiaoxiaole2.on("click",this.OnBtnFanpaiXiaoxiaoLe.bind(this))
        fanpaixiaoxiaole3.on("click",this.OnBtnFanpaiXiaoxiaoLe.bind(this))


        var mishitaotou = cc.find("bottoms/mishitaotou",this.node);
        var mishitaotou2 = cc.find("bottoms2/mishitaotou",this.node);
        var mishitaotou3 = cc.find("bottoms3/mishitaotou",this.node);
        
        mishitaotou.on("click",this.OnBtnMishiTaotou.bind(this));
        mishitaotou2.on("click",this.OnBtnMishiTaotou.bind(this));
        mishitaotou3.on("click",this.OnBtnMishiTaotou.bind(this));


        var huamukuai = cc.find("bottoms/huamukuai",this.node);
        var liang_hmk = cc.find("bottoms/liang_hmk",this.node);



        var huamukuai2 = cc.find("bottoms2/huamukuai",this.node);
        var liang_hmk2 = cc.find("bottoms2/liang_hmk",this.node);
  
        var huamukuai3 = cc.find("bottoms3/huamukuai",this.node);


        huamukuai.on("click",this.OnBtnHuaMuKuai.bind(this));
        liang_hmk.on("click",this.OnBtnHuaMuKuai.bind(this));


        liang_hmk2.on("click",this.OnBtnHuaMuKuai.bind(this));
        huamukuai2.on("click",this.OnBtnHuaMuKuai.bind(this));
        huamukuai3.on("click",this.OnBtnHuaMuKuai.bind(this));


        this.m_dating_last_from_subgame_type = GlobalGameMng.GetInstance().m_dating_last_from_subgame_type ;
        this.m_dating_last_from_subgame_level = GlobalGameMng.GetInstance().m_dating_last_from_subgame_level ;

 
        GlobalGameMng.GetInstance().m_dating_last_from_subgame_type  = 0 ;
       GlobalGameMng.GetInstance().m_dating_last_from_subgame_level = 0 ;



       /*
        var hmk_use_liangse = GlobalGameMng.GetInstance().Is_Dating_HMK_Btn_Use_Liangse();

        if(hmk_use_liangse)
        {
            huamukuai.active = false;
            liang_hmk.active = true;

            huamukuai2.active = false;
            liang_hmk2.active = true;


        }
        else{
            huamukuai.active = true;
            liang_hmk.active = false;

            huamukuai2.active = true;
            liang_hmk2.active = false;
        }
        */
 
        
        var gengduowanfa = cc.find("bottoms/gengduowanfa",this.node);
        var gengduowanfa2 = cc.find("bottoms2/gengduowanfa",this.node);
        var gengduowanfa3 = cc.find("bottoms3/gengduowanfa",this.node);
        
    
        
        gengduowanfa.on("click",this.OnBtnGengduoWanfa.bind(this))
        gengduowanfa2.on("click",this.OnBtnGengduoWanfa.bind(this))
        gengduowanfa3.on("click",this.OnBtnGengduoWanfa.bind(this))
       
 

    
        var shuzihuarongdao = cc.find("bottoms/shuzihuarongdao",this.node);
        var shuzihuarongdao2 = cc.find("bottoms2/shuzihuarongdao",this.node);
        var shuzihuarongdao3 = cc.find("bottoms3/shuzihuarongdao",this.node);
        
        shuzihuarongdao.on("click",this.OnBtnShuziHuaRongDao.bind(this));
        shuzihuarongdao2.on("click",this.OnBtnShuziHuaRongDao.bind(this));
        shuzihuarongdao3.on("click",this.OnBtnShuziHuaRongDao.bind(this));
  
        var yidongdongwu = cc.find("bottoms/yidongdongwu",this.node);
        var yidongdongwu2 = cc.find("bottoms2/yidongdongwu",this.node);
        var yidongdongwu3 = cc.find("bottoms3/yidongdongwu",this.node);
        
        yidongdongwu.on("click",this.OnBtnYidongGuaishouXiaochu.bind(this));
        yidongdongwu2.on("click",this.OnBtnYidongGuaishouXiaochu.bind(this));
        yidongdongwu3.on("click",this.OnBtnYidongGuaishouXiaochu.bind(this));
    

 
        var guaishoulainliankan = cc.find("bottoms/guaishoulainliankan",this.node);
        var guaishoulainliankan2 = cc.find("bottoms2/guaishoulainliankan",this.node);
        var guaishoulainliankan3 = cc.find("bottoms3/guaishoulainliankan",this.node);
        
        guaishoulainliankan.on("click",this.OnBtnLainLianKan.bind(this));
        guaishoulainliankan2.on("click",this.OnBtnLainLianKan.bind(this));
        guaishoulainliankan3.on("click",this.OnBtnLainLianKan.bind(this));


        var fenxiang = cc.find("menu/fenxiang",this.node);
        fenxiang.on("click",this.OnBtnFenxiang.bind(this));



        var qiandao = cc.find("menu/qiandao",this.node);
        qiandao.on("click",this.OnBtnQiandao.bind(this))


 
      //  fenxiang.active = PlatFormMng.GetInstance().IS_Fenxiang_Btn_Show();
        
    

        var tili_goumai_btn = cc.find("topmenu/tili/jia",this.node);
        tili_goumai_btn.on("click",this.OnBtnGoumaiTili.bind(this));
    
       

 
        var paihang = cc.find("menu/paihang",this.node);
        paihang.on("click",this.OnBtnPaihangbang.bind(this));


        var all_paihangbang_hide = GlobalGameMng.GetInstance().IS_All_Paihangbang_Hide();

        if(all_paihangbang_hide)
        {
            paihang.active = false;
        }
    
        var tuijianyouxi_btn = cc.find("menu/tuijianyouxi",this.node);
        tuijianyouxi_btn.on("click",this.OnBtnShowDatingQaunpingGeziGuanggao.bind(this));
        if(!MiddleGamePlatformAction.GetInstance().IS_Show_Zidingyi_MoreGame())
        {
            tuijianyouxi_btn.active = false;
        }




       var bk_From_Game_pop_gd_yx =  this.Check_Back_From_Game_Pop_Gengduo_Youxi();

        var banner_arr = [];
    
        var ishow_bottom_banner_type =  GlobalGameMng.GetInstance().Get_Dating_Next_Need_Show_Banner_Type();
        var node_left = cc.find("node_top/left",this.node)
          

        if(ishow_bottom_banner_type == 1)
        {
            banner_arr = [103];
            node_left.active = false;

          

        }else{
            banner_arr = [101,102];
        }


      
        this.m_game_banner_arr = banner_arr;

  
        MiddleGamePlatformAction.GetInstance().Set_In_Subgame_Valid_Gezi_Guangao_Bannerindex_Arr_Info(false,0,banner_arr);
  
    
      SoundManager.GetInstance().Play_Music("lianliankan/music_bg");
      
        HutuiAppInfoMng.GetInstance().LoadRemoteConfig(()=>{});
        GlobalGameMng.GetInstance().Load_Game_Common_Config(()=>{});

        GSXC_Game_Mng.GetInstance().Post_Read_Server_Config();

        var ibanner_mng_time = GlobalGameMng.GetInstance().Get_Game_Banner_Mng_Time_Config(0);
        this.schedule(this.FD_Banner_Mng_Timer.bind(this),ibanner_mng_time);

        this.schedule(this.FD_Count_Tili.bind(this),0.3);

        this.Refresh_Money();
        this.InitGuanggao();
  
        MiddleGamePlatformAction.GetInstance().Check_First_Enter_Game_Create_Need_Create_Banners();
     
        MiddleGamePlatformAction.GetInstance().Ensure_Create_BK_GameLibao_Banner();



        this.scheduleOnce(this.Check_Show_Pop_Qiandao_And_Gezi.bind(this),0.2);

       // this.scheduleOnce(this.Check_Show_Pop_Qiandao_Dlg.bind(this),0.1);


        ComFunc.Check_Init_Load_All_Preab();
 
 

        this.Dating_Check_Preload_File_Bk_Loaded();
  
       
      
 
        
       // this.Check_Procress_Init_Shouquan();
    
        this.Change_Bottom_Tip_Str();

        
        this.m_process_gamebtn_caidan_mode = GlobalGameMng.GetInstance().Get_Cur_Process_Dating_Show_GameBtn_Caidan_Mode();
        this.Refresh_Caidan_Mode();
      

  
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(2, "进入大厅", 1,
            "大厅界面", 0, "", 0, "");
 

    }

    Dating_Check_Preload_File_Bk_Loaded()
    {
        PreLoadResMng.GetInstance().Dating_Check_Preload_File_Bk_Loaded();
        PreLoadResMng.GetInstance().Dating_Check_Scence_PerLoaded();
    }

    Check_Back_From_Game_Pop_Gengduo_Youxi()
    {
        var config_fanhuidating_auto_pop_gengduoyouxi = GlobalGameMng.GetInstance().IS_FanhuiDating_Auto_Pop_GengduoYouxi_Dlg();

        if(!config_fanhuidating_auto_pop_gengduoyouxi)
        {
            return false;

        }

       var gamelist =  GlobalGameMng.GetInstance().Get_Dating_Caidan_Mode_Back_From_Game_Need_Pop_GengduoYouxi_Gametype_List(this.m_process_gamebtn_caidan_mode);


       if(ComFunc.arrayShuzuContain(gamelist,this.m_prev_game_type) && this.m_prev_game_type > 0)
       {
            this.OnBtnGengduoWanfa();
            return true;
       }

       return false;


    }
    Refresh_Caidan_Mode()
    {
        var bottoms_3 = cc.find("bottoms3",this.node);
        var bottoms_2 = cc.find("bottoms2",this.node);
        var bottoms = cc.find("bottoms",this.node);
       
        

        if(this.m_process_gamebtn_caidan_mode == 2)
        {
            bottoms.active = false;
            bottoms_2.active = true;
            bottoms_3.active = false;
          
        }
        else if(this.m_process_gamebtn_caidan_mode == 3)
        {
            bottoms.active = false;
            bottoms_2.active = false;
            bottoms_3.active = true;
            
        } 
        else
        {
            bottoms.active = true;
            bottoms_2.active = false;
            bottoms_3.active = false;

        }
    }

    IS_First_Dating_Enter()
    {
        var strshaonaomukuai_first_enter_dating = "guaishoudaxiaochu_first_enter_dating";
        var strsave = MyLocalStorge.getItem(strshaonaomukuai_first_enter_dating);

        if(strsave && strsave == "1")
        {
            return false;
        }

        MyLocalStorge.setItem(strshaonaomukuai_first_enter_dating,"1");

        return true;
    }
    Check_Show_Pop_Qiandao_And_Gezi()
    {
        var bhas = this.Check_Show_Pop_Qiandao_Dlg();
        if(bhas)
        {
            return;
        }

        

       
        BannerGuangaoMng.GetInstance().Check_Show_Quanping_Chaiping_Gezi(1,this.m_dating_last_from_subgame_type ,this.m_dating_last_from_subgame_level);

    }
    Check_Show_Pop_Qiandao_Dlg()
    {
 
        if(this.IS_First_Dating_Enter())
        {
            if(GlobalGameMng.GetInstance().IS_First_Enter_Dating_Hide_Qiandao())
            {
                return false;
            }
        }

       
        //接下来判断需要不需要再弹出来签到弹框

        var sign_unlinged = ComFunc.Check_Sign_Has_UnLingqued();
        if(!sign_unlinged)
        {
            return false;
        }


        var dlg_tanchu_type = GlobalGameMng.GetInstance().Get_Qiandao_Dlg_Tachu_Type();
        var itanchu_per_gk = GlobalGameMng.GetInstance().Get_Qiandao_Dlg_Tachu_Per_GK();


        if(!GlobalGameMng.GetInstance().m_b_first_sign_dlg_poped  )
        {

        }else{
            if(dlg_tanchu_type == 0)
            {
                var poped = GlobalGameMng.GetInstance().m_b_first_sign_dlg_poped ;
                if(poped)
                {
                    return false;
                }
            }
            else if(dlg_tanchu_type == 1)
            {
    
            }else if(dlg_tanchu_type == 2)
            {
                this.Add_Qiandao_dlg_tanchu_Jiange_GK();
    
                //间隔几个关卡
                var qd_jiange_gk_info = this.GetLast_Qiandao_dlg_tanchu_Jiange_GK();
                var ijaingegk = qd_jiange_gk_info[1];
    
    
                if(ijaingegk <= itanchu_per_gk)
                {
                    return false;
                }
    
                var last_v = "guaishoudaxiaochu_qiandao_tanchu_dlg_jiange_gk";
                MyLocalStorge.removeItem(last_v);
            }
    
        }


       
       
        GlobalGameMng.GetInstance().m_b_first_sign_dlg_poped = true;
        this.OnBtnQiandao();

        return true;
    }
    GetLast_Qiandao_dlg_tanchu_Jiange_GK()
    {
        var last_v = "guaishoudaxiaochu_qiandao_tanchu_dlg_jiange_gk";

        var prevstr = MyLocalStorge.getItem(last_v,"");

        if(!prevstr)
        {
            return [0,0];
        }


        var pobj = JSON.parse(prevstr);
        if(!pobj)
        {
            return [0,0];
        }

        var ijiangegk = pobj.ijiangegk;
        if(!ijiangegk)
        {
            ijiangegk = 0;
        }
        return [1,ijiangegk];
    }
    Add_Qiandao_dlg_tanchu_Jiange_GK()
    {
        var pinfo = this.GetLast_Qiandao_dlg_tanchu_Jiange_GK();
        var prevgk = pinfo[1];
        var newgk = prevgk+1;

        var obj = {
            ijiangegk:newgk
        }


        var last_v = "guaishoudaxiaochu_qiandao_tanchu_dlg_jiange_gk";

        var str = JSON.stringify(obj);
        MyLocalStorge.setItem(last_v,str);
    }
    Change_Bottom_Tip_Str()
    {
        this.m_last_show_bottom_tip_tick = Date.now();
        var tili_info_label = cc.find("tips/tili_info",this.node);
         tili_info_label.getComponent(cc.Label).string =  GlobalGameMng.GetInstance().Get_Dating_Bottom_Tip_Info_Str();


    }
    OnBtnGoumaiTili()
    {
        var self = this;
        ComCodeFuncMng.Show_Goumai_Tili_Dlg(2,this.node,(bsuc)=>
        { 
            self.Refresh_Money();
        });

    }
    FD_Count_Tili()
    {
        GlobalGameMng.GetInstance().Count_Down_Add_Tili(); 

        this.Refresh_Money();



        if(Date.now() - this.m_last_show_bottom_tip_tick > 10*1000)
        {
            GlobalGameMng.GetInstance().Increase_Dating_Tip_Index();
            this.Change_Bottom_Tip_Str();
        }

    }
    Check_Procress_Init_Shouquan()
    {
        /*
        if(!GlobalGameMng.GetInstance().m_process_dating_shouquan_reuired
               &&  GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(4) > 0
               
               && !ZhanghaoMng.GetInstance().IS_User_Info_Inited()
               )
        {
            GlobalGameMng.GetInstance().m_process_dating_shouquan_reuired = 1;

            ZhanghaoMng.GetInstance().Init_Get_User_Info();
        }
        */
    }

    Refresh_Money()
    {
        var jinbi_c_label = cc.find("topmenu/jinbi/c",this.node);

        var imoney = GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(1);
        jinbi_c_label.getComponent(cc.Label).string = ""+imoney;


        var xunzhang_c_label = cc.find("topmenu/xunzhang/c",this.node);

        var uxunzhang = GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(4);
        xunzhang_c_label.getComponent(cc.Label).string = ""+uxunzhang;


        var xingxing_c_label = cc.find("topmenu/xingxing/c",this.node);

        var ixx = GlobalConfig.GetIns().Get_Self_DestType_Daoju_Count(22);
        xingxing_c_label.getComponent(cc.Label).string = ""+ixx;

        
             

        var enter_cishu_nei_bukou_tili = GlobalGameMng.GetInstance().Get_Per_Game_First_Enter_Cishu_Nei_Bukou_Tili();

        var tili_info_label = cc.find("tips/tili_info",this.node);
      //  tili_info_label.getComponent(cc.Label).string = "每个玩法最开始"+enter_cishu_nei_bukou_tili+"次开始游戏不扣体力";
        
        var tili_node = cc.find("topmenu/tili",this.node);
    
        var tili_c_label = cc.find("topmenu/tili/c",this.node);
        var itili = GlobalGameMng.GetInstance().Get_Tili();
        var imaxtili = GlobalGameMng.GetInstance().Get_Max_Tili();
        tili_c_label.getComponent(cc.Label).string = ""+itili+"/"+imaxtili;

        var is_tili_hide = GlobalGameMng.GetInstance().IS_All_Tili_Hide();

        if(is_tili_hide)
        {
            tili_info_label.active = false;
            tili_node.active = false;
        }
        else{
            tili_info_label.active = true;
            tili_node.active = true;
        }


        var tili_lefttime_label = cc.find("topmenu/tili/lefttime",this.node);
        var tili_countdown_start_Left_count =  GlobalGameMng.GetInstance().m_tili_countdown_start_Left_count;

        var ieplsetick = Date.now() - GlobalGameMng.GetInstance().m_tili_countdown_start_tick;
        var isec=  Math.floor(ieplsetick/1000);

        var left_sec = Math.floor(tili_countdown_start_Left_count - isec) ;

        if(left_sec <= 0)
        {
            left_sec = 0;
        }

        
        if(tili_countdown_start_Left_count > 0)
        {
            tili_lefttime_label.active = true;
            tili_lefttime_label.getComponent(cc.Label).string = ""+ComFunc.FormatLeftSecStr(left_sec);
        }else{
            tili_lefttime_label.active = false;

        }
      
    }

    OnSelectPaihangbangType(iseltype)
    {
        if(iseltype == 0)
        {
            return;
        }
           
        var self = this;
    
        ComFunc.OpenNewDialog(this.node,"preab/dlg/paihangbang","paihangbang", 
         { 
            iseltype:iseltype,
            cb:(chooseother)=>
            {

                if(chooseother > 0)
                {
                    self.OnBtnPaihangbang();
                }
                 
            
            }});
 
    }
    OnBtnPaihangbang()
    {
      //  ZhanghaoMng.GetInstance().Check_Init_Read_User_Info();



        
        var self = this;
    
        ComFunc.OpenNewDialog(this.node,"preab/dlg/select_paihang_type","select_paihang_type", 
         { 
            cb:(iseltype)=>
            {

                self.OnSelectPaihangbangType(iseltype);
                
            }});


       // this.Init_Get_User_Info();
    }
    OnBtnShowDatingQaunpingGeziGuanggao()
    {
        MiddleGamePlatformAction.GetInstance().Show_InGame_MoreGame_Quanping_Gezi();

        
       

    }

    Update_Tuijian_Icon(ituijianwei)
    {
        var last_tuiijian_app_info =  HutuiAppInfoMng.GetInstance().Get_InnerGame_Show_App_Icon_Info(ituijianwei);
 
        if(!last_tuiijian_app_info)
        {
            return;
        }

        var name_node = cc.find("node_top/left/othergame/game"+ituijianwei+"/name",this.node);
        name_node.getComponent(cc.Label).string = ""+last_tuiijian_app_info.toName;
        
        

        var icon_node = cc.find("node_top/left/othergame/game"+ituijianwei+"/icon",this.node);
   
        var simgurl = last_tuiijian_app_info.icon;

        var texture = HutuiAppInfoMng.GetInstance().GetFilePathTexture(simgurl);

        var size_w = HutuiAppInfoMng.GetInstance().Get_Hutui_Gezi_Size();
       
        if(texture)
        {
            var psrite = icon_node.getComponent(cc.Sprite);

            psrite.spriteFrame = new cc.SpriteFrame(texture);

            icon_node.width = size_w.cx;
            icon_node.height = size_w.cy;
           // iconnode.getComponent(cc.Sprite)
        }else
        {
            BaseUIUtils.ShowIconNodePicFilename(icon_node,"resources/game/124",{cx:size_w.cx,cy:size_w.cy});
        }

        this.m_tuijianwe_dest_info_map.putData(ituijianwei,last_tuiijian_app_info);
    }
    Check_Update_Tuijian_Icon_Info()
    {
        if(this.m_last_tuijian_change_tick == 0)
        {
            this.m_last_tuijian_change_tick = Date.now();

            this.Update_Tuijian_Icon(3);
            this.Update_Tuijian_Icon(4);
        
        }
        else{

            if(Date.now() - this.m_last_tuijian_change_tick > HutuiAppInfoMng.GetInstance().Get_Hutui_Update_Tick())
            {
                this.m_last_tuijian_change_tick = Date.now();

                this.Update_Tuijian_Icon(3);
                this.Update_Tuijian_Icon(4);
            }
          
        }
    }

    OnBtnTiaozhuanTuijian(ituijianwei)
    {
        if(!this.m_tuijianwe_dest_info_map.hasKey(ituijianwei))
        {
            return null;
        }

        var tuijian_info = this.m_tuijianwe_dest_info_map.getData(ituijianwei);

        console.log("OnBtnTiaozhuanTuijian ituijianwei="+ituijianwei+",tuijian_info="+tuijian_info);

        if(!tuijian_info)
        {
            var defaultappid = HutuiAppInfoMng.GetInstance().Get_Default_Tuiguan_Appid(ituijianwei);
            PlatFormMng.GetInstance().Tiaozhuan_Tuijian_AppID(defaultappid);

            /*
            if(ituijianwei == 2)
            {
                PlatFormMng.GetInstance().Tiaozhuan_Tuijian_AppID("wx553ebd44ec20a9af");
            }else{
                PlatFormMng.GetInstance().Tiaozhuan_Tuijian_AppID("wx61653cb69e41c1dc");
            }
            */
            
        }else{
            PlatFormMng.GetInstance().Jump_To_App_Game_By_Data(tuijian_info);
        }

    }
    Init_Top_Tuijian_Guangao()
    { 
        var tuijaing_game1_node = cc.find("node_top/left/othergame/game3",this.node);
        var tuijaing_game2_node = cc.find("node_top/left/othergame/game4",this.node);

        var left_node = cc.find("node_top/left",this.node);

        
        if(!MiddleGamePlatformAction.GetInstance().IS_Show_Zidingyi_TuijianWei())
        {
            tuijaing_game1_node.active = false;
            tuijaing_game2_node.active = false;
            left_node.active = false;
            return;
        }
    
        tuijaing_game1_node.on("click",this.OnBtnTiaozhuanTuijian.bind(this,3))

        var self = this;


        tuijaing_game1_node.runAction(cc.repeatForever(

            cc.sequence(cc.rotateTo(0.1,7),cc.rotateTo(0.2,-7),cc.rotateTo(0.1,0),cc.rotateTo(0.2,-7),cc.rotateTo(0.1,0),
            
               
            cc.callFunc(()=>
            {
 
            }),
            cc.delayTime(3))

        ));

         tuijaing_game2_node.on("click",this.OnBtnTiaozhuanTuijian.bind(this,4))

        tuijaing_game2_node.runAction(cc.repeatForever(

            cc.sequence(cc.rotateTo(0.1,7),cc.rotateTo(0.2,-7),cc.rotateTo(0.1,0),cc.rotateTo(0.2,-7),cc.rotateTo(0.1,0),
            
               
            cc.callFunc(()=>
            {

                self.Check_Update_Tuijian_Icon_Info();
            }),
            cc.delayTime(3))

        ));


        this.Check_Update_Tuijian_Icon_Info();



    }
    InitGuanggao()
    {
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(1,false);
    
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(11,false);

        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(12,false);
        
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(13,false);
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(14,false);
        
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(15,false);
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(17,false);
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(19,false);
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(20,false);

        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(31,false);
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(32,false);
        
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(41,false);
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(42,false);

        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(44,false);
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(45,false);
 

        //俄罗斯方块下方banner
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(51,false);
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(52,false);

        MiddleGamePlatformAction.GetInstance().Set_Pause_Dlg_Gezi_Sgow(false);

        

        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(56,false);
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(57,false);

        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(66,false);
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(67,false);
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(68,false);
  
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(71,false);
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(72,false);
      MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(73,false);
  
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(76,false);
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(77,false);
  
  
  
  
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(81,false);
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(82,false);
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(83,false);

        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(87,false);

        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(88,false);
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(89,false);



        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(91,false);

        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(121,false);

        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(161,false);

        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(162,false);



        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(112,false);

        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(113,false);


        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(163,false);
        MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(115,false);



        this.Init_Top_Tuijian_Guangao();
      
        this.Check_Show_Gezi_Guanggao();
    }

    Check_Show_Gezi_Guanggao()
    {

        // /大厅两个格子序号:101,102
       // MiddleGamePlatformAction.GetInstance().Check_Create_Common_Banner(101,2);
      //  MiddleGamePlatformAction.GetInstance().Check_Create_Common_Banner(102,2);
      //  MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(101,true);
      //  MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(102,true);


        var banerid_map = new WMap();
        banerid_map.putData(101,2);
        banerid_map.putData(102,2); 
        banerid_map.putData(103,1); 
        

        for(var ff=0;ff<this.m_game_banner_arr.length;ff++)
        {
            var ff_bannerid = this.m_game_banner_arr[ff];
 
            if(!banerid_map.hasKey(ff_bannerid))
            {

                continue;
            }

            var ibanenrtype = banerid_map.getData(ff_bannerid);


            MiddleGamePlatformAction.GetInstance().Check_Create_Show_Game_Banner_A(ff_bannerid,ibanenrtype);
     

           // MiddleGamePlatformAction.GetInstance().Check_Create_Common_Banner(ff_bannerid,ibanenrtype);
           // MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(ff_bannerid,1);
           // MiddleGamePlatformAction.GetInstance().On_Orignal_Chnage_Banner_Show(ff_bannerid,1)
        }
     
 
       
        this.FD_Banner_Mng_Timer();
    }

    Hide_Dating_Gezi_Show()
    {
        MiddleGamePlatformAction.GetInstance().Hide_Dating_Gezi_Show();
      

    }


    FD_Banner_Mng_Timer()
    { 
        MiddleGamePlatformAction.GetInstance().FD_Banner_Mng_Timer(this.node);

    }

    OnBtnFenxiang()
    {

        PlatFormMng.GetInstance().Dating_Fenxiang();


        ClientLogUtils.GetInstance().Poset_Server_JS_Log(11, "大厅分享点击", 1,
        "", 0, "", 0, "");

    }


    OnBtnQiandao()
    {
        var pndoe = cc.instantiate(this.qiandaoSign);
        var qiandaoSign = pndoe.getComponent("qiandaoSign");
        qiandaoSign.SetInitData(null);
        this.node.addChild(pndoe,100);

    }
    OnBtnGengduoWanfa()
    {
        var pndoe = cc.instantiate(this.more_wanfa);
        var more_wanfa = pndoe.getComponent("more_wanfa");
        more_wanfa.SetDating_Show_Mode(this.m_process_gamebtn_caidan_mode);
        this.node.addChild(pndoe,120);


        
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(12, "大厅更多玩法弹框打开", 1,
        "", 0, "", 0, "");
    }
    OnBtnXiaoMieXingxing()
    {
        if(!this.Check_Enter_Game_Btn_Enough_Tick())
        {
            return;
        }
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(4))
        {
            return;
        }

        this.Hide_Dating_Gezi_Show();
        ComFunc.RealLoadScence("xiaomiexingxing",0,0);
    }

    OnBtnELuoSiFangkuai()
    {
        if(!this.Check_Enter_Game_Btn_Enough_Tick())
        {
            return;
        }
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(8))
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();
        fanpaiXiaoXiaoMng.GetInstance().InitFromDating();
        ComFunc.RealLoadScence("RussinFangkuai",0,0);
    }
    OnBtnLainLianKan()
    {
        if(!this.Check_Enter_Game_Btn_Enough_Tick())
        {
            return;
        }
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(5))
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();

        LianLianKanGameMng.GetInstance().InitFromDating();
        ComFunc.RealLoadScence("lianliankangame",0,0);
    }
    OnBtnPaopaolong()
    {
        if(!this.Check_Enter_Game_Btn_Enough_Tick())
        {
            return;
        }
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(2))
        {
            return;
        }


        var last_gk = PaoPaoLongMng.GetInstance().Get_Max_Can_Enter_GK();

        if(!last_gk || isNaN(last_gk))
        {
            last_gk = 1;
        }
        this.Hide_Dating_Gezi_Show();
        PaoPaoLongMng.GetInstance().LoadLevelConfig(last_gk,(error,pobj)=>
        {
            if(error)
            {
                console.log("关卡配置错误");
                return;
            }
 
            if(!pobj)
            {
                console.log("关卡配置错误");
                return;
            }



            PaoPaoLongMng.GetInstance().m_last_enter_level = last_gk;
            PaoPaoLongMng.GetInstance().m_enter_level = last_gk;
            PaoPaoLongMng.GetInstance().m_enter_level_config = pobj;
 
            ComFunc.RealLoadScence("pplgame",0,0);
          
        });
 
    }
     
    OnBtn_Meiri_ChaoNan()
    {
        if(!this.Check_Enter_Game_Btn_Enough_Tick())
        {
            return;
        }
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(9))
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();

        GSXC_Game_Mng.GetInstance().m_enter_xiaochu_chaonan_moshi = true;
        GSXC_Game_Mng.GetInstance().selectedLevel  = 0;
        ComFunc.RealLoadScence("game",0,0);
    }
    
    Check_Has_Tili_Enter_Subgame_And_Kouchu(isbugametype)
    {


        var bsuc = ComCodeFuncMng.Check_Has_Tili_Enter_Subgame_And_Kouchu(isbugametype,this.node);
        this.Refresh_Money();

        return bsuc;
    }
    OnBtnShuziHuaRongDao()
    {
        ComFunc.OpenNewDialog(this.node,"preab/shuzihuarogndao/shuzihuarongdao_sel_mode","shuzihuarongdao_sel_mode",{
            parentgame:this

        });
    }


    Check_Enter_Game_Btn_Enough_Tick()
    {
        if(this.m_last_enter_game_btn_click_tick > 0)
        {
            if(Date.now() - this.m_last_enter_game_btn_click_tick < 1000)
            {
                return false;
            }
        }
        this.m_last_enter_game_btn_click_tick = Date.now();
        return true;
    }


    OnBtnChuangGuangMoshi()
    {

        if(!this.Check_Enter_Game_Btn_Enough_Tick())
        {
            return;
        }
        

        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(1))
        {
            return;
        }

        this.Hide_Dating_Gezi_Show();

        GSXC_Game_Mng.GetInstance().m_enter_xiaochu_chaonan_moshi = false;
        GSXC_Game_Mng.GetInstance().selectedLevel  = GSXC_Game_Mng.GetInstance().Get_Max_Can_Enter_GK();
        ComFunc.RealLoadScence("game",0,0);
    }

    OnBtn_GuaishouXiaoxiao()
    {
        if(!this.Check_Enter_Game_Btn_Enough_Tick())
        {
            return;
        }
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(6))
        {
            return;
        }
        this.Hide_Dating_Gezi_Show(); 
        GlobalConfig.GetIns().Set_Show_WupingType(2);
        GlobalConfig.GetIns().Enter_Game_Mode(4);
        ComFunc.RealLoadScence("huaduo_xiaoxiao",0,0);
    }
    OnBtn_HuaduoXiaoxiao()
    {
        if(!this.Check_Enter_Game_Btn_Enough_Tick())
        {
            return;
        }
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(6))
        {
            return;
        }
        this.Hide_Dating_Gezi_Show(); 
        GlobalConfig.GetIns().Set_Show_WupingType(2);
        GlobalConfig.GetIns().Enter_Game_Mode(2);
        ComFunc.RealLoadScence("huaduo_xiaoxiao" );
    }
    OnBtnFlapyBirdMode()
    {
        if(!this.Check_Enter_Game_Btn_Enough_Tick())
        {
            return;
        }
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(6))
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();
        FlayBirdGameMng.GetInstance().SetFromGameStart(false);
        ComFunc.RealLoadScence("flapybirdgame",0,0);
  
    }

    OnBtnFangkuaiTiaoyue()
    {
        if(!this.Check_Enter_Game_Btn_Enough_Tick())
        {
            return;
        }
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(7))
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();
        ComFunc.RealLoadScence("tiaodongfangkuai",0,0);
  
    }


    Real_Start_Goto_Game(isubgametype,igk)
    {

        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(isubgametype))
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();

        
        
         
        if(isubgametype  > 100 && isubgametype < 120)
        {

          //  var imode = isubgametype - 100;
           // shuziHuaRongDaoLogicMng.GetInstance().m_select_shuzihuarongdao_mode_type =  imode;
           // shuziHuaRongDaoLogicMng.GetInstance().m_select_shuzihuarongdao_gk =    igk;
    
           // cc.director.loadScene("shuzihuarongdao");

        }  
        else if(isubgametype  > 130 && isubgametype < 140)
        {

            GlobalData.GetInstance().m_select_enter_hmk_nandu = isubgametype - 130;
            GlobalData.GetInstance().m_select_enter_hmk_gk = igk;
          //  cc.director.loadScene("huamukuai");

            var scename  = "huamukuai";
    
            ComFunc.RealLoadScence(scename,0,0);
        }
    }

    OnBtn_Select_Subgame_Nandu(igametype)
    {


        var self = this;
        ComFunc.OpenNewDialog(this.node,"preab/common/com_sel_nandu","com_sel_nandu", { parentgame:this, 
            isubgametype:igametype ,
            cb:(inandu)=>
        {
           
            self.On_Select_Subgame_Nandu(igametype,inandu);
            //self.GoToLevel(isubgametype,lv);

        }});
          
        
    }
    On_Select_Subgame_Nandu(igametype,inandu)
    {
        var irealsubgametype = igametype;

        if(igametype == 1)
        {
            irealsubgametype = HMK_GK_Mng.GetInstance().Get_Mode_GameType(inandu);
        }


        var igk = GlobalData.GetInstance().Get_SubGametype_Max_Can_Enter_GK(irealsubgametype);
   
   
        this.Real_Start_Goto_Game(irealsubgametype,igk);
    }
    OnBtnHuaMuKuai()
    {
       
        var igk = GlobalData.GetInstance().Get_SubGametype_Max_Can_Enter_GK(131);
       if(igk >= 3)
        {
            //第三关后，点击开始选关

         //   this.OnBtn_Select_SubgAme_GK(1);

            //首先，选择难度
 
            this.OnBtn_Select_Subgame_Nandu(1);

            return;
        }
       
        this.Real_Start_Goto_Game(131,igk);
      
    }


    OnBtnMishiTaotou()
    {
        if(!this.Check_Enter_Game_Btn_Enough_Tick())
        {
            return;
        }
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(3))
        {
            return;
        }

        this.Hide_Dating_Gezi_Show();
        MishiTaoTouMng.GetInstance().SetFromDatingEnetr(true);
        ComFunc.RealLoadScence("mishitaotougame",0,0);
    }

    OnBtnYidongGuaishouXiaochu()
    {
        if(!this.Check_Enter_Game_Btn_Enough_Tick())
        {
            return;
        }
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(10))
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();

        YidongDongwuMng.GetInstance().InitFromDating();
        ComFunc.RealLoadScence("yidongguaishouxiaochu",0,0);
  
    }


    OnBtnFanpaiXiaoxiaoLe()
    {
        if(!this.Check_Enter_Game_Btn_Enough_Tick())
        {
            return;
        }
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(11))
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();

        fanpaiXiaoXiaoMng.GetInstance().InitFromDating();
        ComFunc.RealLoadScence("fanpaixiaoxiaole",0,0);
    }
}
