import BaseUIUtils from "../comfuncs/BaseUIUtils";
import BundleLoadUtils from "../comfuncs/BundleLoadUtils";
import SoundManager from "../comfuncs/SoundManager";
import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import GlobalGameMng from "../Mng/GlobalGameMng";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class choujiang_reward_dlg extends cc.Component 
{
 
    
 
    m_cb = null;

    m_kaijianginfo  =null;
    
    onLoad () 
    {


        var putonglq = cc.find("panel/putonglq",this.node);
        var shuangbei = cc.find("panel/shuangbei",this.node);
     
        putonglq.on("click",this.OnBtnPutongLingqu.bind(this));
        shuangbei.on("click",this.OnBtnShaungbei.bind(this));

        SoundManager.GetInstance().Play_Effect("com/btn");

    }
    OnBtnShaungbei()
    {
       
        var self = this; 
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node,
            ()=>
            {
            
            },
            
            "抽奖双倍领取",(bsuc)=>
        {
            if(!bsuc)
            {
            
                return;
            }


            self.RealLingqu(2);
 
        });
 

    }
    OnBtnPutongLingqu()
    {

        this.RealLingqu(1);
    }
    RealLingqu(ibeishhu)
    {
        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb(ibeishhu);
        }
    }
    SetInitData(paradata)
    {
        this.m_cb = paradata.cb;
      
        this.m_kaijianginfo = paradata.kaijianginfo;
        var com_wuping = cc.find("panel/com_wuping",this.node);
        var libao1 = cc.find("panel/libao1",this.node);
        var libao2 = cc.find("panel/libao2",this.node);


        if(this.m_kaijianginfo.type == 2)
        {
            libao1.active = true;
            libao2.active = false;
            com_wuping.active = false;
        }
        else if(this.m_kaijianginfo.type == 3)
        {
            libao1.active = false;
            libao2.active = true;
            com_wuping.active = false;
        }else{
            libao1.active = false;
            libao2.active = false;
            com_wuping.active = true;

            var ff_sub_type = this.m_kaijianginfo.sub_type;
            var ff_c = this.m_kaijianginfo.c;
        
            var ff_siconname = GlobalGameMng.GetInstance().Get_Aawrd_Daoju_Icon(ff_sub_type);

            var c_node = com_wuping.getChildByName("c");
            var icon_node = com_wuping.getChildByName("icon");
          
            
            c_node.getComponent(cc.Label).string = "x"+ff_c;

            BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("resources",icon_node,ff_siconname,{width:150,height:150})

        }
     
        
        /*
        var shuangbei = cc.find("panel/shuangbei",this.node);
     
        if(this.m_byingdao)
        {
            shuangbei.active = false;
        }else{
            shuangbei.active = true;
        }

        this.m_find_kaijiang_info = paradata.kaijianginfo;

        var itype = this.m_find_kaijiang_info.type;
        var c = this.m_find_kaijiang_info.c;
        var sname = this.m_find_kaijiang_info.sname;


        var count_label = cc.find("panel/count",this.node);
        count_label.getComponent(cc.Label).string = "x "+c;

        var kapaiinfo = cc.find("panel/kapaiinfo",this.node);
        var wupinginfo = cc.find("panel/wupinginfo",this.node);  

           
        if(itype  > 100)
        {
            kapaiinfo.active = true;
            wupinginfo.active = false;

 
            var icon = cc.find("icon",kapaiinfo);
         

            var sicon = "game/newkaipai/jc_"+(itype-100);
            BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("resources",icon,sicon,{width:200,height:200})
            

        }
        else{
            kapaiinfo.active = false;
            wupinginfo.active = true;

            var wp_info = this.m_find_kaijiang_info.wp;

            
            var zs1 = wupinginfo.getChildByName("zs1");
            var zs2 = wupinginfo.getChildByName("zs2");

            var jb1 = wupinginfo.getChildByName("jb1");
            var jb2 = wupinginfo.getChildByName("jb2");
            var jb3 = wupinginfo.getChildByName("jb3");

            zs1.active = false;
            zs2.active = false;
            jb1.active = false;
            jb2.active = false;
            jb3.active = false;

            var wp_ndoe = wupinginfo.getChildByName(wp_info);
            if(wp_ndoe)
            {
                wp_ndoe.active = true;
            }
             
        }

        */



    }

   
    
}
