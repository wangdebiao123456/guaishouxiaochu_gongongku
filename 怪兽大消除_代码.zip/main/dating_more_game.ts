import BaseUIUtils from "../comfuncs/BaseUIUtils";
import ComFunc from "../comfuncs/ComFunc";
import SoundManager from "../comfuncs/SoundManager";
import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import DianjiGuaishouMng from "../dianjiguaishou/DianjiGuaishouMng";
import fanpaiXiaoXiaoMng from "../fanpaixiaoxiaole/fanpaiXiaoXiaoMng";
import FlayBirdGameMng from "../flapybirdgame/FlayBirdGameMng";
import GlobalData from "../huamukuai/GlobalData";
import HMK_GK_Mng from "../huamukuai/HMK_GK_Mng";
import LianLianKanGameMng from "../lianliankan/LianLianKanGameMng";
import MishiTaoTouMng from "../mishitaotou/MishiTaoTouMng";
import GlobalGameMng from "../Mng/GlobalGameMng";
import GSXC_Game_Mng from "../Mng/GSXC_Game_Mng";
import TiaozhanChang_Mng from "../Mng/TiaozhanChang_Mng";
import PaoPaoLongMng from "../paopaolonggame/paopaolong/PaoPaoLongMng";
import GlobalConfig from "../pingpinggame/GlobalConfig";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import MyLocalStorge from "../WDT/MyLocalStorge";
import XiaoMieXingxingMng from "../xiaomiexingxing/XiaoMieXingxingMng";
import YidongDongwuMng from "../yidongdongwuxiaochu/YidongDongwuMng";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class dating_more_game extends cc.Component 
{
    m_last_btn_click_tick = 0;
    m_callback = null;
    
    m_all_wanfa_list = [];


    onLoad () 
    {



        var extbtn = cc.find("panel/extbtn",this.node)
        extbtn.on("click",this.OnBtnExit.bind(this))
 
      

        var chuanguangmoshi = cc.find("panel/bottoms/chuanguangmoshi",this.node);

      //  chuanguangmoshi.on("click",this.OnBtnChuangGuangMoshi.bind(this))
  
        var meiritiaozhan_btn = cc.find("panel/bottoms/meiritiaozhan",this.node); 
        //meiritiaozhan_btn.on("click",this.OnBtn_Meiri_ChaoNan.bind(this))
       

        var guaishoulainliankan = cc.find("panel/bottoms/guaishoulainliankan",this.node);
       
        guaishoulainliankan.on("click",this.OnBtnLainLianKan.bind(this));
    

        var paopaolonggame = cc.find("panel/bottoms/paopaolonggame",this.node);
       
        paopaolonggame.on("click",this.OnBtnPaopaolong.bind(this));
    

        var eluosifangkuai = cc.find("panel/bottoms/eluosifangkuai",this.node);
       
        eluosifangkuai.on("click",this.OnBtnELuoSiFangkuai.bind(this));
    

        
        var guaishouduobi = cc.find("panel/bottoms/guaishouduobi",this.node);
       
        guaishouduobi.on("click",this.OnBtnFlapyBirdMode.bind(this));
    
   
        var fanpaixiaoxiaole = cc.find("panel/bottoms/fanpaixiaoxiaole",this.node);
       
        fanpaixiaoxiaole.on("click",this.OnBtnFanpaiXiaoxiaoLe.bind(this));
    

        var guaishoutiaoyue = cc.find("panel/bottoms/guaishoutiaoyue",this.node);
       
        guaishoutiaoyue.on("click",this.OnBtnFangkuaiTiaoyue.bind(this));
    
        var mishitaotou = cc.find("panel/bottoms/mishitaotou",this.node);
       
        mishitaotou.on("click",this.OnBtnMishiTaotou.bind(this));
    


        var xmxx = cc.find("panel/bottoms/xmxx",this.node);
       
        xmxx.on("click",this.OnBtnXiaoMieXingxing.bind(this));
    

        var yidongdongwu = cc.find("panel/bottoms/yidongdongwu",this.node);
       
        yidongdongwu.on("click",this.OnBtnYidongGuaishouXiaochu.bind(this));
    

        var huaduoxiaoxiao = cc.find("panel/bottoms/huaduoxiaoxiao",this.node);    
        huaduoxiaoxiao.on("click",this.OnBtnHuaduo_Xiaoxiao.bind(this));


        var guaishouxiaoxiao_btn = cc.find("panel/bottoms/guaishouxiaoxiao",this.node);

         guaishouxiaoxiao_btn.on("click",this.OnBtn_GuaishouXiaoxiao.bind(this))
    
         var guaishouxiaoxiao_tiaozhanchang = cc.find("panel/bottoms/guaishouxiaoxiao_tiaozhanchang",this.node);

         guaishouxiaoxiao_tiaozhanchang.on("click",this.OnBtn_GuaishouXiaoxiao_Tiaozhan.bind(this))
    
       
      
         
        var huaduo_tiaozhanchang = cc.find("panel/bottoms/huaduo_tiaozhanchang",this.node);
       
        huaduo_tiaozhanchang.on("click",this.OnBtn_Enter_Huaduo_Xiaoxiao_Tiaozhan.bind(this));
     



  

        var luosi_paixu_tiaozhan = cc.find("panel/bottoms/luosi_paixu_tiaozhan",this.node);
        luosi_paixu_tiaozhan.on("click",this.OnBtnLuosiPaixu.bind(this));
      



        var shuzihuarongdao = cc.find("panel/bottoms/shuzihuarongdao",this.node);
       
        shuzihuarongdao.on("click",this.OnBtnShuziHuaRongDao.bind(this));
    
        var huamukuai = cc.find("panel/bottoms/huamukuai",this.node);
       
        huamukuai.on("click",this.OnBtnHuaMuKuai.bind(this));
    
        var szxc = cc.find("panel/bottoms/szxc",this.node);
       
        szxc.on("click",this.OnBtnDianjiGuaishou.bind(this));

        this.Refresh_GK_Info();
    
        /*
        var all_wanfa_list = [guaishouxiaoxiao_btn,chuanguangmoshi,meiritiaozhan_btn,guaishoulainliankan,
            paopaolonggame,eluosifangkuai,guaishouduobi,fanpaixiaoxiaole,guaishoutiaoyue,mishitaotou,
            xmxx,yidongdongwu,shuzihuarongdao,huamukuai,szxc
        
        ];

        this.m_all_wanfa_list = all_wanfa_list;


        var cur_gk = GlobalConfig.GetIns().m_max_win_gk+1;

        for(var ff=0;ff<all_wanfa_list.length;ff++)
        {
            var ff_btn:cc.Node = all_wanfa_list[ff];

            var ff_wanfa_index = ff+1;
           
            ff_btn.on("click",this.OnBtnWanfa.bind(this,ff_wanfa_index));
            var lock_ndoe = cc.find("lock",ff_btn)
 
 

            var ff_jiesuo_btn = lock_ndoe.getChildByName("jiesuo");
            ff_jiesuo_btn.on("click",this.OnBtnJiesuoWanfa.bind(this,ff_wanfa_index));
       
        }
         
        this.Refresh_Info();
        */
    }

    Refresh_GK_Info()
    {
         
        var first_free_tiaozhan_count = TiaozhanChang_Mng.GetInstance().Get_Curday_Can_First_Free_Tiaozhan_Count();
     
        var huaduoxiaoxiao_imaxlv =  GlobalConfig.GetIns().Get_Game_Mode_Enter_Gk(2)

        var huaduoxiaoxiao_lv_label = cc.find("panel/bottoms/huaduoxiaoxiao/gk",this.node)
        huaduoxiaoxiao_lv_label.getComponent(cc.Label).string = "第"+huaduoxiaoxiao_imaxlv+"关"
        


        var huaduoxiaoxiao_tiaozhan_cishu = TiaozhanChang_Mng.GetInstance().Get_SubgameType_CurDay_Tiaozhan_Count(31);
        var huaduoxiaoxiao_tiaozhan_suc_cishu = TiaozhanChang_Mng.GetInstance().Get_TiaozhanChang_Curday_Success_Count(31);

        var huaduoxiaoxiao_free_node = cc.find("panel/bottoms/huaduo_tiaozhanchang/free",this.node)
        var huaduoxiaoxiao_shengyu_node = cc.find("panel/bottoms/huaduo_tiaozhanchang/shengyu",this.node); 
        var huaduoxiaoxiao_invalid_node = cc.find("panel/bottoms/huaduo_tiaozhanchang/invalid",this.node)
       

        huaduoxiaoxiao_invalid_node.active = false;
        huaduoxiaoxiao_shengyu_node.active = false;
        huaduoxiaoxiao_free_node.active = true;

       
        huaduoxiaoxiao_free_node.getComponent(cc.Label).string =  "挑战:"+huaduoxiaoxiao_tiaozhan_cishu+",成功:"+huaduoxiaoxiao_tiaozhan_suc_cishu+"";
     
       

        var guaishouxiaoxiao_imaxlv =  GlobalConfig.GetIns().Get_Game_Mode_Enter_Gk(4)

        var guaishouxiaoxiao_lv_label = cc.find("panel/bottoms/guaishouxiaoxiao/gk",this.node)
        guaishouxiaoxiao_lv_label.getComponent(cc.Label).string = "第"+guaishouxiaoxiao_imaxlv+"关"
        


        var guaishouxiaoxiao_tiaozhan_cishu = TiaozhanChang_Mng.GetInstance().Get_SubgameType_CurDay_Tiaozhan_Count(35);
        var guaishouxiaoxiao_tiaozhan_suc_cishu = TiaozhanChang_Mng.GetInstance().Get_TiaozhanChang_Curday_Success_Count(35);

        var guaishouxiaoxiao_free_node = cc.find("panel/bottoms/guaishouxiaoxiao_tiaozhanchang/free",this.node)
        var guaishouxiaoxiao_shengyu_node = cc.find("panel/bottoms/guaishouxiaoxiao_tiaozhanchang/shengyu",this.node);
         var guaishouxiaoxiao_invalid_node = cc.find("panel/bottoms/guaishouxiaoxiao_tiaozhanchang/invalid",this.node)
       
        guaishouxiaoxiao_invalid_node.active = false;
        guaishouxiaoxiao_shengyu_node.active = false;
        guaishouxiaoxiao_free_node.active = true;

        guaishouxiaoxiao_free_node.getComponent(cc.Label).string =  "挑战:"+guaishouxiaoxiao_tiaozhan_cishu+",成功:"+guaishouxiaoxiao_tiaozhan_suc_cishu+"";
     
        
 
        

        var luosi_paixu_tiaozhan_cishu = TiaozhanChang_Mng.GetInstance().Get_SubgameType_CurDay_Tiaozhan_Count(21);
        var luosi_paixu_tiaozhan_suc_cishu = TiaozhanChang_Mng.GetInstance().Get_TiaozhanChang_Curday_Success_Count(21);

        var luosi_paixu_free_node = cc.find("panel/bottoms/luosi_paixu_tiaozhan/free",this.node)
        var luosi_paixu_shengyu_node = cc.find("panel/bottoms/luosi_paixu_tiaozhan/shengyu",this.node);
        var luosi_paixu_invalid_node = cc.find("panel/bottoms/luosi_paixu_tiaozhan/invalid",this.node)
       
        luosi_paixu_invalid_node.active = false;
        luosi_paixu_shengyu_node.active = false;
        luosi_paixu_free_node.active = true;

    
        luosi_paixu_free_node.getComponent(cc.Label).string = "挑战:"+luosi_paixu_tiaozhan_cishu+",成功:"+luosi_paixu_tiaozhan_suc_cishu+"";
    

 


    }
    Real_Jiesuo_Wanfa(wanfaindex)
    {
        this.Set_Manaual_Jiesuoed_Wanfa(wanfaindex);
        this.Refresh_Info();

        BaseUIUtils.ShowTipTxtDlg("解锁玩法成功",this.node)
    }
    OnBtnJiesuoWanfa(ff_wanfa_index)
    {
        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node,
            ()=>
            {
                MiddleGamePlatformAction.GetInstance().Show_Qiandao_Banners(false);

            },
            
            "解锁大厅更多游戏",(bsuc)=>
        {
            if(!bsuc)
            {
                return;
            }


            self.Real_Jiesuo_Wanfa(ff_wanfa_index);

        });
    }
    Set_Manaual_Jiesuoed_Wanfa(wanfaindex)
    {
        var wanfa_str = "guaishoudaxiaochu_dating_wanfa_jiesuoed_"+wanfaindex;
        MyLocalStorge.setItem(wanfa_str,"ok");
    }
    Get_Manaual_Jiesuoed_Wanfa(wanfaindex)
    {
        var wanfa_str = "guaishoudaxiaochu_dating_wanfa_jiesuoed_"+wanfaindex;
        var str = MyLocalStorge.getItem(wanfa_str);

        if(str == "ok")
        {
            return true;
        }

        return false;
    }

    OnBtnWanfa(wanfaindex)
    {
        var bmanaualjiesuoed = this.Get_Manaual_Jiesuoed_Wanfa(wanfaindex);
        var cur_gk = GlobalConfig.GetIns().m_max_win_gk+1;

        var ff_need_gk = wanfaindex + 1;

        if(cur_gk < ff_need_gk && !bmanaualjiesuoed)
        { 

         //   BaseUIUtils.ShowTipTxtDlg("第"+ff_need_gk+"关解锁",this.node)

          //  return;
        }else{ 
        }


        if(wanfaindex == 1)
        {
            this.OnBtn_GuaishouXiaoxiao();
        }
        if(wanfaindex == 2)
        {
            this.OnBtnChuangGuangMoshi();
        }
        if(wanfaindex == 3)
        {
            this.OnBtn_Meiri_ChaoNan();
        }
        if(wanfaindex == 4)
        {
            this.OnBtnLainLianKan();
        }
        if(wanfaindex == 5)
        {
            this.OnBtnPaopaolong();
        }


        if(wanfaindex == 6)
        {
            this.OnBtnELuoSiFangkuai();
        }
        if(wanfaindex == 7)
        {
            this.OnBtnFlapyBirdMode();
        }

        if(wanfaindex == 8)
        {
            this.OnBtnFanpaiXiaoxiaoLe();
        }
        
        if(wanfaindex == 9)
        {
            this.OnBtnFangkuaiTiaoyue();
        }
        
        if(wanfaindex == 10)
        {
            this.OnBtnMishiTaotou();
        }
        if(wanfaindex == 11)
        {
            this.OnBtnXiaoMieXingxing();
        }
        if(wanfaindex == 12)
        {
            this.OnBtnYidongGuaishouXiaochu();
        }
        
        if(wanfaindex == 13)
        {
            this.OnBtnShuziHuaRongDao();
        }

        if(wanfaindex == 14)
        {
            this.OnBtnHuaMuKuai();
        }
        if(wanfaindex == 15)
        {
            this.OnBtnDianjiGuaishou();
        }
    }
    OnBtnDianjiGuaishou()
    {
        
        this.Hide_Dating_Gezi_Show();
        DianjiGuaishouMng.GetInstance().InitFromDating();

     //   cc.director.loadScene("dianjiguaishou");

        ComFunc.RealLoadScence("dianjiguaishou",0,0);
    }
    On_Select_Subgame_Nandu(igametype,inandu)
    {
        var irealsubgametype = igametype;

        if(igametype == 1)
        {
            irealsubgametype = HMK_GK_Mng.GetInstance().Get_Mode_GameType(inandu);
        }


        var igk = GlobalData.GetInstance().Get_SubGametype_Max_Can_Enter_GK(irealsubgametype);
   
   
        this.Real_Start_Goto_Game(irealsubgametype,igk);
    }

    Real_Start_Goto_Game(isubgametype,igk)
    {

     
        this.Hide_Dating_Gezi_Show();

        
        
         
        if(isubgametype  > 100 && isubgametype < 120)
        {

          //  var imode = isubgametype - 100;
           // shuziHuaRongDaoLogicMng.GetInstance().m_select_shuzihuarongdao_mode_type =  imode;
           // shuziHuaRongDaoLogicMng.GetInstance().m_select_shuzihuarongdao_gk =    igk;
    
           // cc.director.loadScene("shuzihuarongdao");

        }  
        else if(isubgametype  > 130 && isubgametype < 140)
        {

            GlobalData.GetInstance().m_select_enter_hmk_nandu = isubgametype - 130;
            GlobalData.GetInstance().m_select_enter_hmk_gk = igk;
          //  cc.director.loadScene("huamukuai");

            var scename  = "huamukuai";
    
            ComFunc.RealLoadScence(scename,0,0);
        }
    }
    OnBtn_Select_Subgame_Nandu(igametype)
    {


        var self = this;
        ComFunc.OpenNewDialog(this.node,"preab/common/com_sel_nandu","com_sel_nandu", { parentgame:this, 
            isubgametype:igametype ,
            cb:(inandu)=>
        {
           
            self.On_Select_Subgame_Nandu(igametype,inandu);
            //self.GoToLevel(isubgametype,lv);

        }});
          
        
    }
    OnBtnHuaMuKuai()
    {
       
        var igk = GlobalData.GetInstance().Get_SubGametype_Max_Can_Enter_GK(131);
       if(igk >= 3)
        {
            //第三关后，点击开始选关

         //   this.OnBtn_Select_SubgAme_GK(1);

            //首先，选择难度
 
            this.OnBtn_Select_Subgame_Nandu(1);

            return;
        }
       
        this.Real_Start_Goto_Game(131,igk);
      
    }

    OnBtnShuziHuaRongDao()
    {
        ComFunc.OpenNewDialog(this.node,"preab/shuzihuarogndao/shuzihuarongdao_sel_mode","shuzihuarongdao_sel_mode",{
            parentgame:this

        });
    }


    OnBtnYidongGuaishouXiaochu()
    {
        
        this.Hide_Dating_Gezi_Show();

        YidongDongwuMng.GetInstance().InitFromDating();
        ComFunc.RealLoadScence("yidongguaishouxiaochu",0,0);
  
    }

    OnBtnXiaoMieXingxing()
    {
        

        this.Hide_Dating_Gezi_Show();
        XiaoMieXingxingMng.GetInstance().InitFromDating();
        ComFunc.RealLoadScence("xiaomiexingxing",0,0);
    }
    
    OnBtnMishiTaotou()
    {
         

        this.Hide_Dating_Gezi_Show();
        MishiTaoTouMng.GetInstance().SetFromDatingEnetr(true);
        ComFunc.RealLoadScence("mishitaotougame",0,0);
    }
    OnBtnFangkuaiTiaoyue()
    {
        
        this.Hide_Dating_Gezi_Show();
        ComFunc.RealLoadScence("tiaodongfangkuai",0,0);
  
    }

    OnBtnFanpaiXiaoxiaoLe()
    {
         
        this.Hide_Dating_Gezi_Show();

        fanpaiXiaoXiaoMng.GetInstance().InitFromDating();
        ComFunc.RealLoadScence("fanpaixiaoxiaole",0,0);
    }
    OnBtnFlapyBirdMode()
    {
        
        this.Hide_Dating_Gezi_Show();
        FlayBirdGameMng.GetInstance().SetFromGameStart(false);
        ComFunc.RealLoadScence("flapybirdgame",0,0);
  
    }

    OnBtnELuoSiFangkuai()
    {
        
        this.Hide_Dating_Gezi_Show();
        fanpaiXiaoXiaoMng.GetInstance().InitFromDating();
        ComFunc.RealLoadScence("RussinFangkuai",0,0);
    }
    OnBtnPaopaolong()
    {
        

        var last_gk = PaoPaoLongMng.GetInstance().Get_Max_Can_Enter_GK();

        if(!last_gk || isNaN(last_gk))
        {
            last_gk = 1;
        }
        this.Hide_Dating_Gezi_Show();
        PaoPaoLongMng.GetInstance().LoadLevelConfig(last_gk,(error,pobj)=>
        {
            if(error)
            {
                console.log("关卡配置错误");
                return;
            }
 
            if(!pobj)
            {
                console.log("关卡配置错误");
                return;
            }



            PaoPaoLongMng.GetInstance().m_last_enter_level = last_gk;
            PaoPaoLongMng.GetInstance().m_enter_level = last_gk;
            PaoPaoLongMng.GetInstance().m_enter_level_config = pobj;
 
            ComFunc.RealLoadScence("pplgame",0,0);
          
        });
 
    }
     
    OnBtnLainLianKan()
    {
       
        this.Hide_Dating_Gezi_Show();

        LianLianKanGameMng.GetInstance().InitFromDating();
        ComFunc.RealLoadScence("lianliankangame",0,0);
    }
    OnBtn_Meiri_ChaoNan()
    {
      
        this.Hide_Dating_Gezi_Show();

        GSXC_Game_Mng.GetInstance().m_enter_xiaochu_chaonan_moshi = true;
        GSXC_Game_Mng.GetInstance().selectedLevel  = 0;
        ComFunc.RealLoadScence("game",0,0);
    }
    Hide_Dating_Gezi_Show()
    {
        MiddleGamePlatformAction.GetInstance().Hide_Dating_Gezi_Show();
      

    }
    OnBtnChuangGuangMoshi()
    { 
        this.Hide_Dating_Gezi_Show();

        GSXC_Game_Mng.GetInstance().m_enter_xiaochu_chaonan_moshi = false;
        GSXC_Game_Mng.GetInstance().selectedLevel  = GSXC_Game_Mng.GetInstance().Get_Max_Can_Enter_GK();
        ComFunc.RealLoadScence("game",0,0);
    }
    OnBtn_GuaishouXiaoxiao()
    {
       
        if(!this.Check_Btn_Click_Enough())
        {
            return;
        }
        this.Hide_Dating_Gezi_Show(); 
        GlobalConfig.GetIns().Set_Show_WupingType(2);
        GlobalConfig.GetIns().Enter_Game_Mode(4);
        ComFunc.RealLoadScence("huaduo_xiaoxiao",0,0);
    }
    SetInfo(pinfo)
    {
        this.m_callback = pinfo.callback;

       // this.Refresh_Info();
    }
    Refresh_Info()
    {
        var all_wanfa_list = this.m_all_wanfa_list ;


        var cur_gk = GlobalConfig.GetIns().m_max_win_gk+1;

        for(var ff=0;ff<all_wanfa_list.length;ff++)
        {
            var ff_btn:cc.Node = all_wanfa_list[ff];

            var ff_wanfa_index = ff+1;
            var bmanaualjiesuoed = this.Get_Manaual_Jiesuoed_Wanfa(ff_wanfa_index);
    
             var lock_ndoe = cc.find("lock",ff_btn)

            var ff_need_gk = ff + 2;

            if(cur_gk < ff_need_gk && !bmanaualjiesuoed)
            {
                lock_ndoe.active = true;
            }else{
                lock_ndoe.active = false;
            }
            lock_ndoe.active = false;
            var ff_lv_ndoe = lock_ndoe.getChildByName("lv");
            ff_lv_ndoe.getComponent(cc.Label).string = "第"+ff_need_gk+"关解锁"
        }
         

        
        var xunzhang_c_label = cc.find("panel/topmenu/xunzhang/c",this.node);

        var uxunzhang = GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(4);
        xunzhang_c_label.getComponent(cc.Label).string = ""+uxunzhang;

    }
    OnBtnExit()
    {
        this.node.destroy();

        SoundManager.GetInstance().Play_Click_Btn_Effect();
    }
    Check_Btn_Click_Enough()
    {
        if(Date.now() - this.m_last_btn_click_tick < 1000)
        {
            return false;
        }
        this.m_last_btn_click_tick = Date.now() ;

        return true;
    }
    OnBtn_Enter_Huaduo_Xiaoxiao_Tiaozhan()
    {
        
        if(!this.Check_Btn_Click_Enough())
       {
           return;
       }
       var self = this;
        var cur_day_tiaozhan_count = TiaozhanChang_Mng.GetInstance().Get_SubgameType_CurDay_Tiaozhan_Count(31);
        var first_free_tiaozhan_count = TiaozhanChang_Mng.GetInstance().Get_Curday_Can_First_Free_Tiaozhan_Count();
        this.Real_Enter_Huaduo_Xiaoxiao_Tiaozhan();
    }

    Real_Enter_Huaduo_Xiaoxiao_Tiaozhan()
    {
        GlobalConfig.GetIns().Set_Show_WupingType(1);
        GlobalConfig.GetIns().Enter_Game_Mode(1);
      
        TiaozhanChang_Mng.GetInstance().On_Enter_Tiaozhanchang(31)

        ComFunc.RealLoadScence("huaduo_xiaoxiao" );
    }

    OnBtnHuaduo_Xiaoxiao()
    {
        if(!this.Check_Btn_Click_Enough())
        {
            return;
        }
        GlobalConfig.GetIns().Set_Show_WupingType(1);
        GlobalConfig.GetIns().Enter_Game_Mode(2);

        ComFunc.RealLoadScence("huaduo_xiaoxiao" );
    }

    OnBtn_GuaishouXiaoxiao_Tiaozhan()
    {
        if(!this.Check_Btn_Click_Enough())
        {
            return;
        }
        var self = this;
        var cur_day_tiaozhan_count = TiaozhanChang_Mng.GetInstance().Get_SubgameType_CurDay_Tiaozhan_Count(35);
        var first_free_tiaozhan_count = TiaozhanChang_Mng.GetInstance().Get_Curday_Can_First_Free_Tiaozhan_Count();
      
        this.Real_Enter_Guaishou_Xiaoxiao_Tiaozhan();

    }
    Real_Enter_Guaishou_Xiaoxiao_Tiaozhan()
    {

        this.Hide_Dating_Gezi_Show(); 
        GlobalConfig.GetIns().Set_Show_WupingType(2);
        GlobalConfig.GetIns().Enter_Game_Mode(5);

        TiaozhanChang_Mng.GetInstance().On_Enter_Tiaozhanchang(35)

        ComFunc.RealLoadScence("huaduo_xiaoxiao",0,0);
    }

    OnBtnLuosiPaixu()
    {
        if(!this.Check_Btn_Click_Enough())
        {
            return;
        }
        var self = this;
        var cur_day_tiaozhan_count = TiaozhanChang_Mng.GetInstance().Get_SubgameType_CurDay_Tiaozhan_Count(21);
        var first_free_tiaozhan_count = TiaozhanChang_Mng.GetInstance().Get_Curday_Can_First_Free_Tiaozhan_Count();
        this.Real_Enter_LuosiPaixu_Tiaozhan();

     
        
    }
    Real_Enter_LuosiPaixu_Tiaozhan()
    {
        
        TiaozhanChang_Mng.GetInstance().On_Enter_Tiaozhanchang(21)

        ComFunc.RealLoadScence("luosipaixu");
    }
}
