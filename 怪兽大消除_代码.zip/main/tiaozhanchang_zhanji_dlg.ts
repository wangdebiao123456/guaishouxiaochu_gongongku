import ClientLogUtils from "../comfuncs/ClientLogUtils";
import WMap from "../WDT/WMap";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class tiaozhanchang_zhanji_dlg extends cc.Component {

   
    @property(cc.Prefab)
    tiaozhanchang_zhanji_item: cc.Prefab = null;

    m_readed_info = false;
    m_readed_subgametype_curday_tiaozhaned_info_map = new WMap();

    m_index_node_map = new WMap();
    
    onLoad () 
    {
        this.Post_Get_Server_Tiaozhanchang_Zhanji();

          this.Refresh_Info();
    }
    On_Readed_Info(pobj)
    {
        var icount = pobj.icount;
        var objlist = pobj.objlist;
        this.m_readed_info = true;

        this.m_readed_subgametype_curday_tiaozhaned_info_map.clear();
        for(var ff=0;ff<icount;ff++)
        {
            var ff_info =  objlist[ff];
            var gametype = ff_info.gametype;
            var tiaozhancount = ff_info.tiaozhancount;
            var success_count = ff_info.success_count;

            this.m_readed_subgametype_curday_tiaozhaned_info_map.putData(gametype,ff_info)

        }

        this.Refresh_Info();
    }
    Post_Get_Server_Tiaozhanchang_Zhanji()
    {
        var self = this;
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(106, "获取挑战场今日战绩", 0,
        "", 0, "", 0, "",   
        (bsuc,response)=>{

            if(!bsuc)
            {
                return;
            }

            var pobj = JSON.parse(response);

            if(!pobj)
            {
                return;
            }

            var icount = pobj.icount;
            var objlist = pobj.objlist;
            
            self.On_Readed_Info(pobj);

          
        });
    }
    Get_Subgame_Type_Arr()
    {
        var subgametype_arr = [9,31,21,35];

        return subgametype_arr;
    }

    SetInfo(paradata)
    {

    }
    Get_Subgame_Name(ff_subgametype)
    {

        if(ff_subgametype == 9)
        {
            return "三消怪兽挑战";
        }

        if(ff_subgametype == 21)
        {
            return "螺丝排序挑战";
        }

        if(ff_subgametype == 31)
        {
            return "花朵拼拼挑战";
        }

        
        if(ff_subgametype == 35)
        {
            return "怪兽拼拼挑战";
        }

        return "";
    }
    Refresh_Info()
    {
        var subgametype_arr = this.Get_Subgame_Type_Arr();

        var sc_content = cc.find("panel/sc/view/content",this.node);

        for(var ff=0;ff<subgametype_arr.length;ff++)
        {
            var ff_subgametype=  subgametype_arr[ff];

            if(!this.m_index_node_map.hasKey(ff_subgametype))
            {
                var pndoe = cc.instantiate(this.tiaozhanchang_zhanji_item);
                sc_content.addChild(pndoe,20);
                this.m_index_node_map.putData(ff_subgametype,pndoe)
            }

            var ff_old_ndoe = this.m_index_node_map.getData(ff_subgametype);
             
            ff_old_ndoe.setPosition(0,-400*ff - 220);
            var name_node = cc.find("gameinfo/name",ff_old_ndoe);

            var sname = this.Get_Subgame_Name(ff_subgametype);
            name_node.getComponent(cc.Label).string = sname;
             
            for(var tt=1;tt<=100;tt++)
            {
                var tt_node = cc.find("gameinfo/"+tt,ff_old_ndoe);
                if(tt_node)
                {
                    if(ff_subgametype == tt)
                    {
                        tt_node.active = true;
                    }else{
                        tt_node.active = false;
                    }
                    
                }
            }

            var tt_c1_label = cc.find("tiaozhan_zhanji/c1",ff_old_ndoe);
            var tt_c2_label = cc.find("tiaozhan_zhanji/c2",ff_old_ndoe);
            
            var readed_info =  null;
            if(this.m_readed_subgametype_curday_tiaozhaned_info_map.hasKey(ff_subgametype))
            {
                readed_info = this.m_readed_subgametype_curday_tiaozhaned_info_map.getData(ff_subgametype);
            }

            

            if(!readed_info)
            {
                if(this.m_readed_info)
                {
                    tt_c1_label.getComponent(cc.Label).string = "0";
                    tt_c2_label.getComponent(cc.Label).string = "0";
    
                }else{
                    tt_c1_label.getComponent(cc.Label).string = "读取中";
                    tt_c2_label.getComponent(cc.Label).string = "读取中";
    
                }
               
            }
            else{
                tt_c1_label.getComponent(cc.Label).string = ""+readed_info.tiaozhancount
                tt_c2_label.getComponent(cc.Label).string = ""+readed_info.success_count

                
            }
            
        }

        sc_content.height = 400*subgametype_arr.length + 50;
  
    }
}
