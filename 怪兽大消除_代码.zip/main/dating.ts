import BaseUIUtils from "../comfuncs/BaseUIUtils";
import BundleLoadUtils from "../comfuncs/BundleLoadUtils";
import ClientLogUtils from "../comfuncs/ClientLogUtils";
import ComFunc from "../comfuncs/ComFunc";
import LeoGameInfoMng from "../comfuncs/LeoGameInfoMng";
import SoundManager from "../comfuncs/SoundManager";
import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import select_paihang_type from "../dlg/select_paihang_type";
import fanpaiXiaoXiaoMng from "../fanpaixiaoxiaole/fanpaiXiaoXiaoMng";
import FlayBirdGameMng from "../flapybirdgame/FlayBirdGameMng";
import LianLianKanGameMng from "../lianliankan/LianLianKanGameMng";
import Luosi_Game_Mng from "../luosi/Luosi_Game_Mng";
import MishiTaoTouMng from "../mishitaotou/MishiTaoTouMng";
import GlobalGameMng from "../Mng/GlobalGameMng";
import GSXC_Game_Mng from "../Mng/GSXC_Game_Mng";
import TiaozhanChang_Mng from "../Mng/TiaozhanChang_Mng";
import ZhuangXiu_Mng from "../Mng/ZhuangXiu_Mng";
import PaoPaoLongMng from "../paopaolonggame/paopaolong/PaoPaoLongMng";
import GlobalConfig from "../pingpinggame/GlobalConfig";
import HutuiAppInfoMng from "../PlatForm/HutuiAppInfoMng";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import Util from "../utils/Util";
import MyLocalStorge from "../WDT/MyLocalStorge";
import YidongDongwuMng from "../yidongdongwuxiaochu/YidongDongwuMng";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class dating extends cc.Component {

     
    
   // @property(cc.Prefab)
   // qiandaoSign:cc.Prefab = null;
   
    
  
  
    
    @property(cc.Prefab)
    paihangbang:cc.Prefab = null;
   


 
    @property(cc.Prefab)
    xingyunlibao_dlg:cc.Prefab = null;
   
   

    
    @property(cc.Prefab)
    shangcheng_new:cc.Prefab = null;
   

    @property(cc.Prefab)
    yaoqing_dlg:cc.Prefab = null;
   
 
 
    
    @property(cc.Prefab)
    show_get_jiangli:cc.Prefab = null;
    

     
    @property(cc.Prefab)
    select_paihang_type:cc.Prefab = null;
    
    

    @property(cc.Prefab)
    dating_more_game:cc.Prefab = null;
   
 
    @property(cc.Prefab)
    test_mng: cc.Prefab = null;
   

    @property(cc.Prefab)
    tiaozhanchang_zhanji_dlg:cc.Prefab = null;
   

    @property(cc.Prefab)
    qiandaoSign:cc.Prefab = null;
   
    @property(cc.Prefab)
    zaixianlibao_dlg:cc.Prefab = null;
   
    @property(cc.Prefab)
    choujiang_dlg:cc.Prefab = null;
   
    

    @property(cc.Prefab)
    shoucang_dlg:cc.Prefab = null;
   
    
    @property(cc.Prefab)
    add_zhuomian_dlg:cc.Prefab = null;
   
    
    m_game_banner_arr = [];

    
    m_prev_game_type = 0;

    

    m_last_btn_click_tick = 0;

    onLoad () 
    { 
 
        
     
        this.m_prev_game_type=  MiddleGamePlatformAction.GetInstance().m_cur_in_subgame_type;
      
        var qiandaobtn = cc.find("top/menu/qiandaobtn",this.node)
        qiandaobtn.on("click",this.OnBtnQiandao.bind(this))
       

        var rightmenu_qiandao = cc.find("rightmenu/qiandaobtn",this.node);
        rightmenu_qiandao.on("click",this.OnBtnQiandao.bind(this))
       

     
        var xingyunlibao = cc.find("rightmenu/xingyunlibao",this.node)
        xingyunlibao.on("click",this.OnBtnXingyunLibao.bind(this))
       
       
        var shocuangyx = cc.find("top/menu/shocuangyx",this.node)
        shocuangyx.on("click",this.OnBtnShoucangYouxi.bind(this))
      
        var tianjiazhuomian = cc.find("top/menu/tianjiazhuomian",this.node)
        tianjiazhuomian.on("click",this.OnBtnAddZhuomian.bind(this))
      

        
        
        var paihangbang = cc.find("rightmenu/paihangbang",this.node)
        paihangbang.on("click",this.OnBtnPaiHangBang.bind(this))
       
       

        var jindu_libaobtn = cc.find("top/capterinfo/jindu/libaobtn",this.node)
        jindu_libaobtn.on("click",this.OnBtnJinduLibao.bind(this))
       
        var zaixianlibao = cc.find("top/menu/zaixianlibao",this.node);
        zaixianlibao.on("click",this.OnBtn_OnLine_Reward.bind(this))
    
        
      //  var test = cc.find("test/test",this.node)
      //  test.on("click",this.OnBtnTest.bind(this))
      
      
        
        var shangchengbtn = cc.find("rightmenu/shangchengbtn",this.node)
        shangchengbtn.on("click",this.OnBtnSC.bind(this))
      
  
        var addjinbi = cc.find("top/addjinbi",this.node)
        addjinbi.on("click",this.OnBtnSC.bind(this))
      
    
        var add_chuizi = cc.find("top/add_chuizi",this.node)
        add_chuizi.on("click",this.OnBtnSC.bind(this))
      

        var add_zuanshi = cc.find("top/add_zuanshi",this.node)
        add_zuanshi.on("click",this.OnBtnSC.bind(this))
      

        var fenxiangbtn = cc.find("rightmenu/fenxiang",this.node)
        fenxiangbtn.on("click",this.OnBtnYaoqing.bind(this))
       
         
 
        var gengduowanfa = cc.find("bottoms/gengduowanfa",this.node)
        gengduowanfa.on("click",this.OnBtnMoreWanfa.bind(this))
       

        var chuanguangmoshi = cc.find("bottoms/chuanguangmoshi",this.node);
        chuanguangmoshi.on("click",this.OnBtnChuangGuangMoshi.bind(this))
  
        
        
        var huaduoxiaoxiao = cc.find("bottoms/huaduoxiaoxiao",this.node);
        huaduoxiaoxiao.on("click",this.OnBtnHuaduo_Xiaoxiao.bind(this))
  

        
        var huaduo_tiaozhanchang = cc.find("bottoms/huaduo_tiaozhanchang",this.node);
       
        huaduo_tiaozhanchang.on("click",this.OnBtn_Enter_Huaduo_Xiaoxiao_Tiaozhan.bind(this));
       
    
        var guaishouxiaoxiao = cc.find("bottoms/guaishouxiaoxiao",this.node);
        guaishouxiaoxiao.on("click",this.OnBtn_GuaishouXiaoxiao.bind(this))
  
       
        var guaishouxiaoxiao_tiaozhanchang = cc.find("bottoms/guaishouxiaoxiao_tiaozhanchang",this.node);
        guaishouxiaoxiao_tiaozhanchang.on("click",this.OnBtn_GuaishouXiaoxiao_Tiaozhan.bind(this))
  
       

        

        var meiritiaozhan = cc.find("bottoms/meiritiaozhan",this.node);
        meiritiaozhan.on("click",this.OnBtn_Meiri_ChaoNan.bind(this))
  

        var guaishoulainliankan = cc.find("bottoms/guaishoulainliankan",this.node);
        guaishoulainliankan.on("click",this.OnBtnLainLianKan.bind(this));

        
        var paopaolonggame = cc.find("bottoms/paopaolonggame",this.node);
         paopaolonggame.on("click",this.OnBtnPaopaolong.bind(this));
    
         var eluosifangkuai = cc.find("bottoms/eluosifangkuai",this.node);
        eluosifangkuai.on("click",this.OnBtnELuoSiFangkuai.bind(this));


        var guaishouduobi = cc.find("bottoms/guaishouduobi",this.node);
        guaishouduobi.on("click",this.OnBtnFlapyBirdMode.bind(this));
    

        var fanpaixiaoxiaole = cc.find("bottoms/fanpaixiaoxiaole",this.node);
       
        fanpaixiaoxiaole.on("click",this.OnBtnFanpaiXiaoxiaoLe.bind(this));
    
        var mishitaotou = cc.find("bottoms/mishitaotou",this.node);
       
        mishitaotou.on("click",this.OnBtnMishiTaotou.bind(this));
    


        

     

        var luosi_hecheng = cc.find("bottoms/luosi_hecheng",this.node);
        luosi_hecheng.on("click",this.OnBtnLuosiHeCheng.bind(this));
      

        var luosi_paixu_tiaozhan = cc.find("bottoms/luosi_paixu_tiaozhan",this.node);
        luosi_paixu_tiaozhan.on("click",this.OnBtnLuosiPaixu.bind(this));
      

        



        var zhuangxiubtn = cc.find("top/menu/zhuangxiubtn",this.node)
        zhuangxiubtn.on("click",this.OnBtnZhuangxiu.bind(this))
      



        var tiaozhan_zhanji = cc.find("rightmenu/tiaozhan_zhanji",this.node)
        tiaozhan_zhanji.on("click",this.OnBtnTiaozhanchang_Zhanji.bind(this))
      


        


        cc.director.preloadScene("huaduo_xiaoxiao");

     
        this.schedule(this.FD_Timer.bind(this),0.5)
        this.schedule(this.FD_long_Timer.bind(this),1)


        this.FD_long_Timer();
        
        GlobalConfig.GetIns().Post_Server_Max_Fenshu_Pihang();

        this.Refresh_Hongdian();


        this.Post_Read_Shetuan_Info();

        ComFunc.Set_Preb_Name_Node( "preab/com/show_get_jiangli",this.show_get_jiangli)

      //  this.On_Yingdao_Finished_Event();

        var banner_arr = [];
    
         var node_left = cc.find("node_top/left",this.node)
          

        

         SoundManager.GetInstance().Play_Music("lianliankan/music_bg");

      
        this.m_game_banner_arr = banner_arr;

  
        LeoGameInfoMng.GetIns().Check_Post_Read_OpenId();
        MiddleGamePlatformAction.GetInstance().Set_In_Subgame_Valid_Gezi_Guangao_Bannerindex_Arr_Info(false,0,banner_arr);
  

        HutuiAppInfoMng.GetInstance().LoadRemoteConfig(()=>{});
        GlobalGameMng.GetInstance().Load_Game_Common_Config(()=>{});

        GSXC_Game_Mng.GetInstance().Post_Read_Server_Config();

        var ibanner_mng_time = GlobalGameMng.GetInstance().Get_Game_Banner_Mng_Time_Config(0);
        this.schedule(this.FD_Banner_Mng_Timer.bind(this),ibanner_mng_time);



      
        GlobalGameMng.GetInstance().Check_Init_Online_Libao_Data();


        
       

       
        if(!LeoGameInfoMng.GetIns().m_yaoqing_info_posted
               && LeoGameInfoMng.GetIns().m_enter_from_other_user_openid     )
        {
            LeoGameInfoMng.GetIns().Check_Post_Read_OpenId();
            LeoGameInfoMng.GetIns().Check_WX_Load_From_Openid();

        }

 
        this.scheduleOnce(this.Check_First_Show_Pop_Dlg.bind(this),0.2);

        this.scheduleOnce(this.Check_First_Show_Zhuangxiu_Qipai.bind(this),0.2);
     
        this.Refresh_Info();

        
        var shocuangyx_hd = cc.find("top/menu/shocuangyx/hongdian",this.node);
        var tianjiazhuomian_hd = cc.find("top/menu/tianjiazhuomian/hongdian",this.node);

        var pseq =  cc.sequence(cc.delayTime(1),
        cc.targetedAction(shocuangyx_hd,cc.rotateTo(0.1,10)),cc.targetedAction(shocuangyx_hd,cc.rotateTo(0.2,-20)),cc.targetedAction(shocuangyx_hd,cc.rotateTo(0.1,0)),
        cc.targetedAction(shocuangyx_hd,cc.rotateTo(0.1,10)),cc.targetedAction(shocuangyx_hd,cc.rotateTo(0.2,-20)),cc.targetedAction(shocuangyx_hd,cc.rotateTo(0.1,0)))
       
        this.node.runAction(cc.repeatForever(pseq))
        

        var pseq2 =  cc.sequence(cc.delayTime(1),
        cc.targetedAction(tianjiazhuomian_hd,cc.rotateTo(0.1,10)),cc.targetedAction(tianjiazhuomian_hd,cc.rotateTo(0.2,-20)),cc.targetedAction(tianjiazhuomian_hd,cc.rotateTo(0.1,0)),
        cc.targetedAction(tianjiazhuomian_hd,cc.rotateTo(0.1,10)),cc.targetedAction(tianjiazhuomian_hd,cc.rotateTo(0.2,-20)),cc.targetedAction(tianjiazhuomian_hd,cc.rotateTo(0.1,0)))
       
        this.node.runAction(cc.repeatForever(pseq2))
        



        ClientLogUtils.GetInstance().Poset_Server_JS_Log(2, "进入大厅", 1,
            "大厅界面", 0, "", 0, "");
    }

    OnBtn_ChouJiang()
    {
  
        /*
        var self  = this;
        var pndoe = cc.instantiate(this.choujiang_dlg);
        var choujiang_dlg = pndoe.getComponent("choujiang_dlg");
        choujiang_dlg.SetInitData(
            {
                
                cb:()=>
                {
                    self.Refresh_Info();

                    
                }
            }

        );
        this.node.addChild(pndoe,20);
        */
    }

    Check_Btn_Click_Enough()
    {
        if(Date.now() - this.m_last_btn_click_tick < 1000)
        {
            return false;
        }
        this.m_last_btn_click_tick = Date.now() ;

        return true;
    }

    OnBtnLuosiHeCheng()
    {
        if(!this.Check_Btn_Click_Enough())
        {
            return;
        }
        ComFunc.RealLoadScence("luosi_hecheng");
    }
    
     
    OnBtnZhuangxiu()
    {
        if(!this.Check_Btn_Click_Enough())
        {
            return;
        }
        ComFunc.RealLoadScence("zhuangxiu",0,0);
        
        SoundManager.GetInstance().Play_Click_Btn_Effect();
    }
    OnBtnMishiTaotou()
    {
         
        if(!this.Check_Btn_Click_Enough())
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();
        MishiTaoTouMng.GetInstance().SetFromDatingEnetr(true);
        ComFunc.RealLoadScence("mishitaotougame",0,0);
    }

    OnBtnFlapyBirdMode()
    {
        if(!this.Check_Btn_Click_Enough())
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();
        FlayBirdGameMng.GetInstance().SetFromGameStart(false);
        ComFunc.RealLoadScence("flapybirdgame",0,0);
  
    }

    OnBtnELuoSiFangkuai()
    {
        if(!this.Check_Btn_Click_Enough())
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();
        fanpaiXiaoXiaoMng.GetInstance().InitFromDating();
        ComFunc.RealLoadScence("RussinFangkuai",0,0);
    }
    OnBtnPaopaolong()
    {
        
        if(!this.Check_Btn_Click_Enough())
        {
            return;
        }
        var last_gk = PaoPaoLongMng.GetInstance().Get_Max_Can_Enter_GK();

        if(!last_gk || isNaN(last_gk))
        {
            last_gk = 1;
        }
        this.Hide_Dating_Gezi_Show();
        PaoPaoLongMng.GetInstance().LoadLevelConfig(last_gk,(error,pobj)=>
        {
            if(error)
            {
                console.log("关卡配置错误");
                return;
            }
 
            if(!pobj)
            {
                console.log("关卡配置错误");
                return;
            }



            PaoPaoLongMng.GetInstance().m_last_enter_level = last_gk;
            PaoPaoLongMng.GetInstance().m_enter_level = last_gk;
            PaoPaoLongMng.GetInstance().m_enter_level_config = pobj;
 
            ComFunc.RealLoadScence("pplgame",0,0);
          
        });
 
    }
     
    OnBtnLainLianKan()
    {
        if(!this.Check_Btn_Click_Enough())
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();

        LianLianKanGameMng.GetInstance().InitFromDating();



        ComFunc.RealLoadScence("lianliankangame",0,0);
    }

    OnBtn_GuaishouXiaoxiao_Tiaozhan()
    {
        if(!this.Check_Btn_Click_Enough())
        {
            return;
        }
        var self = this;
        var cur_day_tiaozhan_count = TiaozhanChang_Mng.GetInstance().Get_SubgameType_CurDay_Tiaozhan_Count(35);
        var first_free_tiaozhan_count = TiaozhanChang_Mng.GetInstance().Get_Curday_Can_First_Free_Tiaozhan_Count();
     
        /*
        if(cur_day_tiaozhan_count >= 5+first_free_tiaozhan_count)
        {
            BaseUIUtils.ShowTipTxtDlg("该玩法今日挑战次数已用完",this.node)
            return;
        }

        if(cur_day_tiaozhan_count >= first_free_tiaozhan_count)
        {
            WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(this.node,
                ()=>
                {

                },"三消消使用移除",(bsuc)=>
            {
                if(!bsuc)
                {
                    return;
                }
    
    
                self.Real_Enter_Guaishou_Xiaoxiao_Tiaozhan();
    
            });


        }else{
            this.Real_Enter_Guaishou_Xiaoxiao_Tiaozhan();
        }
        */

        this.Real_Enter_Guaishou_Xiaoxiao_Tiaozhan();

    }

    OnBtnLuosiPaixu()
    {
        if(!this.Check_Btn_Click_Enough())
        {
            return;
        }
        var self = this;
        var cur_day_tiaozhan_count = TiaozhanChang_Mng.GetInstance().Get_SubgameType_CurDay_Tiaozhan_Count(21);
        var first_free_tiaozhan_count = TiaozhanChang_Mng.GetInstance().Get_Curday_Can_First_Free_Tiaozhan_Count();
        this.Real_Enter_LuosiPaixu_Tiaozhan();

        
        /*
        if(cur_day_tiaozhan_count >= 5+first_free_tiaozhan_count)
        {
            BaseUIUtils.ShowTipTxtDlg("该玩法今日挑战次数已用完",this.node)
            return;
        }

        if(cur_day_tiaozhan_count >= first_free_tiaozhan_count)
        {
            WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(this.node,
                ()=>
                {

                },"三消消使用移除",(bsuc)=>
            {
                if(!bsuc)
                {
                    return;
                }
    
    
                self.Real_Enter_LuosiPaixu_Tiaozhan();
    
            });


        }else{
            this.Real_Enter_LuosiPaixu_Tiaozhan();
        }
        */

        
    }
    Real_Enter_LuosiPaixu_Tiaozhan()
    {
        
        TiaozhanChang_Mng.GetInstance().On_Enter_Tiaozhanchang(21)

        ComFunc.RealLoadScence("luosipaixu");
    }
    
    OnBtn_Enter_Huaduo_Xiaoxiao_Tiaozhan()
    {
        //GlobalConfig.GetIns().Enter_Game_Mode(2);
  
       // SoundManager.GetInstance().Play_Click_Btn_Effect();
       if(!this.Check_Btn_Click_Enough())
       {
           return;
       }
       var self = this;
        var cur_day_tiaozhan_count = TiaozhanChang_Mng.GetInstance().Get_SubgameType_CurDay_Tiaozhan_Count(31);
        var first_free_tiaozhan_count = TiaozhanChang_Mng.GetInstance().Get_Curday_Can_First_Free_Tiaozhan_Count();
        this.Real_Enter_Huaduo_Xiaoxiao_Tiaozhan();
        /*
        if(cur_day_tiaozhan_count >= 5+ first_free_tiaozhan_count)
        {
            BaseUIUtils.ShowTipTxtDlg("该玩法今日挑战次数已用完",this.node)
            return;
        }

        if(cur_day_tiaozhan_count >= first_free_tiaozhan_count)
        {
            WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(this.node,
                ()=>
                {

                },"三消消使用移除",(bsuc)=>
            {
                if(!bsuc)
                {
                    return;
                }
    
    
                self.Real_Enter_Huaduo_Xiaoxiao_Tiaozhan();
    
            });


        }else{
            this.Real_Enter_Huaduo_Xiaoxiao_Tiaozhan();
        }

        */
  


        
    }
    Real_Enter_Guaishou_Xiaoxiao_Tiaozhan()
    {

        this.Hide_Dating_Gezi_Show(); 
        GlobalConfig.GetIns().Set_Show_WupingType(2);
        GlobalConfig.GetIns().Enter_Game_Mode(5);

        TiaozhanChang_Mng.GetInstance().On_Enter_Tiaozhanchang(35)

        ComFunc.RealLoadScence("huaduo_xiaoxiao",0,0);
    }
    Real_Enter_Huaduo_Xiaoxiao_Tiaozhan()
    {
        GlobalConfig.GetIns().Set_Show_WupingType(1);
        GlobalConfig.GetIns().Enter_Game_Mode(1);
      
        TiaozhanChang_Mng.GetInstance().On_Enter_Tiaozhanchang(31)

        ComFunc.RealLoadScence("huaduo_xiaoxiao" );
    }
    OnBtnHuaduo_Xiaoxiao()
    {
        if(!this.Check_Btn_Click_Enough())
        {
            return;
        }
        GlobalConfig.GetIns().Set_Show_WupingType(1);
        GlobalConfig.GetIns().Enter_Game_Mode(2);

        ComFunc.RealLoadScence("huaduo_xiaoxiao" );
    }
    OnBtn_Meiri_ChaoNan()
    {
        if(!this.Check_Btn_Click_Enough())
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();

        this.Real_Enter_Sanxiaoxiao_TiaozhanChang();
        /*
        var self = this;
        var cur_day_tiaozhan_count = TiaozhanChang_Mng.GetInstance().Get_SubgameType_CurDay_Tiaozhan_Count(9);
        var first_free_tiaozhan_count = TiaozhanChang_Mng.GetInstance().Get_Curday_Can_First_Free_Tiaozhan_Count();
     
        if(cur_day_tiaozhan_count >= 5+ first_free_tiaozhan_count)
        {
            BaseUIUtils.ShowTipTxtDlg("该玩法今日挑战次数已用完",this.node)
            return;
        }

        if(cur_day_tiaozhan_count >= first_free_tiaozhan_count)
        {
            WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(this.node,
                ()=>
                {

                },"三消消使用移除",(bsuc)=>
            {
                if(!bsuc)
                {
                    return;
                }
    
    
                self.Real_Enter_Sanxiaoxiao_TiaozhanChang();
    
            });


        }else{
            this.Real_Enter_Sanxiaoxiao_TiaozhanChang();
        }
        */


      
    }
    Real_Enter_Sanxiaoxiao_TiaozhanChang()
    {
        GSXC_Game_Mng.GetInstance().m_enter_xiaochu_chaonan_moshi = true;
        GSXC_Game_Mng.GetInstance().selectedLevel  = 0;
        GSXC_Game_Mng.GetInstance().Clear_ChaonanTiaozhan_Last_Save_Ju();

        TiaozhanChang_Mng.GetInstance().On_Enter_Tiaozhanchang(9)

        ComFunc.RealLoadScence("game",0,0);
    }
    OnBtnYidongGuaishouXiaochu()
    {
        if(!this.Check_Btn_Click_Enough())
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();

        YidongDongwuMng.GetInstance().InitFromDating();
        ComFunc.RealLoadScence("yidongguaishouxiaochu",0,0);
  
    }
    OnBtnFanpaiXiaoxiaoLe()
    {
        if(!this.Check_Btn_Click_Enough())
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();

        fanpaiXiaoXiaoMng.GetInstance().InitFromDating();
        ComFunc.RealLoadScence("fanpaixiaoxiaole",0,0);
    }
    OnBtn_GuaishouXiaoxiao()
    {
        if(!this.Check_Btn_Click_Enough())
        {
            return;
        }
        this.Hide_Dating_Gezi_Show(); 
        GlobalConfig.GetIns().Set_Show_WupingType(2);
        GlobalConfig.GetIns().Enter_Game_Mode(4);
        ComFunc.RealLoadScence("huaduo_xiaoxiao",0,0);
    }
    OnBtnChuangGuangMoshi()
    { 
        if(!this.Check_Btn_Click_Enough())
        {
            return;
        }


        this.Hide_Dating_Gezi_Show();

        GSXC_Game_Mng.GetInstance().m_enter_xiaochu_chaonan_moshi = false;
        GSXC_Game_Mng.GetInstance().selectedLevel  = GSXC_Game_Mng.GetInstance().Get_Max_Can_Enter_GK();
        ComFunc.RealLoadScence("game",0,0);
    }
     
    Hide_Dating_Gezi_Show()
    {
        MiddleGamePlatformAction.GetInstance().Hide_Dating_Gezi_Show();
      

    }


    FD_Banner_Mng_Timer()
    { 
        MiddleGamePlatformAction.GetInstance().FD_Banner_Mng_Timer(this.node);

    }
    Is_In_Yindao()
    {

        /*
        if(!this.m_b_cur_gk_step_finished )
        {
            return 1;
        }
        */

        return 0;
    }
    OnBtnTestAddZhongzi()
    {
        
        GlobalConfig.GetIns().Change_Self_DaojuType_Count(16,10)
 
        Util.ShowTipTxtDlg("种子+10",this.node);
        this.Refresh_Info()
    }
    OnBtnTestAddGk()
    {

        GlobalConfig.GetIns().m_max_win_gk++;
        GlobalConfig.GetIns().Save_All_Info();
        Util.ShowTipTxtDlg("关卡+1",this.node);
        this.Refresh_Info()
    }
    Refresh_Hongdian()
    { 


        var qiandaobtn_hongdian = cc.find("top/menu/qiandaobtn/hongdian",this.node);
    
        var curday_Can_sign = GlobalConfig.GetIns().Is_CurDay_Can_Sign();
        qiandaobtn_hongdian.active = curday_Can_sign;


        var rightmenu_qiandao_hongdian = cc.find("rightmenu/qiandaobtn/hongdian",this.node);
        rightmenu_qiandao_hongdian.active = curday_Can_sign;



        var shangchengbtn_hongdian = cc.find("rightmenu/shangchengbtn/hongdian",this.node);
    
        if(GlobalConfig.GetIns().Get_Self_DestType_Daoju_Count(5) >= 100)
        {
            shangchengbtn_hongdian.active = true;
        }else{
            shangchengbtn_hongdian.active = false;
        }
        

      //  var chengjiu_hongdian = cc.find("rightmenu/chengjiu/hongdian",this.node);
      //  chengjiu_hongdian.active = GameTaskMng.GetIns().IS_Dating_Chengjiu_Btn_Has_Hongdian();

      
      var xingyunshu_hongdian = cc.find("rightmenu/xingyunlibao/hongdian",this.node);
    
        var bhas_zhuanpan_action = false;
        if(GlobalConfig.GetIns().m_menghuan_huayuan_level >= 3)
        {
            if(GlobalConfig.GetIns().m_cur_day_zhuanpan_action_index < 6)
            {
                bhas_zhuanpan_action= true;
            }
        }
        xingyunshu_hongdian.active = bhas_zhuanpan_action;
       
        var zaixianlibao_hongdian = cc.find("top/menu/zaixianlibao/hongdian",this.node);
    
        
        var zaixian_jeliqgqu = false;
        var left_info = GlobalGameMng.GetInstance().Get_Cur_Day_OnLine_Libao_Left_Sec_Info();
        if(left_info[0])
        {
            var ileftsec = left_info[1];
 
            if(ileftsec <= 0)
            {
                 
                zaixian_jeliqgqu = true;
            }
      
        }
 
        zaixianlibao_hongdian.active  = zaixian_jeliqgqu;


        var zhuangxiubtn_hongdian = cc.find("top/menu/zhuangxiubtn/hongdian",this.node);
    
        var curcapter = ZhuangXiu_Mng.GetInstance().Get_Cur_Zhuangxiu_Capter();
  
        var cur_zx_count = ZhuangXiu_Mng.GetInstance().Get_Capter_Zhuangxiued_Count(curcapter);
 
        var cur_zx_need_chuizi_c = ZhuangXiu_Mng.GetInstance().Get_Capter_Index_Zhuangxiu_Need_Chuizi(curcapter,cur_zx_count);

        var ihasc_chuizi = GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(6);

        if(ihasc_chuizi >= cur_zx_need_chuizi_c)
        {
            zhuangxiubtn_hongdian.active = true;
        }
        
    }
    Check_First_Show_Zhuangxiu_Qipai()
    {
        var curcapter = ZhuangXiu_Mng.GetInstance().Get_Cur_Zhuangxiu_Capter();
  
        var cur_zx_count = ZhuangXiu_Mng.GetInstance().Get_Capter_Zhuangxiued_Count(curcapter);
 
        var cur_zx_need_chuizi_c = ZhuangXiu_Mng.GetInstance().Get_Capter_Index_Zhuangxiu_Need_Chuizi(curcapter,cur_zx_count);

        var ihasc_chuizi = GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(6);


        var qipaitishi = cc.find("top/menu/zhuangxiubtn/qipaitishi",this.node)
        
        if(ihasc_chuizi >= cur_zx_need_chuizi_c)
        {
            qipaitishi.active = true;

            var pseq = cc.sequence(cc.delayTime(10),cc.callFunc(()=>
            {
                qipaitishi.active = false;
            }));

            this.node.runAction(pseq);


        }else{
            qipaitishi.active = false
        }
    }
    FD_long_Timer()
    {

       /*
        if(User_Info_Mng.GetInstance().Get_User_ID() == 0)
        {
            XSC_Server_Request.GetInstance().Poset_Reg_User_Data(
                (bsuc,response)=>
                {  
                    if(!bsuc)
                    {
                        return;
                    }

                    if(!response)
                    {
                        return;
                    }
                    var userinfo = JSON.parse(response);
                    if(!userinfo)
                    {
                        return;
                    }

                    var userid = userinfo.userid;
                    User_Info_Mng.GetInstance().On_Readed_Server_UserID(userid);
                }
            );
        }
        

        */
        GlobalConfig.GetIns().Save_All_Info();
 
        
    }
    FD_Timer()
    {
        this.Refresh_Info();
        this.Refresh_Hongdian(); 
 
    }

    YD_Lingqu_GK_2_Jiangli(callback)
    {
        /*
        var awrad = [
            {
                "t":1,
                "c":50
            },
            {
                "t":11,
                "c":1
            }
        ];

        if(GlobalConfig.GetIns().m_last_lingqued_bx_guoguang_gk  < 2)
        {

            GlobalConfig.GetIns().Common_Add_Award_List(awrad);
        }

        ComFunc.Open_Get_Daoju_Award_Dlg(this.node,awrad,1,callback);
        GlobalConfig.GetIns().m_last_lingqued_bx_guoguang_gk = 2;
        this.Refresh_Info();

*/
    }
     
    Refresh_LuckDraw_Info()
    {
        var left_t_label = cc.find("top/menu/choujiang/t",this.node);

        var left_info = GlobalGameMng.GetInstance().Get_LuckDraw_Save_Data();

        
        if(left_info.cjcount >= 10)
        {
            left_t_label.getComponent(cc.Label).string = "已抽完";
            return;
        }
     
        var ineed_eplase_sec = ComFunc.Get_Choujiang_Mianfei_Need_Sec();
        
        var curday_last_luckdraw_finished_elapse_sec = GlobalGameMng.GetInstance().m_curday_last_luckdraw_finished_elapse_sec;

        if(curday_last_luckdraw_finished_elapse_sec >= ineed_eplase_sec)
        {
            left_t_label.getComponent(cc.Label).string = "可抽取";
            return;
        }


        var lefsec = Math.ceil(ineed_eplase_sec - curday_last_luckdraw_finished_elapse_sec);
        left_t_label.getComponent(cc.Label).string =  ComFunc.FormatLeftSecStr(lefsec);
      
    }
    Refresh_Info()
    { 
 
     
        var addjinbi_c = cc.find("top/addjinbi/c",this.node)
        addjinbi_c.getComponent(cc.Label).string = "" + GlobalConfig.GetIns().Get_Self_DestType_Daoju_Count(1);


        var addxingxing_c = cc.find("top/addxingxing/c",this.node)
        addxingxing_c.getComponent(cc.Label).string = "" + GlobalConfig.GetIns().Get_Self_DestType_Daoju_Count(2);


        var zuanshi_c_label = cc.find("top/add_zuanshi/c",this.node)
        zuanshi_c_label.getComponent(cc.Label).string = ""+GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(5);
        
        var chuizi_c_label = cc.find("top/add_chuizi/c",this.node)
        chuizi_c_label.getComponent(cc.Label).string = ""+GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(6);
      
        var curcapter = ZhuangXiu_Mng.GetInstance().Get_Cur_Zhuangxiu_Capter();
        var cur_zx_count = ZhuangXiu_Mng.GetInstance().Get_Capter_Zhuangxiued_Count(curcapter);
        var  cur_capter_name = ZhuangXiu_Mng.GetInstance().Get_Capter_Name(curcapter);


        var gk_name = cc.find("top/capterinfo/gk",this.node)
        gk_name.getComponent(cc.Label).string = "第 "+curcapter+" 章 "+cur_capter_name;
        
        var iprogress = cur_zx_count/20;
            

        var jindu_c_label = cc.find("top/capterinfo/jindu/c",this.node)
        jindu_c_label.getComponent(cc.Label).string = cur_zx_count + "/20";

        var jindu_bar = cc.find("top/capterinfo/jindu/bar",this.node)
        jindu_bar.getComponent(cc.Sprite).fillRange = iprogress;

  
        var not_lingqued_c  = ZhuangXiu_Mng.GetInstance().Get_Not_Lignqued_Jiangli_Capter_Count();
        var kelingqu_node = cc.find("top/capterinfo/jindu/libaobtn/kelingqu",this.node)
      
        if(not_lingqued_c > 0)
        {
            kelingqu_node.active = true;
        }else{
            kelingqu_node.active = false;
        }
        

         
  

        this.Refresh_GK_Info();
        
        this.Refresh_Online_Libao_Info();
    }

    Refresh_GK_Info()
    {
        var sanxiaoxiao_imaxlv = GSXC_Game_Mng.GetInstance().Get_Max_Can_Enter_GK();

        var sanxiaoxiao_lv_label = cc.find("bottoms/chuanguangmoshi/gk",this.node)
        sanxiaoxiao_lv_label.getComponent(cc.Label).string = "第"+sanxiaoxiao_imaxlv+"关"
        
        var first_free_tiaozhan_count = TiaozhanChang_Mng.GetInstance().Get_Curday_Can_First_Free_Tiaozhan_Count();
        var sanxiao_tiaozhan_cishu = TiaozhanChang_Mng.GetInstance().Get_SubgameType_CurDay_Tiaozhan_Count(9);
        var sanxiao_tiaozhan_suc_cishu = TiaozhanChang_Mng.GetInstance().Get_TiaozhanChang_Curday_Success_Count(9);

        var sanxiaoxiao_free_node = cc.find("bottoms/meiritiaozhan/free",this.node)
        var sanxiaoxiao_shengyu_node = cc.find("bottoms/meiritiaozhan/shengyu",this.node);
        var sanxiaoxiao_shengyu_leftc_label  = cc.find("leftc",sanxiaoxiao_shengyu_node)
        var sanxiaoxiao_invalid_node = cc.find("bottoms/meiritiaozhan/invalid",this.node)
       

        sanxiaoxiao_invalid_node.active = false;
        sanxiaoxiao_shengyu_node.active = false;
        sanxiaoxiao_free_node.active = true;

        var sanxiaoxiao_Can_free_left_c=  first_free_tiaozhan_count-sanxiao_tiaozhan_cishu;


        sanxiaoxiao_free_node.getComponent(cc.Label).string = "挑战:"+sanxiao_tiaozhan_cishu+",成功:"+sanxiao_tiaozhan_suc_cishu+"";
     

        /*
        if(sanxiao_tiaozhan_cishu >= 5+ first_free_tiaozhan_count)
        {
            sanxiaoxiao_invalid_node.active = true;
            sanxiaoxiao_shengyu_node.active = false;
            sanxiaoxiao_free_node.active = false;
        } 
        else if(sanxiao_tiaozhan_cishu >= first_free_tiaozhan_count)
        {
            sanxiaoxiao_invalid_node.active = false;
            sanxiaoxiao_shengyu_node.active = true;
            sanxiaoxiao_free_node.active = false;

            var sanxiaoxiao_shengyu_shiping_use_cishu = sanxiao_tiaozhan_cishu - first_free_tiaozhan_count;
            var sanxiaoxiao_shengyu_Can_shiping_cishu = 5- sanxiaoxiao_shengyu_shiping_use_cishu;

            sanxiaoxiao_shengyu_leftc_label.getComponent(cc.Label).string = "免费:"+sanxiaoxiao_shengyu_Can_shiping_cishu+"/5";
            
        }else{

            sanxiaoxiao_invalid_node.active = false;
            sanxiaoxiao_shengyu_node.active = false;
            sanxiaoxiao_free_node.active = true;

            var sanxiaoxiao_Can_free_left_c=  first_free_tiaozhan_count-sanxiao_tiaozhan_cishu;

            sanxiaoxiao_free_node.getComponent(cc.Label).string = "今日免费:"+sanxiaoxiao_Can_free_left_c+"/"+first_free_tiaozhan_count;
         
        }
        */


        var huaduoxiaoxiao_imaxlv =  GlobalConfig.GetIns().Get_Game_Mode_Enter_Gk(2)

        var huaduoxiaoxiao_lv_label = cc.find("bottoms/huaduoxiaoxiao/gk",this.node)
        huaduoxiaoxiao_lv_label.getComponent(cc.Label).string = "第"+huaduoxiaoxiao_imaxlv+"关"
        


        var huaduoxiaoxiao_tiaozhan_cishu = TiaozhanChang_Mng.GetInstance().Get_SubgameType_CurDay_Tiaozhan_Count(31);
        var huaduoxiaoxiao_tiaozhan_suc_cishu = TiaozhanChang_Mng.GetInstance().Get_TiaozhanChang_Curday_Success_Count(31);

        var huaduoxiaoxiao_free_node = cc.find("bottoms/huaduo_tiaozhanchang/free",this.node)
        var huaduoxiaoxiao_shengyu_node = cc.find("bottoms/huaduo_tiaozhanchang/shengyu",this.node);
        var huaduoxiaoxiao_shengyu_leftc_label  = cc.find("leftc",huaduoxiaoxiao_shengyu_node)
        var huaduoxiaoxiao_invalid_node = cc.find("bottoms/huaduo_tiaozhanchang/invalid",this.node)
       

        huaduoxiaoxiao_invalid_node.active = false;
        huaduoxiaoxiao_shengyu_node.active = false;
        huaduoxiaoxiao_free_node.active = true;

        var huaduoxiaoxiao_Can_free_left_c=  first_free_tiaozhan_count-huaduoxiaoxiao_tiaozhan_cishu;

        huaduoxiaoxiao_free_node.getComponent(cc.Label).string =  "挑战:"+huaduoxiaoxiao_tiaozhan_cishu+",成功:"+huaduoxiaoxiao_tiaozhan_suc_cishu+"";
     
        /*
        if(huaduoxiaoxiao_tiaozhan_cishu >= 5+first_free_tiaozhan_count)
        {
            huaduoxiaoxiao_invalid_node.active = true;
            huaduoxiaoxiao_shengyu_node.active = false;
            huaduoxiaoxiao_free_node.active = false;
        } 
        else if(huaduoxiaoxiao_tiaozhan_cishu >= first_free_tiaozhan_count)
        {
            huaduoxiaoxiao_invalid_node.active = false;
            huaduoxiaoxiao_shengyu_node.active = true;
            huaduoxiaoxiao_free_node.active = false;

            var huaduoxiaoxiao_shengyu_shiping_use_cishu = huaduoxiaoxiao_tiaozhan_cishu - first_free_tiaozhan_count;
            var huaduoxiaoxiao_shengyu_Can_shiping_cishu = 5- huaduoxiaoxiao_shengyu_shiping_use_cishu;

            huaduoxiaoxiao_shengyu_leftc_label.getComponent(cc.Label).string = "免费:"+huaduoxiaoxiao_shengyu_Can_shiping_cishu+"/5";
            
        }else{

            huaduoxiaoxiao_invalid_node.active = false;
            huaduoxiaoxiao_shengyu_node.active = false;
            huaduoxiaoxiao_free_node.active = true;

            var huaduoxiaoxiao_Can_free_left_c=  first_free_tiaozhan_count-huaduoxiaoxiao_tiaozhan_cishu;

            huaduoxiaoxiao_free_node.getComponent(cc.Label).string = "今日免费:"+huaduoxiaoxiao_Can_free_left_c+"/"+first_free_tiaozhan_count;
         
        }
        */
 


        var guaishouxiaoxiao_imaxlv =  GlobalConfig.GetIns().Get_Game_Mode_Enter_Gk(4)

        var guaishouxiaoxiao_lv_label = cc.find("bottoms/guaishouxiaoxiao/gk",this.node)
        guaishouxiaoxiao_lv_label.getComponent(cc.Label).string = "第"+guaishouxiaoxiao_imaxlv+"关"
        


        var guaishouxiaoxiao_tiaozhan_cishu = TiaozhanChang_Mng.GetInstance().Get_SubgameType_CurDay_Tiaozhan_Count(35);
        var guaishouxiaoxiao_tiaozhan_suc_cishu = TiaozhanChang_Mng.GetInstance().Get_TiaozhanChang_Curday_Success_Count(35);

        var guaishouxiaoxiao_free_node = cc.find("bottoms/guaishouxiaoxiao_tiaozhanchang/free",this.node)
        var guaishouxiaoxiao_shengyu_node = cc.find("bottoms/guaishouxiaoxiao_tiaozhanchang/shengyu",this.node);
        var guaishouxiaoxiao_shengyu_leftc_label  = cc.find("leftc",guaishouxiaoxiao_shengyu_node)
        var guaishouxiaoxiao_invalid_node = cc.find("bottoms/guaishouxiaoxiao_tiaozhanchang/invalid",this.node)
       
        guaishouxiaoxiao_invalid_node.active = false;
        guaishouxiaoxiao_shengyu_node.active = false;
        guaishouxiaoxiao_free_node.active = true;

        var guaishouxiaoxiao_Can_free_left_c=  first_free_tiaozhan_count-guaishouxiaoxiao_tiaozhan_cishu;

        guaishouxiaoxiao_free_node.getComponent(cc.Label).string =  "挑战:"+guaishouxiaoxiao_tiaozhan_cishu+",成功:"+guaishouxiaoxiao_tiaozhan_suc_cishu+"";
     
        /*
        if(guaishouxiaoxiao_tiaozhan_cishu >= 5+ first_free_tiaozhan_count)
        {
            guaishouxiaoxiao_invalid_node.active = true;
            guaishouxiaoxiao_shengyu_node.active = false;
            guaishouxiaoxiao_free_node.active = false;
        } 
        else if(guaishouxiaoxiao_tiaozhan_cishu >= first_free_tiaozhan_count)
        {
            guaishouxiaoxiao_invalid_node.active = false;
            guaishouxiaoxiao_shengyu_node.active = true;
            guaishouxiaoxiao_free_node.active = false;

            var guaishouxiaoxiao_shengyu_shiping_use_cishu = guaishouxiaoxiao_tiaozhan_cishu - first_free_tiaozhan_count;
            var guaishouxiaoxiao_shengyu_Can_shiping_cishu = 5- guaishouxiaoxiao_shengyu_shiping_use_cishu;

            guaishouxiaoxiao_shengyu_leftc_label.getComponent(cc.Label).string = "免费:"+guaishouxiaoxiao_shengyu_Can_shiping_cishu+"/5";
            
        }else{

            guaishouxiaoxiao_invalid_node.active = false;
            guaishouxiaoxiao_shengyu_node.active = false;
            guaishouxiaoxiao_free_node.active = true;

            var guaishouxiaoxiao_Can_free_left_c=  first_free_tiaozhan_count-guaishouxiaoxiao_tiaozhan_cishu;

            guaishouxiaoxiao_free_node.getComponent(cc.Label).string = "今日免费:"+guaishouxiaoxiao_Can_free_left_c+"/"+first_free_tiaozhan_count;
         
        }
        */
 
        

        var luosi_paixu_tiaozhan_cishu = TiaozhanChang_Mng.GetInstance().Get_SubgameType_CurDay_Tiaozhan_Count(21);
        var luosi_paixu_tiaozhan_suc_cishu = TiaozhanChang_Mng.GetInstance().Get_TiaozhanChang_Curday_Success_Count(21);

        var luosi_paixu_free_node = cc.find("bottoms/luosi_paixu_tiaozhan/free",this.node)
        var luosi_paixu_shengyu_node = cc.find("bottoms/luosi_paixu_tiaozhan/shengyu",this.node);
        var luosi_paixu_shengyu_leftc_label  = cc.find("leftc",luosi_paixu_shengyu_node)
        var luosi_paixu_invalid_node = cc.find("bottoms/luosi_paixu_tiaozhan/invalid",this.node)
       
        luosi_paixu_invalid_node.active = false;
        luosi_paixu_shengyu_node.active = false;
        luosi_paixu_free_node.active = true;

        var luosi_paixu_Can_free_left_c=  first_free_tiaozhan_count-luosi_paixu_tiaozhan_cishu;

        luosi_paixu_free_node.getComponent(cc.Label).string = "挑战:"+luosi_paixu_tiaozhan_cishu+",成功:"+luosi_paixu_tiaozhan_suc_cishu+"";
     

        /*
        if(luosi_paixu_tiaozhan_cishu >= 5+ first_free_tiaozhan_count)
        {
            luosi_paixu_invalid_node.active = true;
            luosi_paixu_shengyu_node.active = false;
            luosi_paixu_free_node.active = false;
        } 
        else if(luosi_paixu_tiaozhan_cishu >= first_free_tiaozhan_count)
        {
            luosi_paixu_invalid_node.active = false;
            luosi_paixu_shengyu_node.active = true;
            luosi_paixu_free_node.active = false;

            var luosi_paixu_shengyu_shiping_use_cishu = luosi_paixu_tiaozhan_cishu - first_free_tiaozhan_count;
            var luosi_paixu_shengyu_Can_shiping_cishu = 5- luosi_paixu_shengyu_shiping_use_cishu;

            luosi_paixu_shengyu_leftc_label.getComponent(cc.Label).string = "免费:"+luosi_paixu_shengyu_Can_shiping_cishu+"/5";
            
        }else{

            luosi_paixu_invalid_node.active = false;
            luosi_paixu_shengyu_node.active = false;
            luosi_paixu_free_node.active = true;

            var luosi_paixu_Can_free_left_c=  first_free_tiaozhan_count-luosi_paixu_tiaozhan_cishu;

            luosi_paixu_free_node.getComponent(cc.Label).string = "今日免费:"+luosi_paixu_Can_free_left_c+"/"+first_free_tiaozhan_count;
         
        }

        */


        var luosi_hecheng_gk_label = cc.find("bottoms/luosi_hecheng/gk",this.node)
      
         var last_tishi_shuzi_d = Luosi_Game_Mng.GetInstance().m_luosi_hecheng_max_show_shuzi_gk_tishied;
         var last_win_gk = Luosi_Game_Mng.GetInstance().m_last_win_luosi_hecheng_gk;
         if(last_win_gk <= 0)
         {
            last_win_gk=  5;
         }
 
         var imax_show_hecheng_shuzi  = last_tishi_shuzi_d;
         if(last_win_gk > imax_show_hecheng_shuzi)
         {
            imax_show_hecheng_shuzi=  last_win_gk;
         }
         luosi_hecheng_gk_label.getComponent(cc.Label).string = "最大数:"+imax_show_hecheng_shuzi;


    }
    Post_Read_Shetuan_Info()
    {
        var self = this;

       
            
    }
     
    OnBtnYaoqing()
    {
        if(this.Is_In_Yindao())
        {
            return;
        }
        var self = this;
        var pndoe = cc.instantiate(this.yaoqing_dlg);
        var yaoqing_dlg = pndoe.getComponent("yaoqing_dlg");
        yaoqing_dlg.SetInfo(

            {
                callback:()=>
                {
                    self.Refresh_Info();
                }
            }
        )
        this.node.addChild(pndoe,100);
    }

    OnBtnTiaozhanchang_Zhanji()
    {
        var self = this;
        var pndoe = cc.instantiate(this.tiaozhanchang_zhanji_dlg);
        var tiaozhanchang_zhanji_dlg = pndoe.getComponent("tiaozhanchang_zhanji_dlg");
        tiaozhanchang_zhanji_dlg.SetInfo(

            {
                callback:()=>
                {
                    self.Refresh_Info();
                }
            }
        )
        this.node.addChild(pndoe,100);
    }
    OnBtnTest()
    {
        var self = this;
        var pndoe = cc.instantiate(this.test_mng);
        var test_mng = pndoe.getComponent("test_mng");
        test_mng.SetInfo(

            {
                callback:()=>
                {
                    self.Refresh_Info();
                }
            }
        )
        this.node.addChild(pndoe,100);
    }
    OnBtnSC()
    {
        if(this.Is_In_Yindao())
        {
            return;
        }
        var self = this;
        var pndoe = cc.instantiate(this.shangcheng_new);
        var shangcheng_new = pndoe.getComponent("shangcheng_new");
        shangcheng_new.SetInfo(

            {
                callback:()=>
                {
                    self.Refresh_Info();
                }
            }
        )
        this.node.addChild(pndoe,100);
    }
  

    OnBtnMoreWanfa()
    {
        if(this.Is_In_Yindao())
        {
            return;
        }
      

        var self = this;
        var pndoe = cc.instantiate(this.dating_more_game);
        var dating_more_game = pndoe.getComponent("dating_more_game");
        dating_more_game.SetInfo(

            {
                callback:()=>
                {
                    self.Refresh_Info();
                }
            }
        )
        this.node.addChild(pndoe,100);

         
        SoundManager.GetInstance().Play_Click_Btn_Effect();
    }
    OnBtnJinduLibao()
    {
        var not_lingqued_c  = ZhuangXiu_Mng.GetInstance().Get_Not_Lignqued_Jiangli_Capter_Count();

        if(not_lingqued_c > 0)
        {

            var jlc =[{
                "t":6,
                "c":1
            },
            {
                "t":5,
                "c":100
            }]


            ZhuangXiu_Mng.GetInstance().On_Lingqued_Capter_Jiangli();
            GlobalGameMng.GetInstance().Add_DaojuType_Count_List(jlc,not_lingqued_c);
            ComFunc.Open_Get_Daoju_Award_Dlg(this.node, jlc, not_lingqued_c, ()=>{});
       

            this.Refresh_Info();
 
            return;
        }

        var tishi = cc.find("top/capterinfo/jindu/tishi",this.node);
        tishi.active = true;

        var pseq = cc.sequence(cc.delayTime(4),cc.callFunc(()=>
        {
            tishi.active = false;

        }));

        this.node.runAction(pseq);
    }
    OnBtnPaiHangBang()
    {
        if(this.Is_In_Yindao())
        {
            return;
        }

        /*
        var self = this;
        var pndoe = cc.instantiate(this.paihangbang_dlg);
        var huaduo_paihangbang_dlg = pndoe.getComponent("huaduo_paihangbang_dlg");
        huaduo_paihangbang_dlg.SetInfo(

            {
                callback:()=>
                {
                    self.Refresh_Info();
                }
            }
        )
        this.node.addChild(pndoe,100);

        */

          
        var self = this;
        var pndoe = cc.instantiate(this.select_paihang_type);
        var select_paihang_type:select_paihang_type = pndoe.getComponent("select_paihang_type");
        select_paihang_type.SetInitData(

            {
                cb:(iseltype)=>
                {

                    self.OnSelectPaihangbangType(iseltype);
                    
                }
            }
        )
        this.node.addChild(pndoe,100);


        
    }
    OnSelectPaihangbangType(iseltype)
    {
        if(iseltype == 0)
        {
            return;
        }
            

       
        var self = this;
        var pndoe = cc.instantiate(this.paihangbang);
        var paihangbang:select_paihang_type = pndoe.getComponent("paihangbang");
        paihangbang.SetInitData(

            {
                
                iseltype:iseltype,
                cb:(chooseother)=>
                {

                    if(chooseother > 0)
                    {
                        self.OnBtnPaiHangBang();
                    }
                     
                }
            }
        )
        this.node.addChild(pndoe,100);

         
    }
      

    OnBtnQiandao( )
    {
        /*
        if(this.Is_In_Yindao())
        {
            return;
        } */
        this.Real_Pop_Qiandao(0)
       
    }
    Real_Pop_Qiandao(bfromydao)
    {
      
        var self = this;
        var pndoe = cc.instantiate(this.qiandaoSign);
        var huaduo_qiandaoSign = pndoe.getComponent("huaduo_qiandaoSign");
        huaduo_qiandaoSign.SetInfo(

            {
                callback:()=>
                {
                    self.Refresh_Info();

                    if(bfromydao)
                    {
                        self.Check_First_Time_Libao_Show();
                    }
                   
                }
            }
        )
        this.node.addChild(pndoe,100);

        if(bfromydao)
        {

        }else{
            SoundManager.GetInstance().Play_Click_Btn_Effect();
        }
        
     
    }
    
     
    
    update(dt)
    {
       // GameTaskMng.GetIns().Update_Tick(dt);
        GlobalConfig.GetIns().Update_Tick(dt);
        TiaozhanChang_Mng.GetInstance().Update_Tick(dt);

        GlobalGameMng.GetInstance().On_Update(dt)
    }
    OnBtnXingyunLibao()
    {

        
        this.Real_Pop_Xingyun_Libao(0);
    }
    On_Libao_Finished()
    {

    }
    OnBtnAddZhuomian()
    {
        var self  = this;
        var pndoe = cc.instantiate(this.add_zhuomian_dlg);
        var add_zhuomian_dlg = pndoe.getComponent("add_zhuomian_dlg");
        add_zhuomian_dlg.SetInitData(
            {
                
                cb:()=>
                {
                    self.Refresh_Info();
                }
            }

        );
        this.node.addChild(pndoe,20);
    }
    OnBtnShoucangYouxi()
    {
        var self  = this;
        var pndoe = cc.instantiate(this.shoucang_dlg);
        var shoucang_dlg = pndoe.getComponent("shoucang_dlg");
        shoucang_dlg.SetInitData(
            {
                
                cb:()=>
                {
                    self.Refresh_Info();
                }
            }

        );
        this.node.addChild(pndoe,20);
    }

    Real_Show_Zaixian_libao_Dlg()
    {
        var self  = this;
        var pndoe = cc.instantiate(this.zaixianlibao_dlg);
        var zaixianlibao_dlg = pndoe.getComponent("zaixianlibao_dlg");
        zaixianlibao_dlg.SetInitData(
            {
                
                cb:()=>
                {
                    self.Refresh_Info();
                }
            }

        );
        this.node.addChild(pndoe,20);
    }
    OnBtn_OnLine_Reward()
    {
      
        this.Real_Show_Zaixian_libao_Dlg();

        
    }

    
    Check_Show_Zaixian_Libao()
    {
        var left_info = GlobalGameMng.GetInstance().Get_Cur_Day_OnLine_Libao_Left_Sec_Info();
        if(!left_info[0])
        { 
            return false;
        }
        var ileftsec = left_info[1];
 
        if(ileftsec  > 0)
        {
            return false;
        }

        this.Real_Show_Zaixian_libao_Dlg();

        return true;
    }
    Refresh_Online_Libao_Info()
    {
        var left_t_label = cc.find("top/menu/zaixianlibao/t",this.node);

        var left_info = GlobalGameMng.GetInstance().Get_Cur_Day_OnLine_Libao_Left_Sec_Info();
        if(!left_info[0])
        {
            left_t_label.getComponent(cc.Label).string = "领取完毕";
            return;
        }

        var ileftsec = left_info[1];
 
        if(ileftsec <= 0)
        {
            left_t_label.getComponent(cc.Label).string = "可领取";
     
        }else{
            left_t_label.getComponent(cc.Label).string = ComFunc.FormatLeftSecStr(ileftsec)
     
        }
     

    }
    Real_Pop_Xingyun_Libao(bfromydao)
    {
        var self = this;
        var pndoe = cc.instantiate(this.xingyunlibao_dlg);
        var xingyunlibao_dlg = pndoe.getComponent("xingyunlibao_dlg");
        xingyunlibao_dlg.SetInfo(

            {
                callback:()=>
                {
                    self.On_Libao_Finished();
                    self.Refresh_Info();
                }
            }
        )
        this.node.addChild(pndoe,100);

        if(bfromydao)
        {

        }else{
            SoundManager.GetInstance().Play_Click_Btn_Effect();
        }
        
    }
    Check_First_Time_Libao_Show()
    {

        if(GlobalConfig.GetIns().m_xingyun_libao_lingqued)
        {
            
            return;
        }
        var poped = GlobalConfig.GetIns().m_b_first_libao_dlg_poped ;
        if(poped)
        {
            return;
        }

        GlobalConfig.GetIns().m_b_first_libao_dlg_poped = 1;

        this.Real_Pop_Xingyun_Libao(1);
    }

    IS_First_Dating_Enter()
    {
        var strshaonaomukuai_first_enter_dating = "guaishoudaxiaochu_first_enter_dating";
        var strsave = MyLocalStorge.getItem(strshaonaomukuai_first_enter_dating);

        if(strsave && strsave == "1")
        {
            return false;
        }

        MyLocalStorge.setItem(strshaonaomukuai_first_enter_dating,"1");

        return true;
    }
    
    Check_First_Show_Pop_Dlg()
    {
    
        var bshowqiandao = this.Check_Show_Pop_Qiandao_Dlg();

        if(!bshowqiandao)
        {
            var bshow_zaixianlibao = this.Check_Show_Zaixian_Libao();

            if(!bshow_zaixianlibao)
            {
                this.Check_Show_Choujiang_Info();
            }
        }

    }

    Check_Show_Choujiang_Info()
    {
        
        var left_info = GlobalGameMng.GetInstance().Get_LuckDraw_Save_Data();

        

        if(left_info.cjcount >= 10)
        { 
            return false;
        }
        return false;

        /*
        var ineed_eplase_sec = ComFunc.Get_Choujiang_Mianfei_Need_Sec();
        
        var curday_last_luckdraw_finished_elapse_sec = GlobalGameMng.GetInstance().m_curday_last_luckdraw_finished_elapse_sec;

        if(curday_last_luckdraw_finished_elapse_sec < ineed_eplase_sec)
        { 
            return  false;
        }


        this.OnBtn_ChouJiang();
        return true;
        */
    }
    Check_Show_Pop_Qiandao_Dlg()
    {
    

        if(this.IS_First_Dating_Enter())
        {
            if(GlobalGameMng.GetInstance().IS_First_Enter_Dating_Hide_Qiandao())
            {
                return false;
            }
        }

       
        //接下来判断需要不需要再弹出来签到弹框
        var curday_Can_sign = GlobalConfig.GetIns().Is_CurDay_Can_Sign();
     
        if(!curday_Can_sign)
        {
            return false;
        }


        var dlg_tanchu_type = GlobalGameMng.GetInstance().Get_Qiandao_Dlg_Tachu_Type();
        var itanchu_per_gk = GlobalGameMng.GetInstance().Get_Qiandao_Dlg_Tachu_Per_GK();
 
       
        if(GlobalGameMng.GetInstance().m_b_first_sign_dlg_poped)
        {
            return false;
        }
       
        GlobalGameMng.GetInstance().m_b_first_sign_dlg_poped = true;
        this.Real_Pop_Qiandao(1)

        return true;
  
          
    }
    On_Yingdao_Finished_Event()
    {

        /*
        this.Set_Main_Dt_Yingdao_Finished();
               
        this.m_b_cur_gk_step_finished = 1;
 
      
        */
       // this.Check_Show_Pop_Qiandao_Dlg();
    }

    Start_Zhiying()
    {
        /*
        if(this.m_b_cur_gk_step_finished)
        {
            
            this.On_Yingdao_Finished_Event();
            return;
        }

     
        var zhiiyng_steps = this.m_cur_gk_zhiying_step_info_list;
       

        if(!zhiiyng_steps)
        {
            zhiiyng_steps = [];
        }  

 

        var bneed_zhiying_cur = 1;
        
             

        if(bneed_zhiying_cur)
        {
            if(zhiiyng_steps && zhiiyng_steps.length  > 0)
            {
                this.m_b_cur_gk_step_finished = 0;
                this.m_i_cur_gk_zhiying_step = 1;
    
    
                this.Check_Cur_Zhiying_Step_Start();
            }else{
    
                this.On_Yingdao_Finished_Event();
    
              
            }
        }else{
            this.On_Yingdao_Finished_Event();
     
        }
        */
        
    }
    
    Set_Main_Dt_Yingdao_Finished()
    {
        var imax_win_gk = GlobalConfig.GetIns().m_max_win_gk
    
        
        cc.sys.localStorage.setItem("huadouxiaoxiao_main_dt_yd_finished_"+imax_win_gk,"1");
    }
    Get_Main_Dt_Yingdao_Finished(imax_win_gk)
    {
        var stre = cc.sys.localStorage.getItem("huadouxiaoxiao_main_dt_yd_finished_"+imax_win_gk);
        if(!stre)
        {
            return false;
        }

        if(stre == "1")
        {
            return true;
        }
        return false;
    }

    Check_Cur_Zhiying_Step_Start()
    {
        /*
        if(this.m_b_cur_gk_step_finished)
        {
            return;
        }
        if(this.m_i_cur_gk_zhiying_step > this.m_cur_gk_zhiying_step_info_list.length)
        {
            this.On_Yingdao_Finished_Event();


            return;
        }

        var cur_step__action_info = this.m_cur_gk_zhiying_step_info_list[this.m_i_cur_gk_zhiying_step - 1];
       
        var delaypop = cur_step__action_info.delaypop;
        if(!delaypop)
        {
            delaypop = 0;
        }
        var step_action = cur_step__action_info.action;
        var acm = cur_step__action_info.acm;
        this.m_cur_gk_cur_step_action_finished = 0;
        var showtip = cur_step__action_info.showtip;
        var needkuangshi = cur_step__action_info.needkuangshi;
        var popdlgactionlist = cur_step__action_info.popdlgactionlist;
        
        if(!needkuangshi)
        {
            needkuangshi = 0;
        }
        
      
        var self = this;

        if(step_action == 1)
        {
            var pseq = cc.sequence(cc.delayTime(delaypop),cc.callFunc(()=>
            {

                self.ShowGuidTip(  showtip, () => { 
                   
                    self.FD_ChangeTo_Next_Step_Zhiying();
               
               }); 
            
            }));
        

             
            this.node.runAction(pseq);
             
        }
        else if(step_action == 4)
        {
            var jindu_1_btn = cc.find("jindu/1",this.node);
            
            YDActionMng.getInstance().ShowShouzhiYingdao_P(this.shouzhiZhiyingDlg,this.node,jindu_1_btn,()=>
            {
                 
                   
                self.FD_ChangeTo_Next_Step_Zhiying();
            });


        }  
        else if(step_action == 6)
        {


            this.YD_Lingqu_GK_2_Jiangli( ()=>
            { 
                   
                self.FD_ChangeTo_Next_Step_Zhiying();
            });
        }
        else if(step_action == 7)
        {
            var jchengjiu_btn = cc.find("rightmenu/chengjiu",this.node);
            
            YDActionMng.getInstance().ShowShouzhiYingdao_P(this.shouzhiZhiyingDlg,this.node,jchengjiu_btn,()=>
            {
                 
                   
                self.FD_ChangeTo_Next_Step_Zhiying();
            });


        }  
        else if(step_action == 8)
        {
          
            var pndoe = cc.instantiate(this.chengjiu_dlg);
            var chengjiu_dlg = pndoe.getComponent("chengjiu_dlg");
            chengjiu_dlg.SetInfo(
    
                {
                    byingdao:1,
                    popdlgactionlist:popdlgactionlist,
                    callback:()=>
                    {
                        self.Refresh_Info(); 
                   
                        self.FD_ChangeTo_Next_Step_Zhiying();
                    }
                }
            )
            this.node.addChild(pndoe,100);

        } else if(step_action == 99)
        {
            YDActionMng.getInstance().Pop_DelayTime_Dlg_P(this.delaytimeDlg, this.node,delaypop,()=>
            {
                 self.FD_ChangeTo_Next_Step_Zhiying();
   
               
            });

        }  
        else if(step_action == 21)
        {
            var menghuanhuayuan_btn = cc.find("rightmenu/menghuanhuayuan_btn",this.node);
            
            YDActionMng.getInstance().ShowShouzhiYingdao_P(this.shouzhiZhiyingDlg,this.node,menghuanhuayuan_btn,()=>
            { 
                self.FD_ChangeTo_Next_Step_Zhiying();
            });
        }
        else if(step_action == 22)
        {
 
            var pndoe = cc.instantiate(this.menghuan_huayuan_dlg);
            var menghuan_huayuan_dlg = pndoe.getComponent("menghuan_huayuan_dlg");
            menghuan_huayuan_dlg.SetInfo(
    
                {   
                    byingdao:1,
                    popdlgactionlist:popdlgactionlist,
                    callback:()=>
                    {
                        self.Refresh_Info();
                        self.FD_ChangeTo_Next_Step_Zhiying();
   
                    }
                }
            )
            this.node.addChild(pndoe,100);
        }
        */
        
    }
    FD_ChangeTo_Next_Step_Zhiying()
    {
        /*
        this.m_i_cur_gk_zhiying_step++;
        this.Check_Cur_Zhiying_Step_Start();
        */
    }
    ShowGuidTip(stip,calback)
    { 
      //  YDActionMng.getInstance().Pop_Yingdao_TipInfo_Dlg_P(this.yingdao_tip_info_dlg ,this.node, stip,calback);
    
    }
   
    
 
}
