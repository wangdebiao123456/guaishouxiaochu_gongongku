import BaseUIUtils from "../../comfuncs/BaseUIUtils";
import ClientLogUtils from "../../comfuncs/ClientLogUtils";
import ComFunc from "../../comfuncs/ComFunc";
import SoundManager from "../../comfuncs/SoundManager";
import GlobalGameMng from "../../Mng/GlobalGameMng";
import ZhuangXiu_Mng from "../../Mng/ZhuangXiu_Mng";
import Util from "../../utils/Util";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class zhuangxiu extends cc.Component {

    @property(cc.Prefab)
    zhuangxiu_shouji_dlg:cc.Prefab = null;
  
    @property(cc.Prefab)
    zhuangxiu_anim:cc.Prefab = null;
  

    @property(cc.Prefab)
    shangcheng_new:cc.Prefab = null;
   

    
    m_cur_show_capter = 0;
    
    onLoad () 
    {

        var extbtn = cc.find("extbtn",this.node)
        extbtn.on("click",this.OnBtnExit.bind(this))

        var jindu_libaobtn = cc.find("top/capterinfo/jindu/libaobtn",this.node)
        jindu_libaobtn.on("click",this.OnBtnJinduLibao.bind(this))
      

        var zhuangxiubtn = cc.find("menu/zhuangxiubtn",this.node)
        zhuangxiubtn.on("click",this.OnBtnZhuangxiu.bind(this))
      
        
        var add_chuizi = cc.find("top/add_chuizi",this.node)
        add_chuizi.on("click",this.OnBtnSC.bind(this))
      

        var add_zuanshi = cc.find("top/add_zuanshi",this.node)
        add_zuanshi.on("click",this.OnBtnSC.bind(this))
      


        var shoujibtn = cc.find("menu/shoujibtn",this.node)
        shoujibtn.on("click",this.OnBtnShouji.bind(this))
      
        var cur_Capter = ZhuangXiu_Mng.GetInstance().Get_Cur_Zhuangxiu_Capter();
        this.m_cur_show_capter = cur_Capter;
        
        this.Refresh_Info();

        this.Check_Need_Libao_Btn_Effect()
    }
    OnBtnSC()
    { 
        var self = this;
        var pndoe = cc.instantiate(this.shangcheng_new);
        var shangcheng_new = pndoe.getComponent("shangcheng_new");
        shangcheng_new.SetInfo(

            {
                callback:()=>
                {
                    self.Refresh_Info();
                }
            }
        )
        this.node.addChild(pndoe,100);
    }
  
    Add_Pos_Anim(pos)
    {
        var pnode = cc.instantiate(this.zhuangxiu_anim);
        var anim_node = cc.find("center/anim",this.node)
        anim_node.addChild(pnode,20);
        anim_node.setPosition(pos);

        var w_node = pnode.getChildByName("w");

        var w_anim = w_node.getComponent(cc.Animation);
        w_anim.play();

        var pseq = cc.sequence(cc.delayTime(0.5),cc.callFunc(()=>
        {
            pnode.destroy();
        }))

        this.node.runAction(pseq);

        SoundManager.GetInstance().Play_Effect("com/levelUp")
    }
    OnBtnExit()
    {
        
        cc.director.loadScene("dating");
        
        SoundManager.GetInstance().Play_Click_Btn_Effect();
    }
    OnBtnJinduLibao()
    {   

        var not_lingqued_c  = ZhuangXiu_Mng.GetInstance().Get_Not_Lignqued_Jiangli_Capter_Count();

        if(not_lingqued_c > 0)
        {

            var jlc =[{
                "t":6,
                "c":1
            },
            {
                "t":5,
                "c":100
            }]


            ZhuangXiu_Mng.GetInstance().On_Lingqued_Capter_Jiangli();
            GlobalGameMng.GetInstance().Add_DaojuType_Count_List(jlc,not_lingqued_c);
            ComFunc.Open_Get_Daoju_Award_Dlg(this.node, jlc, not_lingqued_c, ()=>{});
            
            var cur_Capter = ZhuangXiu_Mng.GetInstance().Get_Cur_Zhuangxiu_Capter();
            this.m_cur_show_capter = cur_Capter;
            
    

            this.Refresh_Info();

            this.Check_Need_Libao_Btn_Effect();


            ClientLogUtils.GetInstance().Poset_Server_JS_Log(207, "领取装修礼包", this.m_cur_show_capter,
            "第:"+this.m_cur_show_capter+"章", 0, "", 0,  "");

            return;
        }


        var tishi = cc.find("top/capterinfo/jindu/tishi",this.node);
        tishi.active = true;

        var pseq = cc.sequence(cc.delayTime(4),cc.callFunc(()=>
        {
            tishi.active = false;

        }));

        this.node.runAction(pseq);
    }


    OnBtnShouji()
    {
           
        var self = this;
        var pndoe = cc.instantiate(this.zhuangxiu_shouji_dlg);
        var zhuangxiu_shouji_dlg = pndoe.getComponent("zhuangxiu_shouji_dlg");
        zhuangxiu_shouji_dlg.SetInitData(

            {
                cb:(iseltype)=>
                {

                    
                }
            }
        )
        this.node.addChild(pndoe,100);

        SoundManager.GetInstance().Play_Click_Btn_Effect();
    }

    Refresh_Info()
    {
        var curcapter = this.m_cur_show_capter;
        var cur_zx_count = ZhuangXiu_Mng.GetInstance().Get_Capter_Zhuangxiued_Count(curcapter);
        var  cur_capter_name = ZhuangXiu_Mng.GetInstance().Get_Capter_Name(curcapter);


        var gk_name = cc.find("top/capterinfo/gk",this.node)
        gk_name.getComponent(cc.Label).string = "第 "+curcapter+" 章 "+cur_capter_name;
        
        var iprogress = cur_zx_count/20;
            

        var jindu_c_label = cc.find("top/capterinfo/jindu/c",this.node)
        jindu_c_label.getComponent(cc.Label).string = cur_zx_count + "/20";

        var jindu_bar = cc.find("top/capterinfo/jindu/bar",this.node)
        jindu_bar.getComponent(cc.Sprite).fillRange = iprogress;

        var zuanshi_c_label = cc.find("top/add_zuanshi/c",this.node)
        zuanshi_c_label.getComponent(cc.Label).string = ""+GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(5);
        
        var chuizi_c_label = cc.find("top/add_chuizi/c",this.node)
        chuizi_c_label.getComponent(cc.Label).string = ""+GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(6);
       
        var cur_zx_need_chuizi_c = ZhuangXiu_Mng.GetInstance().Get_Capter_Index_Zhuangxiu_Need_Chuizi(curcapter,cur_zx_count);

        var zhuangxiubtn_c_label = cc.find("menu/zhuangxiubtn/c",this.node)
        zhuangxiubtn_c_label.getComponent(cc.Label).string = ""+cur_zx_need_chuizi_c;
        

       
        var not_lingqued_c  = ZhuangXiu_Mng.GetInstance().Get_Not_Lignqued_Jiangli_Capter_Count();
        var kelingqu_node = cc.find("top/capterinfo/jindu/libaobtn/kelingqu",this.node)
      
        if(not_lingqued_c > 0)
        {
            kelingqu_node.active = true;
        }else{
            kelingqu_node.active = false;
        }
        


        for(var ff=1;ff<=8;ff++)
        {
            var ff_center_node = cc.find("center/"+ff,this.node);

            if(!ff_center_node)
            {
                continue;
            }


            if(ff == curcapter)
            {
                ff_center_node.active = true;
            }else{
                ff_center_node.active = false;
            }
        }
        var cur_capter_node = cc.find("center/"+curcapter,this.node);

        if(cur_capter_node)
        {

            for(var gg=1;gg<=20;gg++)
            {
                var gg_ndoe = cc.find(""+gg,cur_capter_node);

                if(!gg_ndoe)
                {
                    continue;
                }

                if(cur_zx_count >= gg)
                {
                    gg_ndoe.active = true;
                }else{
                    gg_ndoe.active = false;
                }
            }
        }
    }

    OnBtnZhuangxiu()
    {
        var curcapter = this.m_cur_show_capter;

        if(curcapter >= 5)
        {
            BaseUIUtils.ShowTipTxtDlg("第5章正在开发中，敬请期待",this.node);
            return;
        }


        var cur_zx_count = ZhuangXiu_Mng.GetInstance().Get_Capter_Zhuangxiued_Count(curcapter);

        if(cur_zx_count >= 20)
        {
            BaseUIUtils.ShowTipTxtDlg("本章已装修完成",this.node);
            return;
        }
     
        var cur_zx_need_chuizi_c = ZhuangXiu_Mng.GetInstance().Get_Capter_Index_Zhuangxiu_Need_Chuizi(curcapter,cur_zx_count);

        var ihasc_chuizi = GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(6);

        if(ihasc_chuizi < cur_zx_need_chuizi_c)
        {
            BaseUIUtils.ShowTipTxtDlg("装修所需锤子不足",this.node);
            return;
        }

        var cur_capter_node = cc.find("center/"+curcapter,this.node);
        var inewindex = cur_zx_count+1;
        var show_node = cc.find("" + inewindex,cur_capter_node);


        GlobalGameMng.GetInstance().Change_Self_DaojuType_Count(6,-1*cur_zx_need_chuizi_c);
        ZhuangXiu_Mng.GetInstance().Add_Cur_Capter_Zhuangxiu_C(curcapter);

        this.Refresh_Info();

        if(show_node)
        {
            var pos = show_node.getPosition();

            this.Add_Pos_Anim(pos);


        }
        this.Check_Need_Libao_Btn_Effect();


        ClientLogUtils.GetInstance().Poset_Server_JS_Log(206, "装修成功", curcapter,
        "第:"+curcapter+"章", cur_zx_count, "装修序号:"+cur_zx_count, 0,  "");

    }
    Check_Need_Libao_Btn_Effect()
    {
        var libaobtn = cc.find("top/capterinfo/jindu/libaobtn",this.node)
     
        var not_lingqued_c  = ZhuangXiu_Mng.GetInstance().Get_Not_Lignqued_Jiangli_Capter_Count();

        if(not_lingqued_c == 0)
        {
            libaobtn.stopAllActions();
            libaobtn.setPosition(165,5);
            return;
        }

        libaobtn.stopAllActions();
        libaobtn.setPosition(165,5);

        var psq = cc.sequence(cc.moveBy(0.2,0,5),cc.moveBy(0.4,0,-10),cc.moveBy(0.2,0,5));
        var ptagrt = cc.repeatForever(psq);
        libaobtn.runAction(ptagrt)


    }


        
    update(dt)
    {
      
        GlobalGameMng.GetInstance().On_Update(dt)
    }
}
