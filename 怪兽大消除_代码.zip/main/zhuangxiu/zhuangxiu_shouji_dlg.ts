import ZhuangXiu_Mng from "../../Mng/ZhuangXiu_Mng";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class zhuangxiu_shouji_dlg extends cc.Component {

   
    
    
    
    onLoad () 
    {


        this.Refresh_Info();


    }
    SetInitData(paradata)
    {

    }
    Refresh_Info()
    {
        var cur_Capter = ZhuangXiu_Mng.GetInstance().Get_Cur_Zhuangxiu_Capter();
     
        for(var ff=1;ff<=8;ff++)
        {
            var ff_ndoe = cc.find("panel/sc/view/content/"+ff,this.node);

            var ff_name = ZhuangXiu_Mng.GetInstance().Get_Capter_Name(ff);

            var gk_label1 = cc.find("jindu/capterinfo/gk",ff_ndoe);
            var gk_label2 = cc.find("lock/capterinfo/gk",ff_ndoe);

            gk_label1.getComponent(cc.Label).string = "第 "+ff+" 章 "+ff_name;
            gk_label2.getComponent(cc.Label).string = "第 "+ff+" 章 "+ff_name;
            var ff_zx_count = ZhuangXiu_Mng.GetInstance().Get_Capter_Zhuangxiued_Count(ff);

            var lock_node = cc.find("lock",ff_ndoe);
            var jindu_node = cc.find("jindu",ff_ndoe);
          
            if(ff > cur_Capter)
            {
                lock_node.active = true;
                
                jindu_node.active = false;
            }
            else{

                lock_node.active = false;
                jindu_node.active = true;

                var jindu_Bar = cc.find("jindu/jindutiao_huang",jindu_node);
                var jindu_c_label  = cc.find("jindu/c",jindu_node);

                jindu_c_label.getComponent(cc.Label).string = ff_zx_count + "/20";
                var iprogress = ff_zx_count/20;
                jindu_Bar.getComponent(cc.Sprite).fillRange = iprogress;

            }



        }


    }
}
