 
const { ccclass, property } = cc._decorator;
@ccclass
export default class TilePoolMng {


    pools: any = {};
    resKey: any = {}

    initReadTiles(callback) 
    {
        //tile
        cc.resources.load('preab/Tile',  cc.Prefab, (e, res: cc.Prefab) => {

            this.resKey['Tile'] = res
            for (let i = 0; i < 100; i++) {
                let node = cc.instantiate(res)
                this.put('Tile', node)
            }
            callback&&callback()

        })
    }

    get(key: string) {
        if (this.pools[key] == null) {
            this.pools[key] = new cc.NodePool()
        }
        if (this.pools[key].size() > 0) {
            let node = this.pools[key].get();
            
            var tilenode = node.getComponent(node.name);
            tilenode.SetIs_Chaonan(false);
            return tilenode;
        }
        let node = cc.instantiate(this.resKey[key])
        var tilenode = node.getComponent(node.name);

        tilenode.SetIs_Chaonan(false);
        return tilenode;

    }
    put(key: string, node: cc.Node) {
        if (this.pools[key] == null) {
            this.pools[key] = new cc.NodePool()
        }
        this.pools[key].put(node)
    }


}


