import MyLocalStorge from "../WDT/MyLocalStorge";
import ComFunc from "../comfuncs/ComFunc"; 
import GS_GK_ConfigParse from "./GS_GK_ConfigParse";
import TilePoolMng from "./PoolManager";
import YYGKCreateMng from "./YYGKCreateMng";
import WMap from "../WDT/WMap";
import BundleLoadUtils from "../comfuncs/BundleLoadUtils";


export default class GSXC_Game_Mng
{
    static _instance:GSXC_Game_Mng = null;
    static GetInstance() 
    {
        if (!GSXC_Game_Mng._instance) {
            // doSomething
            GSXC_Game_Mng._instance = new GSXC_Game_Mng();
             
        }
        return GSXC_Game_Mng._instance;
    }

    m_readed_remote_gk_json=  null;
    constructor()
    {
      
        this.InitRead_Game_Basic_Info();
        this.InitRead_Game_Play_Last_Save_Data();


        this.Post_Read_Server_Config();

    }

    Post_Read_Server_Config(){
        var irand11 = Math.floor(Math.random()*1000) ;
        var config_json = "https://outercoms.zfgame123.com/config/guaishou_da_xiaochu/wx/chaonangk/guaishou_chaonan_level.json?r="+irand11;
 
        var self = this;
 
     
        cc.assetManager.loadRemote(config_json, (err, jobj:cc.JsonAsset) =>  
        {
            if(err)
            {
                self.m_readed_remote_gk_json = null;        
                console.log("加载配置错误:"+err)
                return;
            }
            self.m_readed_remote_gk_json =  jobj.json;
          
        });
    }
    Get_Init_Chaonan_GK_Block_Type_Count()
    {
        var local_default =   13;  

        if(!this.m_readed_remote_gk_json)
        {
            console.log("!this.m_readed_remote_gk_json block=15");
            return local_default;
        }


        var block_count_arr_count_min = this.m_readed_remote_gk_json.block_count_arr_count_min;
        var block_count_arr_count_max = this.m_readed_remote_gk_json.block_count_arr_count_max;

        if(!block_count_arr_count_min || !block_count_arr_count_max)
        {
            console.log("!block_count_arr_count_min || !block_count_arr_count_max");
          
            return local_default;
        }

        var icc = block_count_arr_count_min + Math.floor(Math.random()*(block_count_arr_count_max  - block_count_arr_count_min + 1));

        if(icc <= block_count_arr_count_min)
        {
            icc = block_count_arr_count_min;
        }
        if(icc >= block_count_arr_count_max)
        {
            icc = block_count_arr_count_max;
        }

        if(icc > 20)
        {
            icc = 20;
        }
        if(icc <= 5)
        {
            icc = 5;
        }

        console.log("block count icc="+icc);
        
        return icc;
    }

    Get_Init_First9_GK_Data()
    {
        var local_default = this.m_init_first_9_gk_data1; // this.m_gk_test1; // this.m_init_chaonan_gk_data1;//this.m_init_chaonan_gk_data1

        return local_default;
    }
    Get_Init_Chaonan_GK_Data()
    { 

        var local_default = this.m_init_chaonan_gk_data1; // this.m_gk_test1; // this.m_init_chaonan_gk_data1;//this.m_init_chaonan_gk_data1

        if(!this.m_readed_remote_gk_json)
        {
            console.log("!this.m_readed_remote_gk_json");

            return local_default;
        }

        
        if(!this.m_readed_remote_gk_json.bvalid)
        {
            console.log("!this.m_readed_remote_gk_json.bvalid");

            return this.m_init_chaonan_gk_data1;
        }

        if(this.m_readed_remote_gk_json.in_shenhe_use_default)
        {
            var use_local_index = this.m_readed_remote_gk_json.use_local_index;
            console.log("use_local_index="+use_local_index);

            if(use_local_index == 1)
            {
                //local用1
                return this.m_init_chaonan_gk_data1;
            }
            if(use_local_index == 2)
            {
                //local用2
                return this.m_gk_test1;
            }

          
            if(this.m_readed_remote_gk_json.use_default_gk_data)
            {
                console.log("in_shenhe_use_default  use_default_gk_data");

                return this.m_readed_remote_gk_json.use_default_gk_data;
            }
        }

        var level_list = this.m_readed_remote_gk_json.level_data_list;
        if(!level_list)
        {
            console.log("!level_list");

             return local_default;
        }
        if(!level_list.length)
        {
          
            console.log("!level_list.length");

             return local_default;
        }

        var use_level_type = this.m_readed_remote_gk_json.use_level_type;

        if(use_level_type == 0)
        {
            console.log("!use_level_type == 0");

            return level_list[0];
        }

        var irand1 = Math.floor(level_list.length*Math.random()) ;
    
        if(irand1 <= 0)
        {
            irand1= 0 ;
        }
        if(irand1 >= level_list.length)
        {
            irand1 = 0;
        }
        console.log("!irand1 == "+irand1);

        var config_level = level_list[irand1];


        return config_level;
    }
 
    m_gk_test1=  [[28,20,1],[24,16,2],[32,16,2],[24,24,2],[32,24,2],[28,12,3],[28,28,3],[20,20,3],
    [36,20,3],[24,16,4],[32,16,4],[24,24,4],[32,24,4],[28,12,5],[20,20,5],[36,20,5],[28,28,5],[24,16,6],
    [32,16,6],[24,24,6],[32,24,6],[28,20,7],[24,16,8],[32,16,8],[24,24,8],[32,24,8],[28,12,9],[20,20,9],[36,20,9],
    [28,28,9],[24,16,10],[32,16,10],[24,24,10],[32,24,10],[20,12,11],[28,12,11],[36,12,11],[20,20,11],[20,28,11],[28,28,11],[36,28,11]
    ,[36,20,11],[24,16,12],[32,16,12],[24,24,12],[32,24,12],[20,12,13],[28,12,13],[36,12,13],[20,20,13],[20,28,13],[28,28,13],
    [36,28,13],[36,20,13],[28,20,13],[16,8,14],[24,8,14],[32,8,14],[40,8,14],[16,16,14],[16,24,14],[16,32,14],[24,32,14],[32,32,14],
    [40,32,14],[40,16,14],[40,24,14],[12,4,15],[20,4,15],[28,4,15],[36,4,15],[44,4,15],[12,12,15],[12,20,15],[44,12,15],[44,20,15],
    [20,12,15],[28,12,15],[36,12,15],[20,20,15],[36,20,15],[8,4,16],[16,4,16],[24,4,16],[32,4,16],[40,4,16],[48,4,16],[8,12,16],[16,12,16],
    [24,12,16],[32,12,16],[40,12,16],[48,12,16],[8,20,16],[16,20,16],[24,20,16],[32,20,16],[40,20,16],[48,20,16],[12,4,17],[20,4,17],[28,4,17],
    [36,4,17],[44,4,17],[12,12,17],[20,12,17],[28,12,17],[36,12,17],[44,12,17],[12,20,17],[20,20,17],[28,20,17],[36,20,17],[44,20,17],
    [8,4,18],[16,4,18],[24,4,18],[32,4,18],[40,4,18],[48,4,18],[8,12,18],[16,12,18],[24,12,18],[32,12,18],[40,12,18],[48,12,18],[8,20,18],
    [16,20,18],[24,20,18],[32,20,18],[40,20,18],[48,20,18],[12,4,19],[20,4,19],[28,4,19],[36,4,19],[44,4,19],[12,12,19],[20,12,19],[28,12,19],
    [36,12,19],[44,12,19],[12,20,19],[20,20,19],[28,20,19],[36,20,19],[44,20,19],[8,4,20],[16,4,20],[24,4,20],[32,4,20],[40,4,20],[48,4,20],
    [8,12,20],[16,12,20],[24,12,20],[32,12,20],[40,12,20],[48,12,20],[8,20,20],[16,20,20],[24,20,20],[32,20,20],[40,20,20],[48,20,20],
    [12,0,21],[12,8,21],[12,16,21],[20,0,21],[28,0,21],[36,0,21],[44,0,21],[44,8,21],[44,16,21],[12,24,21],[20,24,21],[28,24,21],
    [36,24,21],[44,24,21],[24,12,21],[32,12,21],[8,4,22],[16,4,22],[24,4,22],[32,4,22],[40,4,22],[8,12,22],[16,12,22],[40,12,22],
    [48,4,22],[48,12,22],[8,20,22],[16,20,22],[24,20,22],[32,20,22],[40,20,22],[48,20,22],[12,0,23],[12,8,23],[12,16,23],[12,24,23],
    [20,0,23],[28,0,23],[36,0,23],[44,0,23],[20,8,23],[28,8,23],[36,8,23],[44,8,23],[20,16,23],[28,16,23],[36,16,23],[44,16,23],[20,24,23],
    [28,24,23],[36,24,23],[44,24,23],[8,4,24],[8,12,24],[8,20,24],[16,0,24],[24,0,24],[32,0,24],[40,0,24],[48,4,24],[48,12,24],[48,20,24],
    [16,28,24],[24,28,24],[32,28,24],[40,28,24],[12,0,25],[20,0,25],[28,0,25],[36,0,25],[44,0,25],[12,28,25],[20,28,25],[28,28,25],[36,28,25],
    [44,28,25],[4,16,25],[52,16,25],[8,4,26],[48,4,26],[4,8,27],[52,8,27],[52,12,28],[4,12,28]];
   
   
    m_init_chaonan_gk_data1 =   [[28,20,1],[8,52,1],[48,52,1],[24,16,2],[32,16,2],[24,24,2],[32,24,2],[9,52,2],[47,52,2],[28,12,3],[28,28,3],
        [20,20,3],[36,20,3],[10,52,3],[46,52,3],[24,16,4],[32,16,4],[24,24,4],[32,24,4],[11,52,4],[45,52,4],[28,12,5],[20,20,5],[36,20,5],
        [28,28,5],[12,52,5],[44,52,5],[24,16,6],[32,16,6],[24,24,6],[32,24,6],[13,52,6],[43,52,6],[28,20,7],[14,52,7],[42,52,7],[24,16,8],
        [32,16,8],[24,24,8],[32,24,8],[15,52,8],[41,52,8],[28,12,9],[20,20,9],[36,20,9],[28,28,9],[16,52,9],[40,52,9],[24,16,10],[32,16,10],
        [24,24,10],[32,24,10],[17,52,10],[39,52,10],[20,12,11],[28,12,11],[36,12,11],[20,20,11],[20,28,11],[28,28,11],[36,28,11],[36,20,11],
        [18,52,11],[38,52,11],[24,16,12],[32,16,12],[24,24,12],[32,24,12],[19,52,12],[37,52,12],[20,12,13],[28,12,13],[36,12,13],[20,20,13],
        [20,28,13],[28,28,13],[36,28,13],[36,20,13],[28,20,13],[20,52,13],[16,8,14],[24,8,14],[32,8,14],[40,8,14],[16,16,14],[16,24,14],
        [16,32,14],[24,32,14],[32,32,14],[40,32,14],[40,16,14],[40,24,14],[12,4,15],[20,4,15],[28,4,15],[36,4,15],[44,4,15],[12,12,15],
        [12,20,15],[44,12,15],[44,20,15],[20,12,15],[28,12,15],[36,12,15],[20,20,15],[36,20,15],[12,36,15],[20,36,15],[28,36,15],[36,36,15],
        [44,36,15],[8,4,16],[16,4,16],[24,4,16],[32,4,16],[40,4,16],[48,4,16],[8,12,16],[16,12,16],[24,12,16],[32,12,16],[40,12,16],
        [48,12,16],[8,20,16],[16,20,16],[24,20,16],[32,20,16],[40,20,16],[48,20,16],[8,40,16],[16,40,16],[24,40,16],[32,40,16],[40,40,16],
        [48,40,16],[12,4,17],[20,4,17],[28,4,17],[36,4,17],[44,4,17],[12,12,17],[20,12,17],[28,12,17],[36,12,17],[44,12,17],[12,20,17],
        [20,20,17],[28,20,17],[36,20,17],[44,20,17],[8,4,18],[16,4,18],[24,4,18],[32,4,18],[40,4,18],[48,4,18],[8,12,18],[16,12,18],
        [24,12,18],[32,12,18],[40,12,18],[48,12,18],[8,20,18],[16,20,18],[24,20,18],[32,20,18],[40,20,18],[48,20,18],[12,4,19],[20,4,19]
        ,[28,4,19],[36,4,19],[44,4,19],[12,12,19],[20,12,19],[28,12,19],[36,12,19],[44,12,19],[12,20,19],[20,20,19],[28,20,19],[36,20,19],
        [44,20,19],[8,4,20],[16,4,20],[24,4,20],[32,4,20],[40,4,20],[48,4,20],[8,12,20],[16,12,20],[24,12,20],[32,12,20],[40,12,20],
        [48,12,20],[8,20,20],[16,20,20],[24,20,20],[32,20,20],[40,20,20],[48,20,20],[12,0,21],[12,8,21],[12,16,21],[20,0,21],[28,0,21],
        [36,0,21],[44,0,21],[44,8,21],[44,16,21],[12,24,21],[20,24,21],[28,24,21],[36,24,21],[44,24,21],[24,12,21],[32,12,21],[8,4,22],
        [16,4,22],[24,4,22],[32,4,22],[40,4,22],[8,12,22],[16,12,22],[40,12,22],[48,4,22],[48,12,22],[8,20,22],[16,20,22],[24,20,22],
        [32,20,22],[40,20,22],[48,20,22],[12,0,23],[12,8,23],[12,16,23],[12,24,23],[20,0,23],[28,0,23],[36,0,23],[44,0,23],[20,8,23],
        [28,8,23],[36,8,23],[44,8,23],[20,16,23],[28,16,23],[36,16,23],[44,16,23],[20,24,23],[28,24,23],[36,24,23],[44,24,23],[8,4,24],
        [8,12,24],[8,20,24],[16,0,24],[24,0,24],[32,0,24],[40,0,24],[48,4,24],[48,12,24],[48,20,24],[16,28,24],[24,28,24],[32,28,24],
        [40,28,24],[12,0,25],[20,0,25],[28,0,25],[36,0,25],[44,0,25],[12,28,25],[20,28,25],[28,28,25],[36,28,25],[44,28,25],[4,16,25],
        [52,16,25],[8,4,26],[48,4,26],[4,8,27],[52,8,27],[52,12,28],[4,12,28]];


    m_init_first_9_gk_data1 =   [[28,20,1],[8,52,1],[48,52,1],[24,16,2],[32,16,2],[24,24,2],[32,24,2],[9,52,2],[47,52,2] ];

   //当前是否是超难模式
    m_enter_xiaochu_chaonan_moshi=  false;

    public m_b_game_end_has_award:boolean = false;
    public level: number = 1;
    public selectedLevel: number = 1;

    m_chaonan_mode_wined_cishu = 0;
    //关卡星星
    levelstar = {};//key:lv value:star
    public money: number = 0;

    public itemShuffle: number = 1;
    public itemUndo: number = 1;
    public itemHint: number = 1;
    public itemYichu: number = 1;
    public showHelp: number = 1;




    public m_tile_pool_mng:TilePoolMng = new TilePoolMng();
    public  level_config_parser:GS_GK_ConfigParse=new GS_GK_ConfigParse();;



    //普通模式和超难模式保存的上次玩的数据
    m_last_com_mode_save_game_play_data = null;
 
    m_last_chaonan_mode_save_game_play_data = null;

   
    getTile(key: string)
    {
       return  this.m_tile_pool_mng.get(key);
    }
    recover(key: string, node: cc.Node)
    {
        this.m_tile_pool_mng.put(key, node);
    }

    Get_Max_Can_Enter_GK()
    {
        if(!this.level )
        {
            return 1;
        }
        return this.level;
    }
    Add_ChaonanMode_Guoguang_Cishu()
    {
        this.m_chaonan_mode_wined_cishu++;
        this.Save_Game_Basic_Info();
    }
    InitRead_Game_Basic_Info()
    {
        var str= MyLocalStorge.getItem("guaishouxiaochu_base_info");
        if(!str)
        {
            return;
        }

        var basic_obj = JSON.parse(str);
        if(!basic_obj)
        {
            return;
        }
        this.level = ComFunc.Check_Read_Number(basic_obj.level);
   
        this.selectedLevel = ComFunc.Check_Read_Number(basic_obj.selectedLevel);
        this.money = ComFunc.Check_Read_Number(basic_obj.money);
        this.itemShuffle = ComFunc.Check_Read_Number(basic_obj.itemShuffle);
        this.itemUndo = ComFunc.Check_Read_Number(basic_obj.itemUndo);
        this.itemHint = ComFunc.Check_Read_Number(basic_obj.itemHint);
        this.itemYichu = ComFunc.Check_Read_Number(basic_obj.itemYichu);
        this.showHelp = ComFunc.Check_Read_Number(basic_obj.showHelp);
        this.m_chaonan_mode_wined_cishu = ComFunc.Check_Read_Number(basic_obj.m_chaonan_mode_wined_cishu);

        var levelstar = basic_obj.levelstar;
   
        if(levelstar)
        {
            this.levelstar = levelstar;
        }

     
    }
    Save_Game_Basic_Info()
    {
        var basicinfo = {  level:this.level,selectedLevel:this.selectedLevel,money:this.money,
            itemShuffle:this.itemShuffle,itemUndo:this.itemUndo,itemHint:this.itemHint,
            itemYichu:this.itemYichu,showHelp:this.showHelp,levelstar:this.levelstar,
            m_chaonan_mode_wined_cishu:this.m_chaonan_mode_wined_cishu
        };

       
        MyLocalStorge.setItem("guaishouxiaochu_base_info",JSON.stringify(basicinfo));

    }
    static getGSTypes(total: number, typeCount) {
        let data = []
        let k = 0
        while (total > 0) {
            let type = k % typeCount
            data.push(type, type, type)
            total -= 3;
            k++;

            if(total <= 2)
            {
                break;
            }
        }
        return data
    }
    static get_Chaonan_GSTypes(total: number, typeCount) {

        var ileftall=  total;

        var ineedtypecount = Math.floor(total/3);
        var pj_count = Math.floor(ineedtypecount/typeCount);

        let data = [];
        var left_arr = new WMap();
        for(var ff=0;ff<typeCount;ff++)
        {
            left_arr.putData(ff,1);
            for(var hh=0;hh<pj_count;hh++)
            {
                data.push(ff, ff, ff);

                ileftall -=3;
                ineedtypecount -=1;
            }
        }


 
        let k = 0
        while (ileftall > 0) 
        {
            let type = k % typeCount
            data.push(type, type, type)
            ileftall -= 3;
            k++;

            if(ileftall <= 2)
            {
                break;
            }
        }
        return data
    }
    
    InitReadConfig(callback:Function)
    {
        var self  = this;
        
        BundleLoadUtils.GetInstance().LoadLocalBundleResource("conf","comdefine/info",cc.JsonAsset,(err, data: cc.JsonAsset)=>
        {
            var json_info_Data=data.json  
            self.level_config_parser.setup({Level:json_info_Data.Level,Floor:json_info_Data.Floor})
            callback&&callback() 
        });
        
   
    }
    InitLoadTiles(callback:Function)
    {
        var self  = this;
       
        this.m_tile_pool_mng.initReadTiles(callback);
    }
    get_Level_FloorData(ifl)
    {
        return this.level_config_parser.get_Level_FloorData(ifl);

    }

    readLevelData(ilevel:number)
    {
        return this.level_config_parser.readLevelData(ilevel);

    }

    Get_ChaoNanMoshi_Data()
    {

        var src_floor_lev_data =  this.readLevelData( Math.floor( 3000 + Math.random()*1000) );
      //  return floor_lev_data;

      
        var exist_floor_id_list = src_floor_lev_data.floorIds;


        var total_gw_type_count = 30 + Math.floor(Math.random()*6);
        var floor_id_list = [];

        var all_title_count = 0;

        var iexist_len = exist_floor_id_list.length;

        var icengshu = 20 + Math.floor(Math.random()*11);

        for(var ff=0;ff<icengshu;ff++)
        {
            var ff_index = Math.floor(ff%iexist_len);

            var irand1 = ff_index;// Math.floor(Math.random()*exist_floor_id_list.length);

            if(irand1 < 0)
            {
                irand1=  0;
            }
            if(irand1 >= iexist_len)
            {
                irand1= iexist_len - 1;
            }

            var exist_id = exist_floor_id_list[irand1];



            var ff_floor_id = Number(exist_id) ;
            floor_id_list.push(""+ff_floor_id);

            let floorData = GSXC_Game_Mng.GetInstance().get_Level_FloorData(ff_floor_id)
            let ff_tiles = floorData.layouts;
          
            all_title_count += ff_tiles.length;
            //20-270
        }


        var idesc_left_c = all_title_count - Math.floor(50*Math.random());

        var ineed_tc = Math.floor(Math.floor(idesc_left_c/3)*3);


        var level_data = 
        {
            count:ineed_tc,
            typeCount:total_gw_type_count,
            floorIds:floor_id_list,
            id:0,
            level:0
        };


        src_floor_lev_data.floorIds = floor_id_list;
        src_floor_lev_data.typeCount = total_gw_type_count;
        src_floor_lev_data.count = ineed_tc;
 

        return src_floor_lev_data;
 
       // return this.readLevelData( Math.floor( 2000 + Math.random()*1000) );
    }





    InitRead_Game_Play_Last_Save_Data()
    {
        try{

            var str1= MyLocalStorge.getItem("guaishou_xiaochu_chaonan_mode_last_game_play_data");
            if(str1)
            {
                var basic_obj1 = JSON.parse(str1);

                if(basic_obj1 && basic_obj1.bvalid)
                {
                    this.m_last_chaonan_mode_save_game_play_data = basic_obj1;
                }
            }

        }catch(e1)
        {
        }


        try{

            var str2= MyLocalStorge.getItem("guaishou_xiaochu_common_mode_last_game_play_data");
            if(str2)
            {
                var basic_obj2 = JSON.parse(str2);

                if(basic_obj2 && basic_obj2.bvalid)
                {
                    this.m_last_com_mode_save_game_play_data = basic_obj2;
                }
            }

        }catch(e2)
        {
        }


    }

    Clear_ChaonanTiaozhan_Last_Save_Ju()
    {
        if(this.m_enter_xiaochu_chaonan_moshi)
        {

            this.m_last_chaonan_mode_save_game_play_data = null;
           
            MyLocalStorge.removeItem("guaishou_xiaochu_chaonan_mode_last_game_play_data"); 
        }
        else{
            this.m_last_com_mode_save_game_play_data = null;

            MyLocalStorge.removeItem("guaishou_xiaochu_common_mode_last_game_play_data");
        }
 
    }

    Save_All_Mode_Last_Game_Play_Data()
    {
        if(!this.m_last_chaonan_mode_save_game_play_data)
        {
            MyLocalStorge.removeItem("guaishou_xiaochu_chaonan_mode_last_game_play_data");

        }else{
            MyLocalStorge.setItem("guaishou_xiaochu_chaonan_mode_last_game_play_data",JSON.stringify(this.m_last_chaonan_mode_save_game_play_data));
        }

        if(!this.m_last_com_mode_save_game_play_data)
        {
            MyLocalStorge.removeItem("guaishou_xiaochu_common_mode_last_game_play_data");

        }else{
            MyLocalStorge.setItem("guaishou_xiaochu_common_mode_last_game_play_data",JSON.stringify(this.m_last_com_mode_save_game_play_data));
        }


    }

    Save_Curju_ChaoNanMoshiData(curjudata)
    {
        if(!curjudata)
        {
            return;
        }
        if(this.m_enter_xiaochu_chaonan_moshi)
        {

            this.m_last_chaonan_mode_save_game_play_data = curjudata;
        }
        else{
            this.m_last_com_mode_save_game_play_data = curjudata;
           
        }


        this.Save_All_Mode_Last_Game_Play_Data();


    }

    Get_Prev_Save_Game_Data()
    {
        if(this.m_enter_xiaochu_chaonan_moshi)
        {

           return this.m_last_chaonan_mode_save_game_play_data ;
        }
        else{
            return this.m_last_com_mode_save_game_play_data ;

        }
    }


    matchLayout= [
        "240_219_1_1",
        "40_539_1_2",
        "440_539_1_2",
        "200_179_2_1",
        "280_179_2_1",
        "197_270_2_1",
        "283_270_2_1",
        "50_539_2_2",
        "430_539_2_2",
        "240_139_3_1",
        "160_219_3_1",
        "320_219_3_1",
        "240_299_3_1",
        "60_539_3_2",
        "420_539_3_2",
        "199_174_4_1",
        "285_176_4_1",
        "197_268_4_1",
        "285_268_4_1",
        "70_539_4_2",
        "410_539_4_2",
        "240_123_5_1",
        "160_219_5_1",
        "320_219_5_1",
        "240_309_5_1",
        "80_539_5_2",
        "400_539_5_2",
        "200_178_6_1",
        "287_178_6_1",
        "286_271_6_1",
        "200_272_6_1",
        "90_539_6_2",
        "390_539_6_2",
        "240_219_7_1",
        "100_539_7_2",
        "380_539_7_2",
        "198_168_8_1",
        "284_168_8_1",
        "196_259_8_1",
        "283_259_8_1",
        "110_539_8_2",
        "370_539_8_2",
        "240_126_9_1",
        "160_219_9_1",
        "320_219_9_1",
        "240_305_9_1",
        "120_539_9_2",
        "360_539_9_2",
        "199_167_10_1",
        "283_168_10_1",
        "199_259_10_1",
        "282_259_10_1",
        "130_539_10_2",
        "350_539_10_2",
        "330_128_11_1",
        "160_129_11_1",
        "245_129_11_1",
        "160_219_11_1",
        "327_219_11_1",
        "160_311_11_1",
        "241_312_11_1",
        "327_312_11_1",
        "140_539_11_2",
        "340_539_11_2",
        "199_166_12_1",
        "283_167_12_1",
        "200_258_12_1",
        "283_258_12_1",
        "150_539_12_2",
        "330_539_12_2",
        "155_126_13_1",
        "327_127_13_1",
        "240_128_13_1",
        "241_216_13_1",
        "328_218_13_1",
        "156_219_13_1",
        "156_308_13_1",
        "241_308_13_1",
        "327_309_13_1",
        "160_539_13_2",
        "202_63_14_1",
        "114_64_14_1",
        "287_65_14_1",
        "372_65_14_1",
        "373_157_14_1",
        "116_159_14_1",
        "370_252_14_1",
        "115_254_14_1",
        "286_347_14_1",
        "371_347_14_1",
        "114_348_14_1",
        "200_348_14_1",
        "407_49_15_1",
        "67_50_15_1",
        "153_50_15_1",
        "322_50_15_1",
        "239_52_15_1",
        "405_145_15_1",
        "67_146_15_1",
        "154_146_15_1",
        "320_146_15_1",
        "240_147_15_1",
        "404_238_15_1",
        "67_241_15_1",
        "154_241_15_1",
        "320_242_15_1",
        "70_379_15_1",
        "155_379_15_1",
        "240_379_15_1",
        "325_379_15_1",
        "410_379_15_1",
        "371_41_16_1",
        "457_41_16_1",
        "32_43_16_1",
        "117_43_16_1",
        "201_43_16_1",
        "287_43_16_1",
        "32_139_16_1",
        "285_139_16_1",
        "370_139_16_1",
        "458_139_16_1",
        "115_140_16_1",
        "200_140_16_1",
        "117_232_16_1",
        "200_232_16_1",
        "371_232_16_1",
        "285_233_16_1",
        "30_234_16_1",
        "458_234_16_1",
        "40_419_16_1",
        "120_419_16_1",
        "200_419_16_1",
        "280_419_16_1",
        "360_419_16_1",
        "440_419_16_1",
        "240_38_17_1",
        "326_38_17_1",
        "70_40_17_1",
        "411_40_17_1",
        "155_42_17_1",
        "410_136_17_1",
        "69_139_17_1",
        "152_139_17_1",
        "235_139_17_1",
        "325_139_17_1",
        "65_231_17_1",
        "240_231_17_1",
        "153_232_17_1",
        "323_232_17_1",
        "409_234_17_1",
        "23_37_18_1",
        "110_37_18_1",
        "197_40_18_1",
        "282_42_18_1",
        "367_43_18_1",
        "453_46_18_1",
        "27_129_18_1",
        "110_129_18_1",
        "193_130_18_1",
        "279_131_18_1",
        "366_132_18_1",
        "453_134_18_1",
        "285_226_18_1",
        "371_227_18_1",
        "457_227_18_1",
        "32_229_18_1",
        "116_229_18_1",
        "200_229_18_1",
        "235_42_19_1",
        "69_43_19_1",
        "151_43_19_1",
        "320_43_19_1",
        "405_43_19_1",
        "70_139_19_1",
        "152_139_19_1",
        "234_139_19_1",
        "322_139_19_1",
        "407_139_19_1",
        "240_230_19_1",
        "324_231_19_1",
        "156_234_19_1",
        "409_234_19_1",
        "70_235_19_1",
        "119_43_20_1",
        "287_43_20_1",
        "204_45_20_1",
        "371_45_20_1",
        "455_45_20_1",
        "34_46_20_1",
        "454_137_20_1",
        "31_138_20_1",
        "368_138_20_1",
        "120_139_20_1",
        "200_139_20_1",
        "285_139_20_1",
        "204_230_20_1",
        "288_230_20_1",
        "373_230_20_1",
        "29_231_20_1",
        "117_232_20_1",
        "458_232_20_1",
        "71_0_21_1",
        "155_1_21_1",
        "239_2_21_1",
        "327_3_21_1",
        "412_4_21_1",
        "80_99_21_1",
        "400_99_21_1",
        "198_139_21_1",
        "285_139_21_1",
        "411_171_21_1",
        "72_177_21_1",
        "154_266_21_1",
        "411_267_21_1",
        "325_268_21_1",
        "70_269_21_1",
        "240_269_21_1",
        "112_37_22_1",
        "27_38_22_1",
        "197_39_22_1",
        "281_40_22_1",
        "368_41_22_1",
        "454_42_22_1",
        "29_139_22_1",
        "112_139_22_1",
        "369_139_22_1",
        "456_139_22_1",
        "197_232_22_1",
        "113_234_22_1",
        "28_235_22_1",
        "281_235_22_1",
        "368_237_22_1",
        "455_237_22_1",
        "68_2_23_1",
        "155_2_23_1",
        "240_5_23_1",
        "322_6_23_1",
        "408_9_23_1",
        "67_99_23_1",
        "155_99_23_1",
        "241_99_23_1",
        "326_99_23_1",
        "410_99_23_1",
        "154_193_23_1",
        "240_194_23_1",
        "412_195_23_1",
        "326_196_23_1",
        "67_197_23_1",
        "415_290_23_1",
        "330_291_23_1",
        "156_292_23_1",
        "244_293_23_1",
        "70_296_23_1",
        "120_19_24_1",
        "200_19_24_1",
        "280_19_24_1",
        "360_19_24_1",
        "40_47_24_1",
        "440_48_24_1",
        "40_139_24_1",
        "440_139_24_1",
        "440_229_24_1",
        "40_230_24_1",
        "120_299_24_1",
        "200_299_24_1",
        "280_299_24_1",
        "360_299_24_1",
        "80_19_25_1",
        "160_19_25_1",
        "240_19_25_1",
        "320_19_25_1",
        "400_19_25_1",
        "0_179_25_1",
        "480_179_25_1",
        "80_299_25_1",
        "160_299_25_1",
        "240_299_25_1",
        "320_299_25_1",
        "400_299_25_1",
        "40_59_26_1",
        "440_59_26_1",
        "0_99_27_1",
        "480_99_27_1",
        "0_139_28_1",
        "480_139_28_1"
    ]
}