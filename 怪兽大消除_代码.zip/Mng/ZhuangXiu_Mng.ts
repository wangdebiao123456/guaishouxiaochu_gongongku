import ComFunc from "../comfuncs/ComFunc";
import Util from "../utils/Util";
import MyLocalStorge from "../WDT/MyLocalStorge";
import WMap from "../WDT/WMap";

 
export default class ZhuangXiu_Mng {

    static _instance:ZhuangXiu_Mng = null;
    static GetInstance() 
    {
        if (!ZhuangXiu_Mng._instance) {
            // doSomething
            ZhuangXiu_Mng._instance = new ZhuangXiu_Mng();
             
        }
        return ZhuangXiu_Mng._instance;
    }


    m_max_lingqued_jiangli_capter = 0;

    //0-8
    m_max_finished_zhuangxiu_capter = 0;
    //0-20
    m_capter_zhuangxiued_count_map = new WMap();

    constructor()
    {

        this.InitRead_Game_Basic_Info();
    }
    InitRead_Game_Basic_Info()
    {
        var str= MyLocalStorge.getItem("naolixunlian_zhuangxiu_info");
        if(!str)
        {
            return;
        }

        var basic_obj = JSON.parse(str);
        if(!basic_obj)
        {
            return;
        }
        this.m_max_lingqued_jiangli_capter = ComFunc.Check_Read_Number(basic_obj.m_max_lingqued_jiangli_capter);
        this.m_max_finished_zhuangxiu_capter = ComFunc.Check_Read_Number(basic_obj.m_max_finished_zhuangxiu_capter);
 
        this.m_capter_zhuangxiued_count_map = Util.Serize_Saved_OBJ_Map(basic_obj.m_capter_zhuangxiued_count_map);
 
    }
    Save_Game_Basic_Info()
    {

       

        var basicinfo = {
            m_max_lingqued_jiangli_capter:this.m_max_lingqued_jiangli_capter,
            m_max_finished_zhuangxiu_capter:this.m_max_finished_zhuangxiu_capter,
            m_capter_zhuangxiued_count_map:Util.Format_Save_OBJ_Map(this.m_capter_zhuangxiued_count_map)
        };

        

        MyLocalStorge.setItem("naolixunlian_zhuangxiu_info",JSON.stringify(basicinfo));

    }

    On_Lingqued_Capter_Jiangli()
    {
        this.m_max_lingqued_jiangli_capter = this.m_max_finished_zhuangxiu_capter;
        this.Save_Game_Basic_Info();
    }
    Get_Not_Lignqued_Jiangli_Capter_Count()
    {
        if(this.m_max_lingqued_jiangli_capter >= this.m_max_finished_zhuangxiu_capter)
        {
            return 0;
        }

        var icc = this.m_max_finished_zhuangxiu_capter - this.m_max_lingqued_jiangli_capter ;
        return icc;
    }

    Get_Capter_Index_Zhuangxiu_Need_Chuizi(icapter,zhuangxiued_count)
    {
        if(zhuangxiued_count <= 4)
        {
            return 6;
        }
        if(zhuangxiued_count <= 9)
        {
            return 8;
        }

        if(zhuangxiued_count <= 14)
        {
            return 10;
        }
        if(zhuangxiued_count  >= 15)
        {
            return 12;
        }
 
        return 12;
    }

    Get_Cur_Zhuangxiu_Capter()
    {
        var icapter = 1 + this.m_max_finished_zhuangxiu_capter;
        return icapter;
    }
    Add_Cur_Capter_Zhuangxiu_C(icapter)
    {
        var prevc = 0;
        if(this.m_capter_zhuangxiued_count_map.hasKey(icapter))
        {
            var icc = this.m_capter_zhuangxiued_count_map.getData(icapter);
            prevc = icc;
        }

        var newcc = prevc + 1;

        this.m_capter_zhuangxiued_count_map.putData(icapter,newcc);

        if(newcc >= 20)
        {
            if(icapter > this.m_max_finished_zhuangxiu_capter)
            {
                this.m_max_finished_zhuangxiu_capter  = icapter;
            }

        }

        this.Save_Game_Basic_Info();
    }
    Get_Capter_Zhuangxiued_Count(icapter)
    {
        if(this.m_capter_zhuangxiued_count_map.hasKey(icapter))
        {
            var icc = this.m_capter_zhuangxiued_count_map.getData(icapter);
            return icc;
        }

        return 0;
    }

    Get_Capter_Name(icapter)
    {
        if(icapter == 1)
        {
            return "花园";
        }
        if(icapter == 2)
        {
            return "浴室";
        }

        if(icapter == 3)
        {
            return "卧室";
        }
        if(icapter == 4)
        {
            return "厨房";
        }

        if(icapter == 5)
        {
            return "书房";
        }

        if(icapter == 6)
        {
            return "天台";
        }
        if(icapter == 7)
        {
            return "庭院";
        }

        if(icapter == 8)
        {
            return "豪宅";
        }

        return "花园";
    }


}
