import WMap from "../WDT/WMap";
import MyLocalStorge from "../WDT/MyLocalStorge";
import ComFunc from "../comfuncs/ComFunc";
import ClientLogUtils from "../comfuncs/ClientLogUtils";
import PlatFormParaMng from "../PlatForm/PlatFormParaMng";
import GSXC_Game_Mng from "./GSXC_Game_Mng";
import PaoPaoLongMng from "../paopaolonggame/paopaolong/PaoPaoLongMng";
import LianLianKanGameMng from "../lianliankan/LianLianKanGameMng";
import XiaoMieXingxingMng from "../xiaomiexingxing/XiaoMieXingxingMng";
import fanpaiXiaoXiaoMng from "../fanpaixiaoxiaole/fanpaiXiaoXiaoMng";
import GlobalMng from "../huamukuai/GlobalMng";
import HutuiAppInfoMng from "../PlatForm/HutuiAppInfoMng";



class PerDayWanfaEnterCishu
{
    public ienterdayunion:number = 0;
    public ienterdaycishu:number = 0;
}


export default class GlobalGameMng
{
    static _instance:GlobalGameMng = null;
    static GetInstance() 
    {
        if (!GlobalGameMng._instance) {
            // doSomething
            GlobalGameMng._instance = new GlobalGameMng();
             
        }
        return GlobalGameMng._instance;
    }


    m_loading_to_game_scence_name = "";

    
    m_b_first_sign_dlg_poped = false;

    m_process_dating_shouquan_reuired = 0;
   //道具类型-数目的map
    //1:金币，2：钻石，3：体力，4.勋章 5:兵种技能卡牌      
    m_all_in_bag_daoju_type_leftcount_map = new WMap();

    //各个玩法总共进入的次数
    m_subgametype_enter_gamed_cishu_map = new WMap();

    //各个玩法当日进入游戏的次数
    m_subgametype_perday_entered_gamed_cishu_map = new WMap();


    m_dating_last_from_subgame_type  = 0;
    m_dating_last_from_subgame_level  = 0;

    m_queryed_other_user_nick_touxiang_info_map =  new WMap();


    m_readed_game_common_config_remote_json = null;
    m_last_save_valid_common_config_remote_json = null;

    //最后一次跳过时间
    m_last_tiaoguo_gk_tick = 0;


    m_cur_process_dating_show_caidan_mode = 0;
    m_cur_process_shoukanfuli_libao_dlg_mode = 0;

    //继续上次游戏存档剩余
    m_continue_prev_game_left_count = 5;


    m_subgametype_last_show_banner_type_map = new WMap();

 //体力开始计时tick
    m_tili_countdown_start_tick = 0;
    m_tili_countdown_start_Left_count = 0;


    //连续观看获得无限体力数目
    m_lianxu_guangkan_wuxian_tili_video_count = 0;
    //连续观看获得无限体力24小时开始时间
    m_lianxu_guangkan_wuxian_tili_tick = 0;


    m_lianxu_guangkan_wuxian_48huor_tili_video_count = 0;

    //连续观看获得无限体力48小时开始时间
    m_lianxu_guangkan_wuxian_tili_48_huor_tick = 0;

    m_cur_process_fanhuidating_queren_dlg_mode = 0;
    m_dating_bottom_tip_index= 0 ;


    m_gametype_shouci_libao_show_count_map = new WMap();

    m_gametype_last_save_game_prev_play_data_map = new WMap();

    m_dating_prev_show_banner_type = 0;

    m_last_game_config_json_refresh_tick = 0;

    m_default_config = null;

    m_curday_last_luckdraw_finished_elapse_sec = 0;

    m_first_online_info_inited = false;
    m_cur_day_online_liqued_count =  0;
    m_cur_online_elapse_sec = 0;
    m_last_online_libao_lingqu_day_union = 0;
    m_last_online_data_saved_tick = 0;

    m_online_config=
    {
        "1": {
            "time": 300,
            "jl": [
                {
                    "t":5,
                    "c":50
                },
                {
                    "t":6,
                    "c":1
                }
            ]
        },
        "2": {
            "time": 600,
            "jl": [
                {
                    "t":5,
                    "c":100
                },
                {
                    "t":6,
                    "c":2
                }
            ] 
        },
        "3": {
            "time": 1200,
            "jl": [
                 
                {
                    "t":5,
                    "c":150
                },
                {
                    "t":6,
                    "c":2
                }
            ] 
        } 
    }




    constructor()
    {

        this.InitRead_Last_Save_Common_Server_Config();
        this.InitRead_Game_Basic_Info();

 
        this.Check_Save_First_Reg_Day_Info();
    }
    Set_Default_Config(default_config)
    {
        this.m_default_config = default_config;
    }
    On_Game_Enter(isubgametype,pgame,pnode)
    {
        if(Date.now() - this.m_last_game_config_json_refresh_tick < 30000)
        {
            return;
        }
        this.m_last_game_config_json_refresh_tick = Date.now();

        HutuiAppInfoMng.GetInstance().LoadRemoteConfig(()=>{


        }); 
 
  
        GlobalGameMng.GetInstance().Load_Game_Common_Config(()=>{
        
 
        });

    }
    Get_Dating_Next_Need_Show_Banner_Type()
    {
        var server_config_dating_bottom_show_banner_type=  GlobalGameMng.GetInstance().Get_Dating_Bottom_Show_Banner_Type();

        var ishow_bottom_banner_type = 2;

        if(server_config_dating_bottom_show_banner_type == 1)
        {
            ishow_bottom_banner_type = 1;
        } 
        else  if(server_config_dating_bottom_show_banner_type == 3)
        {
            if(this.m_dating_prev_show_banner_type == 2)
            {
                ishow_bottom_banner_type = 1;
            }else{
                ishow_bottom_banner_type = 2;
            }
        }


        this.m_dating_prev_show_banner_type = ishow_bottom_banner_type;
        return ishow_bottom_banner_type;
    }


    Read_GameType_Prev_Save_Data(igametype)
    {
        var str1= MyLocalStorge.getItem("shaonaomukuai_gametype_"+igametype+"_last_game_play_data");
        if(str1)
        {
            var basic_obj1 = JSON.parse(str1);

            if(basic_obj1 && basic_obj1.bvalid)
            {
                return  basic_obj1;
            }
        }

        return null;
    }
    Delete_GameType_Prev_Save_Data(igametype)
    {
        this.m_gametype_last_save_game_prev_play_data_map.RemoveKey(igametype);
        var str1= "gs_shaonaomukuai_gametype_"+igametype+"_last_game_play_data";
        MyLocalStorge.removeItem(str1);
    }

    Change_GameType_Prev_Save_Data(igametype,pnewobj)
    {
        this.m_gametype_last_save_game_prev_play_data_map.putData(igametype,pnewobj);
        var str1= "gs_shaonaomukuai_gametype_"+igametype+"_last_game_play_data";
        MyLocalStorge.setItem(str1,JSON.stringify(pnewobj));
    }

    Get_Prev_Save_Game_Data(igametype)
    {

        if(this.m_gametype_last_save_game_prev_play_data_map.hasKey(igametype))
        {
            var pobj = this.m_gametype_last_save_game_prev_play_data_map.getData(igametype);
            return pobj;
        }
        var pinfo = this.Read_GameType_Prev_Save_Data(igametype);
        this.m_gametype_last_save_game_prev_play_data_map.putData(igametype,pinfo);
        return pinfo;
    }
    Get_Jiange_Gk_Show_Guoguang_Libao()
    {
        return 4;
    }
    Add_CurProcess_GameType_Shouci_Libao_Show_Count(igametype)
    {
        if(!this.m_gametype_shouci_libao_show_count_map.hasKey(igametype))
        {
            this.m_gametype_shouci_libao_show_count_map.putData(igametype,1);
        }else{
            var icc = this.m_gametype_shouci_libao_show_count_map.getData(igametype);
            this.m_gametype_shouci_libao_show_count_map.putData(igametype,1 + icc);
  
        }
    }
   
    Get_CurProcess_GameType_Shouci_Libao_Show_Count(igametype)
    {
        if(!this.m_gametype_shouci_libao_show_count_map.hasKey(igametype))
        {
            return 0;
        }

        var icc = this.m_gametype_shouci_libao_show_count_map.getData(igametype);
        return icc;
    }


    Start_CountDown_Add_Tili()
    {
        var last_tili_info = MyLocalStorge.getItem("guaishouxiaochu_last_save_tili_info");
        if(!last_tili_info)
        {
            return;
        }
        var obj = JSON.parse(last_tili_info);

        if(!obj)
        {
            return;
        }

        var last_count_down_tili_tick = ComFunc.Check_Read_Number(obj.last_count_down_tili_tick) ;
   
        if(last_count_down_tili_tick == 0 ||   isNaN(last_count_down_tili_tick))
        {
            return;
        }
        var iepalsetick = Date.now() - last_count_down_tili_tick;
        var permintue_tick = 60*1000;

        if(iepalsetick > permintue_tick)
        {
            var ieplase_min = Math.floor(iepalsetick/permintue_tick);

          
            if(ieplase_min <= 0)
            {
                ieplase_min = 0;
            }

            var ineedaddtili = ieplase_min;

            var config_can_add_tili_max=  this.Get_LongTime_Not_Play_Can_Add_Max_Tili();
            if(ineedaddtili > config_can_add_tili_max && config_can_add_tili_max > 0)
            {
                ineedaddtili = config_can_add_tili_max;
            }
         
            this.Add_Tili(ineedaddtili);

            this.Save_Til_iInfo();

            this.Save_Game_Basic_Info();

            console.log("Start_CountDown_Add_Tili ieplase_min = "+ieplase_min+",config_can_add_tili_max="+config_can_add_tili_max+",ineedaddtili="+ineedaddtili)

        }

    }





  
    Get_Cur_Valid_Server_Common_Config()
    {
        if(this.m_readed_game_common_config_remote_json)
        {
            if(this.m_readed_game_common_config_remote_json.bvalid)
            {
                return this.m_readed_game_common_config_remote_json;
            }
        }

        if(this.m_last_save_valid_common_config_remote_json)
        {
            if(this.m_last_save_valid_common_config_remote_json.bvalid)
            {
                return this.m_last_save_valid_common_config_remote_json;
            }
        }
        if(this.m_default_config)
        {
            return this.m_default_config;
        }
        return null;
    }


    Add_Subgametype_Enterd_Cishu(isbugametype,iaddcc)
    {
        var prevcc = 0;
        if(this.m_subgametype_enter_gamed_cishu_map.hasKey(isbugametype))
        {
            prevcc = this.m_subgametype_enter_gamed_cishu_map.getData(isbugametype);
        }

        this.m_subgametype_enter_gamed_cishu_map.putData(isbugametype,prevcc + 1);

        
        var curdayuinon = ComFunc.GetCurDayUnion();


    //    console.log("Add_Subgametype_Enterd_Cishu curdayuinon ="+curdayuinon);

        var prev_day_enter_data:PerDayWanfaEnterCishu =  null;

        if(this.m_subgametype_perday_entered_gamed_cishu_map.hasKey(isbugametype))
        {
            var previnfo:PerDayWanfaEnterCishu = this.m_subgametype_perday_entered_gamed_cishu_map.getData(isbugametype);

            if(previnfo.ienterdayunion == curdayuinon)
            {
                prev_day_enter_data = previnfo;
            }
        }

        if(prev_day_enter_data)
        {
            prev_day_enter_data.ienterdaycishu++;
        }
        else{
            prev_day_enter_data = new PerDayWanfaEnterCishu();
            prev_day_enter_data.ienterdaycishu = 1;
            prev_day_enter_data.ienterdayunion = curdayuinon;

        }

        this.m_subgametype_perday_entered_gamed_cishu_map.putData(isbugametype,prev_day_enter_data);

        this.Save_Game_Basic_Info();
    }




    Get_Subgametype_Enterd_Cishu(isbugametype)
    {
        if(this.m_subgametype_enter_gamed_cishu_map.hasKey(isbugametype))
        {
            var icishu = this.m_subgametype_enter_gamed_cishu_map.getData(isbugametype);
            return icishu;
        }

        return 0;
    }
    Get_Subgametype_CurDay_Enterd_Cishu(isbugametype)
    {

        var cur_day_union = ComFunc.GetCurDayUnion();

        if(this.m_subgametype_perday_entered_gamed_cishu_map.hasKey(isbugametype))
        {
            var prevdata:PerDayWanfaEnterCishu = this.m_subgametype_perday_entered_gamed_cishu_map.getData(isbugametype);
          
          
            if(prevdata.ienterdayunion == cur_day_union)
            {
                return  prevdata.ienterdaycishu;
            }
          
            return 0;
        }

        return 0;
    }
    //观看获得无限体力视频一次
    On_Watch_Lianxu_Wuxian_Tili_Video_Suc()
    {
        this.m_lianxu_guangkan_wuxian_tili_video_count++;

        if(this.m_lianxu_guangkan_wuxian_tili_video_count >= 3)
        {
            this.m_lianxu_guangkan_wuxian_tili_video_count = 0;
            this.Add_Tili(this.Get_Max_Tili());
            this.m_lianxu_guangkan_wuxian_tili_tick = Date.now();
        }

        this.Save_Game_Basic_Info();
    }
    On_Watch_Lianxu_Wuxian_48huor_Tili_Video_Suc()
    {
        this.m_lianxu_guangkan_wuxian_48huor_tili_video_count++;

        if(this.m_lianxu_guangkan_wuxian_48huor_tili_video_count >= 5)
        {
            this.m_lianxu_guangkan_wuxian_48huor_tili_video_count = 0;
            this.Add_Tili(this.Get_Max_Tili());
            this.m_lianxu_guangkan_wuxian_tili_48_huor_tick= Date.now();
        }

        this.Save_Game_Basic_Info();
    }

    Get_Lianxu_Video_Wuxian_48huor_Tili_Left_Sec()
    {
        if(this.m_lianxu_guangkan_wuxian_tili_48_huor_tick == 0)
        {
            return 0;
        }

        var wuxiansecd = 48*3600 ;
       // var wuxiansecd = 30;

        var ieplasetick = Date.now() - this.m_lianxu_guangkan_wuxian_tili_48_huor_tick;

        var ileftsec = Math.floor(wuxiansecd - ieplasetick/1000);
        if(ileftsec <= 0)
        {
            ileftsec=  0;
            this.m_lianxu_guangkan_wuxian_tili_48_huor_tick  = 0;
            this.Save_Game_Basic_Info();
        }

        return ileftsec;
    }
    //连续观看无限体力剩余时间
    Get_Lianxu_Video_Wuxian_Tili_Left_Sec()
    {

        if(this.m_lianxu_guangkan_wuxian_tili_tick == 0)
        {
            return 0;
        }

        var wuxiansecd = 24*3600 ;
       // var wuxiansecd = 30;

        var ieplasetick = Date.now() - this.m_lianxu_guangkan_wuxian_tili_tick;

        var ileftsec = Math.floor(wuxiansecd - ieplasetick/1000);
        if(ileftsec <= 0)
        {
            ileftsec=  0;
            this.m_lianxu_guangkan_wuxian_tili_tick  = 0;
            this.Save_Game_Basic_Info();
        }

        return ileftsec;
         
    }

    Count_Down_Add_Tili()
    {
        var itili = this.Get_Tili();
        var imaxtili = this.Get_Max_Tili();
        if(itili >= imaxtili)
        {
            if(this.m_tili_countdown_start_tick > 0)
            {
             
                MyLocalStorge.removeItem("guaishouxiaochu_last_save_tili_info");
            }

            this.m_tili_countdown_start_tick = 0;
            this.m_tili_countdown_start_Left_count = 0;

        }
        else{

            if(this.m_tili_countdown_start_tick  == 0)
            {
                this.m_tili_countdown_start_tick  = Date.now();
                this.m_tili_countdown_start_Left_count = 60;

                this.Save_Til_iInfo();
            }

            var ieplsetick = Date.now() - this.m_tili_countdown_start_tick;
            var isec=  Math.floor(ieplsetick/1000);
            var ileftsec = this.m_tili_countdown_start_Left_count - isec;

            if(ileftsec <= 0)
            {
                this.m_tili_countdown_start_tick  = Date.now();
                this.m_tili_countdown_start_Left_count = 60;
                this.Add_Tili(1);

                this.Save_Til_iInfo();
                this.Save_Game_Basic_Info();
            }

        }

    }
    Save_Til_iInfo()
    {
        var obj  = {
            m_tili_countdown_start_tick:this.m_tili_countdown_start_tick,
            m_tili_countdown_start_Left_count:this.m_tili_countdown_start_Left_count,
            last_count_down_tili_tick:Date.now()
        };


        MyLocalStorge.setItem("guaishouxiaochu_last_save_tili_info",JSON.stringify(obj));
    }



    Add_Tili(icount)
    {
        this.Change_Self_DaojuType_Count(3,icount);
        //做数据校验
        var icurtili = this.Get_Tili();
        if(icurtili > this.Get_Max_Tili())
        {
            icurtili = this.Get_Max_Tili();
            this.m_all_in_bag_daoju_type_leftcount_map.putData(3,icurtili);
            this.Save_Game_Basic_Info();
        }else if(icurtili <= 0)
        {
            icurtili=  0;
            this.m_all_in_bag_daoju_type_leftcount_map.putData(3,icurtili);
            this.Save_Game_Basic_Info();
        }

       
    }

    Get_Tili()
    {
        return this.Get_Self_DestType_Daoju_Count(3);
    }

    Get_Self_Reg_Day()
    {

        return this.Check_Save_First_Reg_Day_Info();
    }


    Check_Save_First_Reg_Day_Info()
    {
        

        var icurdayuinon = ComFunc.GetCurDayUnion();
        var self_reg_day = icurdayuinon;

        var bprevsaved = false;
        var prev_reg_day = 0;
        var reg_day_info = MyLocalStorge.getItem("guaishou_daxiaochu_reg_day");
        var jobj = null;
        if(reg_day_info)
        {
            try{
                jobj = JSON.parse(reg_day_info);
            }catch(e)
            {}
            
            if(jobj)
            {
                var reg_day_uinon = jobj.reg_day_uinon;
                if(reg_day_uinon && reg_day_uinon > 0 )
                {
                    bprevsaved = true;
                    prev_reg_day = reg_day_uinon;
                    self_reg_day = reg_day_uinon;;
                }
            }
        }

        if(!bprevsaved)
        {
            var obj = {reg_day_uinon:icurdayuinon};
            

            MyLocalStorge.setItem("guaishou_daxiaochu_reg_day",JSON.stringify(obj));
        }else{

            //console.log("prev_reg_day="+prev_reg_day);

        }

        self_reg_day = Number(self_reg_day);
      
        return self_reg_day;
    }

    Get_Valid_Game_Common_Config()
    {


        return null;
    }

    IS_All_Tili_Hide()
    {
        /*
        if(!this.m_readed_game_common_config_remote_json)
        {
            return false;
        }

        if(!this.m_readed_game_common_config_remote_json.bvalid)
        {
            return false;
        }
        */
 
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return false;
        }
        var dating_tili_hide_all = cur_valid_config.dating_tili_hide_all;

        if(dating_tili_hide_all == undefined)
        {
            return false;
        }

        if(dating_tili_hide_all > 0)
        {
            return true;
        }

        return false;
    }


    IS_All_Paihangbang_Hide()
    {

        var idefaultv = 0;
       
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var all_paihangbang_hide = cur_valid_config.all_paihangbang_hide;
        if(all_paihangbang_hide == undefined)
        {
            return idefaultv;
        }

        return all_paihangbang_hide;
    }

    //每次购买的体力
    Get_PerCi_Goumai_Tili()
    {
        var idefaultv = 30;
        /*
        if(!this.m_readed_game_common_config_remote_json)
        {
            return idefaultv;
        }

        if(!this.m_readed_game_common_config_remote_json.bvalid)
        {
            return idefaultv;
        }
        */

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var goumai_tili_per_ci = cur_valid_config.goumai_tili_per_ci;
        if(goumai_tili_per_ci == undefined)
        {
            return idefaultv;
        }

        if(goumai_tili_per_ci > 0 && goumai_tili_per_ci < 100)
        {
            return goumai_tili_per_ci;
        }

        return idefaultv;
    }
    //进入游戏一次扣除体力数目，一般都是1
    Get_Enter_Game_PerCi_Sub_Tili()
    {
        var idefaultv = 3;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var enter_game_perci_sub_tili = cur_valid_config.enter_game_perci_sub_tili;
        if(enter_game_perci_sub_tili == undefined)
        {
            return idefaultv;
        }

        if(enter_game_perci_sub_tili >= 0 && enter_game_perci_sub_tili<20)
        {
            return enter_game_perci_sub_tili;
        }

        return idefaultv;
    }


    IS_InGamePlay_Time_Can_Add_Tili()
    {
        var idefaultv = 1;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var ingame_play_time_can_add_tili = cur_valid_config.ingame_play_time_can_add_tili;
        if(ingame_play_time_can_add_tili == undefined)
        {
            return idefaultv;
        }

     
        return ingame_play_time_can_add_tili;
    }


    //用户长时间不玩游戏，能增加的最大体力 
    Get_LongTime_Not_Play_Can_Add_Max_Tili()
    {
        var idefaultv = 60;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var longtime_not_play_can_add_max_tili = cur_valid_config.longtime_not_play_can_add_max_tili;

        console.log("longtime_not_play_can_add_max_tili = "+longtime_not_play_can_add_max_tili)
        if(longtime_not_play_can_add_max_tili == undefined)
        {
            return idefaultv;
        }

        if(longtime_not_play_can_add_max_tili > 0)
        {
            return longtime_not_play_can_add_max_tili;
        }

        return idefaultv;
    }


    Increase_Dating_Tip_Index()
    {
        this.m_dating_bottom_tip_index++;

    }
    Get_Dating_Bottom_Tip_Info_Str()
    {
        var desaultstr = "每个玩法最开始3次进入不扣体力";
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return desaultstr;
        }
        var dating_bottom_tip_list = cur_valid_config.dating_bottom_tip_list;
        if(!dating_bottom_tip_list)
        {
            return desaultstr;
        }
        if(!dating_bottom_tip_list.length)
        {
            return desaultstr;
        }



        if(this.m_dating_bottom_tip_index >= dating_bottom_tip_list.length || this.m_dating_bottom_tip_index< 0)
        {
            this.m_dating_bottom_tip_index = 0;
        }

        var str = dating_bottom_tip_list[this.m_dating_bottom_tip_index];
        return str;

    }

    

    Get_Game_Inner_Bottom_Gezi_Or_banner_Type3_Change_Sec()
    {
        var idefaultv = 35;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var game_inner_bottom_gezi_or_banner_type3_change_sec = cur_valid_config.game_inner_bottom_gezi_or_banner_type3_change_sec;
        if(!game_inner_bottom_gezi_or_banner_type3_change_sec)
        {
            return idefaultv;
        }

        if(game_inner_bottom_gezi_or_banner_type3_change_sec > 0)
        {
            return game_inner_bottom_gezi_or_banner_type3_change_sec;
        }

        return idefaultv;
    }
    //最大体力，也是从服务器可以配置的
    Get_Max_Tili()
    {
        var idefaultv = 60;

        /*
        if(!this.m_readed_game_common_config_remote_json)
        {
            return idefaultv;
        }

        if(!this.m_readed_game_common_config_remote_json.bvalid)
        {
            return idefaultv;
        }
        */

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var dating_tili_max = cur_valid_config.dating_tili_max;
        if(!dating_tili_max)
        {
            return idefaultv;
        }

        if(dating_tili_max > 0)
        {
            return dating_tili_max;
        }

        return idefaultv;
    }
    //判断服务器配置游戏场内格子或者banner是否应该挨着底部
    IS_Game_Scence_Bottom_Banner_Align_Bottom(ibannertype)
    {
        /*
        if(!this.m_readed_game_common_config_remote_json)
        {
            return 0;
        }

        if(!this.m_readed_game_common_config_remote_json.bvalid)
        {
            return 0;
        }
        */

        var idefaultv = 1;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }


        if(ibannertype == 1)
        {
            //banner
            var game_inner_bottom_banner_pos_align_bottom = cur_valid_config.game_inner_bottom_banner_pos_align_bottom;

            if(game_inner_bottom_banner_pos_align_bottom == 1)
            {
                return 1;
            }

            return game_inner_bottom_banner_pos_align_bottom;
        }else{
            //格子

            var game_inner_bottom_gezi_pos_align_bottom = cur_valid_config.game_inner_bottom_gezi_pos_align_bottom;

            if(game_inner_bottom_gezi_pos_align_bottom == 1)
            {
                return 1;
            }

            return game_inner_bottom_gezi_pos_align_bottom;
        }

       

        return idefaultv;
    }
    //得到服务器配置游戏场底部应该显示的banenr还是格子
    Get_Game_Scence_Next_Bottom_Banner_Type(isubgametypw)
    {
        

        var idefaultv = 2;

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }


        var special_game_inner_bottom_show_banner_or_gezi_type =  cur_valid_config.special_game_inner_bottom_show_banner_or_gezi_type;

        if(special_game_inner_bottom_show_banner_or_gezi_type)
        {
            for(var ff=0;ff<special_game_inner_bottom_show_banner_or_gezi_type.length;ff++)
            {
                var ff_info = special_game_inner_bottom_show_banner_or_gezi_type[ff];
                if(ff_info.i == isubgametypw)
                {
                    var ff_s = ff_info.s;

                    if(ff_s)
                    {
                        return ff_s;
                    }
                }
            }
        }



        var game_inner_bottom_show_banner_or_gezi_type =  cur_valid_config.game_inner_bottom_show_banner_or_gezi_type;

        if(game_inner_bottom_show_banner_or_gezi_type == 1)
        {
            return 1;
        }

        if(game_inner_bottom_show_banner_or_gezi_type == 2)
        {
            return 2;
        }

        //3:格子和banner交替出现
        if(game_inner_bottom_show_banner_or_gezi_type == 3)
        {
            return 3;
        }


        //随机切换
        var prevtype=  0;
        if(this.m_subgametype_last_show_banner_type_map.hasKey(isubgametypw))
        {
            prevtype=  this.m_subgametype_last_show_banner_type_map.getData(isubgametypw);
        }

        if(prevtype == 2)
        {
            this.m_subgametype_last_show_banner_type_map.putData(isubgametypw,1);
            return 1;
        }

        this.m_subgametype_last_show_banner_type_map.putData(isubgametypw,2);
        return 2;
    }
    Cacualte_Pre_Day_Liucun( curdayindex, day_index_liucun_user_count_map)
    {
        var reg_cc = 1500;

        for(var ff=0;ff<day_index_liucun_user_count_map.size();ff++)
        {
            var ff_index = day_index_liucun_user_count_map.GetKeyByIndex(ff);
            var ff_cc = day_index_liucun_user_count_map.GetEntryByIndex(ff);

            if(ff_index == curdayindex)
            {
                continue;
            }

            
            if(ff_index + 1 == curdayindex)
            {

                var newcc = Math.floor(reg_cc*0.15);
                day_index_liucun_user_count_map.putData(ff_index,newcc)
                continue;
            }

            if(ff_index + 2 == curdayindex)
            {

                var newcc = Math.floor(reg_cc*0.07);
                day_index_liucun_user_count_map.putData(ff_index,newcc)
                continue;
            }


            if(ff_index + 3 == curdayindex)
            {

                var newcc = Math.floor(reg_cc*0.04);
                day_index_liucun_user_count_map.putData(ff_index,newcc)
                continue;
            }


            
            if(ff_index + 4 == curdayindex)
            {

                var newcc = Math.floor(reg_cc*0.04);
                day_index_liucun_user_count_map.putData(ff_index,newcc)
                continue;
            }

            if(ff_index + 5 == curdayindex)
            {

                var newcc = Math.floor(reg_cc*0.03);
                day_index_liucun_user_count_map.putData(ff_index,newcc)
                continue;
            }


            if(ff_index + 6 == curdayindex)
            {

                var newcc = Math.floor(reg_cc*0.02);
                day_index_liucun_user_count_map.putData(ff_index,newcc)
                continue;
            }




           var newcc2 = Math.floor(reg_cc*0.02);
            day_index_liucun_user_count_map.putData(ff_index,newcc2)
      
        }

    }
    SumMapCount(day_index_liucun_user_count_map)
    {

        var allcc=  0;
        for(var ff=0;ff<day_index_liucun_user_count_map.size();ff++)
        {
            var ff_c = day_index_liucun_user_count_map.GetEntryByIndex(ff);
            allcc += ff_c;
        }

        return allcc;

    }
    Test()
    {

        var qiantian_day_huoyue_user_count = 0;
        var qiantian_day_reg_user_count = 0;


        var prev_day_huoyue_user_count = 0;
        var prev_day_reg_user_count = 0;


        var curday_user_huoyue_use_count = 0;
        var curday_user_reg_use_count = 1500;


        var day_index_liucun_user_count_map = new WMap();


        

        
        for(var ff=1;ff<=100;ff++)
        {
              /*
            var qiantian_liucun_zuotian_huoyue = Math.floor(qiantian_day_huoyue_user_count*0.3);
            var qiantian_liucun_reg_huoyue = Math.floor(qiantian_day_reg_user_count*0.15);

            prev_day_huoyue_user_count += qiantian_liucun_zuotian_huoyue + qiantian_liucun_reg_huoyue;
              

            curday_user_huoyue_use_count = Math.floor(prev_day_huoyue_user_count*0.3);

        
            var curday_all_cc = curday_user_huoyue_use_count + curday_user_reg_use_count;

            console.log("第"+ff+"天,活跃人数:"+curday_all_cc+",prevday_huoyue_liucun_user=");

            prev_day_reg_user_count = curday_user_reg_use_count;
            prev_day_huoyue_user_count = 
         
 */

        //    day_index_liucun_user_count_map.putData(ff,curday_user_reg_use_count);

         ///   this.Cacualte_Pre_Day_Liucun(ff,day_index_liucun_user_count_map);

          //  var allcc = this.SumMapCount(day_index_liucun_user_count_map);

        //    console.log("第"+ff+"天,活跃人数:"+allcc);
 
          


  /*
            var prevday_huoyue_liucun_user = Math.floor(prev_day_huoyue_user_count*0.3);
            var prevday_reg_liucun_user = Math.floor(prev_day_reg_user_count*0.15);

            var prev_day_user_count = prevday_huoyue_liucun_user  + prevday_reg_liucun_user;

            curday_user_huoyue_use_count = prev_day_user_count + curday_user_reg_use_count;

            console.log("第"+ff+"天,活跃人数:"+curday_user_huoyue_use_count+",prevday_huoyue_liucun_user="+
            prevday_huoyue_liucun_user+",prevday_reg_liucun_user="+prevday_reg_liucun_user);

            prev_day_huoyue_user_count = prev_day_user_count;
            prev_day_reg_user_count = curday_user_reg_use_count;
            */
          

        }


    }


    On_RealTiaoGuoGK_Use()
    {
        this.m_last_tiaoguo_gk_tick = Date.now();

        this.Save_Game_Basic_Info();
    }



    //小于这天注册的用户不扣体力
    Get_Reg_Day_Xiaoyu_Dest_Day_Bukou_Tili()
    {
        var idesfaultvalue = 0;
 

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idesfaultvalue;
        }


        var regday_unoin_xiaoyu_dest_day_bukou_tili = cur_valid_config.regday_unoin_xiaoyu_dest_day_bukou_tili;
        if(!regday_unoin_xiaoyu_dest_day_bukou_tili)
        {
            return idesfaultvalue;
        }

        if(regday_unoin_xiaoyu_dest_day_bukou_tili > 0 )
        {
            return regday_unoin_xiaoyu_dest_day_bukou_tili;
        }

        return idesfaultvalue;
    }
    //获得配置的每个玩法最开始几次内不扣体力
    Get_Per_Game_First_Enter_Cishu_Nei_Bukou_Tili()
    {
        var idesfaultvalue = 3;
       
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idesfaultvalue;
        }

        var per_game_first_enter_cishu_nei_bukou_tili = cur_valid_config.per_game_first_enter_cishu_nei_bukou_tili;
        if(!per_game_first_enter_cishu_nei_bukou_tili)
        {
            return idesfaultvalue;
        }

        if(per_game_first_enter_cishu_nei_bukou_tili > 0 && per_game_first_enter_cishu_nei_bukou_tili < 200)
        {
            return per_game_first_enter_cishu_nei_bukou_tili;
        }

        return idesfaultvalue;
    }

    //每到这个关卡，就必须出现
    Get_GameType_Shouci_Libao_show_gk_Jiange(isubgametype)
    {
        var idesfaultvalue = 3;
       
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idesfaultvalue;
        }

        var game_shouci_libao_show_gk_jiange = cur_valid_config.game_shouci_libao_show_gk_jiange;
        
        var per_gametype_shouci_libao_show_type = cur_valid_config.per_gametype_shouci_libao_show_type;
       
        if(per_gametype_shouci_libao_show_type)
        {
            for(var ff=0;ff<per_gametype_shouci_libao_show_type.length;ff++)
            {
                var ff_arr = per_gametype_shouci_libao_show_type[ff];
                if(ff_arr[0] == isubgametype && ff_arr.length >= 3)
                {
                    return ff_arr[2];
                }
            }
        }

        if(game_shouci_libao_show_gk_jiange == undefined)
        {
            return idesfaultvalue;
        }
      

        return game_shouci_libao_show_gk_jiange;
    } 
    Get_GameType_Shouci_Libao_ShowType(isubgametype)
    {
        var idesfaultvalue = 99;
       
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idesfaultvalue;
        }

        if(this.In_Shenhe())
        {
            return 99;
        }

        var game_shouci_libao_show_type = cur_valid_config.game_shouci_libao_show_type;
        
        var per_gametype_shouci_libao_show_type = cur_valid_config.per_gametype_shouci_libao_show_type;
       
        if(per_gametype_shouci_libao_show_type)
        {
            for(var ff=0;ff<per_gametype_shouci_libao_show_type.length;ff++)
            {
                var ff_arr = per_gametype_shouci_libao_show_type[ff];
                if(ff_arr[0] == isubgametype && ff_arr.length >= 3)
                {
                    return ff_arr[1];
                }
            }
    
        }

        if(game_shouci_libao_show_type == undefined)
        {
            return idesfaultvalue;
        }
        
        return game_shouci_libao_show_type;
    }

    Get_GameType_Shouci_Libao_Delay_Pop_Sec(isubgametype)
    {
        var idesfaultvalue =1;
       
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idesfaultvalue;
        }
        var per_gametype_shouci_libao_pop_delay_sec = cur_valid_config.per_gametype_shouci_libao_pop_delay_sec;


        for(var ff=0;ff<per_gametype_shouci_libao_pop_delay_sec.length;ff++)
        {
            var ff_info_arr  = per_gametype_shouci_libao_pop_delay_sec[ff];

            if(ff_info_arr[0] == isubgametype && ff_info_arr.length >= 2)
            {
                return ff_info_arr[1];
            }
        }
        return idesfaultvalue;
    }
    Get_Per_Game_PerDay_First_Enter_Cishu_Nei_Bukou_Tili()
    {
        var idesfaultvalue = 2;
       
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idesfaultvalue;
        }

        var per_game_perday_first_enter_cishu_nei_bukou_tili = cur_valid_config.per_game_perday_first_enter_cishu_nei_bukou_tili;
        if(per_game_perday_first_enter_cishu_nei_bukou_tili == undefined)
        {
            return idesfaultvalue;
        }

        return per_game_perday_first_enter_cishu_nei_bukou_tili;
    }
    


    Get_Sanxiaoxiao_Tiaozhan_Play_Self_Music_Index()
    {
        /*
        if(!this.m_readed_game_common_config_remote_json)
        {
            return 0;
        }

        if(!this.m_readed_game_common_config_remote_json.bvalid)
        {
            return 0;
        }

*/
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return 0;
        }

        if(!cur_valid_config.sanxiaoxiao_tiaozhan_use_self_bk_music_index)
        {
            return 0;
        }
        var self_bk_music_index =  cur_valid_config.sanxiaoxiao_tiaozhan_use_self_bk_music_index

        return self_bk_music_index;
    }

    //服务器配置三消消挑战是否用羊的背景音乐
    IS_Sanxiaoxiao_Tiaozhan_Play_Yangyang_Music()
    {
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return false;
        }

/*
        if(!this.m_readed_game_common_config_remote_json)
        {
            return false;
        }

        if(!this.m_readed_game_common_config_remote_json.bvalid)
        {
            return false;
        }
        */

        if(!cur_valid_config.sanxiaoxiao_tiaozhan_use_yangyang_bk_music)
        {
            return false;
        }
        var bcanshow =  cur_valid_config.sanxiaoxiao_tiaozhan_use_yangyang_bk_music

        return bcanshow;
    }
    //服务器配置 左上角三消的格子广告能否显示
    IS_Sanxiaoxiao_Game_LeftTop_Gezi_Guangao_Can_Show()
    {
        /*
        if(!this.m_readed_game_common_config_remote_json)
        {
            return true;
        }

        if(!this.m_readed_game_common_config_remote_json.bvalid)
        {
            return true;
        }
        */

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return true;
        }


        if(!cur_valid_config.sanxiaoxiao_left_top_gezi_guanggao_can_show)
        {
            return true;
        }
        var bcanshow =  cur_valid_config.sanxiaoxiao_left_top_gezi_guanggao_can_show

        return bcanshow;
    }


    //服务器配置泡泡龙推荐位是否显示
    IS_PaoPaoLong_Game_TuijianWei_Need_Show()
    {
        /*
        if(!this.m_readed_game_common_config_remote_json)
        {
            return true;
        }

        if(!this.m_readed_game_common_config_remote_json.bvalid)
        {
            return true;
        }
        */


        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return true;
        }


        if(cur_valid_config.ppl_guangbi_self_left_tuijianwei  == 0)
        {
            return false;
        }
     

        return true;
    }

    //服务器配置推荐位是否显示
    IS_Sanxiaoxiao_Game_TuijianWei_Need_Show(ituijianwei)
    {
        

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return true;
        }

/*
        if(!this.m_readed_game_common_config_remote_json)
        {
            return true;
        }

        if(!this.m_readed_game_common_config_remote_json.bvalid)
        {
            return true;
        }
        */

        if(ituijianwei == 1)
        {
            if(cur_valid_config.sanxiaoxiao_game1_tuijianwei_show  == 0)
            {
                return false;
            }
        }
        else if(ituijianwei == 2)
        {
            if(cur_valid_config.sanxiaoxiao_game2_tuijianwei_show  == 0)
            {
                return false;
            }
        }

      

        return true;
    }


    Get_Gamesuc_Dlg_First_Gouxuan_Need_Min_GK()
    {
        var idefaultv = 4;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamesuc_dlg_video_config = cur_valid_config.gamesuc_dlg_video_config;

        if(!gamesuc_dlg_video_config)
        {
            return idefaultv;
        }

    
        var gamesuc_dlg_first_check_min_gk = gamesuc_dlg_video_config.gamesuc_dlg_first_check_min_gk;
        if(gamesuc_dlg_first_check_min_gk == undefined)
        {
            return idefaultv;
        }

        return gamesuc_dlg_first_check_min_gk;
    }
    IS_Game_Type_Need_Show_Guoguang_Libao(igametype)
    {
        var idefaultv = 1;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }


        var gamesuc_need_guoguang_libao = cur_valid_config.gamesuc_need_guoguang_libao;
        if(gamesuc_need_guoguang_libao == undefined)
        {
            return idefaultv;
        }

        return gamesuc_need_guoguang_libao;
    }



    Get_Gamesuc_Dlg_Per_Game_Type_GouxuanBtn_Config(igametype)
    {
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return null;
        }

        var gamesuc_dlg_video_config =  cur_valid_config.gamesuc_dlg_video_config;

        if(!gamesuc_dlg_video_config)
        {
            return null;
        }

        if(this.In_Shenhe())
        {
            return null;
        }

        var gametype_rang_gouxuan_btn_conf =  gamesuc_dlg_video_config.gametype_rang_gouxuan_btn_conf;

        for(var ff=0;ff<gametype_rang_gouxuan_btn_conf.length;ff++)
        {
            var ff_info_arr = gametype_rang_gouxuan_btn_conf[ff];
            var ff_gamettpye_range = ff_info_arr[0];

            
            if(ff_info_arr.length >= 5  && ff_gamettpye_range.length == 2  )
            {
                var cmincx =  ff_gamettpye_range[0];
                var cmaxcx =  ff_gamettpye_range[1];


                if(cmincx <= igametype && igametype <= cmaxcx)
                {
                    return ff_info_arr;
                }
              
            }
        }
        return null;
    }

    Get_Fuhuo_Dlg_End_Show_Cancel_Btn_Per_Game_Type_Config(igametype)
    {
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return null;
        }

        var fuhuo_dlg_gametype_show_cancel_btn_sec_conf =  cur_valid_config.fuhuo_dlg_gametype_show_cancel_btn_sec_conf;

        for(var ff=0;ff<fuhuo_dlg_gametype_show_cancel_btn_sec_conf.length;ff++)
        {
            var ff_info_arr = fuhuo_dlg_gametype_show_cancel_btn_sec_conf[ff];
            if(ff_info_arr[0] == igametype && ff_info_arr.length >= 3)
            {
                return ff_info_arr;
            }
        }
        return null;

    }
 
    Get_Fuhuo_Dlg_End_Show_Cancel_Btn()
    {
        var idefaultv = 0;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }
         

        var fuhuo_dlg_daojishi_end_show_cancel_btn = cur_valid_config.fuhuo_dlg_daojishi_end_show_cancel_btn;
        return fuhuo_dlg_daojishi_end_show_cancel_btn;
    }
    Get_Fuhuo_Dlg_Daojishi_All_Sec()
    {
        var idefaultv = 6;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }
        if(!cur_valid_config.fuhuo_dlg_daojishi_all_sec)
        {
            return idefaultv;
        }

        var iallsec = cur_valid_config.fuhuo_dlg_daojishi_all_sec;
        return iallsec;

    }
    //游戏暂停弹框返回大厅是否需要确定弹框--默认情况下都是需要的
    IS_Game_Pause_Dlg_FanhuiDating_Need_Queren()
    {
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return 1;
        }
/*

        if(!this.m_readed_game_common_config_remote_json)
        {
            return 1;
        }

        if(!this.m_readed_game_common_config_remote_json.bvalid)
        {
            return 1;
        }
*/

        if(cur_valid_config.game_pause_dlg_need_fanhuidating_confirm  == 0)
        {
            return 0;
        }

        return 1;
    }
    //游戏胜利返回大厅是否需要确定弹框--默认情况下都是需要的
    IS_Game_Success_Dlg_FanhuiDating_Need_Queren()
    {
        /*
        if(!this.m_readed_game_common_config_remote_json)
        {
            return 1;
        }

        if(!this.m_readed_game_common_config_remote_json.bvalid)
        {
            return 1;
        }
        */

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return 1;
        }
        if(cur_valid_config.game_suc_dlg_need_fanhuidating_confirm  == 0)
        {
            return 0;
        }

        return 1;
    }
    //游戏失败返回大厅是否需要确定弹框--默认情况下都是需要的
    IS_Game_Fail_Dlg_FanhuiDating_Need_Queren()
    {
        /*
        if(!this.m_readed_game_common_config_remote_json)
        {
            return 1;
        }

        if(!this.m_readed_game_common_config_remote_json.bvalid)
        {
            return 1;
        }
        */

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return 1;
        }

        if(cur_valid_config.game_fail_dlg_need_fanhuidating_confirm  == 0)
        {
            return 0;
        }

        return 1;
    }

    IS_Game_Need_First_Enter_Sanxiaoxiao()
    {
        /*
        if(!this.m_readed_game_common_config_remote_json)
        {
            return false;
        }

        if(!this.m_readed_game_common_config_remote_json.bvalid)
        {
            return false;
        }
        */


        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return false;
        }

        if(cur_valid_config.first_enter_san_xiaoxiao > 0)
        {
            return true;
        }

        return false;
    }
    On_Loaded_Server_Remote_Common_Config(remoteobj)
    {
        if(!remoteobj)
        {
            return;
        }

        var min_Valid_version = 1;
        if(remoteobj.min_valid_version )
        {
            min_Valid_version = remoteobj.min_valid_version;
        }

        if(min_Valid_version > PlatFormParaMng.GetInstance().Get_Cur_Version())
        {
            return;
        }

        var self = this;
        self.m_readed_game_common_config_remote_json =  remoteobj;

        if(self.m_readed_game_common_config_remote_json)
        {
            if(self.m_readed_game_common_config_remote_json.bvalid)
            {
                MyLocalStorge.setItem("guaishoudaciaochu_last_save_server_common_config",JSON.stringify(self.m_readed_game_common_config_remote_json))
            }
        }
    }

    Load_Game_Common_Config(callback)
    {
        var irand11 = Math.floor(Math.random()*1000) ;
        var config_json = "https://outercoms.zfgame123.com/config/guaishou_da_xiaochu/wx/guaishou_da_xiaochu_common_config.json?r="+irand11;
 
        var self = this;
 
     
        cc.assetManager.loadRemote(config_json, (err, jobj:cc.JsonAsset) =>  
        {
            if(err)
            {
                self.m_readed_game_common_config_remote_json = null;
                callback();
                console.log("加载配置错误:"+err)
                return;
            }

            if(jobj.json)
            {
                self.On_Loaded_Server_Remote_Common_Config(jobj.json);

            }
         
         
           
            callback();
        });
    }


    On_Readed_Other_User_Basic_Info( existed, sguid, snickname, stouxiangurl)
    {
        if(existed)
        {
            var pinfo = {existed:existed,snickname:snickname,stouxiangurl:stouxiangurl};

            this.m_queryed_other_user_nick_touxiang_info_map.putData(sguid,pinfo);
        }else{
            var pinfo2 = {existed:existed,snickname:"用户",stouxiangurl:""};

            this.m_queryed_other_user_nick_touxiang_info_map.putData(sguid,pinfo2);
        }
      
    }
    

    Query_Other_User_Nick_Touxiang_Info(sguid)
    {
        if(this.m_queryed_other_user_nick_touxiang_info_map.hasKey(sguid))
        {
            var pinfo =  this.m_queryed_other_user_nick_touxiang_info_map.getData(sguid);
            return pinfo;
        }

        return null;
    }

    Add_DaojuType_Count_List(awarddaoju,ibeishu = 1)
    { 
        for(var ff=0;ff<awarddaoju.length;ff++){
            var ff_info =  awarddaoju[ff];
            var ff_t = ff_info.t;
            var ff_c = ff_info.c * ibeishu;
            // cc.log('ff_T' + ff_t);
            // cc.log('ff_C' + ff_c);
 
            if(!this.m_all_in_bag_daoju_type_leftcount_map.hasKey(ff_t)){
                this.m_all_in_bag_daoju_type_leftcount_map.putData(ff_t,ff_c);
            }else{
                var iprevc = this.m_all_in_bag_daoju_type_leftcount_map.getData(ff_t);
                this.m_all_in_bag_daoju_type_leftcount_map.putData(ff_t,ff_c + iprevc);
            }
        }
        this.Save_Game_Basic_Info();
    }
    Change_Self_DaojuType_Count(idaojutype,icount){
        var ff_t = idaojutype;
        var ff_c = icount;
        if(!this.m_all_in_bag_daoju_type_leftcount_map.hasKey(ff_t)){



            if(ff_c < 0)
            {
                ff_c=  0;
            }
            this.m_all_in_bag_daoju_type_leftcount_map.putData(ff_t,ff_c);
        }else{
            var iprevc = this.m_all_in_bag_daoju_type_leftcount_map.getData(ff_t);

            var inewc = ff_c + iprevc;
            if(inewc <= 0)
            {
                inewc = 0;
            }
            this.m_all_in_bag_daoju_type_leftcount_map.putData(ff_t,inewc);
        }

     
        this.Save_Game_Basic_Info();
      
    }
    Get_Self_DestType_Daoju_Count(itype){
        
        var inewcc = 0;
        if(this.m_all_in_bag_daoju_type_leftcount_map.hasKey(itype)){
            var icc = this.m_all_in_bag_daoju_type_leftcount_map.getData(itype);
            return icc;
        }
        else{

         
            if(itype == 3)
            {
                //体力
                inewcc = this.Get_Max_Tili();
            }

            this.m_all_in_bag_daoju_type_leftcount_map.putData(itype,inewcc);

         
        }



        return inewcc;
    }


    Get_Continue_Prev_Game_Left_Count()
    {
        return this.m_continue_prev_game_left_count;
    }

    Change_Continue_Prev_Game_Left_Count(ichangecount)
    {
        this.m_continue_prev_game_left_count += ichangecount;

        if(this.m_continue_prev_game_left_count <= 0)
        {
            this.m_continue_prev_game_left_count  = 0;
        }
        this.Save_Game_Basic_Info();
    }
   

    InitRead_Last_Save_Common_Server_Config()
    {
        
        var str = MyLocalStorge.getItem("guaishoudaciaochu_last_save_server_common_config", "");

        if(!str)
        {
            return;
        }
    
        var basic_obj = JSON.parse(str);
        if(!basic_obj)
        {
            return;
        }

        if(!basic_obj.bvalid)
        {
            return;
        }

        this.m_last_save_valid_common_config_remote_json = basic_obj;
       // console.log("m_last_save_valid_common_config_remote_json="+str);
    }

    InitRead_Game_Basic_Info()
    {   
        var str= MyLocalStorge.getItem("guaishoudaxiaochu_global_basic_info");
        if(!str)
        {
            return;
        }

        var basic_obj = JSON.parse(str);
        if(!basic_obj)
        {
            return;
        }


        var daoju_count_list=  basic_obj.daoju_count_list;
        if(!daoju_count_list)
        {
            daoju_count_list = [];
        }

        for(var ff=0;ff<daoju_count_list.length;ff++)
        {
            var ff_info = daoju_count_list[ff];
            var ff_itype = ff_info.itype;
            var ff_c= ff_info.c;
            if(ff_c >= 0)
            {
                this.m_all_in_bag_daoju_type_leftcount_map.putData(ff_itype,ff_c);

            }
        }
      
            // /体力初始化
        if(!this.m_all_in_bag_daoju_type_leftcount_map.hasKey(3))
        {
            
            this.m_all_in_bag_daoju_type_leftcount_map.putData(3,this.Get_Max_Tili());

        }



        var enter_subgame_count_list=  basic_obj.enter_subgame_count_list;
        if(!enter_subgame_count_list)
        {
            enter_subgame_count_list = [];
        }
        for(var ff=0;ff<enter_subgame_count_list.length;ff++)
        {
            var ff_info = enter_subgame_count_list[ff];
            var ff_itype = ff_info.itype;
            var ff_c= ff_info.c;
            if(ff_c >= 0)
            {
                this.m_subgametype_enter_gamed_cishu_map.putData(ff_itype,ff_c);

            }
        }

 
        
        var perday_enter_subgame_count_list=  basic_obj.perday_enter_subgame_count_list;
        if(!perday_enter_subgame_count_list)
        {
            perday_enter_subgame_count_list = [];
        }



        var curday_union = ComFunc.GetCurDayUnion();

        for(var ff=0;ff<perday_enter_subgame_count_list.length;ff++)
        {
            var ff_info = perday_enter_subgame_count_list[ff];
            var ff_itype = ff_info.itype;
            var ff_c= ff_info.c;
            var ff_d= ff_info.d;


            if(curday_union == ff_d && ff_c > 0)
            {
                var ff_perday:PerDayWanfaEnterCishu = new PerDayWanfaEnterCishu();
                ff_perday.ienterdayunion = ff_d;
                ff_perday.ienterdaycishu = ff_c;

                this.m_subgametype_perday_entered_gamed_cishu_map.putData(ff_itype,ff_perday);
            }
            
        }
 
 


        this.m_last_tiaoguo_gk_tick = ComFunc.Check_Read_Number(basic_obj.m_last_tiaoguo_gk_tick);
        if(this.m_last_tiaoguo_gk_tick > Date.now())
        {
            this.m_last_tiaoguo_gk_tick = 0;
        }
 

        if(basic_obj.m_continue_prev_game_left_count == undefined)
        {
            basic_obj.m_continue_prev_game_left_count = 5;
        }
        this.m_continue_prev_game_left_count = ComFunc.Check_Read_Number(basic_obj.m_continue_prev_game_left_count);
        if(this.m_continue_prev_game_left_count <= 0)
        {
            this.m_continue_prev_game_left_count = 0;
        }
  

        this.m_continue_prev_game_left_count = ComFunc.Check_Read_Number(basic_obj.m_continue_prev_game_left_count);
   
        this.m_lianxu_guangkan_wuxian_tili_video_count = ComFunc.Check_Read_Number(basic_obj.m_lianxu_guangkan_wuxian_tili_video_count);
        this.m_lianxu_guangkan_wuxian_tili_tick = ComFunc.Check_Read_Number(basic_obj.m_lianxu_guangkan_wuxian_tili_tick);
   
        this.m_lianxu_guangkan_wuxian_tili_48_huor_tick = ComFunc.Check_Read_Number(basic_obj.m_lianxu_guangkan_wuxian_tili_48_huor_tick);
        this.m_lianxu_guangkan_wuxian_48huor_tili_video_count = ComFunc.Check_Read_Number(basic_obj.m_lianxu_guangkan_wuxian_48huor_tili_video_count);
   
 
    }

    Save_Game_Basic_Info()
    {

       

        var basicinfo = {m_last_tiaoguo_gk_tick:this.m_last_tiaoguo_gk_tick,  daoju_count_list:[] ,
            enter_subgame_count_list:[] ,perday_enter_subgame_count_list:[],
            m_continue_prev_game_left_count:this.m_continue_prev_game_left_count ,
            m_lianxu_guangkan_wuxian_tili_video_count:this.m_lianxu_guangkan_wuxian_tili_video_count ,
            m_lianxu_guangkan_wuxian_tili_tick:this.m_lianxu_guangkan_wuxian_tili_tick ,
            m_lianxu_guangkan_wuxian_48huor_tili_video_count:this.m_lianxu_guangkan_wuxian_48huor_tili_video_count,
            m_lianxu_guangkan_wuxian_tili_48_huor_tick:this.m_lianxu_guangkan_wuxian_tili_48_huor_tick
        };

       

        var daoju_count_list = [];
        for(var ff=0;ff<this.m_all_in_bag_daoju_type_leftcount_map.size();ff++)
        {
            var ff_type = this.m_all_in_bag_daoju_type_leftcount_map.GetKeyByIndex(ff);
            var ff_count = this.m_all_in_bag_daoju_type_leftcount_map.GetEntryByIndex(ff);
           
            daoju_count_list.push({itype:ff_type,c:ff_count});
           
        }
        basicinfo.daoju_count_list = daoju_count_list;
       

        var enter_subgame_count_list = [];
        for(var ff=0;ff<this.m_subgametype_enter_gamed_cishu_map.size();ff++)
        {
            var ff_type = this.m_subgametype_enter_gamed_cishu_map.GetKeyByIndex(ff);
            var ff_count = this.m_subgametype_enter_gamed_cishu_map.GetEntryByIndex(ff);
           
            enter_subgame_count_list.push({itype:ff_type,c:ff_count});
           
        }

        basicinfo.enter_subgame_count_list = enter_subgame_count_list;
        
 
        var perday_enter_subgame_count_list = [];
        for(var ff=0;ff<this.m_subgametype_perday_entered_gamed_cishu_map.size();ff++)
        {
            var ff_type = this.m_subgametype_perday_entered_gamed_cishu_map.GetKeyByIndex(ff);
            var ff_perday:PerDayWanfaEnterCishu = this.m_subgametype_perday_entered_gamed_cishu_map.GetEntryByIndex(ff);
           
            perday_enter_subgame_count_list.push({itype:ff_type,c:ff_perday.ienterdaycishu,d:ff_perday.ienterdayunion});
           
        }

        basicinfo.perday_enter_subgame_count_list = perday_enter_subgame_count_list;
        
 


        MyLocalStorge.setItem("guaishoudaxiaochu_global_basic_info",JSON.stringify(basicinfo));

    }

    //跳过关卡还要多久才能用
    Get_Tiaoguo_Gk_Action_Need_Left_Sec()
    {
        if(this.m_last_tiaoguo_gk_tick == 0)
        {
            return 0;
        }

        var ieplasetick = Date.now() - this.m_last_tiaoguo_gk_tick;


        var ineedjiangesec = 20;

        var ilefsec =  Math.ceil( ineedjiangesec - ieplasetick/1000);

        if(ilefsec <= 0)
        {
            ilefsec = 0;
        }

        return ilefsec;
    }

    Get_Game_Type_Name(igametype)
    {
        if(igametype == 1)
        {
            return  "三消怪兽";
        }

        if(igametype == 9)
        {
            return  "三消怪兽挑战";
        }
        if(igametype == 2)
        {
            return  "泡泡龙";
        }
        if(igametype == 3)
        {
            return  "密室逃脱";
        }

        if(igametype == 4)
        {
            return  "消灭星星";
        }


        if(igametype == 5)
        {
            return  "连连看";
        }


        
        if(igametype == 6)
        {
            return  "怪兽躲避";
        }

         
        if(igametype== 7)
        {
            return  "怪兽跳跃";
        }

        if(igametype == 8)
        {
            return  "俄罗斯方块";
        }

        if(igametype == 10)
        {
            return  "移动怪兽消除";
        }
        if(igametype == 11)
        {
            return  "翻牌消消乐";
        }
        if(igametype == 12)
        {
            return  "数字消除";
        }

        if(igametype == 21)
        {
            return  "螺丝排序挑战场";
        }
        if(igametype == 22)
        {
            return  "螺丝合成";
        }



        if(igametype == 131)
        {
            return  "滑木块-简单";

        }
        if(igametype == 132)
        {
            return  "滑木块-普通";

        }
        if(igametype == 133)
        {
            return  "滑木块-中等";
        }
        if(igametype == 134)
        {
            return  "滑木块-困难";
        } if(igametype == 135)
        {
            return  "滑木块-超难";
        }

        if(igametype >30 && igametype < 40)
        {
            if(igametype == 34)
            {
                return  "怪兽拼拼";
            }

            if(igametype == 31)
            {
                return  "花朵拼拼挑战场";
            }
            if(igametype == 35)
            {
                return  "怪兽拼拼挑战场";
            }

            return  "花朵拼拼";
        }

        if(igametype > 100 && igametype <=  120)
        {
            var imode = igametype - 100;
            return  "数字华容道-"+imode+"x"+imode;
        }

        return "";
    }

     

    /*
    Get_Guoguang_Gk_Jiangli_Jinbi_Xingxing(isubgametype, igk)
    {

        var iguoguangcount = GlobalGameMng.GetInstance().Get_GameType_GK_Guoguang_Count(isubgametype, igk);
        var bfistwin = true;
        if(iguoguangcount > 0)
        {
            bfistwin = false;
        }

        var ijinbiadd = 5;
        var ixingxingadd = 2;
        if(bfistwin)
        {
            ijinbiadd = 10;
            ixingxingadd = 5;

            if(igk%4 == 0  )
            {
                ijinbiadd += 10;
                ixingxingadd += 5;
            }
        }

        return [ijinbiadd,ixingxingadd]

    }
    */

    Get_Guoguang_Gk_Jiangli(isubgametype, igk)
    {
        var iguoguangcount = GlobalGameMng.GetInstance().Get_GameType_GK_Guoguang_Count(isubgametype, igk);
        var bfistwin = true;
        if(iguoguangcount > 0)
        {
            bfistwin = false;
        }


        return this.Get_Game_Gk_Winned_Jiangli(isubgametype,igk,bfistwin,iguoguangcount)
    }
    Get_Game_Gk_Winned_Jiangli(igametype,igk,bfirstwin,igkwinnedcount)
    {
        var ijinbi = 5;
        var izuanshi = 0;
        if(bfirstwin)
        {
            ijinbi = 10;
            izuanshi = 10;
        }else{
            if(igkwinnedcount >= 5)
            {
                ijinbi = 1;
                izuanshi = 0;
            }
        }


        if(izuanshi > 0)
        {
            return [{"t":1,"c":ijinbi},{"t":5,"c":izuanshi}];
        }

        return [{"t":1,"c":ijinbi}];

        /*
        var ijinbiadd = 5;
        var ixuanzhangadd = 0;
        if(bfirstwin)
        {
            ijinbiadd = 10;
            ixuanzhangadd = 10;

            if(igk%4 == 0  )
            {
                ijinbiadd += 10;
                ixuanzhangadd += 10;
            }
        }

        if(igkwinnedcount >= 10)
        {
            ijinbiadd = 1;
        
        }

        if(ixuanzhangadd > 0)
        {
            return [{"t":1,"c":ijinbiadd},{"t":4,"c":ixuanzhangadd}];
        }

        return [{"t":1,"c":ijinbiadd}];
        */

    }

    Get_GameType_GK_Guoguang_Count(isubgametype, ilevel)
    {
        var str = "game_"+isubgametype+"_gk_"+ilevel+"_suc_c";
        var prevstr = MyLocalStorge.getItem(str,"");
        var ipevc = 0;
        if(prevstr)
        {
            ipevc = ComFunc.Check_Read_Number(prevstr);
        }
        return ipevc;
    }

    On_GameType_GK_Guoguang(isubgametype, ilevel)
    {
        var ipevc = this.Get_GameType_GK_Guoguang_Count(isubgametype, ilevel)
        var str = "game_"+isubgametype+"_gk_"+ilevel+"_suc_c";
   
        ipevc +=1;
        MyLocalStorge.setItem(str,""+ipevc);
    }




    Get_Gamesuc_Dlg_Default_Gouxuan()
    {
        var idefaultv = 0;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            if(this.Check_Chaoguo_Shenhe_Riqi())
            {
                return 1;
            }

            return idefaultv;
        }
        if(this.In_Shenhe())
        {
            return 0;
        }
        var gamesuc_dlg_video_config = cur_valid_config.gamesuc_dlg_video_config;

        if(!gamesuc_dlg_video_config)
        {
            return idefaultv;
        }
   
        var gamesuc_dlg_default_gouxuan = gamesuc_dlg_video_config.gamesuc_dlg_default_gouxuan;
        if(gamesuc_dlg_default_gouxuan == undefined)
        {
            return idefaultv;
        }

        return gamesuc_dlg_default_gouxuan;
    }

    IS_Dating_Mode_3_More_Wanfa_Show_Mukuai_Yuoxi()
    {
        var idefaultv = 1;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }


        var dating_mode3_morewanfa_show_mukuai_youxi = cur_valid_config.dating_mode3_morewanfa_show_mukuai_youxi;
        if(dating_mode3_morewanfa_show_mukuai_youxi == undefined)
        {
            return idefaultv;
        }

        return dating_mode3_morewanfa_show_mukuai_youxi;
    }
    Get_Gamesuc_Dlg_ReCheck_Gouxuan_Need_GK()
    {
        var idefaultv = 3;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamesuc_dlg_video_config = cur_valid_config.gamesuc_dlg_video_config;

        if(!gamesuc_dlg_video_config)
        {
            return idefaultv;
        }
    
        var gamesuc_dlg_recheck_gouxuan_need_jiange_gk = gamesuc_dlg_video_config.gamesuc_dlg_recheck_gouxuan_need_jiange_gk;
        if(gamesuc_dlg_recheck_gouxuan_need_jiange_gk == undefined)
        {
            return idefaultv;
        }

        return gamesuc_dlg_recheck_gouxuan_need_jiange_gk;
    }
    Get_Gamesuc_Dlg_Next_Gouxuan_Type()
    {
        var idefaultv = 2;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            if(this.Check_Chaoguo_Shenhe_Riqi())
            {
                return 1;
            }

            return idefaultv;
        }
        if(this.In_Shenhe())
        {
            return 0;
        }
        var gamesuc_dlg_video_config = cur_valid_config.gamesuc_dlg_video_config;
      
        if(!gamesuc_dlg_video_config)
        {
            return idefaultv;
        }



        var gamesuc_dlg_next_gouxuan_type = gamesuc_dlg_video_config.gamesuc_dlg_next_gouxuan_type;
        if(gamesuc_dlg_next_gouxuan_type == undefined)
        {
            return idefaultv;
        }

        return gamesuc_dlg_next_gouxuan_type;
    }

    
    Check_Chaoguo_Shenhe_Riqi()
    {
        var curdayuinn = ComFunc.GetCurDayUnion();

      //  console.log("Check_Chaoguo_Shenhe_Riqi curdayuinn="+curdayuinn)
        if(curdayuinn > PlatFormParaMng.GetInstance().m_xianding_tishen_fangkai_day)
        {
            console.log("过期 curdayuinn="+curdayuinn)
            return true;
        }

        return false;
    }
    Get_Qiandao_Next_Gouxuan_Type()
    {
        var idefaultv = 2;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {

            if(this.Check_Chaoguo_Shenhe_Riqi())
            {
                return 1;
            }

            return idefaultv;
        }

        if(this.In_Shenhe())
        {
            return 0;
        }


        var qiandao_dlg_next_gouxuan_type = cur_valid_config.qiandao_dlg_next_gouxuan_type;
        if(qiandao_dlg_next_gouxuan_type == undefined)
        {
            return idefaultv;
        }

        return qiandao_dlg_next_gouxuan_type;
    }

    Get_Qiandao_Default_Gouxuan()
    {
        var idefaultv = 0;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            if(this.Check_Chaoguo_Shenhe_Riqi())
            {
                return 1;
            }

            return idefaultv;
        }
    
        if(this.In_Shenhe())
        {
            return 0;
        }



        var qiandao_dlg_default_gouxuan = cur_valid_config.qiandao_dlg_default_gouxuan;
        if(qiandao_dlg_default_gouxuan == undefined)
        {
            return idefaultv;
        }

        return qiandao_dlg_default_gouxuan;
    }


    //0:进程内弹出一次，1：每次都要弹出，2：在间隔gk后弹出
    Get_Qiandao_Dlg_Tachu_Type()
    {
        var idefaultv = 0;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            if(this.Check_Chaoguo_Shenhe_Riqi())
            {
                return 1;
            }
            return idefaultv;
        }


        var qiandao_dlg_tanchu_type = cur_valid_config.qiandao_dlg_tanchu_type;
        if(qiandao_dlg_tanchu_type == undefined)
        {
            return idefaultv;
        }

        return qiandao_dlg_tanchu_type;
    }

    //间隔几关
    Get_Qiandao_Dlg_Tachu_Per_GK()
    {
        var idefaultv = 0;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }


        var qiandao_dlg_tanchu_per_guangka = cur_valid_config.qiandao_dlg_tanchu_per_guangka;
        if(qiandao_dlg_tanchu_per_guangka == undefined)
        {
            return idefaultv;
        }

        return qiandao_dlg_tanchu_per_guangka;
    }

 

    //明确控制banner是否自动刷新
    IS_Server_JingQue_Kongzhi_Banner_Need_Auto_Shuaxin(ibannerindex)
    {

        /*
        if(!this.m_readed_game_common_config_remote_json)
        {
            return [0,0];
        }

        if(!this.m_readed_game_common_config_remote_json.bvalid)
        {
            
        }


        */
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return  [0,0];
        }

         //直接id配置是否需要刷新
         var banner_id_autoshuaxin = cur_valid_config.banner_id_autoshuaxin;

         if(!banner_id_autoshuaxin)
         {
            return [0,0];
         }
         if(banner_id_autoshuaxin && banner_id_autoshuaxin.length > 0)
         {
             for(var ff=0;ff<banner_id_autoshuaxin.length;ff++)
             {
                 var ff_sub_arr = banner_id_autoshuaxin[ff];
                 if(ff_sub_arr.length == 2)
                 {
                     var ff_bannerid = ff_sub_arr[0];
                     var ff_banner_need_auto_shuaxin = ff_sub_arr[1];
 
                     if(ff_bannerid == ibannerindex)
                     {
                        return [1, ff_banner_need_auto_shuaxin];
                     }
                 }
             }
         }
 
         return [0,0];
    }
    //banner是否需要自动刷新
    Check_Banner_Need_Zidong_Shuaxin(ibannerindex,ibanenrtype)
    {

        /*
        if(!this.m_readed_game_common_config_remote_json)
        {
            return false;
        }

        if(!this.m_readed_game_common_config_remote_json.bvalid)
        {
            return false;
        }

        */

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return  false;
        }

       

        if(ibanenrtype == 2)
        {
            var gezi_need_zidong_shuaxin = cur_valid_config.gezi_need_zidong_shuaxin;

            if(!gezi_need_zidong_shuaxin)
            {
                gezi_need_zidong_shuaxin = 0;
            }

            return gezi_need_zidong_shuaxin;
        }

        var banner_need_zidong_shuaxin = cur_valid_config.banner_need_zidong_shuaxin;

        if(!banner_need_zidong_shuaxin)
        {
            banner_need_zidong_shuaxin = 0;
        }

        return banner_need_zidong_shuaxin;
    }

    Send_Server_Xunzhang_Paihangbang()
    {
        var ixunzhangcount = this.Get_Self_DestType_Daoju_Count(4);

        this.Send_Server_GameType_Paihangbang(1001, ixunzhangcount);
    }

    Check_Post_Request_Other_User_Info(sguid,callback)
    {
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(104, "获取其他用户昵称头像", 0,
             sguid, 0, "", 0, "",   callback);
    }
    Post_Server_Get_PaihangBang_Data(itype,callback)
    {
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(103, "获取排行榜数据", itype,
        "", 0, "", 0, "",   callback);
    }

    Record_User_Stay_In_Subgame_Sec(prev_gametype,istaysec)
    {
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(25 , "记录游戏玩法停留时长", prev_gametype,
        "", istaysec, istaysec+"秒", 0, "",   null);
    }
    Send_Server_GameType_Paihangbang(isubgametype,iscore)
    {
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(102, "发送排行榜数据", isubgametype,
            "", iscore, "", 0, "",
            (bsuc,sresponse)=>
            {
                if(!bsuc)
                {
                    return;
                }


              //  console.log("排行榜返回1:"+sresponse);
                

            });

    }
//滑木块使用预定义关卡数目
Get_Huamukuai_First_Use_Yudingyi_GK()
{
    var idefaultv = 8;
    var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
    if(!cur_valid_config)
    {
        return idefaultv;
    }


    var huamukuai_first_use_yudingyi_gk_c = cur_valid_config.huamukuai_first_use_yudingyi_gk_c;
    if(huamukuai_first_use_yudingyi_gk_c == undefined)
    {
        return idefaultv;
    }

    return huamukuai_first_use_yudingyi_gk_c;
}
   
    Get_Aawrd_Daoju_Icon(iawrdtype)
    {
        if(iawrdtype < 10)
        {
            return "daoju/com/"+iawrdtype;
        }
        else if(iawrdtype < 50)
        {
            return "daoju/com/"+iawrdtype;
        }
        else if(iawrdtype > 100 && iawrdtype < 200)
        {
            var idaojutype = iawrdtype - 100;

            return "daoju/game1/"+idaojutype;
        }

        else if(iawrdtype > 200 && iawrdtype < 300)
        {
            var idaojutype = iawrdtype - 200;

            return "daoju/game2/"+idaojutype;
        }

        else if(iawrdtype > 400 && iawrdtype < 500)
        {
            var idaojutype = iawrdtype - 400;

            return "daoju/game4/"+idaojutype;
        }


        else  if(iawrdtype > 500 && iawrdtype < 600)
        {
            var idaojutype = iawrdtype - 500;

            return "daoju/game5/"+idaojutype;
        }

        else  if(iawrdtype > 1100 && iawrdtype < 1200)
        {
            var idaojutype = iawrdtype - 1100;

            return "daoju/game11/"+idaojutype;
        }

        


        return "image/game/help"
    }
    Get_DaojuType_Show_Name(iawrdtype)
    {

        if(iawrdtype == 1)
        {
            return "金币";
        }
        if(iawrdtype ==2)
        {
            return "星星";
        }
        if(iawrdtype ==3)
        {
            return "体力";
        }
        if(iawrdtype == 4)
        {
            return "勋章";
        }

        if(iawrdtype == 5)
        {
            return "钻石";
        } 
        
        if(iawrdtype == 6)
        {
            return "锤子";
        }


        if(iawrdtype == 11)
        {
            return "重玩卡";
        }
        if(iawrdtype == 12)
        {
            return "跳关卡";
        }

        if(iawrdtype == 13)
        {
            return "自动提示卡";
        }
        if(iawrdtype == 14)
        {
            return "逐歩提示卡";
        }
        
   
        if(iawrdtype == 21)
        {
            return "提示";
        }
        if(iawrdtype == 22)
        {
            return "刷子";
        }

        if(iawrdtype == 23)
        {
            return "冰冻";
        }
        if(iawrdtype == 24)
        {
            return "刷新";
        }


        if(iawrdtype == 32)
        {
            return "星星";
        }


        if(iawrdtype == 31)
        {
            return "提示卡";
        }
        if(iawrdtype == 34)
        {
            return "刷新卡";
        }


        if(iawrdtype == 51)
        {
            return "螺丝排序撤回";
        }
        if(iawrdtype == 52)
        {
            return "螺丝排序刷新";
        }

        if(iawrdtype == 53)
        {
            return "螺丝排序调整";
        }




        if(iawrdtype == 101)
        {
            return "三消消撤回";
        }
        if(iawrdtype == 102)
        {
            return "三消消移除";
        }

        if(iawrdtype == 103)
        {
            return "三消消提示";
        }

        if(iawrdtype == 104)
        {
            return "三消消随机";
        }
 


        if(iawrdtype == 201)
        {
            return "泡泡龙炸弹";
        }
        if(iawrdtype == 202)
        {
            return "泡泡龙糖果";
        }

        if(iawrdtype == 203)
        {
            return "泡泡龙横波";
        }

        if(iawrdtype == 204)
        {
            return "泡泡龙竖波";
        }
 



        if(iawrdtype == 401)
        {
            return "消灭星星随机";
        }
        if(iawrdtype == 402)
        {
            return "消灭星星改色";
        }

        if(iawrdtype == 403)
        {
            return "消灭星星击碎";
        }





        if(iawrdtype == 501)
        {
            return "连连看随机";
        }


        if(iawrdtype == 502)
        {
            return "连连看放大镜";
        }

        if(iawrdtype == 503)
        {
            return "连连看炸弹";
        }


        if(iawrdtype == 1101)
        {
            return "翻牌增加步数";
        }

        if(iawrdtype == 1102)
        {
            return "翻牌透视";
        }


        if(iawrdtype == 1103)
        {
            return "翻牌炸弹";
        }



        return "物品";
    }
    Common_Add_Award_List(awarddaoju,ibeishu)
    {
        for(var ff=0;ff<awarddaoju.length;ff++){
            var ff_info =  awarddaoju[ff];
            var ff_t = ff_info.t;
            var ff_c = ff_info.c  ;
             var icount=  ff_c*ibeishu;

            if(ff_t < 10)
            {
                this.Change_Self_DaojuType_Count(ff_t,icount);
                this.Save_Game_Basic_Info();

            }else if(ff_t > 10 && ff_t< 20)
            {
                
                if(ff_t == 11)
                {
                    GlobalMng.GetInstance().Change_ChongwanKa_Count(icount);
                } 
                else if(ff_t == 12)
                {
                    GlobalMng.GetInstance().Add_TiaoGuangKa_Count(icount);
                }else if(ff_t == 13)
                {
                    GlobalMng.GetInstance().Add_XiaoTishiKa_Count(icount);
                }else if(ff_t == 14)
                {
                    GlobalMng.GetInstance().Add_DaTishiKa_Count(icount);
                }

            }
            else if(ff_t > 100 && ff_t < 200)
            {
                //

                var irealtype = ff_t - 100 ;


                if(irealtype == 1)
                {
                    GSXC_Game_Mng.GetInstance().itemUndo += icount;
                } 
                else if(irealtype == 2)
                {
                    GSXC_Game_Mng.GetInstance().itemYichu += icount;
                } else if(irealtype == 3)
                {
                    GSXC_Game_Mng.GetInstance().itemHint += icount;
                }else if(irealtype == 4)
                {
                    GSXC_Game_Mng.GetInstance().itemShuffle += icount;
                }


                GSXC_Game_Mng.GetInstance().Save_Game_Basic_Info();
            }
            else if(ff_t > 200 && ff_t < 300)
            {
                //泡泡龙
                var idaojutype = ff_t - 200 + 100;


                PaoPaoLongMng.GetInstance().Change_Daoju_Type_Count(idaojutype,icount);
      
               

            }else if(ff_t > 500 && ff_t <600)
            {
                //连连看

                var idaojutype = ff_t - 500 + 100;
                LianLianKanGameMng.GetInstance().Change_Daoju_Type_Count(idaojutype,icount);
         


            }else if(ff_t > 400 && ff_t < 500)
            {
                //消灭星星
                var idaojutype = ff_t - 400 + 100;
            

                XiaoMieXingxingMng.GetInstance().Change_Daoju_Type_Count(idaojutype,icount);
          
          

            }else if(ff_t > 1100 && ff_t < 1200)
            {
                //翻牌消消乐
                var idaojutype = ff_t - 1100 + 100;
            
                fanpaiXiaoXiaoMng.GetInstance().Change_Daoju_Type_Count(idaojutype,icount);
          
 
         
            }




        }
    }


    Get_Self_Reg_Tick()
    {

        return this.Check_Save_First_Reg_Tick();
    }



   
    Check_Save_First_Reg_Tick()
    {
        

         var self_reg_tick = Date.now();

        var bprevsaved = false;
        var prev_reg_day = 0;
        var reg_day_info = MyLocalStorge.getItem("guaishou_daxiaochu_reg_tick");
        var jobj = null;
        if(reg_day_info)
        {
            try{
                jobj = JSON.parse(reg_day_info);
            }catch(e)
            {}
            
            if(jobj)
            {
                var reg_day_tick =  jobj.reg_day_tick;
                if(reg_day_tick && reg_day_tick > 0 )
                {
                    bprevsaved = true;
                 
                    self_reg_tick = reg_day_tick;
                }
            }
        }

        if(!bprevsaved)
        {
            var obj = {reg_day_tick:self_reg_tick};
            

            MyLocalStorge.setItem("guaishou_daxiaochu_reg_tick",JSON.stringify(obj));
        }else{
 

        }

      
        return self_reg_tick;
    }


    Get_All_Banner_Gezi_Default_Shuaxin_Sec()
    {
        var idefaultv = 0;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var banner_gezi_all_default_shuaxin_sec = cur_valid_config.banner_gezi_all_default_shuaxin_sec;
        if(banner_gezi_all_default_shuaxin_sec == undefined)
        {
            return idefaultv;
        }

        return banner_gezi_all_default_shuaxin_sec;
    }
    Get_First_Enter_Game_Need_Create_BannerID_List()
    {
        var idefaultv =  [];
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var first_enter_game_need_create_bannerid_list = cur_valid_config.first_enter_game_need_create_bannerid_list;
        if(first_enter_game_need_create_bannerid_list == undefined)
        {
            return idefaultv;
        }

        return first_enter_game_need_create_bannerid_list;
    }

    Get_Sanxiaoxiao_GameFuhuo_Dlg_Dealy_Show_Btn_Sec()
    {
        var idefaultv = 1.2;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var sanxiaoxiao_gamefuhuo_dlg_delay_show_btn_sec = cur_valid_config.sanxiaoxiao_gamefuhuo_dlg_delay_show_btn_sec;
        if(sanxiaoxiao_gamefuhuo_dlg_delay_show_btn_sec == undefined)
        {
            return idefaultv;
        }

        return sanxiaoxiao_gamefuhuo_dlg_delay_show_btn_sec;
    }
    Get_Sanxiaoxiao_GoumaiDaoju_Dlg_Dealy_Show_Btn_Sec()
    {
        var idefaultv = 1.2;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var sanxiaoxiao_goumaidaoju_dlg_delay_show_btn_sec = cur_valid_config.sanxiaoxiao_goumaidaoju_dlg_delay_show_btn_sec;
        if(sanxiaoxiao_goumaidaoju_dlg_delay_show_btn_sec == undefined)
        {
            return idefaultv;
        }

        return sanxiaoxiao_goumaidaoju_dlg_delay_show_btn_sec;
    }
    Get_FanhuiDating_Queren_Dlg_Dealy_Show_Btn_Sec()
    {
        var idefaultv = 1.2;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var fanhuidating_queren_dlg_delay_show_btn_sec = cur_valid_config.fanhuidating_queren_dlg_delay_show_btn_sec;
        if(fanhuidating_queren_dlg_delay_show_btn_sec == undefined)
        {
            return idefaultv;
        }

        return fanhuidating_queren_dlg_delay_show_btn_sec;
    }
    Get_ShouKan_Libao_Dlg_Dealy_Show_Btn_Sec()
    {
        var idefaultv = 1.2;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var shoukanfuli_libao_dlg_delay_show_btn_sec = cur_valid_config.shoukanfuli_libao_dlg_delay_show_btn_sec;
        if(shoukanfuli_libao_dlg_delay_show_btn_sec == undefined)
        {
            return idefaultv;
        }

        return shoukanfuli_libao_dlg_delay_show_btn_sec;
    }
    Get_QuanpingGuangao_Dlg_Dealy_Show_Btn_Sec()
    { 
        var idefaultv = 1.2;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var quanpingguangao_dlg_delay_show_btn_sec = cur_valid_config.quanpingguangao_dlg_delay_show_btn_sec;
        if(quanpingguangao_dlg_delay_show_btn_sec == undefined)
        {
            return idefaultv;
        }

        return quanpingguangao_dlg_delay_show_btn_sec;
    }

    Get_Banner_Manual_Destroy_Config()
    {
        var idefaultv = [];
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var banner_manual_destroy_config = cur_valid_config.banner_manual_destroy_config;
        if(banner_manual_destroy_config == undefined)
        {
            return idefaultv;
        }

        return banner_manual_destroy_config;
    }
    Get_BannerIndex_Shuaxin_Sec(ibannerindex)
    { 

        var idefaultv = this.Get_All_Banner_Gezi_Default_Shuaxin_Sec();
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var banner_gezi_id_shuaxin_sec_list = cur_valid_config.banner_gezi_id_shuaxin_sec_list;
        if(banner_gezi_id_shuaxin_sec_list  )
        {
            for(var ff=0;ff<banner_gezi_id_shuaxin_sec_list.length;ff++)
            {
                var ff_arr = banner_gezi_id_shuaxin_sec_list[ff];
    
                if(ff_arr.length < 2)
                {
                    continue;
                }
    
                if(ff_arr[0] == ibannerindex)
                {
                    return ff_arr[1]
                }
            }
        }

         

        var banner_gezi_shuaxin_sec_list = cur_valid_config.banner_gezi_shuaxin_sec_list;
     
        if(banner_gezi_shuaxin_sec_list )
        {
            for(var ff=0;ff<banner_gezi_shuaxin_sec_list.length;ff++)
            {
                var ff_info  = banner_gezi_shuaxin_sec_list[ff];

                var ff_i = ff_info.i;
                var ff_s = ff_info.s;
            
             
                if(ComFunc.arrayShuzuContain(ff_i,ibannerindex))
                {
                   // console.log("ibannerindex="+ibannerindex+",ff_i="+ff_i+",ff_s="+ff_s);
                    return ff_s;
                }
            }
        }

        return idefaultv;
    }

    
    Get_After_Start_Reg_Sec()
    {
        var eplasetick = Date.now()  - this.Get_Self_Reg_Tick();

        var isec = Math.floor(eplasetick/1000);

        return isec;
    }

    Get_After_Start_Reg_Tick()
    {
        var eplasetick = Date.now()  - this.Get_Self_Reg_Tick();

        return eplasetick;
    }
    Get_Qiandao_Start_Tick_Not_Gouxuan_Sec()
    {
        var idefaultv = 0;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }


        var qiandao_start_tick_not_gouxuan_count_sec = cur_valid_config.qiandao_start_tick_not_gouxuan_count_sec;
        if(qiandao_start_tick_not_gouxuan_count_sec == undefined)
        {
            return idefaultv;
        }

        return qiandao_start_tick_not_gouxuan_count_sec;
    }

    Get_Start_Sec_NotKou_Tili()
    {
        var idefaultv = 60;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var start_sec_not_kou_tili = cur_valid_config.start_sec_not_kou_tili;
        if(start_sec_not_kou_tili == undefined)
        {
            return idefaultv;
        }

       

        return start_sec_not_kou_tili;
    }

    Get_Qiandao_Start_Tick_Default_Gouxuan()
    {
        var idefaultv = 0;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }


        var qiandao_start_tick_default_gouxuan = cur_valid_config.qiandao_start_tick_default_gouxuan;
        if(qiandao_start_tick_default_gouxuan == undefined)
        {
            return idefaultv;
        }

        return qiandao_start_tick_default_gouxuan;
    }


    Get_GameSuc_Dlg_Start_Tick_Default_Gouxuan()
    {
        var idefaultv = 0;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }


        var gamesuccess_start_tick_default_gouxuan = cur_valid_config.gamesuccess_start_tick_default_gouxuan;
        if(gamesuccess_start_tick_default_gouxuan == undefined)
        {
            return idefaultv;
        }

        return gamesuccess_start_tick_default_gouxuan;
    }

    Get_GameSuccess_Start_Tick_Not_Gouxuan_Sec()
    {
        var idefaultv = 0;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }


        var gamesuccess_start_tick_not_gouxuan_count_sec = cur_valid_config.gamesuccess_start_tick_not_gouxuan_count_sec;
        if(gamesuccess_start_tick_not_gouxuan_count_sec == undefined)
        {
            return idefaultv;
        }

        return gamesuccess_start_tick_not_gouxuan_count_sec;
    }

    Get_GameSuc_Dlg_Dealy_Show_Btn_Sec()
    { 
        var idefaultv = 1;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamesuc_dlg_delay_show_btn_sec = cur_valid_config.gamesuc_dlg_delay_show_btn_sec;
        if(gamesuc_dlg_delay_show_btn_sec == undefined)
        {
            return idefaultv;
        }

        return gamesuc_dlg_delay_show_btn_sec;
    }

    Get_GameSuc_LingquWuping_Dlg_Dealy_Show_Btn_Sec()
    { 
        var idefaultv = 1;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamesuc_lingquwuping_dlg_delay_show_btn_sec = cur_valid_config.gamesuc_lingquwuping_dlg_delay_show_btn_sec;
        if(gamesuc_lingquwuping_dlg_delay_show_btn_sec == undefined)
        {
            return idefaultv;
        }

        return gamesuc_lingquwuping_dlg_delay_show_btn_sec;
    }

    Get_Qiandao_Dlg_Dealy_Show_Btn_Sec()
    { 
        var idefaultv = 1;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var qiandao_dlg_delay_show_btn_sec = cur_valid_config.qiandao_dlg_delay_show_btn_sec;
        if(qiandao_dlg_delay_show_btn_sec == undefined)
        {
            return idefaultv;
        }

        return qiandao_dlg_delay_show_btn_sec;
    }
    Get_GameFail_Dlg_Dealy_Show_Btn_Sec()
    { 
        var idefaultv = 2;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamefail_dlg_delay_show_btn_sec = cur_valid_config.gamefail_dlg_delay_show_btn_sec;
        if(gamefail_dlg_delay_show_btn_sec == undefined)
        {
            return idefaultv;
        }

        return gamefail_dlg_delay_show_btn_sec;
    }
    Get_GameFail_Continue_ChongWan_Dlg_Dealy_Show_Btn_Sec()
    {
        var idefaultv = 1.2;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamefail_continue_chongwan_dlg_delay_show_btn_sec = cur_valid_config.gamefail_continue_chongwan_dlg_delay_show_btn_sec;
        if(gamefail_continue_chongwan_dlg_delay_show_btn_sec == undefined)
        {
            return idefaultv;
        }

        return gamefail_continue_chongwan_dlg_delay_show_btn_sec;
    }

    IS_FanhuiDating_Auto_Pop_GengduoYouxi_Dlg()
    {
        var idefaultv = 1;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var fanhuidating_need_pop_auto_gengduowanfa = cur_valid_config.fanhuidating_need_pop_auto_gengduowanfa;
        if(fanhuidating_need_pop_auto_gengduowanfa == undefined)
        {
            return idefaultv;
        }

        return fanhuidating_need_pop_auto_gengduowanfa;
    }
    Get_GameFail_Dlg_Need_Show_Continue_Next_Dlg()
    {
        var idefaultv = 1;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamefail_dlg_need_show_continue_next_dlg = cur_valid_config.gamefail_dlg_need_show_continue_next_dlg;
        if(gamefail_dlg_need_show_continue_next_dlg == undefined)
        {
            return idefaultv;
        }

        return gamefail_dlg_need_show_continue_next_dlg;
    }
    Get_Chaping_Min_Jiange_Sec()
    {
        var idefaultv = 30;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var chaping_min_show_jiange_sec = cur_valid_config.chaping_min_show_jiange_sec;
        if(chaping_min_show_jiange_sec == undefined)
        {
            return idefaultv;
        }

        return chaping_min_show_jiange_sec;
    }

    Get_Huamukuai_Jiesuo_Nandu_Need_Shiping()
    {
        var idefaultv = 1;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var huamukuai_jiesuo_nandu_need_shiping = cur_valid_config.huamukuai_jiesuo_nandu_need_shiping;
        if(huamukuai_jiesuo_nandu_need_shiping == undefined)
        {
            return idefaultv;
        }

        return huamukuai_jiesuo_nandu_need_shiping;
    }
    IS_Watch_Video_Guanggao_Qufen_Mingxi()
    {
        var idefaultv = 1;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var watch_video_guangao_qufen_mingxi = cur_valid_config.watch_video_guangao_qufen_mingxi;
        if(watch_video_guangao_qufen_mingxi == undefined)
        {
            return idefaultv;
        }

     

        return watch_video_guangao_qufen_mingxi;
    }
    GameEnd_Pop_SuccessDlg_Delay_Sec(isubgametype)
    {
        var idefaultv = 4;
        return idefaultv;
        /*
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamesuc_dlg_video_config = cur_valid_config.gamesuc_dlg_video_config;
        if(!gamesuc_dlg_video_config)
        {
            return idefaultv;
        }

        var game_end_pop_success_dlg_dealy_sec = gamesuc_dlg_video_config.game_end_pop_success_dlg_dealy_sec;
        if(!game_end_pop_success_dlg_dealy_sec)
        {
            return idefaultv;
        }
        return game_end_pop_success_dlg_dealy_sec;
        */

    }

    Get_GameBottom_ChaogaoPing_Need_Show_Juzhen_Gezi()
    {
        var idefaultv = 1;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var all_game_bottom_chaogaoping_show_juzhen_gezi = cur_valid_config.all_game_bottom_chaogaoping_show_juzhen_gezi;
        if(all_game_bottom_chaogaoping_show_juzhen_gezi == undefined)
        {
            return idefaultv;
        }

        return all_game_bottom_chaogaoping_show_juzhen_gezi;
    }

    Get_Dating_Bottom_Show_Banner_Type()
    {
        var idefaultv = 2;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var dating_bottom_need_show_banner_type = cur_valid_config.dating_bottom_need_show_banner_type;
        if(dating_bottom_need_show_banner_type == undefined)
        {
            return idefaultv;
        }

        return dating_bottom_need_show_banner_type;
    }
    Get_GameSuc_dlg_Com_Lignqu_Need_Show_GameLingqu_Dlg()
    {
        var idefaultv = 1;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamesuc_dlg_com_lingqu_need_show_gamelingqu_dlg = cur_valid_config.gamesuc_dlg_com_lingqu_need_show_gamelingqu_dlg;
        if(gamesuc_dlg_com_lingqu_need_show_gamelingqu_dlg == undefined)
        {
            return idefaultv;
        }

        return gamesuc_dlg_com_lingqu_need_show_gamelingqu_dlg;
    }
      
    Get_LoadingTo_Game_Scence_Max_Tick(iscencindex)
    {
        var idefaultv = 2000;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }


        var loading_to_game_scence_tick_conf = cur_valid_config.loading_to_game_scence_tick_conf;
        if(loading_to_game_scence_tick_conf == undefined)
        {
            return idefaultv;
        }


        for(var ff=0;ff<loading_to_game_scence_tick_conf.length;ff++)
        {
            var ff_info = loading_to_game_scence_tick_conf[ff];

            var ff_arr = ff_info.i;
            var ff_min = ff_info.x;
            var ff_max = ff_info.d;

            if(ComFunc.arrayShuzuContain(ff_arr,iscencindex))
            {

                return ff_max;
            }
        }

        return idefaultv;
    }

    Get_LoadingTo_Game_Scence_Min_Tick(iscencindex)
    {
        var idefaultv = 1000;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }


        var loading_to_game_scence_tick_conf = cur_valid_config.loading_to_game_scence_tick_conf;
        if(loading_to_game_scence_tick_conf == undefined)
        {
            return idefaultv;
        }


        for(var ff=0;ff<loading_to_game_scence_tick_conf.length;ff++)
        {
            var ff_info = loading_to_game_scence_tick_conf[ff];

            var ff_arr = ff_info.i;
            var ff_min = ff_info.x;
            var ff_max = ff_info.d;

            if(ComFunc.arrayShuzuContain(ff_arr,iscencindex))
            {

                return ff_min;
            }
        }

        return idefaultv;
    }
    IS_First_Enter_Dating_Hide_Qiandao()
    {
        var idefaultv = 0;

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }
        var first_enter_dating_hide_qiandao = cur_valid_config.first_enter_dating_hide_qiandao;
        if(!first_enter_dating_hide_qiandao)
        {
            first_enter_dating_hide_qiandao = 0;
        }

        return first_enter_dating_hide_qiandao;
    }
    Get_From_Subgame_To_Secene_Show(ifromsubgame,enter_scence_index,iposindex)
    {
        var idefaultv = 1;

        if(enter_scence_index == 0)
        {
             return 1;
        }

        /*
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }


        var loading_scece_show_conf = cur_valid_config.loading_scece_show_conf;
        if(loading_scece_show_conf == undefined)
        {
            return idefaultv;
        }



        for(var ff=0;ff<loading_scece_show_conf.length;ff++)
        {
            var ff_info = loading_scece_show_conf[ff];

            var fall = ff_info.fall;
            var f_f = ff_info.f;
            var f_tall = ff_info.tall;
            var f_t = ff_info.t;
            var f_indexall = ff_info.indexall;
            var f_index = ff_info.index;
            var f_show = ff_info.show;

            var bfuhe = true;

            if(!fall)
            {
                var contain1 = ComFunc.arrayShuzuContain(f_f,ifromsubgame)

                if(!contain1)
                {
                    bfuhe = false;
                }
            }

            if(!f_tall)
            {
                var contain2 = ComFunc.arrayShuzuContain(f_t,enter_scence_index)

                if(!contain2)
                {
                    bfuhe = false;
                }
            }

            if(!f_indexall)
            {
                var contain3 = ComFunc.arrayShuzuContain(f_index,iposindex)

                if(!contain3)
                {
                    bfuhe = false;
                }
            }

            if(!bfuhe)
            {
                continue;
            }


            console.log("scece ifromsubgame="+ifromsubgame+",enter_scence_index="+enter_scence_index+
                ",iposindex="+iposindex+",f_show="+f_show);

            return f_show
        }


        */
        return idefaultv;
    }


    //判断是否应该屏蔽对应的格子
    Check_Banner_Index_Need_Pingbi(ibannerindex)
    {
        var idefaultv = 0;

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var banner_gezi_need_pingbi_id_list = cur_valid_config.banner_gezi_need_pingbi_id_list;
        if(banner_gezi_need_pingbi_id_list == undefined)
        {
            return idefaultv;
        }


        for(var ff=0;ff<banner_gezi_need_pingbi_id_list.length;ff++)
        {
            var ff_id = banner_gezi_need_pingbi_id_list[ff];
            if(ff_id == ibannerindex)
            {
                return 1;
            }
        }

        return idefaultv;
    }


    Get_Mode_45_Tiaozhan_Btn_Need_Min_CG_GK()
    {
        var idefaultv = 0;

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var special_dating_gamebtn_caidan = cur_valid_config.special_dating_gamebtn_caidan;
   
        var cur_reg_day = this.Get_Self_Reg_Day();


        for(var ff=0;ff<special_dating_gamebtn_caidan.length;ff++)
        {
            var ff_info = special_dating_gamebtn_caidan[ff];

            if(ff_info.startday <= cur_reg_day && cur_reg_day <= ff_info.endday)
            {
                var tiaozhan_btn_need_cg_gk = ff_info.tiaozhan_btn_need_cg_gk;

                if(!tiaozhan_btn_need_cg_gk)
                {
                    tiaozhan_btn_need_cg_gk = 0;
                }

                return tiaozhan_btn_need_cg_gk;
            }
        }
        return idefaultv;
    
    }
    Get_Mode_45_MoreWanfa_Btn_Need_Min_CG_GK()
    {
        var idefaultv = 0;

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var special_dating_gamebtn_caidan = cur_valid_config.special_dating_gamebtn_caidan;
   
        var cur_reg_day = this.Get_Self_Reg_Day();


        for(var ff=0;ff<special_dating_gamebtn_caidan.length;ff++)
        {
            var ff_info = special_dating_gamebtn_caidan[ff];

            if(ff_info.startday <= cur_reg_day && cur_reg_day <= ff_info.endday)
            {
                var morewanfa_btn_need_cg_gk = ff_info.morewanfa_btn_need_cg_gk;

                if(!morewanfa_btn_need_cg_gk)
                {
                    morewanfa_btn_need_cg_gk = 0;
                }

                return morewanfa_btn_need_cg_gk;
            }
        }
        return idefaultv;
    
    }
    Get_Config_Dating_Show_GameBtn_Caidan_Mode()
    {
        var idefaultv = 1;

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var special_dating_gamebtn_caidan = cur_valid_config.special_dating_gamebtn_caidan;
   
        var cur_reg_day = this.Get_Self_Reg_Day();


        for(var ff=0;ff<special_dating_gamebtn_caidan.length;ff++)
        {
            var ff_info = special_dating_gamebtn_caidan[ff];

            if(ff_info.startday <= cur_reg_day && cur_reg_day <= ff_info.endday)
            {
                var ff_mdoe = ff_info.mode;

                return ff_mdoe;
            }
        }


        var dating_show_gamebtn_caidan_mode = cur_valid_config.dating_show_gamebtn_caidan_mode;
        if(dating_show_gamebtn_caidan_mode == undefined)
        {
            return idefaultv;
        }
 

        return dating_show_gamebtn_caidan_mode;
    }
    Get_Sanxiaoxiao_Daojutype_Per_Shiping_Goumai_Count(itype)
    {
        var idefaultv = 3;

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var sanxiaoxiao_daojutype_pershiping_goumai_count = cur_valid_config.sanxiaoxiao_daojutype_pershiping_goumai_count;
        if(!sanxiaoxiao_daojutype_pershiping_goumai_count)
        {
            return idefaultv;
        }

        var icc  = 3;
        for(var ff=0;ff<sanxiaoxiao_daojutype_pershiping_goumai_count.length;ff++)
        {
            var ff_info = sanxiaoxiao_daojutype_pershiping_goumai_count[ff];

            var ff_t = ff_info.t;
            var ff_c = ff_info.c;

            if(ff_t == itype)
            {
                return ff_c;
            }

            if(ff_t == 0)
            {
                icc = ff_c;
            }
        }

        if(!icc)
        {
            icc = 3;
        }

        return icc;
    }
    Get_Cur_Process_Dating_Show_GameBtn_Caidan_Mode()
    {

        if(this.m_cur_process_dating_show_caidan_mode > 0)
        {
            return this.m_cur_process_dating_show_caidan_mode;
        }

        var config_caidan_mode = this.Get_Config_Dating_Show_GameBtn_Caidan_Mode();

       // var config_caidan_mode = this.Get_Config_Dating_Show_GameBtn_Caidan_Mode();

        if(!config_caidan_mode)
        {
            config_caidan_mode = 1;
        }
        this.m_cur_process_dating_show_caidan_mode = config_caidan_mode;
        
        return this.m_cur_process_dating_show_caidan_mode;
    }
    IS_Watch_Video_Guanggao_Not_Same_Unionid_Need_Destroy_Prev()
    {
        var idefaultv = 0;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var watch_video_not_same_need_destroy_prev = cur_valid_config.watch_video_not_same_need_destroy_prev;
        if(watch_video_not_same_need_destroy_prev == undefined)
        {
            return idefaultv;
        }

     

        return watch_video_not_same_need_destroy_prev;
    }

    Get_Huaduo_Xiaoxiao_Config_Show_Type()
    {
        var idefaultv = 3;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var huaduoxiaoxiao_config_show_type = cur_valid_config.huaduoxiaoxiao_config_show_type;
        if(huaduoxiaoxiao_config_show_type == undefined)
        {
            return idefaultv;
        }
        if(!huaduoxiaoxiao_config_show_type)
        {
            return idefaultv;
        }

     

        return huaduoxiaoxiao_config_show_type;
    }
    Get_Config_Shoukan_Libao_Dlg_Mode()
    {
        var idefaultv = 1;

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var shoukan_fuli_libao_dlg_mode = cur_valid_config.shoukan_fuli_libao_dlg_mode;
        if(shoukan_fuli_libao_dlg_mode == undefined)
        {
            return idefaultv;
        }
 

        return shoukan_fuli_libao_dlg_mode;
    }
    Get_Cur_Process_Shoukan_Libao_Dlg_Mode()
    {
        if(this.m_cur_process_shoukanfuli_libao_dlg_mode > 0)
        {
            return this.m_cur_process_shoukanfuli_libao_dlg_mode;
        }
        var config_caidan_mode = this.Get_Config_Shoukan_Libao_Dlg_Mode();

        if(!config_caidan_mode)
        {
            config_caidan_mode = 1;
        }
        this.m_cur_process_shoukanfuli_libao_dlg_mode = config_caidan_mode;
        
        return this.m_cur_process_shoukanfuli_libao_dlg_mode;
    }

    Get_Config_Process_FanhuiDating_Queren_Dlg_Mode()
    {
        var idefaultv = 2;

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var fanhuidating_queren_dlg_mode = cur_valid_config.fanhuidating_queren_dlg_mode;
        if(fanhuidating_queren_dlg_mode == undefined)
        {
            return idefaultv;
        }
 

        return fanhuidating_queren_dlg_mode;
    }
    Get_Watch_Video_Fail_Need_Show_Error_Lingqu_Dlg_Left_Sec(i_watch_type)
    {
        var idefaultv = 10;
        /*
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var watch_video_fail_dlg = cur_valid_config.watch_video_fail_dlg;
        if(!watch_video_fail_dlg)
        {
            return idefaultv;
        }

        for(var ff=0;ff<watch_video_fail_dlg.length;ff++)
        {
            var ff_info  = watch_video_fail_dlg[ff];
            var ff_ntype = ff_info.ntype;
            var ff_sec = ff_info.sec;

            if(ComFunc.Is_In_Arr_Range_Arr(ff_ntype,i_watch_type))
            {
                return ff_sec;
            }
        }

        */
        return idefaultv;

    }
    Is_Dating_HMK_Btn_Use_Liangse()
    {
        var idefaultv = 0;

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var dating_hmk_btn_use_liangse = cur_valid_config.dating_hmk_btn_use_liangse;
        if(dating_hmk_btn_use_liangse == undefined)
        {
            return idefaultv;
        }
 

        return dating_hmk_btn_use_liangse;
    }
    Get_Cur_Process_FanhuiDating_Queren_Dlg_Mode()
    {
        if(this.m_cur_process_fanhuidating_queren_dlg_mode > 0)
        {
            return this.m_cur_process_fanhuidating_queren_dlg_mode;
        }
        var config_caidan_mode = this.Get_Config_Process_FanhuiDating_Queren_Dlg_Mode();

        if(!config_caidan_mode)
        {
            config_caidan_mode = 1;
        }
        this.m_cur_process_fanhuidating_queren_dlg_mode = config_caidan_mode;
        
        return this.m_cur_process_fanhuidating_queren_dlg_mode;
    }
    Get_Game_Banner_Mng_Time_Config(igametype)
    {
        var idefaultv = 2;

        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var speical_game_banner_mng_time_sec = cur_valid_config.speical_game_banner_mng_time_sec;

        if(speical_game_banner_mng_time_sec)
        {
            for(var ff=0;ff<speical_game_banner_mng_time_sec.length;ff++)
            {
                var ff_info  = speical_game_banner_mng_time_sec[ff];

                if(ff_info.i == igametype)
                {
                    var sec = ff_info.s;

                    if(sec && sec > 0)
                    {
                        return sec;
                    }
                }
            }
        }
  
        var all_game_banner_mng_time_sec_default = cur_valid_config.all_game_banner_mng_time_sec_default;
        if(all_game_banner_mng_time_sec_default == undefined)
        {
            return idefaultv;
        }
        return all_game_banner_mng_time_sec_default;
    }

    Get_Dating_Caidan_Mode_Back_From_Game_Need_Pop_GengduoYouxi_Gametype_List(icaidanmode)
    {
        if(icaidanmode == 2)
        {

            return [7,4,10,12,11,103,104,105,106,107,108,109]
        }

        if(icaidanmode == 3)
        {

            return [7,4,10,12,103,104,105,106,107,108,109,131,132,133,134,135,136]
        }
        if(icaidanmode == 4)
        {

            return [];
        }
        if(icaidanmode == 5)
        {

            return [2,3,4,5,6,7,8,10,11,12,103,104,105,106,107,108,109,131,132,133,134,135,136]
        }
        return [7,4,10,12];
    }
    IS_Can_Show_Zidingyi_TuijianWei()
    {
        var idefaultv = 1;
  
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var game_all_tuijianwei_show = cur_valid_config.game_all_tuijianwei_show;
        if(game_all_tuijianwei_show == undefined)
        {
            return idefaultv;
        }

        return game_all_tuijianwei_show;
    }
    IS_GameSuc_Dlg_Tuijianwei_Show()
    {
        var idefaultv = 1;
  
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamesuc_dlg_tuijianwei_show = cur_valid_config.gamesuc_dlg_tuijianwei_show;
        if(gamesuc_dlg_tuijianwei_show == undefined)
        {
            return idefaultv;
        }

        return gamesuc_dlg_tuijianwei_show;
    }
    IS_GameFail_Dlg_Tuijianwei_Show()
    {
        var idefaultv = 1;
  
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamefail_dlg_tuijianwei_show = cur_valid_config.gamefail_dlg_tuijianwei_show;
        if(gamefail_dlg_tuijianwei_show == undefined)
        {
            return idefaultv;
        }

        return gamefail_dlg_tuijianwei_show;
    }
    IS_Game_Continue_Fail_Dlg_Tuijianwei_Show()
    {
        var idefaultv = 1;
  
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var game_continue_fail_dlg_tuijianwei_show = cur_valid_config.game_continue_fail_dlg_tuijianwei_show;
        if(game_continue_fail_dlg_tuijianwei_show == undefined)
        {
            return idefaultv;
        }

        return game_continue_fail_dlg_tuijianwei_show;
    }
    In_Shenhe()
    {
        var idefaultv = 1;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }
        var in_shenhe_kg = cur_valid_config.in_shenhe_kg;
        if(in_shenhe_kg == 1)
        {
            return 1;
        }

        return 0;
    }
    Get_Game_Suc_Dlg_Auto_Uncheck_Gouxuan_Type()
    {
        var idefaultv = 0;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        if(this.In_Shenhe())
        {
            return 0;
        }

        var gamesuc_dlg_video_config = cur_valid_config.gamesuc_dlg_video_config;

        if(!gamesuc_dlg_video_config)
        {
            return idefaultv;
        }

    
        var aotu_uncheck_gouxuan_type = gamesuc_dlg_video_config.aotu_uncheck_gouxuan_type;
        if(aotu_uncheck_gouxuan_type == undefined)
        {
            return idefaultv;
        }

        return aotu_uncheck_gouxuan_type;
    }
    IS_Watch_Video_Fail_Need_Show_Error_Lingqu_Dlg(i_watch_type)
    {
        var idefaultv = 0;

        return 0;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        //审核开关打开，正在审核，不弹出
        var in_shenhe_kg = cur_valid_config.in_shenhe_kg;
        if(in_shenhe_kg == 1)
        {
            return 0;
        }

        var watch_video_fail_dlg = cur_valid_config.watch_video_fail_dlg;
        if(!watch_video_fail_dlg)
        {
            return idefaultv;
        }

        for(var ff=0;ff<watch_video_fail_dlg.length;ff++)
        {
            var ff_info  = watch_video_fail_dlg[ff];
            var ff_ntype = ff_info.ntype;

            if(ComFunc.Is_In_Arr_Range_Arr(ff_ntype,i_watch_type))
            {
                return 1;
            }
        }

        return idefaultv;
    }
    Get_Game_Suc_Dlg_Minsec_Jiange_From_Last_Watch_Video()
    {
        var idefaultv = 0;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamesuc_dlg_video_config = cur_valid_config.gamesuc_dlg_video_config;

        if(!gamesuc_dlg_video_config)
        {
            return idefaultv;
        }

    
        var minsec_jiange_from_last_watch_video_default_check = gamesuc_dlg_video_config.minsec_jiange_from_last_watch_video_default_check;
        if(minsec_jiange_from_last_watch_video_default_check == undefined)
        {
            return idefaultv;
        }

        return minsec_jiange_from_last_watch_video_default_check;
    }
   
    Get_Gamesuc_Dlg_Use_Default_Menu_Type()
    {
        var idefaultv = 2;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            if(this.Check_Chaoguo_Shenhe_Riqi())
            {
                return 1;
            }

            return idefaultv;
        }

        if(this.In_Shenhe())
        {
            return 2;  
        }
        var gamesuc_dlg_video_config = cur_valid_config.gamesuc_dlg_video_config;
        if(!gamesuc_dlg_video_config)
        {
            return idefaultv;
        }



        var gamesuc_dlg_default_use_menu_type = gamesuc_dlg_video_config.gamesuc_dlg_default_use_menu_type;
        if(gamesuc_dlg_default_use_menu_type == undefined)
        {
            return idefaultv;
        }

        return gamesuc_dlg_default_use_menu_type;
    }
    Get_ComDlg_Top_Show_Banner_Or_Gezi()
    {
        var idefaultv = 2;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

         
        var comdlg_top_show_banner_or_gezi = cur_valid_config.comdlg_top_show_banner_or_gezi;
        if(!comdlg_top_show_banner_or_gezi)
        {
            return idefaultv;
        } 
        return comdlg_top_show_banner_or_gezi;
    }
    IS_Game_End_Lingqu_Dlg_Tuijianwei_Show()
    {
        var idefaultv = 1;
  
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var game_end_lingqu_dlg_tuijianwei_show = cur_valid_config.game_end_lingqu_dlg_tuijianwei_show;
        if(game_end_lingqu_dlg_tuijianwei_show == undefined)
        {
            return idefaultv;
        }

        return game_end_lingqu_dlg_tuijianwei_show;
    }


    Get_Enter_Game_Bk_Create_Gezi_List(isubgametype)
    {
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return [];
        }

        var enter_game_bk_create_gezi_list = cur_valid_config.enter_game_bk_create_gezi_list;
  

        var default_list = [];
        for(var ff=0;ff<enter_game_bk_create_gezi_list.length;ff++)
        {
            var ff_info  = enter_game_bk_create_gezi_list[ff];

            var ff_t = ff_info.t;
            var ff_l = ff_info.l;

            if(ff_t == isubgametype)
            {
                return ff_l;
            }

            if(ff_t == 0)
            {
                default_list = ff_l;
            }
        }

        if(!default_list)
        {
            default_list = [];
        }


        return default_list;
    }


    
    IS_ChaiPing_Pingbi_All()
    {
        var idefaultv = 1;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var chaiping_pingbi_all = cur_valid_config.chaiping_pingbi_all;
        if(chaiping_pingbi_all == undefined)
        {
            return idefaultv;
        }

        return chaiping_pingbi_all;
    }
    IS_ChaiPing_Pingbi_First_Reg_Day()
    {
        var idefaultv = 0;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var chaiping_pingbi_reg_day = cur_valid_config.chaiping_pingbi_reg_day;
        if(chaiping_pingbi_reg_day == undefined)
        {
            return idefaultv;
        }

        return chaiping_pingbi_reg_day;
    }

    IS_ChaiPing_Type_Valid(ichaipingtype)
    {
        var idefaultv = 1;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var chaiping_valid_type_list = cur_valid_config.chaiping_valid_type_list;
        if(!chaiping_valid_type_list)
        {
            return idefaultv;
        }


        for(var ff=0;ff<chaiping_valid_type_list.length;ff++)
        {
            var ff_info = chaiping_valid_type_list[ff];
            var tarr = ff_info.tarr;
            var trange = ff_info.trange;
            var ff_c = ff_info.c;

            if(tarr && tarr.length > 0)
            {
                if(ComFunc.arrayShuzuContain(tarr,ichaipingtype))
                {
                    return ff_c;
                }
            }

            if(trange && trange.length >= 2)
            {
                var tr1 = trange[0];
                var tr2 = trange[1];

                if(tr1 <= ichaipingtype && ichaipingtype <= tr2)
                {
                    return ff_c;
                }
            }
        }

        return idefaultv;
    }

    Get_Quanping_Gezi_Chaiping_Config()
    {
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return null;
        }
        var quanping_gezi_chaiping_config = cur_valid_config.quanping_gezi_chaiping_config;
  
        return quanping_gezi_chaiping_config;
    }
    IS_Quanping_Gezi_Cahiping_Manual_Destroy_Need_Auto_ReCreate()
    {
        var idefaultv = 0;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var quanping_gezi_chaiping_config = cur_valid_config.quanping_gezi_chaiping_config;
        if(!quanping_gezi_chaiping_config == undefined )
        {
            return idefaultv;
        }

        var manual_deatroy_need_auto_recreate = quanping_gezi_chaiping_config.manual_deatroy_need_auto_recreate;
        if(manual_deatroy_need_auto_recreate == undefined)
        {
            return idefaultv;
        }

        return manual_deatroy_need_auto_recreate;
    }
    IS_HMK_Need_Finger_Yingdao()
    {
        var idefaultv = 1;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var hmk_need_finger_yingdao = cur_valid_config.hmk_need_finger_yingdao;
        if(hmk_need_finger_yingdao == undefined)
        {
            return idefaultv;
        }

        return hmk_need_finger_yingdao;
    }
    Get_Default_First_Enter_Game_Mode()
    {
        //默认进入：0：大厅，2：花朵，4：怪兽
        var idefaultv = 4;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var default_enter_first_game_mode = cur_valid_config.default_enter_first_game_mode;
        if(default_enter_first_game_mode == undefined)
        {
            return idefaultv;
        }

        return default_enter_first_game_mode;
    }
    Get_Huaduoxiaoxiao_Not_Check_Count()
    {
        var idefaultv = 3;
 
        
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            if(this.Check_Chaoguo_Shenhe_Riqi())
            {
                return 1;
            }

            return idefaultv;
        }

        
        var huaduoxiaoxiao_not_check_count = cur_valid_config.huaduoxiaoxiao_not_check_count;
        if(huaduoxiaoxiao_not_check_count == undefined)
        {
            return idefaultv;
        }

        return huaduoxiaoxiao_not_check_count;
    }
    Get_Qiandao_Menu_Type()
    {
        var idefaultv = 2;
 
        /*
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            if(this.Check_Chaoguo_Shenhe_Riqi())
            {
                return 1;
            }

            return idefaultv;
        }

        if(this.In_Shenhe())
        {
            return 2;
        }

        var qiandao_menu_type = cur_valid_config.qiandao_menu_type;
        if(qiandao_menu_type == undefined)
        {
            return idefaultv;
        }
        */

        return idefaultv;
    }
    IS_GameEnd_Need_Pop_Animate(isubgametype)
    {
        var idefaultv = 1;
        var cur_valid_config = this.Get_Cur_Valid_Server_Common_Config();
        if(!cur_valid_config)
        {
            return idefaultv;
        }

        var gamesuc_dlg_video_config = cur_valid_config.gamesuc_dlg_video_config;
        if(!gamesuc_dlg_video_config)
        {
            return idefaultv;
        }

        var game_end_need_pop_animate = gamesuc_dlg_video_config.game_end_need_pop_animate;
        if(!game_end_need_pop_animate)
        {
            return idefaultv;
        }
        return game_end_need_pop_animate;
    }
    Get_Game_End_Aniamte_Dealy_Sec()
    {
        return 0.5;
    }


    Get_Cur_Day_OnLine_Libao_Left_Sec_Info()
    {
        var rewardinfo4 = this.m_online_config["1"];
    
        if(this.m_cur_day_online_liqued_count  >= 3)
        {
         
            return [0,0,rewardinfo4];
        }

        var iindex = this.m_cur_day_online_liqued_count + 1;
        var rewardinfo = this.m_online_config[""+iindex];
        if(!rewardinfo)
        {
            return [0,0,rewardinfo4];
        }

        var need_time_Sec = rewardinfo.time;

        var ilefsec = Math.ceil(need_time_Sec - this.m_cur_online_elapse_sec) ;
      
        if(ilefsec <= 0)
        {
            ilefsec = 0;
        }

        return [1,ilefsec,rewardinfo]
    }
    Save_On_Line_Libao_Data()
    {
        
        var pobj={
            last_online_libao_lingqu_day_union:this.m_last_online_libao_lingqu_day_union,
            cur_day_online_liqued_count:this.m_cur_day_online_liqued_count,
            cur_online_elapse_sec: this.m_cur_online_elapse_sec,
            m_curday_last_luckdraw_finished_elapse_sec:this.m_curday_last_luckdraw_finished_elapse_sec
        };

        var strinfo = JSON.stringify(pobj);

        
        MyLocalStorge.setItem("gsfwz_online_libao_last_lingqu_info", strinfo);
    }
    Check_Init_Online_Libao_Data()
    {
        if(this.m_first_online_info_inited)
        {
            return;
        }
        this.m_first_online_info_inited = true;


        var stringo = MyLocalStorge.getItem("gsfwz_online_libao_last_lingqu_info");

        if(!stringo)
        {
            this.Init_OnLine_Libao_Save_Data();
            return;
        }

        var jobj = JSON.parse(stringo);

        if(!jobj)
        {
            this.Init_OnLine_Libao_Save_Data();
            return;
        }


        this.m_last_online_libao_lingqu_day_union = ComFunc.Check_Read_Number(jobj.last_online_libao_lingqu_day_union) ;
        this.m_cur_day_online_liqued_count = ComFunc.Check_Read_Number(jobj.cur_day_online_liqued_count);

        this.m_cur_online_elapse_sec = ComFunc.Check_Read_Number(jobj.cur_online_elapse_sec);

        this.m_curday_last_luckdraw_finished_elapse_sec = ComFunc.Check_Read_Number(jobj.m_curday_last_luckdraw_finished_elapse_sec);

        
        var curdayunion = ComFunc.GetCurDayUnion();

        if(curdayunion != this.m_last_online_libao_lingqu_day_union)
        {
            
            this.Init_OnLine_Libao_Save_Data();

            this.m_curday_last_luckdraw_finished_elapse_sec = 0;
        }

        

    }
    Init_OnLine_Libao_Save_Data()
    {
        this.m_last_online_libao_lingqu_day_union = ComFunc.GetCurDayUnion();
        this.m_cur_day_online_liqued_count = 0;
        this.m_cur_online_elapse_sec = 0;

        
        var pobj={
            last_online_libao_lingqu_day_union:ComFunc.GetCurDayUnion(),
            cur_day_online_liqued_count:0,
            cur_online_elapse_sec: 0,
        };

        var strinfo = JSON.stringify(pobj);

        
        MyLocalStorge.setItem("gsfwz_online_libao_last_lingqu_info", strinfo);
    }


    On_Update(dt)
    {

        if(dt > 1)
        {
            return;
        }
        this.m_cur_online_elapse_sec += dt;
        this.m_curday_last_luckdraw_finished_elapse_sec += dt;

        if(Date.now() - this.m_last_online_data_saved_tick > 2000)
        {
            this.m_last_online_data_saved_tick = Date.now();
            this.Save_On_Line_Libao_Data();
        }

        var curdayunion = ComFunc.GetCurDayUnion();

        if(curdayunion != this.m_last_online_libao_lingqu_day_union)
        {
            
            this.Init_OnLine_Libao_Save_Data();

            this.m_curday_last_luckdraw_finished_elapse_sec = 0;

        }
       
    }


    Online_Libao_Lingqu(ibeishu = 1)
    {
        var left_info = this.Get_Cur_Day_OnLine_Libao_Left_Sec_Info();

        if(!left_info[0])
        {
           
            return;
        }

        var ileftsec = left_info[1];

        if(ileftsec > 0)
        {
            return;
        }

        var rewardinfo = left_info[2];
        if(!rewardinfo)
        {
            return;
        }

        var rewardlist = rewardinfo.jl; 

 


        this.Add_DaojuType_Count_List(rewardlist,ibeishu); 
        
        this.m_cur_day_online_liqued_count++;
        this.m_cur_online_elapse_sec = 0;

        this.Save_Game_Basic_Info();

      
       
        if(this.m_last_online_libao_lingqu_day_union != ComFunc.GetCurDayUnion())
        {
            this.m_last_online_libao_lingqu_day_union = ComFunc.GetCurDayUnion();
            this.m_cur_day_online_liqued_count = 0;
        }
        this.Save_On_Line_Libao_Data();

         return rewardlist;
    }


    Get_Default_Luck_Draw_Data()
    {
        var luckdata={
            "bfirst":1,
            "last_cj_day":ComFunc.GetCurDayUnion(),
            "first_day":ComFunc.GetCurDayUnion(),
            "cjcount":0
        }

        return luckdata;
    }
    Get_LuckDraw_Save_Data()
    {
        var gk1_str =  MyLocalStorge.getItem("gsfwz_luckdraw_save_data");
 
        if(!gk1_str )
        {
            return this.Get_Default_Luck_Draw_Data();
        }

        var pobj = JSON.parse(gk1_str);
        if(!pobj )
        {
            return this.Get_Default_Luck_Draw_Data();
        }
 

        if(pobj.last_cj_day != ComFunc.GetCurDayUnion())
        {
            pobj.cjcount = 0;
            pobj.last_cj_day = ComFunc.GetCurDayUnion();
            
        }

        return pobj;
    }

    On_LuckDraw_CJ_End( )
    {
        var luckdata= this.Get_LuckDraw_Save_Data();

        var firstday = luckdata.first_day;
        var cjcount = luckdata.cjcount;
        var last_cj_day = luckdata.last_cj_day;


        

            if(last_cj_day == ComFunc.GetCurDayUnion())
            {
                var newc = 1+cjcount;
                luckdata={
                    "bfirst":0,
                    "last_cj_day":ComFunc.GetCurDayUnion(),
                    "first_day":firstday,
                    "cjcount":newc
                }
            }
            else{
                luckdata={
                    "bfirst":0,
                    "last_cj_day":ComFunc.GetCurDayUnion(),
                    "first_day":firstday,
                    "cjcount":1
                }
    
            }
        

        var jstr = JSON.stringify(luckdata);

         MyLocalStorge.setItem("gsfwz_luckdraw_save_data",jstr);

         this.m_curday_last_luckdraw_finished_elapse_sec = 0;
 
    }






}