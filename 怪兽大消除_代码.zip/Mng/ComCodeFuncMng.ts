import BaseUIUtils from "../comfuncs/BaseUIUtils";
import ComFunc from "../comfuncs/ComFunc";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import GlobalGameMng from "./GlobalGameMng";
import MyLocalStorge from "../WDT/MyLocalStorge";
import HutuiAppInfoMng from "../PlatForm/HutuiAppInfoMng";
import PlatFormMng from "../PlatForm/PlatFormMng";
import SoundManager from "../comfuncs/SoundManager";

export default class ComCodeFuncMng
{

    static Get_Para_Count(strpara)
    {
        var last_v = strpara;

        var prevstr = MyLocalStorge.getItem(last_v,"");

        if(!prevstr)
        {
            return [0,0];
        }


        var pobj = JSON.parse(prevstr);
        if(!pobj)
        {
            return [0,0];
        }

        var ijiangegk = pobj.ijiangegk;
        if(!ijiangegk)
        {
            ijiangegk = 0;
        }
        return [1,ijiangegk];
    }
    static Add_Para_Count(strpara)
    {
        var pinfo = ComCodeFuncMng.Get_Para_Count(strpara);
        var prevgk = pinfo[1];
        var newgk = prevgk+1;

        var obj = {
            ijiangegk:newgk
        }


        var last_v = strpara;

        var str = JSON.stringify(obj);
        MyLocalStorge.setItem(last_v,str);
    }

    static Remove_Para_Count(strpara)
    {
        MyLocalStorge.removeItem(strpara);
    }

    




    static OnBtn_PaihangBang(pgame,pgamenode,isubgametype)
    {
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(isubgametype,true);
        ComCodeFuncMng.OnSelectPaihangbangType(pgame,pgamenode,isubgametype,isubgametype)
    }
    static OnSelectOtherPaihangbangType(pgame,pgamenode,isubgametype)
    {
        var self = pgame;
    
        ComFunc.OpenNewDialog(self.node,"preab/dlg/select_paihang_type","select_paihang_type", 
         { 
            cb:(iseltype)=>
            {
                if(iseltype == 0)
                {
                    ComCodeFuncMng.On_Paihangbang_Dlg_Close(pgame,pgamenode,isubgametype);
                    return;
                }

                ComCodeFuncMng.OnSelectPaihangbangType(pgame,pgamenode,isubgametype,iseltype);
                
            }});
    }
    static  On_Paihangbang_Dlg_Close(pgame,pgamenode,isubgametype)
    {
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(isubgametype,false);

        if(pgame.On_Paihangbang_Dlg_Close)
        {
            pgame.On_Paihangbang_Dlg_Close();
        }
    }
    static OnSelectPaihangbangType(pgame,pgamenode,isubgametype,iseltype)
    {

        if(iseltype == 0)
        {
            return;
        }
        var self = pgame;
    
       
        ComFunc.OpenNewDialog(self.node,"preab/dlg/paihangbang","paihangbang", 
         { 
            iseltype:iseltype,
            cb:(chooseother)=>
            {

                if(chooseother > 0)
                {
                    ComCodeFuncMng.OnSelectOtherPaihangbangType(pgame,pgamenode,isubgametype);
                }else{

                    ComCodeFuncMng.On_Paihangbang_Dlg_Close(pgame,pgamenode,isubgametype);
                }
                 
            
            }});
    }

    //itype:1-体力不足，2：购买体力
    static Show_Goumai_Tili_Dlg(itype, pndoe,callback)
    {

        var self = this;
        ComFunc.OpenNewDialog(pndoe,"preab/goumai_tili","goumai_tili", {  
            itype:itype,
            cb:(iret)=>
            {

                if(callback)
                {
                    callback(iret);
                }
            }
        });
       
    }

    static Check_Has_Tili_Enter_Subgame_And_Kouchu(isbugametype:number,pnode:cc.Node,callback=null)
    {
        //首先，判断是否要全部取消体力
        var allhide_tili = GlobalGameMng.GetInstance().IS_All_Tili_Hide();
        if(allhide_tili)
        {
            GlobalGameMng.GetInstance().Add_Subgametype_Enterd_Cishu(isbugametype,1);
            if(callback)
            {
                callback(true);
            }
            return true;
        }


        var inowstartsec = GlobalGameMng.GetInstance().Get_After_Start_Reg_Sec();
        var start_sec_notkou = GlobalGameMng.GetInstance().Get_Start_Sec_NotKou_Tili();
        

        //前面几次不扣体力
        var first_enter_cishunei_bukou_tili = GlobalGameMng.GetInstance().Get_Per_Game_First_Enter_Cishu_Nei_Bukou_Tili();

        //游戏玩法进入的次数
        var iprev_enterd_game_cishu = GlobalGameMng.GetInstance().Get_Subgametype_Enterd_Cishu(isbugametype);

        //今日进入游戏次数
        var curday_enterd_game_cishu = GlobalGameMng.GetInstance().Get_Subgametype_CurDay_Enterd_Cishu(isbugametype);

        //单个游戏每日几次内不扣体力
        var pergame_perday_first_enter_cishunei_bukou_tili = GlobalGameMng.GetInstance().Get_Per_Game_PerDay_First_Enter_Cishu_Nei_Bukou_Tili();

        
        //小于这天注册的用户不扣体力
        var regday_unoin_xiaoyu_dest_day_bukou_tili = GlobalGameMng.GetInstance().Get_Reg_Day_Xiaoyu_Dest_Day_Bukou_Tili();

        var cur_reg_Day = GlobalGameMng.GetInstance().Get_Self_Reg_Day();

        var itilinow = GlobalGameMng.GetInstance().Get_Tili();

        //进入游戏一次扣除体力数
        var enter_game_perci_sub_tili = GlobalGameMng.GetInstance().Get_Enter_Game_PerCi_Sub_Tili();
        var ileft_wuxian_tili_sec = GlobalGameMng.GetInstance().Get_Lianxu_Video_Wuxian_Tili_Left_Sec();


        var ileft_wuxian_48huor_tili_sec = GlobalGameMng.GetInstance().Get_Lianxu_Video_Wuxian_48huor_Tili_Left_Sec();
 
        //是否需要扣体力
        var bneed_koutili = true;
  
        if(iprev_enterd_game_cishu < first_enter_cishunei_bukou_tili)
        {
            bneed_koutili = false;
        }

        if(inowstartsec < start_sec_notkou && start_sec_notkou > 0)
        {
            bneed_koutili = false;
        }

        //今日几次内不扣体力
        if(curday_enterd_game_cishu < pergame_perday_first_enter_cishunei_bukou_tili)
        {
            bneed_koutili = false;
        }

        console.log("curday_enterd_game_cishu="+curday_enterd_game_cishu+",pergame_perday_first_enter_cishunei_bukou_tili="+pergame_perday_first_enter_cishunei_bukou_tili);


        if(enter_game_perci_sub_tili == 0)
        {
            bneed_koutili = false;
        }

        if(regday_unoin_xiaoyu_dest_day_bukou_tili && regday_unoin_xiaoyu_dest_day_bukou_tili > 0)
        {
            if( cur_reg_Day < regday_unoin_xiaoyu_dest_day_bukou_tili)
            {
                bneed_koutili = false;
            }
        }
        



        //无限体力时间内
        if(ileft_wuxian_tili_sec > 0)
        {
            bneed_koutili = false;
        }
 
        if(ileft_wuxian_48huor_tili_sec > 0)
        {
            bneed_koutili = false;
        }
 


        //不需要扣体力
        if(!bneed_koutili)
        {
            GlobalGameMng.GetInstance().Add_Subgametype_Enterd_Cishu(isbugametype,1);
       
            if(callback)
            {
                callback(true);
            }
            return true;
        }

        if(itilinow < enter_game_perci_sub_tili)
        {
            //体力不足,弹出购买体力框

            ComCodeFuncMng.Show_Goumai_Tili_Dlg(1,pnode,(bsuc)=>
            {
               // BaseUIUtils.ShowTipTxtDlg("购买体力成功",pnode);

                if(callback)
                {
                    callback(bsuc);
                }

            });

            return false;
        }

        //扣体力
        GlobalGameMng.GetInstance().Add_Tili( -1*enter_game_perci_sub_tili);

        GlobalGameMng.GetInstance().Add_Subgametype_Enterd_Cishu(isbugametype,1);
        if(callback)
        {
            callback(true);
        }
        return true;
    }



    static Check_Shoukan_Fuli_Lingqued(isubgametype)
    {
        var str = "guaishoudxc_shoukan_game_"+isubgametype+"_lingqued";
        var savedstr = MyLocalStorge.getItem(str);

        if(!savedstr)
        {
            return 0;
        }
        var obj  = JSON.parse(savedstr);
        if(!obj)
        {
            return 0;
        }

        var lingqued =  obj.lingqued;

        if(!lingqued)
        {
            return 0;
        }

        return lingqued;
    }

    static  On_Shoukan_Lingqued(gamenode,isubgametype,igk,libaolist = null)
    {
        var str = "guaishoudxc_shoukan_game_"+isubgametype+"_lingqued";
        var obj = {lingqued:1};
        var savedstr = JSON.stringify(obj);
        MyLocalStorge.setItem(str,savedstr);

        if(libaolist)
        {
            ComFunc.Open_Get_Daoju_Award_Dlg(gamenode, libaolist, 1,null);
  
        }
     
    }



    //过关奖励
    static  Game_Suc_Show_Guoguang_Fuli(game,gamenode:cc.Node,isubgametype,igk,callback = null)
    {

        var strpara = "guaishouxc_guoguang_libao_game_"+isubgametype+"_gk_"+igk+"_lqed";

        var lingqued = ComCodeFuncMng.Get_Para_Count(strpara);
        var iguoguangedcount = lingqued[1];

        if(iguoguangedcount > 0)
        {
            if(callback)
            {
                callback();
            }
            return;
        }

        ComFunc.OpenNewDialog(gamenode,"preab/game_shoukan_libao","game_shoukan_libao",
        {parentgame:game,
            
            itype:2,
            isubgametype:isubgametype,
            igk:igk,
            
            cb: (iret,libaolist)=>
        {
            if(iret == 0)
            {
                if(callback)
                {
                    callback();
                }
                return;
            }

            ComCodeFuncMng.Add_Para_Count(strpara);
            ComFunc.Open_Get_Daoju_Award_Dlg(gamenode, libaolist, 1,callback);
  

        }},70);
    }





    //弹出首看福利
    static Check_Show_Shoukan_Fuli(game,gamenode:cc.Node,isubgametype,igk,callback = null)
    {
        var blingqued = ComCodeFuncMng.Check_Shoukan_Fuli_Lingqued(isubgametype);
        if(blingqued)
        {
            return false;
        }
    
        //还没有领取

        //关卡第二关后每关都提示下
        if(igk <= 1)
        {
            return false;
        }


        var bopend_other_dlg = MiddleGamePlatformAction.GetInstance().Is_Subgame_Gezi_Dlg_Has_One_Show();
        if(bopend_other_dlg)
        {
            //打开了其他比如暂停等弹框,就先不弹出
            return false;
        }



        var shouci_libao_show_type =  GlobalGameMng.GetInstance().Get_GameType_Shouci_Libao_ShowType(isubgametype);
        var shouci_libao_show_gk_jiange =  GlobalGameMng.GetInstance().Get_GameType_Shouci_Libao_show_gk_Jiange(isubgametype);

        var ishowcount =  GlobalGameMng.GetInstance().Get_CurProcess_GameType_Shouci_Libao_Show_Count(isubgametype);
      
      
     

        

        //每关都弹出来
        if(shouci_libao_show_type == 1)
        {

        }else if(shouci_libao_show_type == 99)
        {

            return false;
        }
        else if(shouci_libao_show_type == 0)
        {
            //只弹出一次
            if(ishowcount >= 1)
            {
                return false;
            }
        }
        else if(shouci_libao_show_type == 2)
        {
            //首次弹出，另外，接下来，关卡在%3
            if(ishowcount >= 1)
            {
                var strpara = "guaisdxc_shouci_libao_game_"+isubgametype+"_notshow_jiange_cishu";

                 var jiange_cishu_info = ComCodeFuncMng.Get_Para_Count(strpara);
                 var ijiange_cishu = jiange_cishu_info[1];

                 if(ijiange_cishu >= shouci_libao_show_gk_jiange)
                 {
                    ComCodeFuncMng.Remove_Para_Count(strpara);
                 }else
                 {
                    ComCodeFuncMng.Add_Para_Count(strpara);
                    return false;
                 }
 
            }
        }

        GlobalGameMng.GetInstance().Add_CurProcess_GameType_Shouci_Libao_Show_Count(isubgametype);


        ComFunc.OpenNewDialog(gamenode,"preab/game_shoukan_libao","game_shoukan_libao",
        {parentgame:game,
            
            itype:1,
            isubgametype:isubgametype,
            igk:igk,
            
            cb: (iret,libaolist)=>
        {
            if(iret == 0)
            {
                return;
            }

            ComCodeFuncMng.On_Shoukan_Lingqued(gamenode,isubgametype,igk,libaolist);

            if(callback)
            {
                callback();
            }
            

        }},70);
 
        return true;
        

    }




    static OnBtnTiaozhuanTuijian(ituijianwei,parentgame,parent_node,othergame_node)
    {
        if(!parentgame.m_tuijianwe_dest_info_map.hasKey(ituijianwei))
        {
            var defaultappid = HutuiAppInfoMng.GetInstance().Get_Default_Tuiguan_Appid(ituijianwei);
            PlatFormMng.GetInstance().Tiaozhuan_Tuijian_AppID(defaultappid);

            return null;
        }

        var tuijian_info = parentgame.m_tuijianwe_dest_info_map.getData(ituijianwei);

        console.log("OnBtnTiaozhuanTuijian ituijianwei="+ituijianwei+",tuijian_info="+tuijian_info);

        if(!tuijian_info)
        {
            var defaultappid = HutuiAppInfoMng.GetInstance().Get_Default_Tuiguan_Appid(ituijianwei);
            PlatFormMng.GetInstance().Tiaozhuan_Tuijian_AppID(defaultappid);

          
            
        }else{
            PlatFormMng.GetInstance().Jump_To_App_Game_By_Data(tuijian_info);
        }
    }

    static Init_Top_Tuijian_Guangao(parentgame,parent_node,othergame_node)
    {

      //  var self = parentgame;

        var tuijaing_game2_node = cc.find("game2",othergame_node);

        
        if(!MiddleGamePlatformAction.GetInstance().IS_Show_Zidingyi_TuijianWei())
        { 
            tuijaing_game2_node.active = false;
            
            return;
        }

        
        tuijaing_game2_node.on("click",

            ()=>
            {
                ComCodeFuncMng.OnBtnTiaozhuanTuijian(2,parentgame,parent_node,othergame_node);
            }
        );
        
         
        tuijaing_game2_node.runAction(cc.repeatForever(

            cc.sequence(cc.rotateTo(0.1,7),cc.rotateTo(0.2,-7),cc.rotateTo(0.1,0),cc.rotateTo(0.2,-7),cc.rotateTo(0.1,0),
            
               
            cc.callFunc(()=>
            {

                ComCodeFuncMng.Check_Update_Tuijian_Icon_Info(parentgame,parent_node,othergame_node);
            }),
            cc.delayTime(3))

        ));


        ComCodeFuncMng.Check_Update_Tuijian_Icon_Info(parentgame,parent_node,othergame_node);
    }
    static Update_Tuijian_Icon(ituijianwei, parentgame,parent_node,othergame_node)
    {
        var last_tuiijian_app_info =  HutuiAppInfoMng.GetInstance().Get_InnerGame_Show_App_Icon_Info(ituijianwei);
 
        if(!last_tuiijian_app_info)
        {
            return;
        }

        var name_node = cc.find("game"+ituijianwei+"/name",othergame_node);
        name_node.getComponent(cc.Label).string = ""+last_tuiijian_app_info.toName;
        
        

        var icon_node = cc.find("game"+ituijianwei+"/icon",othergame_node);
   
        var simgurl = last_tuiijian_app_info.icon;

        var texture = HutuiAppInfoMng.GetInstance().GetFilePathTexture(simgurl);
        var size_w = HutuiAppInfoMng.GetInstance().Get_Hutui_Gezi_Size();
       
        if(texture)
        {
            var psrite = icon_node.getComponent(cc.Sprite);

            psrite.spriteFrame = new cc.SpriteFrame(texture);

            icon_node.width = size_w.cx;
            icon_node.height = size_w.cy;
           // iconnode.getComponent(cc.Sprite)
        }else
        {
            BaseUIUtils.ShowIconNodePicFilename(icon_node,"resources/game/default",{cx:size_w.cx,cy:size_w.cy});
        }

        parentgame.m_tuijianwe_dest_info_map.putData(ituijianwei,last_tuiijian_app_info);
    }
    static Check_Update_Tuijian_Icon_Info(parentgame,parent_node,othergame_node)
    {
        if(parentgame.m_last_tuijian_change_tick == 0)
        {
            parentgame.m_last_tuijian_change_tick = Date.now();
 
            ComCodeFuncMng.Update_Tuijian_Icon(2,parentgame,parent_node,othergame_node);
        
        }
        else{

            if(Date.now() - parentgame.m_last_tuijian_change_tick > HutuiAppInfoMng.GetInstance().Get_Hutui_Update_Tick())
            {
                parentgame.m_last_tuijian_change_tick = Date.now();
 
                ComCodeFuncMng.Update_Tuijian_Icon(2,parentgame,parent_node,othergame_node);
            }
          
        }
    }

    static Show_InGame_MoreGame_Quanping_Gezi(pnode)
    {

        SoundManager.GetInstance().Play_Effect('com/clickbtn');

        MiddleGamePlatformAction.GetInstance().Show_InGame_MoreGame_Quanping_Gezi();
        /*
        ComFunc.OpenNewDialog(pnode,"preab/common/more_guangao_dlg","more_guangao_dlg",
        {
            ifrom:2
            
        });
        */
    }


    static  On_Game_Enter(isubgametype,pgame,pnode)
    {

        
        var gezilist = GlobalGameMng.GetInstance().Get_Enter_Game_Bk_Create_Gezi_List(isubgametype);
    
        MiddleGamePlatformAction.GetInstance().Check_Create_Bk_Gezi_List(gezilist);
      
 
        MiddleGamePlatformAction.GetInstance().Show_Qiandao_Banners(false);

        
        GlobalGameMng.GetInstance().On_Game_Enter(isubgametype,pgame,pnode);
    }

    static Init_Com_Two_Guangao(parentgame,parent_node,othergame_node,posarr)
    {


        for(var ff=0;ff<posarr.length;ff++)
        {
            var ff_index = ff+1;
            var f_tuijianwei = posarr[ff];

            console.log("Init_Com_Two_Guangao ,ff_index="+ff_index+",tuijianwei="+f_tuijianwei);

            ComCodeFuncMng.Init_Com_Two_Guangao_Pos(parentgame,parent_node,othergame_node,ff_index,f_tuijianwei)
        }

      

        
    }


    static Init_Com_Two_Guangao_Pos(parentgame,parent_node,othergame_node,ipos,ituijianwei)
    {
        var tuijaing_game_node = cc.find("game"+ipos,othergame_node);

        tuijaing_game_node.on("click",

            ()=>
            {
                ComCodeFuncMng.OnBtnTiaozhuanTuijian(ituijianwei,parentgame,parent_node,othergame_node);
            }
         );
    
     
         tuijaing_game_node.runAction(cc.repeatForever(

            cc.sequence(cc.rotateTo(0.1,7),cc.rotateTo(0.2,-7),cc.rotateTo(0.1,0),cc.rotateTo(0.2,-7),cc.rotateTo(0.1,0),
            
            
            cc.callFunc(()=>
            {

                ComCodeFuncMng.Check_Update_Tuijian_Icon_Info_By_Pos(ipos,ituijianwei,parentgame,parent_node,othergame_node);
            }),
            cc.delayTime(3))

        ));
        ComCodeFuncMng.Check_Update_Tuijian_Icon_Info_By_Pos(ipos,ituijianwei,parentgame,parent_node,othergame_node);
    }


    static Check_Update_Tuijian_Icon_Info_By_Pos(ipos,ituijianwei, parentgame,parent_node,othergame_node)
    {

        if(!parentgame.m_last_tuijian_change_tick_map.hasKey(ipos)  )
        {
            parentgame.m_last_tuijian_change_tick_map.putData(ipos,Date.now());
 
            ComCodeFuncMng.Update_Tuijian_Icon_By_Pos(ipos,ituijianwei ,parentgame,parent_node,othergame_node);
        
        }
        else{

            var lasttitck  =parentgame.m_last_tuijian_change_tick_map.getData(ipos);

            if(Date.now() - lasttitck > HutuiAppInfoMng.GetInstance().Get_Hutui_Update_Tick())
            {
                parentgame.m_last_tuijian_change_tick_map.putData(ipos,Date.now());
 
                ComCodeFuncMng.Update_Tuijian_Icon_By_Pos(ipos,ituijianwei,parentgame,parent_node,othergame_node);
            }
          
        }
    }
    static Update_Tuijian_Icon_By_Pos(ipos, ituijianwei, parentgame,parent_node,othergame_node)
    {
        var last_tuiijian_app_info =  HutuiAppInfoMng.GetInstance().Get_InnerGame_Show_App_Icon_Info(ituijianwei);
 
        if(!last_tuiijian_app_info)
        {
            return;
        }

        var name_node = cc.find("game"+ipos+"/name",othergame_node);
        name_node.getComponent(cc.Label).string = ""+last_tuiijian_app_info.toName;
        
        

        var icon_node = cc.find("game"+ipos+"/icon",othergame_node);
   
        var simgurl = last_tuiijian_app_info.icon;

        var texture = HutuiAppInfoMng.GetInstance().GetFilePathTexture(simgurl);
        var size_w = HutuiAppInfoMng.GetInstance().Get_Hutui_Gezi_Size();
       
        if(texture)
        {
            var psrite = icon_node.getComponent(cc.Sprite);

            psrite.spriteFrame = new cc.SpriteFrame(texture);

            icon_node.width = size_w.cx;
            icon_node.height = size_w.cy;
           // iconnode.getComponent(cc.Sprite)
        }else
        {
            BaseUIUtils.ShowIconNodePicFilename(icon_node,"resources/game/default",{cx:size_w.cx,cy:size_w.cy});
        }

        parentgame.m_tuijianwe_dest_info_map.putData(ituijianwei,last_tuiijian_app_info);
    }
}