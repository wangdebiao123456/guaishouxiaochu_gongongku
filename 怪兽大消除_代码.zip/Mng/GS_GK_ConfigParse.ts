 
export class LayoutInfoData {
    w: number
    h: number
    index: number
    tiles: any
    startRow: number
    startCol: number
    alignH: number
    alignW: number
}
export class LevelInfoCO {
    layouts: LayoutInfoData[]
    typeCount: number
    types: number[]
    allTile: any

}
export class FloorInfoData {
    id: number
    floor: number
    count: number
    layouts: any
}
export class LevelInfoData {
    id: number
    level: number
    count: number
    floorIds: number[]
    typeCount: number
}
export default class GS_GK_ConfigParse {

    levels: any
    floors: any
    setup(obj: { Floor: any, Level: any }) {
        this.levels = []
  
        for (const temp of obj.Level.Values) {
            let data = new LevelInfoData()
            data.id = temp[0]
            data.level = temp[1]
            data.count = temp[2]
            data.floorIds = temp[3].split(',')
            data.typeCount = temp[4]
            this.levels[data.id] = data
       
        }
      
        this.floors = []
        for (const temp of obj.Floor.Values) {
            let data = new FloorInfoData()
            data.id = temp[0]
            data.floor = temp[1]
            data.count = temp[2]
            data.layouts = JSON.parse(temp[3])
            this.floors[data.id] = data
        }

    }
    readLevelData(id: number) {
        var leveldata = this.levels[id];
        return leveldata;
    }
    get_Level_FloorData(id:number):FloorInfoData
    {
        return this.floors[id]
    }
     
    public static initArray2(row: number, col: number, value: number = null) {
        let arr = []
        for (let i = 0; i < row; i++) {
            arr[i] = []
            for (let j = 0; j < col; j++) {
                arr[i][j] = value
            }
        }
        return arr
    }
    parse(text: string) {
        let obj = JSON.parse(text)
        let co = new LevelInfoCO()
        co.layouts = []
        let totalTile = 0
        co.allTile = []
        for (let i = 0; i < obj.length - 1; i++) {
            let layoutData = new LayoutInfoData()
            layoutData.tiles = obj[i][3]
            layoutData.index = obj[i][0]
            layoutData.alignW = obj[i][1]
            layoutData.alignH = obj[i][2]
            co.layouts.push(layoutData)
            co.allTile[i] = GS_GK_ConfigParse.initArray2(20, 20, 0)
            let maxRow = 0
            let maxCol = 0
            let minRow = 999
            let minCol = 999
            for (const pos of layoutData.tiles) {
                totalTile++
                if (pos[0] > maxRow)
                    maxRow = pos[0]
                if (pos[0] < minRow)
                    minRow = pos[0]

                if (pos[1] > maxCol)
                    maxCol = pos[1]
                if (pos[1] < minCol)
                    minCol = pos[1]
                co.allTile[i][pos[0]][pos[1]] = 1
            }
            layoutData.w = maxCol - minCol + 1
            layoutData.h = maxRow - minRow + 1
            layoutData.startRow = minRow
            layoutData.startCol = minCol


        }

        co.typeCount = obj[obj.length - 1]

        let c = co.typeCount
        let data = []
        let k = 0
        while (totalTile > 0) {
            let type = k % co.typeCount
            data.push(type, type, type)
            totalTile -= 3
            k++
        }
        co.types = data

        return co
    }
}
