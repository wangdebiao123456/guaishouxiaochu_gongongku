import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import IPlatformMng from "./IPlatformMng";
import ClientLogUtils from "../comfuncs/ClientLogUtils";


var PaySDKMng_on_LetianTang_AppStore_Video_Success = function(bsuc:string)
{
    if(bsuc == "0")
    {
        WatchVideoAdveseMng.GetInstance().OnVideFailEnd();

    }else{
        WatchVideoAdveseMng.GetInstance().OnVideoSuccessEnd();

    }
   
};

 

var P_LetianTang_AppStore_MSg = function(itype:number, sinfo:string)
{


    LeTianTangAppStorePlatformMng.AddMsg(itype,sinfo);
     

    /*
    WatchVideoAdveseMng.GetInstance().Show_Tip_Txt(sinfo);
    ClientLogUtils.GetInstance().Poset_Server_JS_Log(77, "苹果支付日志",itype,
    sinfo, 0, "", 0, "");
    */

};



export default class LeTianTangAppStorePlatformMng extends IPlatformMng
{
    static m_all_appstore_msg_list = [];
    m_last_watch_callback = null;
    constructor()
    {
        super();

        this.Init();
    }

    public   Init()
    {
        //if(cc.sys.os == cc.sys.OS_IOS)
        { 
            cc.on_LetianTang_AppStore_Video_Success = PaySDKMng_on_LetianTang_AppStore_Video_Success;
            cc.on_LetianTang_AppStore_MSg = P_LetianTang_AppStore_MSg;
        }
    }

    FD_Mng_Timer(mainnode:cc.Node)
    {
        if(LeTianTangAppStorePlatformMng.m_all_appstore_msg_list.length <= 0)
        {
            return;
        }

        var topinfo =  LeTianTangAppStorePlatformMng.m_all_appstore_msg_list[0];
        LeTianTangAppStorePlatformMng.m_all_appstore_msg_list.splice(0,1);

        var itype = topinfo[0];
        var sinfo = topinfo[1];
        
       // BaseUIUtils.ShowTipTxtDlg(sinfo,mainnode, new cc.Vec2(0,600 - itype*10 ));


        ClientLogUtils.GetInstance().Poset_Server_JS_Log(77, "苹果支付日志",itype,
        sinfo, 0, "", 0, "");
    }

    static  AddMsg(itype,sinfo)
    {

        this.m_all_appstore_msg_list.push([itype,sinfo])
    }

    CheckShowChaiping()
    {
        let ret = jsb.reflection.callStaticMethod("jsinterface","JNICheckShowChaiping" ,"");
    
    }
    Watch_Com_Guanggao_ID(guanggaoname,in_cb,agv,callback)
    {
        this.m_last_watch_callback = callback;

        jsb.reflection.callStaticMethod("jsinterface","JNIWatchComGuanggaoID" ,"" );
    

    }
}