import IPlatformMng from "./IPlatformMng";

 

export default class DefaultPlatformMng extends IPlatformMng
{
    constructor()
    {
        super();

    }
    IS_Show_Zidingyi_MoreGame()
    {
        return false;
    }
    IS_Can_Show_Zidingyi_TuijianWei()
    {
        return false;
    }
    IS_Game_End_Xuanyao_Btn_Show()
    {
        return false;
    }
    Is_Dating_Show_Tuijian_Tiaozhuan()
    {
        return false;
    }
    IS_Fenxiang_Btn_Show()
    {

        return true;
    }
    Watch_Com_Guanggao_ID(guanggaoname,in_cb,agv,callback)
    {
        callback(true);
    }
}