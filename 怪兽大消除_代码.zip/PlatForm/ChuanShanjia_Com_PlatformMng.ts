import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import IPlatformMng from "./IPlatformMng";

var PaySDKMng_On_ChuanShanjia_Jili_Reward_Success = function(bsuc:string)
{
    if(bsuc == "0")
    {
        WatchVideoAdveseMng.GetInstance().OnVideFailEnd();

    }else{
        WatchVideoAdveseMng.GetInstance().OnVideoSuccessEnd();

    }
   
};


export default class ChuanShanjia_Com_PlatformMng extends IPlatformMng
{
    constructor()
    {
        super();

        this.InitSDK();
    }

    InitSDK()
    {
        cc.On_ChuanShanjia_Jili_Reward_Success = PaySDKMng_On_ChuanShanjia_Jili_Reward_Success;
    }
    Get_Storge_Type()
    {

        return 2;
    }

    CheckShowChaiping()
    {
        jsb.reflection.callStaticMethod('org/cocos2dx/javascript/AppActivity',
            'Jin_Show_Chaiping','(I)V',1);

    }
    Watch_Com_Guanggao_ID(guanggaoname,in_cb,agv,callback)
    {
        jsb.reflection.callStaticMethod('org/cocos2dx/javascript/AppActivity',
        'Jin_Start_Jili_Shiping','(I)V',1);
    }
}