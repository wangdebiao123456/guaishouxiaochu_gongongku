import IPlatformMng from "./IPlatformMng";

export default class P_4399_XiaoyouxiHezi_PlatformMng extends IPlatformMng
{
    constructor()
    {
        super();

    }
    IS_Fenxiang_Btn_Show()
    {

        return true;
    }
    Dating_Fenxiang()
    {
         var str=  this.Get_Dating_Fenxiang_Str();
         gamebox.shareMessageToFriend({
            type:0, //0： 普通分享 1：邀战分享
            success:res =>{
                //分享成功回调
            },
            fail:res => {
                 //分享失败回调
            },
            complete:res => {
                //成功失败都会走的回调
            },
       })

        
    }
    IS_Game_End_Xuanyao_Btn_Show()
    {
        return false;
    }
    login(callback)
    {
        console.log("gamebox.login");
        gamebox.login({

        })
    }
     
    CheckShowChaiping()
    {
        const interstitialAd = gamebox.createInterstitialAd();
        interstitialAd.show().catch(() => {
            // 失败重试
            interstitialAd.load()
              .then(() => interstitialAd.show())
              .catch(err => {
                console.log('InterstitialAd 广告显示失败', err)
              })
        })
    }

    Watch_Com_Guanggao_ID(guanggaoname,in_cb,agv,callback)
    {
        const ad = gamebox.createRewardedVideoAd();
        ad.show().catch(() => {
            // 失败重试
            ad.load()
              .then(() => ad.show())
              .catch(err => {
                console.log('激励视频 广告显示失败', err)
              })
        })

        ad.onCompleted(()=>
        {
            callback(true);
        })


    }
}