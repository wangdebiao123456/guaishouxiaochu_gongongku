   
import MyLocalStorge from "../WDT/MyLocalStorge";
 
import IPlatBannerMng from "./IPlatBannerMng"; 
import PlatFormParaMng from "./PlatFormParaMng";
//import PlatFormMng from "./PlatFormMng";
 

export default class IPlatformMng 
{
    m_banner_mng = null;

    

    constructor()
    {

    }
    Get_Chaping_Min_Jiange_Sec()
    {
        return 15;
    }
    IS_Can_Show_Zidingyi_TuijianWei()
    {
        return false;
    }
    IS_Show_Zidingyi_MoreGame()
    {
        return false;
    }
    Init_Get_User_Info(callback)
    {

    }
    Get_Saved_GUID()
    {
        return "";
    }
    Share_Msg(strtiel,strtyip)
    {

    }
    Check_WX_Login_Read_OpenId(callback)
    {
        
    }
    Is_In_Test_Version()
    {
      
        if(PlatFormParaMng.GetInstance().m_b_in_test)
        {
            return true;
        }
       

        return false;
    }
    Create_Banner_Mng()
    {
        return new IPlatBannerMng();
    }

    GetPlatFrom_Banner_Mng()
    {
        if(this.m_banner_mng == null)
        {
            this.m_banner_mng =  this.Create_Banner_Mng();
        }
      
        return   this.m_banner_mng;
    }
  

    //1:普通，2：android
    Get_Storge_Type()
    {

        return 1;
    }
    Check_Update()
    {
        
    }
    login(callback)
    {
        
    }
    IS_Fenxiang_Btn_Show()
    {

        return false;
    }
    Get_Dating_Fenxiang_Str()
    {
        return  "快来一起玩这个小兵大战僵尸的游戏,太好玩啦";
    }
    Dating_Fenxiang()
    {
        
    }
    Exit_Game()
    {
        cc.game.end();
    }
    Check_Show_YonghuXieyi()
    {
        return false;
    }
    PreLoad_Jili_Shiping(itype)
    {

    }
    OnBtnGengduoYouxi()
    {
        
    }
    Watch_Com_Guanggao_ID(guanggaoname,in_cb,agv,callback)
    {

    }
    CheckShowChaiping(ichaipingtype)
    {

    }
    Start_Luping()
    {

    }
    Stop_Luping()
    {

    }
    Fengxiang_Youxi_Luping(stitle,sscontent,callback)
    {

    }
    FD_Mng_Timer(mainnode:cc.Node)
    {
      
    }
    Manual_Destroy_banner(ibannerindex)
    {
        var  platformmng = this.GetPlatFrom_Banner_Mng();
        platformmng.Manual_Destroy_banner(ibannerindex)
    }
    Is_Banner_Show_Now(ibannerindex)
    {
        var  platformmng = this.GetPlatFrom_Banner_Mng();
        return platformmng.Is_Banner_Show_Now(ibannerindex);
    }

    Get_Banner_Type(ibannerindex)
    {
        var  platformmng = this.GetPlatFrom_Banner_Mng();
        return platformmng.Get_Banner_Type(ibannerindex);
    }

    
    Refresh_All_Banner_Show()
    {
        var  platformmng = this.GetPlatFrom_Banner_Mng();
        platformmng.Refresh_All_Banner_Show();
    }
    FD_Banner_Mng_Timer(pmainnode)
    {
        var  platformmng = this.GetPlatFrom_Banner_Mng();
        platformmng.FD_Banner_Mng_Timer(pmainnode);
    }
    IS_Zhanghuan_Gongzhanghao_Info_Show()
    {
        return false;
    }
    Set_Banner_Need_Show(ibannerindex,bshow)
    {
        var  platformmng = this.GetPlatFrom_Banner_Mng();
        platformmng.Set_Banner_Need_Show(ibannerindex,bshow);
    }

    Check_Create_Banner(ibannerindex,ibannertype, callback)
    {
        var  platformmng = this.GetPlatFrom_Banner_Mng();
        platformmng.Check_Create_Banner(ibannerindex,ibannertype, callback);
    }
    Refresh_Banner_Change_Show(backbannerindex)
    {
        var  platformmng = this.GetPlatFrom_Banner_Mng();
        platformmng.Refresh_Banner_Change_Show(backbannerindex)
    }
    Tiaozhuan_Tuijian_AppID(appid)
    {
         
    }

    Jump_To_App_Game_By_Data( app_info)
    {

    }
    Is_Dating_Show_Tuijian_Tiaozhuan()
    {
        return false;
    }

    IS_Game_End_Xuanyao_Btn_Show()
    {
        return false;
    }
}