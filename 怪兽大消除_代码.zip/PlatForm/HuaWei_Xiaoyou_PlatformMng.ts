import IPlatformMng from "./IPlatformMng";


export default class HuaWei_Xiaoyou_PlatformMng extends IPlatformMng
{
  
    constructor()
    {
        super();

    }

}