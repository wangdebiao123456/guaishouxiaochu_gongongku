import BytedanceBannerMng from "./BytedanceBannerMng";
import IPlatformMng from "./IPlatformMng";


export default class ByteDancePlatformMng extends IPlatformMng
{

    m_last_luping_url:string = "";

    constructor()
    {
        super();

    }

    IS_Fenxiang_Btn_Show()
    {

        return true;
    }
    IS_Game_End_Xuanyao_Btn_Show()
    {
        return true;
    }
    Share_Msg(strtiel,strtyip)
    {
        tt.shareAppMessage({
       
            title:strtiel,
            desc: strtyip,
           
            success() {
              console.log("分享成功");
            },
            fail(e) {
              console.log("分享失败");
            },
          });
    }
    Dating_Fenxiang()
    {
         var str=  this.Get_Dating_Fenxiang_Str();
        
         tt.shareAppMessage({
       
            title: "超好玩的怪兽消除游戏",
            desc: "快来玩这款好玩的消除游戏,比某羊香多了",
           
            success() {
              console.log("分享成功");
            },
            fail(e) {
              console.log("分享失败");
            },
          });
    }

    Watch_Com_Guanggao_ID(guanggaoname,in_cb,agv,callback)
    {

        const videoAd = tt.createRewardedVideoAd({
            adUnitId: "159qqpi6k6eh208lej",
        });

        videoAd
            .show()
            .then((err) => {
                console.log("视频广告展示");
            })
            .catch((err) => {
                console.log("广告组件出现问题", err);
                // 可以手动加载一次
                videoAd.load().then(() => {
                    console.log("手动加载成功");
                    // 加载成功后需要再显示广告
                    videoAd.show();
                })
            });

        function Close(res) {
            if (res.isEnded) {
                agv = true;
                callback(agv);
                console.log("true:" + res.isEnded);
            }else{
                agv = false;
                callback(agv)
                console.log("false:" + res.isEnded);
            }

            // if (res.count) {
                //在支持多例模式的版本上会返回该字段，并且是否返回该字段与multiton是否为true无关
                //判断观看了几次广告
                // console.log("用户完整看了多少次广告：" + res.count);
                // console.log("yes" + agv);
            // }

            videoAd
                .destroy()
                // .then(() => {
                //     //这里再次创建其他adUnitId的广告实例
                // })
                .catch((err) => {
                    console.log("广告组件出现问题", err);
                });
        };

        videoAd.onClose(Close);
    }
    Create_Banner_Mng()
    {
        return new BytedanceBannerMng();
    }
    CheckShowChaiping()
    {
        var adins = tt.createInterstitialAd({
            adUnitId:"79ail46i7m427jd9c7"
        });
        adins.show() .then((err) => {
            console.log("插屏广告展示");
        })
    }

    Start_Luping()
    {

        if(this.m_last_luping_url )
        {
            /*
            const fileSystemManager = tt.getFileSystemManager();
            fileSystemManager.removeSavedFile(
                {
                    filePath:this.m_last_luping_url 
                }
            );
            */

            this.m_last_luping_url = "";
        }

        tt.getSystemInfo({
            success(res) {
              const screenWidth = res.screenWidth;
              const screenHeight = res.screenHeight;
              const recorder = tt.getGameRecorderManager();
              var maskInfo = recorder.getMark();
              var x = (screenWidth - maskInfo.markWidth) / 2;
              var y = (screenHeight - maskInfo.markHeight) / 2;
          
              recorder.onStart((res) => {
                console.log("录屏开始");
                // do something;
              });
              //添加水印并且居中处理
              recorder.start({
                duration: 300,
                isMarkOpen: false,
                locLeft: x,
                locTop: y,
              });
            },
          });


          var self =this;


          const recorder2 = tt.getGameRecorderManager();
         

         
          recorder2.onStop((res2) => {
              // console.log(res.videoPath);
              // do something;
              console.log("录屏结束:"+res2.videoPath);
              self.m_last_luping_url = res2.videoPath;
              // self.lp_fenxiang();
          });
  
    }
    Stop_Luping()
    {
        const recorder = tt.getGameRecorderManager();

        recorder.onError((err) => {
            console.log("录屏错误:"+err)
        })

       
        recorder.stop();

        console.log("准备停止录屏")
    }
    Fengxiang_Youxi_Luping(stitle,sscontent,callback)
    {
            var self =this;

          
   
        console.log("可用录屏得到的本地文件路径:" + self.m_last_luping_url)
        if(!self.m_last_luping_url)
        {
        
            
            callback(false,"录屏时间小于3秒,无法分享");
            return;
        }

        // 视频分享
        tt.shareAppMessage({
            channel: "video",
            title: stitle,
            desc: sscontent,
            imageUrl: "",
             query: "",
            extra: {
                videoPath: self.m_last_luping_url, // 可用录屏得到的本地文件路径
                videoTopics: ["怪兽消除"],
                withVideoId: true,
            },
            success(res) {
                console.log("分享视频成功");
                callback(true);
              //  self.videoId = res.videoId;
                // tt.showModal({
                //     title: "分享成功",
                //     content: JSON.stringify(res.videoId),
                // });
            },
            fail(e) {
                // tt.showModal({
                //     title: "分享失败",
                //     content: JSON.stringify(e),
                // });


                var sremsg:string = e.errMsg;
                if(sremsg.indexOf("cancel") >= 0)
                {
                    callback(false,"用户取消");
      
                }else{
                    callback(false,"录屏时间小于3秒,无法分享!");
      
                }

                console.log("分享视频失败:" + e.errMsg); 
            },
        });

    }


}