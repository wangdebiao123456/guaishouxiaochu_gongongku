 

import WMap from "../WDT/WMap";
import ComFunc from "../comfuncs/ComFunc";
import MyLocalStorge from "../WDT/MyLocalStorge";

export default class HutuiAppInfoMng 
{

    
    static _instance:HutuiAppInfoMng = null;
    static GetInstance() 
    {
        if (!HutuiAppInfoMng._instance) {
            // doSomething
            HutuiAppInfoMng._instance = new HutuiAppInfoMng();
             
        }
        return HutuiAppInfoMng._instance;
    }

    m_valid_tubiao_img_event_map = new WMap();
    m_file_path_texture_map = new WMap();
    
    m_readed_remote_json = null;

    m_last_save_valid_hutui_wx_config_remote_json = null;


    /*
    m_all_dating_app_info_list = [];
    m_all_inner_game_show_icon_shaing_list = [];

    m_show_dating_app_index = -1;
    m_show_inner_game_app_index = -1;
    */

    m_pos_dest_app_info_list_map = new WMap();
    m_pos_show_app_index_map = new WMap();

    m_default_config = null;

    constructor()
    {

        this.InitRead_Last_Save_Common_Server_Config();
    }

    InitRead_Last_Save_Common_Server_Config()
    {
        
        var str = MyLocalStorge.getItem("guaishou_da_xiaochu_last_save_server_hutui_wx_config", "");

        if(!str)
        {
            return;
        }
    
        var basic_obj = JSON.parse(str);
        if(!basic_obj)
        {
            return;
        }

        if(!basic_obj.bvalid)
        {
            return;
        }

        this.m_last_save_valid_hutui_wx_config_remote_json = basic_obj;
       // console.log("m_last_save_valid_common_config_remote_json="+str);
    }



    Set_Default_Config(default_config)
    {
        this.m_default_config = default_config;
    }
    Get_Hutui_Gezi_Size()
    {
        return {cx:90,cy:90};
    }
    Get_Default_Tuiguan_Appid(ituijianwei)
    {
        if(ituijianwei == 2)
        {
            return "wx553ebd44ec20a9af";
        }
        
        return "wx61653cb69e41c1dc";
    }


    Get_Config()
    {
        if(this.m_readed_remote_json)
        {
            return this.m_readed_remote_json;
        }

        if(this.m_last_save_valid_hutui_wx_config_remote_json)
        {
            return this.m_last_save_valid_hutui_wx_config_remote_json;
        }

        if(this.m_default_config)
        {
            return this.m_default_config;
        }


        return null;
    }

    Get_InnerGame_Show_App_Icon_Info(ituijianwei)
    {
        var default_config = this.Get_Config();
        if(!default_config)
        {
            return null;
        }

        var tuijianweiinfolist = default_config.tuijianweiinfolist;
        if(!tuijianweiinfolist)
        {
            return null;
        }

        var tuijian_app_list=  null;
        var tuijian_Seq  = -1;
        for(var ff=0;ff<tuijianweiinfolist.length;ff++)
        {
            var ff_info  =tuijianweiinfolist[ff];


            var bfuhe = false;
            
            if(ff_info.pos == ituijianwei)
            {
                bfuhe = true;
            }

            var posarr = ff_info.posarr;
            if(posarr)
            {

                if(ComFunc.arrayShuzuContain(posarr,ituijianwei))
                {
                    bfuhe = true;
                }
            }

            var pos_range = ff_info.pos_range;
            if(pos_range)
            {
                for(var hh=0;hh<pos_range.length;hh++)
                {
                    var hh_arr = pos_range[hh];
                    if(hh_arr && hh_arr.length == 2)
                    {
                        var hh_x1 = hh_arr[0];
                        var hh_x2 = hh_arr[1];
                        
                        if(hh_x1 <= ituijianwei && ituijianwei<= hh_x2)
                        {
                            bfuhe = true;
                        }
                    }
                }

            }
         

            if(bfuhe)
            {
                tuijian_Seq = ff_info.showseq;
                if(!tuijian_Seq)
                {
                    tuijian_Seq = -1;
                }
                tuijian_app_list = ff_info.applist;
            }


          
        }

        if(!tuijian_app_list)
        {
            return null;
        }

        if(tuijian_app_list.length == 0)
        {
            return null;
        }

        var previndex=  -1;
        if(this.m_pos_show_app_index_map.hasKey(ituijianwei))
        {
            previndex  =  this.m_pos_show_app_index_map.getData(ituijianwei);
        }

        if(previndex == -1)
        {
            if(tuijian_Seq == 1)
            {
                tuijian_Seq = 0;
            }else if(tuijian_Seq == 3 || tuijian_Seq == 2)
            {
                previndex = Math.floor(Math.random() * tuijian_app_list.length)
            }else{
                tuijian_Seq = 0;
            }
        } 
        else{
            previndex++;
            if(tuijian_Seq == 3)
            {
                previndex = Math.floor(Math.random() * tuijian_app_list.length);
            }

        }



        if(previndex >= tuijian_app_list.length )
        {
            previndex = 0;
        }

        if(previndex < 0)
        {
            previndex = 0;
        }

        this.m_pos_show_app_index_map.putData(ituijianwei,previndex);
 
        var showiconinfo = tuijian_app_list[previndex];


        return showiconinfo;
    }

    Get_Hutui_Update_Tick()
    {
        var default_config = this.Get_Config();
        if(!default_config)
        {
            return 10*1000;
        }
       

        if(!default_config.update_icon_sec)
        {
            return 10*1000;
        }

        var isec = Number(default_config.update_icon_sec*1000) ;
        return isec;

        
    }

 
    NotifyValidTubiaoImgReaded(simgurl)
    {
        var pmap = this.m_valid_tubiao_img_event_map.Copy();

        for(var ff=0;ff<pmap.size();ff++)
        {
            var ff_pp = pmap.GetKeyByIndex(ff);
            ff_pp.On_Tubiao_Img_Readed_Event(simgurl);
        }

    }
    RegValidTubiaoImgEventLisnter(pp)
    {
        this.m_valid_tubiao_img_event_map.putData(pp,1);
    }
    UnRegValidTubiaoImgEventLisnter(pp)
    {
        this.m_valid_tubiao_img_event_map.RemoveKey(pp);
    }
    LoadRemoteAddresPic(simgurl)
    {
        var self = this;
        cc.assetManager.loadRemote(simgurl, (err, texture) =>  
        {
            if(err)
            {
                return;
            } 
 
      
            self.m_file_path_texture_map.putData(simgurl,texture);
            this.NotifyValidTubiaoImgReaded(simgurl);
        });
    }
    On_Load_Remote_Success()
    {
        if(this.m_readed_remote_json)
        {
            var tuijianweiinfolist = this.m_readed_remote_json.tuijianweiinfolist;

            for(var ff=0;ff<tuijianweiinfolist.length;ff++)
            {
                var ff_info =  tuijianweiinfolist[ff];
                var ff_applist = ff_info.applist;

                for(var gg=0;gg<ff_applist.length;gg++)
                {
                    var gg_data = ff_applist[gg];
                    var gg_icon = gg_data.icon;

                    this.LoadRemoteAddresPic(gg_icon);

                }
            }

 

            MyLocalStorge.setItem("guaishou_da_xiaochu_last_save_server_hutui_wx_config",JSON.stringify(this.m_readed_remote_json))
    

        }

    }
    
    
   LoadRemoteConfig(callback)
   {

 
       var irand11 = Math.floor(Math.random()*1000) ;
       var config_json = "https://outercoms.zfgame123.com/config/guaishou_da_xiaochu/wx/tuijian/guaishou_xiaochu_tuijian_wx.json?r="+irand11;

       var self = this;

    
       cc.assetManager.loadRemote(config_json, (err, jobj:cc.JsonAsset) =>  
       {
           if(err)
           {
               self.m_readed_remote_json = null;
               callback();
               console.log("加载配置错误:"+err)
               return;
           }
           self.m_readed_remote_json =  jobj.json;
           self.On_Load_Remote_Success();
           callback();
       });
       
   }


   GetFilePathTexture(spath)
    {
        if(this.m_file_path_texture_map.hasKey(spath))
        {
            var stexture = this.m_file_path_texture_map.getData(spath);
            return stexture;
        }
          
        return null;
    }
}