import ComFunc from "../comfuncs/ComFunc";
import PlatFormMng from "../PlatForm/PlatFormMng";
import PlatFormParaMng from "../PlatForm/PlatFormParaMng";
import PlatFormType from "../PlatForm/PlatFormType";
import XSC_Server_Request from "../utils/XSC_Server_Request";
import MyLocalStorge from "../WDT/MyLocalStorge";

 
export default class ZhanghaoMng
{
    static _instance:ZhanghaoMng = null;
    static GetInstance() 
    {
        if (!ZhanghaoMng._instance) {
            // doSomething
            ZhanghaoMng._instance = new ZhanghaoMng();
             
        }
        return ZhanghaoMng._instance;
    }


    m_cur_process_regetted = 0;

    //账号信息发送到服务器同步了吗 
    m_cur_zhanghao_basic_info_sended = 0;
   

    m_user_info_init_readed = 0;
    m_saved_nickname = "";
    m_saved_touxiang_url = "";


   

    constructor()
    {
        this.InitReadBasicInfo();
        
    }

    RequireYongyhuXinxin()
    {
        ZhanghaoMng.GetInstance().Check_Init_Read_User_Info();

    }
    Check_Showquan_Get_User_Info()
    {

        if(PlatFormParaMng.GetInstance().GetPlatFormType() != PlatFormType.PlatFormType_WX)
        {
            return;
        }
        
        var self = this;

        wx.requirePrivacyAuthorize(
            {
                 success: res => {
                     // 非标准API的方式处理用户个人信息
 
                     self.RequireYongyhuXinxin();
                 },
                 fail: () => {},
                 complete:() => {}
             }
         );
    }

    Get_Self_Touxiang_URL()
    {

        return this.m_saved_touxiang_url;
    }

    Get_Self_Show_Nickname()
    {
        if(this.m_saved_nickname)
        {
            return this.m_saved_nickname;
        }

        return "我";
    }
    Check_Init_Read_User_Info()
    {
        
        if(this.IS_User_Info_Inited() && this.m_cur_process_regetted)
        {
            this.Check_Post_Server_Zhanghao_Info();
            return;
        }


        this.Init_Get_User_Info();
       

    }

    Init_Get_User_Info()
    {
        
        PlatFormMng.GetInstance().Init_Get_User_Info((bsuc,userinfo)=>
        {
            if(!bsuc)
            {
                return;
            }

            ZhanghaoMng.GetInstance().On_Read_User_Info(userinfo.nickName,userinfo.avatarUrl);

        });

         
    }
    IS_User_Info_Inited()
    {
        return this.m_user_info_init_readed;
    }

    On_Send_Server_Success()
    {
        this.m_cur_zhanghao_basic_info_sended = 1;
        this.SaveBasicInfo();
    }
    Check_Post_Server_Zhanghao_Info()
    {
        if(!this.m_user_info_init_readed)
        {
            return;
        }
        if(this.m_cur_zhanghao_basic_info_sended)
        {
            return;
        }

        var sguid = PlatFormMng.GetInstance().Get_Saved_GUID();
        if(!sguid)
        {
            return;
        }

        var self = this;

        XSC_Server_Request.GetInstance().Poset_Server_JS_Log(101, "客户端获取昵称头像", 1,
            this.m_saved_nickname, 0, this.m_saved_touxiang_url, 0, "",
            (bsuc,sresponse)=>
            {
                if(!bsuc)
                {
                    return;
                }


               // console.log("服务器返回1:"+sresponse);
                if(sresponse == "ok")
                {
                    self.On_Send_Server_Success();
                }

            });

    }

    On_Read_User_Info(nickName,avatarUrl)
    {
        this.m_cur_process_regetted = 1;
        this.m_cur_zhanghao_basic_info_sended = 0;
        this.m_user_info_init_readed = 1;
        this.m_saved_nickname = nickName;
        this.m_saved_touxiang_url = avatarUrl;

        
        console.log("On_Read_User_Info nickName="+nickName+",avatarUrl="+avatarUrl);
       
        this.SaveBasicInfo();
         
        this.Check_Post_Server_Zhanghao_Info();
    }
    SaveBasicInfo()
    {
        var obj = {
            m_user_info_init_readed:this.m_user_info_init_readed,
            m_cur_zhanghao_basic_info_sended:this.m_cur_zhanghao_basic_info_sended,
            m_saved_nickname:this.m_saved_nickname,
            m_saved_touxiang_url:this.m_saved_touxiang_url,

        }

        MyLocalStorge.setItem("jingshangtianhua_zhanghao_sys_basicinfo",JSON.stringify(obj));

    }
    InitReadBasicInfo()
    {
        var preinfo = MyLocalStorge.getItem("jingshangtianhua_zhanghao_sys_basicinfo","");
        var jobj = null;
        if(preinfo)
        {
            try{
                jobj = JSON.parse(preinfo);
            }catch(e)
            {}
            
        }

        if(!jobj)
        {

            return;
        }

        this.m_user_info_init_readed = ComFunc.Check_Read_Number(jobj.m_user_info_init_readed);
        this.m_cur_zhanghao_basic_info_sended = ComFunc.Check_Read_Number(jobj.m_cur_zhanghao_basic_info_sended);
      
        
        this.m_saved_nickname = jobj.m_saved_nickname ? jobj.m_saved_nickname : "用户";
        this.m_saved_touxiang_url = jobj.m_saved_touxiang_url ? jobj.m_saved_touxiang_url : "";

      
    }
    SetShare_Call_Func(cb)
    {
        wx.onShareMessageToFriend((res)=>
        {
            cb(res);
        });
    }
}