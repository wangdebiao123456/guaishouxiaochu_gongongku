import MyHttpPostInfoUtil from "../comfuncs/MyHttpPostInfoUtil"; 
import MyLocalStorge from "../WDT/MyLocalStorge";
import WMap from "../WDT/WMap";
import IPlatformMng from "./IPlatformMng";
import WXBannerMng from "./WXBannerMng";
import GlobalGameMng from "../Mng/GlobalGameMng";
import ClientLogUtils from "../comfuncs/ClientLogUtils";
import LeoGameInfoMng from "../comfuncs/LeoGameInfoMng";


export default class WXPlatformMng extends IPlatformMng
{
    m_video = null;
    m_appid_navaiged_tick_map = new WMap();

    m_readed_wx_openid_info=  null;

    m_last_vide_union_id = "";
 
    constructor()
    {
        super();
        wx.onShareAppMessage(function () {
            return {
                "query":this.Get_Share_Query() 
              
            }
          })


          wx.showShareMenu({
            withShareTicket: true,
            menus: ['shareAppMessage', 'shareTimeline']
          })
    }

    Get_Chaping_Min_Jiange_Sec()
    {
        return 15;
    }
    IS_Game_End_Xuanyao_Btn_Show()
    {
        return true;
    }
    IS_Show_Zidingyi_MoreGame()
    {
        return true;
    }
    IS_Can_Show_Zidingyi_TuijianWei()
    {
        var bshow = GlobalGameMng.GetInstance().IS_Can_Show_Zidingyi_TuijianWei();

        return bshow;
    }
    ReadPrev_WX_OpenID_Info()
    {
        var str= MyLocalStorge.getItem("guaishou_da_xiaochu_wx_openid_info");
        if(!str)
        {
            return null;
        }

        var obj = JSON.parse(str);
        if(!obj)
        {
            return null;
        }


        var openid = obj.openid;
        if(!openid)
        {
            return null;
        }

        return obj;
    }
    Post_Server_Req_OpenID_Info(scode,callback)
    {
      
        var obj =
        {
            code: scode,
            appid:"wx0718c2639902aedc"
          };


          var self = this;

        var str = JSON.stringify(obj);
        MyHttpPostInfoUtil.POSTData( 'https://outercoms.zfgame123.com/Get_WX_Login_OpenID_Info.aspx',str,
        (bsuc,response)=>
        {
            console.log("Get_WX_Login_OpenID_Info response="+response);
        
            if(!bsuc)
            {
                console.log("获取openid错误:");
                callback();
                return;
            }

            var resobj = JSON.parse(response);

            var openid = resobj.openid;

            if(!openid)
            {
                callback();
                return;
            }
            var unionid = resobj.unionid;
            if(!unionid)
            {
                unionid = "";
            }
            console.log("获取openid:"+openid);
            LeoGameInfoMng.GetIns().On_Readed_WX_OpenId(openid);
          
            var saveifo = {unionid:unionid,openid:openid};

            var jsaveinfoi = JSON.stringify(saveifo);
            MyLocalStorge.setItem("guaishou_da_xiaochu_wx_openid_info",jsaveinfoi);

            self.m_readed_wx_openid_info = saveifo;
            callback();

        });
      
        
        
    }
    Check_WX_Login_Read_OpenId(callback)
    { 
        if(this.Is_In_Test_Version())
        {
            return ;
        }
      
        var wx_openinfo = this.ReadPrev_WX_OpenID_Info();
        if(wx_openinfo)
        {
            this.m_readed_wx_openid_info = wx_openinfo;
            callback();
            return;
        }

     
       
        var self = this;

        //读取
        wx.login({
            success (res) {
              if (res.code) {

                console.log("登录code=" + res.code);

                self.Post_Server_Req_OpenID_Info(res.code,callback);
              


              } else {
                callback();
                console.log('登录失败！' + res.errMsg)
              }
             
            }
          })
        
    }


    Check_Read_WX_OpenID()
    {
        return LeoGameInfoMng.GetIns().m_wx_openid;
     /*
        if(this.m_readed_wx_openid_info )
        {
            return  this.m_readed_wx_openid_info.openid;

        }

        var wx_openinfo = this.ReadPrev_WX_OpenID_Info();
        if(wx_openinfo)
        {
            this.m_readed_wx_openid_info = wx_openinfo;
      
            return  wx_openinfo.openid;
        }
        return "";
        */
    }
    Create_Banner_Mng()
    {
        return new WXBannerMng();
    }
    
    IS_Fenxiang_Btn_Show()
    {

        return true;
    }
    Get_Saved_GUID()
    {

        if(this.Is_In_Test_Version())
        {
            return super.Get_Saved_GUID();
        }

        
        var stropeniud = this.Check_Read_WX_OpenID();

        return stropeniud;
         
    }
    Get_Share_Query()
    {
        var appid = this.Get_Saved_GUID();

        var strquery = "fromopenid="+appid+"&plate=wx&u=1";
        return strquery;
    }
    Share_Msg(strtiel,strtyip)
    {
        if(this.Is_In_Test_Version())
        {

            return;
        }
        wx.shareAppMessage({
            "query":this.Get_Share_Query(),
            title: strtyip
          });
    }
    Dating_Fenxiang()
    {
        if(this.Is_In_Test_Version())
        {

            return;
        }
        
        wx.shareAppMessage({
            title: '超好玩的怪兽大消除游戏,超多玩法,几千关卡超好玩,一起来玩吧'
          });
    }
    IS_Zhanghuan_Gongzhanghao_Info_Show()
    {
        return true;
    }
    Is_Dating_Show_Tuijian_Tiaozhuan()
    {
        return true;
    }
    Tiaozhuan_Tuijian_AppID(appid)
    {
        if(this.Is_In_Test_Version())
        {

            return;
        }
        
        wx.navigateToMiniProgram({appId:appid})
    }

    Get_Chaiping_Union_ID(ichaipingtype)
    {


        if(ichaipingtype == 12)
        {
            //签到
            return "adunit-24690de36dfbac0a";
        }


        
        if(ichaipingtype  >= 21 && ichaipingtype <= 25)
        {
            return "adunit-6d4c6daeab3d20f2";
        }


        if(ichaipingtype  >= 26 && ichaipingtype <= 29)
        {
            return "adunit-acba3aa14ccc6cdf";
        }


        if(ichaipingtype  >= 31 && ichaipingtype <= 39)
        {
            return "adunit-0a18158897e814b0";
        }





        return 'adunit-35cb3fbe5f537c41';
    }
    CheckShowChaiping(ichaipingtype   = 0)
    {
        if(this.Is_In_Test_Version())
        {

            return;
        }
        
        var self = this;
        var chaipingid = this.Get_Chaiping_Union_ID(ichaipingtype);
    //    var chaping_gg = wx.createInterstitialAd({ adUnitId: 'adunit-35cb3fbe5f537c41' });
         var chaping_gg = wx.createInterstitialAd({ adUnitId: chaipingid});
   
      //  var chaping_gg = wx.createInterstitialAd({ adUnitId: 'adunit-35cb3fbe5f537c41' });
        chaping_gg.load(()=>{})

        chaping_gg.onLoad(() => {
            console.log('插屏 广告加载成功');
           // 
         
         });


          chaping_gg.onError(err => {
                chaping_gg.destroy();
              console.log("onError:"+err)
         });

         chaping_gg.onClose(res => {
            chaping_gg.destroy();
            console.log('插屏 广告关闭')
        });


        chaping_gg.show().catch((err) => {

            if(err)
            {
             
                console.error("显示error:"+ JSON.stringify(err) )
            }
            else{
                console.log('show 正常')
                //self.InitChaping();
            }
           
          });

    }

    Get_Guangao_ID_By_Name_MX(guanggaoname)
    {
       
        if(guanggaoname == "视频解锁难度")
        {
            return "adunit-27fe2f0b3bcdeb39";
        }
        if(guanggaoname == "复活")
        {
            return "adunit-8841e11e91fce95e";
        }

        if(guanggaoname == "三消消复活")
        {
            return "adunit-09954261dbaa0f9f";
        }


        if(guanggaoname == "游戏胜利双倍")
        {
            return "adunit-fcc953384fbeb490";
        }


        if(guanggaoname == "购买三消消道具")
        {
            return "adunit-e007e5b2e3f6bfbc";
        }


        if(guanggaoname == "普通购买体力")
        {
            return "adunit-609fc673dd09edf1";
        }
        if(guanggaoname == "连续购买48小时体力")
        {
            return "adunit-609fc673dd09edf1";
        }
        
        if(guanggaoname == "连续购买体力")
        {
            return "adunit-609fc673dd09edf1";
        }

        if(guanggaoname == "跳过关卡")
        {
            return "adunit-33d0f44c6c25dbe0";
        }


        if(guanggaoname == "签到双倍")
        {
            return "adunit-17f96f799ceed7b6";
        }
        if(guanggaoname == "购买道具")
        {
            return "adunit-a1fd1337a5087f3d";
        }


        if(guanggaoname == "三消消使用移除")
        {
            return "adunit-4e4d5cff427b73ab";
        }

        if(guanggaoname == "俄罗斯方块继续游戏")
        {
            return "adunit-11e9f54a463e25a1";
        }


        if(guanggaoname == "俄罗斯方块选择类型")
        {
            return "adunit-2d555b15c80af070";
        }
        
        if(guanggaoname == "视频解锁华容道模式")
        {
            return "adunit-92f6dd8cfd836df7";
        }
        
        if(guanggaoname == "领取首看礼包")
        {
            return "adunit-15caa977d74b81a8";
        }

 
        if(guanggaoname == "领取过关礼包")
        {
            return "adunit-15caa977d74b81a8";
        }


         
       
       return "adunit-f6bdbb7becd193c7";

    }
    Watch_Com_Guanggao_ID_B_Qufen_MX(guanggaoname,in_cb,agv,callback)
    {
        var self =  this;
        
        var guangaounitid =  this.Get_Guangao_ID_By_Name_MX(guanggaoname);

        if(this.m_last_vide_union_id != guangaounitid)
        {
            if(GlobalGameMng.GetInstance().IS_Watch_Video_Guanggao_Not_Same_Unionid_Need_Destroy_Prev())
            {
                if(this.m_video)
                {
                    this.m_video.destroy();
                }
                this.m_video = null;
            }
        }


        this.m_last_vide_union_id = guangaounitid;

        var videoAd = wx.createRewardedVideoAd({
            adUnitId: guangaounitid
        });
        this.m_video =videoAd;
        videoAd.offError();
        videoAd.offClose();
       

        
        videoAd.onError(  (err)=> {
           // callback(false);

           if(!err)
           {
              err = "";
           }
           callback(false,1,"视频播放错误:"+err.errCode);
        
            wx.showToast({
                title: "视频播放错误:"+err.errCode,
                icon: "error",
                duration: 1500
                })
          //  HDZhanZhengGameMng.GetInstance().Notify_HD_Event(HDZhanzheng_Event.HDZhanzheng_Event_Play_Vieo_Fail)
        });
        videoAd.onClose(function (res) {
            // 用户点击了【关闭广告】按钮
            // 小于 2.1.0 的基础库版本，res 是一个 undefined
            if (res && res.isEnded || res === undefined) {
                // 正常播放结束，可以下发游戏奖励
                callback(true);
            }
            else {
                // 播放中途退出，不下发游戏奖励
                callback(false,0,"用户中途退出");
            }
        });
    
        // 用户触发广告后，显示激励视频广告
        videoAd.show().catch(  (err)=> {
            // 失败重试
            videoAd.load()
                .then(function () { return videoAd.show(); })
                .catch(function (err) {
            
                     // self.m_b_playing_video = false;
                    //self.OnVideFailEnd();

                    if(!err)
                    {
                       err = "";
                    }
                    callback(false,2,"无视频广告:"+err.errCode);


                    wx.showToast({
                        title: "暂无视频广告,请稍后再试:"+err.errCode,
                        icon: "error",
                        duration: 1500
                    })
                    console.log('激励视频 广告显示失败'+JSON.stringify(err));

            });
        });
    }

    Watch_Com_Guanggao_ID(guanggaoname,in_cb,agv,callback)
    {

        if(this.Is_In_Test_Version())
        {

            callback(true);
            return;
        }

        var bqufen_mixi =  GlobalGameMng.GetInstance().IS_Watch_Video_Guanggao_Qufen_Mingxi();

        if(bqufen_mixi)
        {
 
             this.Watch_Com_Guanggao_ID_B_Qufen_MX(guanggaoname,in_cb, agv,callback)
             return;
        }


        var self =  this;
        
        var guangaounitid = "adunit-f6bdbb7becd193c7";

        if (!this.m_video) {
            // 创建激励视频广告实例，提前初始化
            var videoAd = wx.createRewardedVideoAd({
                adUnitId: guangaounitid
            });
            this.m_video = videoAd;
            this.m_video.onError(  (err)=> {

                if(!err)
                {
                   err = "";
                }
                callback(false,1,"视频播放错误:"+err.errCode);
             
                wx.showToast({
                    title: "视频播放错误:"+err.errCode,
                    icon: "error",
                    duration: 1500
                })
              //  HDZhanZhengGameMng.GetInstance().Notify_HD_Event(HDZhanzheng_Event.HDZhanzheng_Event_Play_Vieo_Fail)
            });
            this.m_video.onClose(function (res) {
                // 用户点击了【关闭广告】按钮
                // 小于 2.1.0 的基础库版本，res 是一个 undefined
                if (res && res.isEnded || res === undefined) {
                    // 正常播放结束，可以下发游戏奖励
                   callback(true);
                    // cb(agv);
                }
                else {
                    // 播放中途退出，不下发游戏奖励
                    callback(false,0,"用户中途退出");
                }
            });
        }
        // 用户触发广告后，显示激励视频广告
        this.m_video.show().catch(  (err)=> {
            // 失败重试
            self.m_video.load()
                .then(function () { return self.m_video.show(); })
                .catch(function (err) {


                    if(!err)
                    {
                       err = "";
                    }
                    callback(false,2,"无视频广告:"+err.errCode);

                
                console.log('激励视频 广告显示失败'+JSON.stringify(err));
                wx.showToast({
                    title: "暂无视频广告,请稍后再试:"+err.errCode,
                    icon: "error",
                    duration: 1500
                })
            });
        });



        /*
        if(this.Is_In_Test_Version())
        {

            callback(true);
            return;
        }

        var self =  this;
        
        var guangaounitid = "adunit-f6bdbb7becd193c7";

        if (!this.m_video) {
            // 创建激励视频广告实例，提前初始化
            var videoAd = wx.createRewardedVideoAd({
                adUnitId: guangaounitid
            });
            this.m_video = videoAd;
            this.m_video.onError(  (err)=> {
                wx.showToast({
                    title: "视频播放错误:"+err.errCode,
                    icon: "error",
                    duration: 1500
                })
              //  HDZhanZhengGameMng.GetInstance().Notify_HD_Event(HDZhanzheng_Event.HDZhanzheng_Event_Play_Vieo_Fail)
            });
            this.m_video.onClose(function (res) {
                // 用户点击了【关闭广告】按钮
                // 小于 2.1.0 的基础库版本，res 是一个 undefined
                if (res && res.isEnded || res === undefined) {
                    // 正常播放结束，可以下发游戏奖励
                   callback(true);
                    // cb(agv);
                }
                else {
                    // 播放中途退出，不下发游戏奖励
                    callback(false);
                }
            });
        }
        // 用户触发广告后，显示激励视频广告
        this.m_video.show().catch(  (err)=> {
            // 失败重试
            self.m_video.load()
                .then(function () { return self.m_video.show(); })
                .catch(function (err) {
                
                console.log('激励视频 广告显示失败'+JSON.stringify(err));

                wx.showToast({
                    title: "暂无视频广告,请稍后再试:"+err.errCode,
                    icon: "error",
                    duration: 1500
                })
 
            });
        });
        */
 
    }
    Check_Update()
    {
        const updateManager = wx.getUpdateManager()

            updateManager.onCheckForUpdate(function (res) {
            // 请求完新版本信息的回调
            console.log(res.hasUpdate)
            })

            updateManager.onUpdateReady(function () {
            wx.showModal({
                title: '更新提示',
                content: '新版本已经准备好，是否重启应用？',
                success(res) {
                if (res.confirm) {
                    // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
                    updateManager.applyUpdate()
                }
                }
            })
            })

            updateManager.onUpdateFailed(function () {
            // 新版本下载失败
            })
    }



    Jump_To_App_Game_By_Data(data)
    {
       
        let gameJumpData = data; 
        var appId = gameJumpData.toAppID;

        if(this.m_appid_navaiged_tick_map.hasKey(appId))
        {
            var lasttick = this.m_appid_navaiged_tick_map.getData(appId);

            if(Date.now() - lasttick < 1000)
            {
                return;
            }
        }
        this.m_appid_navaiged_tick_map.putData(appId,Date.now());
        
        let wx_ = wx;
        let self = this;
        //游戏跳转参数
        // let appId = data.appId;
        let sysinfo = wx_.getSystemInfoSync();
        let plat = 3;
        if (sysinfo.platform == "ios") plat = 1;
        if (sysinfo.platform == "android") plat = 2;
        // if (!appId) appId = gameJumpData.appId;
        let jumpObj = {
            toName: gameJumpData.toName,
            toAppID: gameJumpData.toAppID,
            togameid: gameJumpData.togameid,
            toAppPath: gameJumpData.toAppPath,
            addtiond: gameJumpData.addtiond,
            platform: plat 
        }
 
      
        console.log("jumto :"+gameJumpData.toAppID+",path="+gameJumpData.toAppPath);
       
        wx_.navigateToMiniProgram({
            appId: gameJumpData.toAppID,
            extraData:jumpObj,
            path: gameJumpData.toAppPath,
            success(res) {
                ClientLogUtils.GetInstance().Poset_Server_JS_Log(39, "成功跳转微信小程序", 0,
                "appid:"+appId, 0, ""+gameJumpData.toName, 0,  "");
            },
            fail(res) {
             
            }
        });


        
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(38, "点击跳转微信小程序", 0,
        "appid:"+appId, 0, ""+gameJumpData.toName, 0,  "");
    }

    Init_Get_User_Info(callback)
    {
        this.createUserInfoButton(callback );
    }
    createUserInfoButton(callback, x = 0, y = 0, width = cc.winSize.width, height = cc.winSize.height): void 
    {
		var userInfoButton = wx.createUserInfoButton({
            type: 'image',
            text: '游戏申请获取您的信息用于排行榜数据',
            // image: this._userInfoButtonData.url,
            style: {
                // left: this.systemInfo.screenWidth * this._userInfoButtonData.x - this._userInfoButtonData.width / 2,
                // top: this.systemInfo.screenHeight * this._userInfoButtonData.y - this._userInfoButtonData.height / 2,
                // width: this._userInfoButtonData.width,
                // height: this._userInfoButtonData.height
                left: x,
                top: y,
                width: cc.winSize.width,
                height: cc.winSize.height
            }
        });


        userInfoButton.onTap((res) => {
            // 此处可以获取到用户信息
            var userInfo = res.userInfo;

            if(userInfo)
            {


                console.log("获得用户信息:"+JSON.stringify(userInfo));

                var nickName = userInfo.nickName;
                var avatarUrl = userInfo.avatarUrl;


                callback(true, {nickName:nickName,avatarUrl:avatarUrl});
            }else{

                callback(false);
                 
            }

            userInfoButton.destroy();

        })
	}
    public getSetting(callback): void {
		wx.getSetting({
            success: (res: { authSetting: wx.types.AuthSetting }) => {
                // if (res.authSetting['scope.userInfo']) {
                // 	if (cbDone)
                // 		cbDone(res.authSetting['scope.userInfo']);
                // } else
                // 	if (cbFail) cbFail("开关无");

                var bscopeuserinfo = res.authSetting['scope.userInfo'];
                
                if (callback)   callback(true, bscopeuserinfo);
            },
            fail: (res) => {
                if (callback) callback(false,res);
            }
        });
	}
}