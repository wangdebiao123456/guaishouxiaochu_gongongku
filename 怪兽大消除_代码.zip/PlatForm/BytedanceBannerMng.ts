import IPlatBannerMng from "./IPlatBannerMng";

export default class BytedanceBannerMng  extends IPlatBannerMng
{
    constructor()
    {
       super();
    }

    GetBanner_Pos(ibannerindex)
    {
         
        const { windowWidth, windowHeight } = tt.getSystemInfoSync();
        //真实分辨率
        var irealheight = this.Get_Real_Height();
 
        var ireal_width = this.Get_Real_Width();
        var ibilv = windowWidth/ireal_width;
        var ibilv2 = windowHeight/irealheight;
     

        console.log("irealheight="+irealheight+",windowHeight="+windowHeight)

        var x = 0;
        var y = 2000;

        //大厅左下角格子
        if(ibannerindex == 1)
        {

            x=   windowWidth/2-  150;

            y = windowHeight/2 + 520*ibilv2;
           // var bottom_realy = (irealheight/2-450)*ibilv2 ;



          //  y = windowHeight - bottom_realy ;
            
        }  
         
        return {x:x,y:y}
    }

    Get_Banner_Union_ID(ibannerindex)
    {
     
        return "jaea8k66gf602ecef7";
   
    }
    On_Banner_Pos_Resize(bannerAd,ibannerindex,size_width, size_height)
    {
        const { windowWidth, windowHeight } = tt.getSystemInfoSync();
    
        if(ibannerindex == 1)
        {
            bannerAd.style.top = windowHeight - size_height;
            bannerAd.style.left = (windowWidth - size_width) / 2;
          
        }

    }
    //ibannertype:1-普通banner,2:格子       
    Check_Create_Banner(ibannerindex,ibannertype, callback)
    {
        var self = this;

        if(this.m_banner_index_banner_map.hasKey(ibannerindex))
        {
            var banner = this.m_banner_index_banner_map.getData(ibannerindex);
            callback(true,ibannerindex, banner);
            return;
        } 
       
        var banner_ubiinid = this.Get_Banner_Union_ID(ibannerindex);

        this.m_banner_index_type_map.putData(ibannerindex,ibannertype);


        var bannerpos = this.GetBanner_Pos(ibannerindex);

        const { windowWidth, windowHeight } = tt.getSystemInfoSync();
   
        var irealheight = this.Get_Real_Height();


        var ibiliv = windowHeight/irealheight;
 
      // var systeminfo =  tt.getSystemInfoSync();
 

       // const pixelRatio = systeminfo.pixelRatio;

        //底部居中
        const width = 320  ;
        const height = 80  ;
        const bannerTop = windowHeight - height -5;

        const bannerLeft = (windowWidth - width)/2;

       // const bannerTop = windowHeight/2 + ibiliv*380;


        console.log("显示banner bannerLeft="+bannerLeft+",top="+bannerTop+",windowHeight="+windowHeight+",windowWidth="+windowWidth)


        
        var banner_ubiinid = this.Get_Banner_Union_ID(ibannerindex);

          
        var bannerAd = tt.createBannerAd( 
            {
                
                adUnitId:banner_ubiinid, 
                adIntervals:30,
                style:{
                    width : width,
                    height : height,
                    left : bannerLeft,
                    top : bannerTop ,
                    adIntervals: 35
                }
            
            }
        ); 

        bannerAd.onResize((size)=>
        {
            bannerAd.style.top = windowHeight - size.height-2;
        });

        bannerAd.onError(
            (err)=>
            {
            
                console.log("banner广告错误:"+JSON.stringify(err));
                //bannerAd.destroy();
              //  self.m_banner_index_banner_map.RemoveKey(ibannerindex);
            }
        );
        if(bannerAd)
        {
            this.m_banner_index_banner_map.putData(ibannerindex,bannerAd);

            callback(true,ibannerindex,bannerAd);
        }
     

    }
    Refresh_Banner_Change_Show(ibannerindex)
    {
        
        if(this.m_banner_index_banner_map.hasKey(ibannerindex))
        {
            var banner  = this.m_banner_index_banner_map.getData(ibannerindex);
         
            var ibanenrtype = this.Get_Banner_Type(ibannerindex);
            var bshow = this.Is_Banner_Show_Now(ibannerindex);

          //  console.log("Refresh_Banner_Change_Show bshow="+bshow);

            if(ibanenrtype == 2)
            {
                if(bshow)
                {
                    if(!banner.isShow() || !this.Has_Banner_Showed(ibannerindex))
                    {
                        banner.show();
                        this.Set_Banner_Showed(ibannerindex);
                    }
                    

                }else{

                    
                    if(banner.isShow())
                    {
                        banner.hide();
                    } 

                }
            }else{
                if(bshow)
                {
                    banner.show();
                    this.Set_Banner_Showed(ibannerindex);

                }else{

                    
                    banner.hide();
                }


            }
            
          
        }
    }

}