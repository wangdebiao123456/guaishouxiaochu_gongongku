import IPlatBannerMng from "./IPlatBannerMng";

export default class P_4399_App_BannerMng  extends IPlatBannerMng
{
    constructor()
    {
       super();
    }

}