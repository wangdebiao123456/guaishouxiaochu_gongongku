import IPlatformMng from "./IPlatformMng";
import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import P_4399_App_BannerMng from "./P_4399_App_BannerMng";

var PaySDKMng_On_4399_APP_Jili_Reward_Success = function(bsuc:string)
{
    if(bsuc == "0")
    {
        WatchVideoAdveseMng.GetInstance().OnVideFailEnd();

    }else{
        WatchVideoAdveseMng.GetInstance().OnVideoSuccessEnd();

    }
   
};



export default class P_4399_App_PlatformMng extends IPlatformMng
{
    constructor()
    {
        super();

        this.InitSDK();
    }

    Create_Banner_Mng()
    {
        return new P_4399_App_BannerMng();
    }
    Check_Show_YonghuXieyi()
    {
        return false;
    }
     
    Get_Storge_Type()
    {

        return 2;
    }
    InitSDK()
    {
        cc.On_4399_APP_Jili_Reward_Success = PaySDKMng_On_4399_APP_Jili_Reward_Success;
    }
    CheckShowChaiping()
    {
        jsb.reflection.callStaticMethod('org/cocos2dx/javascript/AppActivity',
            'Jin_Show_Chaiping','(I)V',1);

    }
    Watch_Com_Guanggao_ID(guanggaoname,in_cb,agv,callback)
    {
        jsb.reflection.callStaticMethod('org/cocos2dx/javascript/AppActivity',
        'Jin_Start_Jili_Shiping','(I)V',1);
    }
}