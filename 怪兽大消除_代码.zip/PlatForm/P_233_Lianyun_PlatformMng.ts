
import IPlatformMng from "./IPlatformMng";

export default class P_233_Lianyun_PlatformMng extends IPlatformMng
{
    constructor()
    {
        super();

    }
    Get_Storge_Type()
    {

        return 2;
    }

    Watch_Com_Guanggao_ID(guanggaoname,in_cb,agv,callback)
    {
        //JniHelper.JIN_Open_Jili_Shiping();


    }
}