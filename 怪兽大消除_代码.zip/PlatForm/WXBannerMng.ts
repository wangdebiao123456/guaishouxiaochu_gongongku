import ComFunc from "../comfuncs/ComFunc";
import GlobalGameMng from "../Mng/GlobalGameMng";
import WMap from "../WDT/WMap";
import IPlatBannerMng from "./IPlatBannerMng";
import MiddleGamePlatformAction from "./MiddleGamePlatformAction";

export default class WXBannerMng  extends IPlatBannerMng
{
    constructor()
    {
       super();
    }

    IS_GaoBili_Pingmu() 
    {
 

        var windows_size = cc.director.getWinSize();
        var cx1 = windows_size.width;
        var cy1 =  windows_size.height;

        let size1 = cc.view.getFrameSize();
        var cx2 = size1.width;
        var cy2=  size1.height;

        
        var icom_sclae = cx1/cy1;
        var ireal_sclae = cx2/cy2;
  
        if(ireal_sclae < icom_sclae)
        {
            //高比实际高

          
            if(icom_sclae/ireal_sclae > 1.1)
            {
                return true;
            }


           
        } 

        return false;

    }



    Get_Scale_aujust_y()
    {
        var winsize_pixel =  cc.director.getWinSizeInPixels();

        var iscale1 = 1;

        var adjuesty=  winsize_pixel.height;
        if(winsize_pixel.height/winsize_pixel.width > 1280/720)
        {
            //屏幕高比较高

            iscale1 = winsize_pixel.width/720;
            adjuesty =  winsize_pixel.height/iscale1;

        }

    }
    Get_Game_Inner_Banner_Bottom_Banner_Y(ibannertype,bannerheight = null)
    {

        
        let systemInfo  = wx.getSystemInfoSync();
          var windowHeight = systemInfo.windowHeight;
 
 
 
        //真实分辨率
        var irealheight = this.Get_Real_Height();
 
    
        //真实分辨率 
        var ibilv_y = windowHeight/irealheight;


        var iyy1 = 113;
        if(ibannertype == 1)
        {
            iyy1 = 80;

        }

        if(bannerheight && bannerheight > 0)
        {
            iyy1 = bannerheight +1;

        }


        var alginbottom = GlobalGameMng.GetInstance().IS_Game_Scence_Bottom_Banner_Align_Bottom(ibannertype);
        var y =  windowHeight - iyy1;  

        if(alginbottom)
        {
                 
        }
        else{
            var itopy = irealheight  - 1280 - 5   ;

            if(ComFunc.ISChaoGaoPing())
            {
               itopy = irealheight  - 1300 -5 ;

            }

            var idibuy =   itopy;

            var aligin_y =  windowHeight - idibuy*ibilv_y;
            
            if(aligin_y > windowHeight - iyy1)
            {
                aligin_y = windowHeight - iyy1;
            }
            
            y= aligin_y;
        }

        return y;
    }

    GetBanner_Pos(ibannerindex)
    {

       



        let systemInfo  = wx.getSystemInfoSync();
        var windowWidth = systemInfo.windowWidth;
        var windowHeight = systemInfo.windowHeight;


        var winsize_pixel =  cc.director.getWinSizeInPixels();

       // console.log("winsize_pixel.cx="+winsize_pixel.width+",winsize_pixel.cy="+winsize_pixel.height);

        var pix_bili_y1 = windowHeight/winsize_pixel.height;
 
 
        //真实分辨率
        var irealheight = this.Get_Real_Height();
 
        var ireal_width = this.Get_Real_Width();
        var ibilv = windowWidth/ireal_width;
     
        var x = 0;
        var y = 2000;

       
        var cx = windowWidth;
        if(windowWidth > 400)
        {
            cx = 400;
        }
        var ileft =  2;

    
        //真实分辨率 
        var ibilv_y = windowHeight/irealheight;

        var itop = windowHeight/2 + 400*ibilv_y;



        if(ibannerindex  == 101)
        {
            // /大厅左边格子

             x=10;
             y = windowHeight -  180*ibilv_y;

        } 
        
        else if(ibannerindex  == 121)
        {
            // /大厅左边格子

             x=10;
             y = windowHeight -  180*ibilv_y;

        }  else if(ibannerindex  == 122)
        {
            // /大厅左边格子

             x=10;
             y = 20*ibilv_y;

        }  
        else if(ibannerindex  == 124 || ibannerindex  == 63   || ibannerindex  ==  160   || ibannerindex  ==  75
            || ibannerindex  ==  58 || ibannerindex  ==  33)
        {
            // /大厅左边格子

            x=2;
            y = 1;

        } 
        else if(ibannerindex  == 123)
        {
            // /大厅左边格子

             x=1;
             y = windowHeight/2 + 300*ibilv_y;

        }  
        
        else if(ibannerindex  == 102)
        {
            // /大厅左边格子

             x=windowWidth - 80;
             y = windowHeight - 180*ibilv_y;

        }
        else if(ibannerindex  == 103)
        {
            // /大厅底部banner

             x= 0;
             y = windowHeight - 113;

        }
        
        else if(ibannerindex  == 11 || ibannerindex  == 87)
        {
            // /怪兽消除左上角

            y =  40*ibilv_y;
            x = 260*ibilv;

        }
        else if(ibannerindex  == 13 || ibannerindex  == 66)
        {
            x = 2;

            y =  140*ibilv_y;
         
        } else if(ibannerindex  == 15)
        {
            x = windowWidth/2 + 125*ibilv;

            y = 10;// windowHeight/2 - 500*ibilv_y;
         
        }else if(ibannerindex  == 17 || ibannerindex == 18)
        {
            x = 2;

            y =  200*ibilv_y+10;
         
        }
        else if(ibannerindex  == 155)
        {
            x = 2;

            y =  480*ibilv_y+10;
        }
        else if(ibannerindex  == 163)
        {
            x = 2;

            y =  60*ibilv_y+30;
        }

        else if(ibannerindex  == 19)
        {
            
            x = 2;

            y =  windowHeight/2 + 440*ibilv_y;  
        }else if(ibannerindex  == 20)
        {
            
            x = 2;

            y =  180*ibilv_y;  
        }
        else if(ibannerindex  == 31)
        {
            //普通复活上方banner
            
            x = 5;

            y =  10;  
 

            y =  windowHeight/2 - 340*ibilv_y  - 100 ;  
            if(y < 10)
            {
                y = 10;
            }
        }else if(ibannerindex  == 32)
        {
            
            x = 5;

            y =  windowHeight/2 + 150*ibilv_y; 
        }
        else if(ibannerindex  == 41 )
        {
            //胜利弹框上面格子
            
            x = 5;
             y = windowHeight/2 -  330*ibilv_y;
 
 
          
        }else if(  ibannerindex  == 44)
        {
            
            x = 5;
           
 
             var itopy = irealheight/2 - 640  +410;


             if(ComFunc.ISChaoGaoPing())
             {
                itopy = irealheight/2 - 700  +410;
 
             }

         //    var ineeddescyt = irealheight/2 - itopy;


             y = windowHeight/2 -  itopy*ibilv_y;
 
        }
        else if(ibannerindex  == 42  )
        {
            //胜利弹框下方格子
            
            x = 5;

            y =  windowHeight/2 + 410*ibilv_y;;  
        }else if(  ibannerindex  == 45)
        {
            //失败弹框下方格子
            
            x = 5;

            y =  windowHeight/2 + 410*ibilv_y;;  
        }
        
        else if(ibannerindex  == 56)
        {
            
            x = 5;

            y =  windowHeight/2 - 300*ibilv_y  -100 ;  
            if(y < 10)
            {
                y = 10;
            }
        }
        else if(ibannerindex  == 76)
        {
            
            x = 5;

            y =  windowHeight/2 - 420*ibilv_y  -100 ;  
            if(y < 5)
            {
                y = 5;
            }


        }
        else if(ibannerindex  == 57)
        {
            
            x = 5;

            y =  windowHeight/2 + 180*ibilv_y;;  
        }else if(ibannerindex  == 77)
        {
            
            x = 5;

            y =  windowHeight/2 + 355*ibilv_y;;  
        }
        else if(ibannerindex  == 62  )
        {
            //暂停弹框上方banner
            x = 5;

         //   y =  windowHeight - 80;  

             y = windowHeight/2 - 100  - 350*ibilv_y;

            
        }
        else if( ibannerindex  == 162)
        {
            //暂停弹框上方banner
            x = 5;

         //   y =  windowHeight - 80;  

             y = windowHeight/2 - 100  - 425*ibilv_y;

            
        }
        
        else if(ibannerindex  == 61 || ibannerindex  == 161)
        {
            
            x = 5;

            y =  windowHeight/2 + 295*ibilv_y; 
        }
        else if(ibannerindex  == 72 || ibannerindex  == 82   || ibannerindex  == 88  || ibannerindex  == 38 || ibannerindex  == 14 || ibannerindex  == 67|| ibannerindex  == 112)
        {
            
            x = 5;

           
            y= this.Get_Game_Inner_Banner_Bottom_Banner_Y(1);
         
           

        }
        else if(  ibannerindex  == 83  || ibannerindex  == 89  || ibannerindex  == 39|| ibannerindex  == 68|| ibannerindex == 113 || ibannerindex == 12 || ibannerindex == 51 || ibannerindex == 52  || ibannerindex == 73)
        {
            
              
            x = (windowWidth-360)/2;

            y= this.Get_Game_Inner_Banner_Bottom_Banner_Y(2);
          
           
        }

        else if(ibannerindex  == 40  || ibannerindex  == 29  || ibannerindex  == 114 )
        { 

            x = 2;

            y =  1080*ibilv_y; 
        }
        else if(ibannerindex  == 71  )
        {
            
            x = windowWidth - 80;

            y =  120*ibilv_y;  

            if(ComFunc.ISChaoGaoPing())
            {
                y =  145*ibilv_y;  

            }
        }
        else if( ibannerindex ==   91)
        {
            
            x = windowWidth - 80;

            y =  20*ibilv_y;  
        }
        
        else if(ibannerindex  == 81)
        {
            
            x = windowWidth - 65;

            y =  880*ibilv_y - 80;  
        }
        else if(  ibannerindex  == 95)
        {
            //退出确认中间弹框格子
            x = 5;
           
 
             var itopy = 150;


             if(ComFunc.ISChaoGaoPing())
             {
                itopy = 150 +60;
 
             }

         //    var ineeddescyt = irealheight/2 - itopy;


             y =  itopy*ibilv_y;
 
        }
        else if(  ibannerindex  == 96)
        {
            x = 2;

            y =  390*ibilv_y+10;

        }else if(  ibannerindex  == 177)
        {
            x = 2;

            y =  390*ibilv_y+10;

        }
        else if(  ibannerindex  == 97)
        {
             //退出确认弹框左边格子
             x = 2;
         
             y = windowHeight/2 + 340*ibilv_y;

        }else if(  ibannerindex  == 98)
        {
             //退出确认弹框左边格子
             x = windowWidth - 80;
         
             y = windowHeight/2 + 340*ibilv_y;

        }else if(  ibannerindex  == 166)
        {
            x= 0;
            y = 0;
        }else if(  ibannerindex  >= 261 && ibannerindex  <= 265)
        {
            //单格子

            var index11 = ibannerindex - 261;
            x = index11 * 76;
         
            y = windowHeight - 120;

            console.log("格子 261")
        }
        else if(  ibannerindex == 199|| ibannerindex == 198)
        {
            x = 2;

            y =  60;

            if(ComFunc.ISChaoGaoPing())
            {
                y =  100;

            }
         
        } 
        
        else if(  ibannerindex  == 195)
        {
            x = 2;

            y =  500*ibilv_y+2;

        }
        else{


            x = ileft;
            y = itop;
        }








        return {x:x,y:y}
    }

    Get_Banner_Union_ID(ibannerindex,ibannertype)
    {

        var bchaogaoping = ComFunc.ISChaoGaoPing();

        var bchaogaoping_need_juzhen = GlobalGameMng.GetInstance().Get_GameBottom_ChaogaoPing_Need_Show_Juzhen_Gezi();

        var bshow_bottom_game_juzhen_gezi = false;
        if(bchaogaoping_need_juzhen && bchaogaoping)
        {
            bshow_bottom_game_juzhen_gezi = true;
        }


        if(ibannerindex == 101 || ibannerindex == 102)
        {
            return "adunit-bb19bc647d3b0f82";
        }
        
        if(ibannerindex == 103)
        {
            return "adunit-916df06c2809290c";
        }
        //怪兽消除左上角格子
        if(ibannerindex == 11)
        {
            return "adunit-de418b6e88dc7fee";
        }



         //连连看左上角格子
         if(ibannerindex == 13)
         {
             return "adunit-de418b6e88dc7fee";
         }

         //连连看下面banner
         if(ibannerindex == 14)
         {
             return "adunit-ba2d45ca434c6529";
         }


 
 
         //俄罗斯方块you上角格子
         if(ibannerindex == 15)
         {
             return "adunit-a3b0b995ef50e631";
         }
 
         if(ibannerindex == 17)
         {
             return "adunit-5c32015a9c7db754";
         }
 
         if(ibannerindex == 18)
         {

            return "adunit-add3838a6546b8b5" 
         }
         
         if(ibannerindex == 155)
         {

            return "adunit-2acb2e5d37801c3e" 
         }
         
        
         if(ibannerindex == 163)
         {

            return "adunit-8044f4412956c03f" 
         }

         //游戏失败继续
         if(ibannerindex == 177)
         {
             return "adunit-add3838a6546b8b5";
         }
         //移动怪兽消除下方格子
         if(ibannerindex == 19)
         {
             return "adunit-5f378028d900f9ea";
         }
         

             //移动怪兽消除左上角格子
         if(ibannerindex == 20)
         {

            return "adunit-de418b6e88dc7fee";
            // return "adunit-740a7b06144e279e";
         }
         
 
         if(ibannerindex == 31)
         {
             return "adunit-3a11bb23ec54e3c0";
         }
         if(ibannerindex == 32)
         {
             return "adunit-13580c3c25db3d69";
         }



         if(ibannerindex == 41)
         {
             return "adunit-16755f531ff28552";
         }



         if(ibannerindex == 42)
         {
             return "adunit-032a7060b6510e32";
         }




         if(ibannerindex == 44)
         {
             return "adunit-14ef5f0b704ed443";
         }

         if(ibannerindex == 45)
         {
             return "adunit-6b4106b00b5b4485";
         }
         

         //俄罗斯方块下方banenr
         if(ibannerindex == 51)
         {
             return "adunit-856523d04f0386bd";
         }

         //56:三消消复活弹框上方banner,57:三消消复活下方格子
         if(ibannerindex == 56)
         {
             return "adunit-1f7b23045c7333c3";
         }

         if(ibannerindex == 57)
         {
             return "adunit-217cc3d35528f150";
         }


         if(ibannerindex == 121 || ibannerindex == 122)
         {
             return "adunit-288f02f368595105";
         }

         if(ibannerindex == 123)
         {
            return "adunit-9f70c4c3f67edc6c";
        }



        if(ibannerindex == 124  || ibannerindex  == 63 || ibannerindex  == 160   || ibannerindex  ==  75
            || ibannerindex  ==  58 || ibannerindex  ==  33)
        {
           return "adunit-3ff888814acad0a5";
       }


        
         
          //暂停弹框下方banner
          if(ibannerindex == 62 )
          {
              return "adunit-78d7ad3905977ec9";
          }


          if(ibannerindex == 162)
          {
              return "adunit-375eff4a9aa1cde4";
          }


        //暂停弹框上方格子
        if(ibannerindex == 61 || ibannerindex == 161)
        {
            if(ComFunc.ISChaoGaoPing())
            {
                return "adunit-574499a4dcd1edfb";
            }

            return "adunit-26037abbe0b58cb8"
          
        }

        if(ibannerindex == 166)
        {
            //礼包上方大格子

            if(bchaogaoping)
            {
               // return "adunit-d702bfbd8a5481dc"
            }
           
             return "adunit-574499a4dcd1edfb";
        }

        if(ibannerindex == 198 || ibannerindex == 199 )
        {
            return "adunit-d702bfbd8a5481dc";
        }


        //翻牌消消乐 右上角格子
        if(ibannerindex == 66)
        {
            

            return "adunit-de418b6e88dc7fee";
           // return "adunit-67f51c46f406c712"
        
        }

        //翻牌消消乐 下面banner
        if(ibannerindex == 67)
        {
            

            return "adunit-f9ffc9e5cfa377f5"
        
        }

        //翻牌消消乐 等下面格子
        if(ibannerindex == 68 || ibannerindex == 12 || ibannerindex ==  52 || ibannerindex ==  73)
        {
            

            return "adunit-f72214082048d75a"
        
        }
        

        //消灭星星右上角格子
        if(ibannerindex == 71)
        {
            

            return "adunit-de418b6e88dc7fee"
           
          
        }

        //消灭星星下方banner
        if(ibannerindex == 72)
        {
            

            return "adunit-1f202ae10f6a1e0c"
          
        }


        //76:三消购买道具上方banner,77:购买道具下方格子

        if(ibannerindex == 76)
        {
            
            return "adunit-c00611c734ef88d6"
          
        }

        if(ibannerindex == 77)
        {
            
            return "adunit-1486368bcbe2147b"
          
        }



        //泡泡龙右边格子
        if(ibannerindex == 81)
        {
           // return "adunit-de418b6e88dc7fee"
           
            
            return "adunit-c4d3ed210e6b81a7"
            
        }

        //泡泡龙下方banner
        if(ibannerindex == 82)
        {
            

            return "adunit-3736dc05f50c3cda"
            
        }
           //泡泡龙下方格子
        if(ibannerindex == 83)
        { 
             
            return "adunit-f72214082048d75a"
            
        }


        

        //三消消左上角格子
        if(ibannerindex == 87)
        {
            

            return "adunit-363b077f45a3c935"
            
        }
        //三消消下方banner
        if(ibannerindex == 88)
        {
            

            return "adunit-6ec00789349fd599"
            
        }

        //三消消下方格子
        if(ibannerindex == 89)
        {
            

            return "adunit-ab3ed3b0c6cb2f68"
            
        }


        //滑木块下方banner
        if(ibannerindex == 38)
        {
            

            return "adunit-6ec00789349fd599"
            
        }

        //滑木块下方格子
        if(ibannerindex == 39)
        {
           
            return "adunit-ab3ed3b0c6cb2f68"
            
        }
        if(ibannerindex == 40 || ibannerindex == 29 || ibannerindex == 114)
        {
            // /超高屏幕需要矩阵
            return "adunit-7c7ed79d9ba5afb2"
            
        }


        //数字消除右上角
        if(ibannerindex == 91)
        {
            
           // adunit-7c7ed79d9ba5afb2
            return "adunit-de418b6e88dc7fee"
            
        }

        //退出确定弹框 95:中间格子,96:下方格子,97:左边竖着格子,98:右边竖着格子
        if(ibannerindex == 95 || ibannerindex == 96)
        {

            return "adunit-1636f5195f2d6375"
            
        }
        if(ibannerindex == 97 || ibannerindex == 98)
        {

            return "adunit-a8cf9641a3e194eb"
            
        }


         if(ibannerindex == 195)
        {

            return "adunit-49c956304fee43a3"
            
        }


        //数字华容道下方banneer
        if(ibannerindex == 112)
        {
            

            return "adunit-f9ffc9e5cfa377f5"
        
        }

        if(ibannerindex == 113)
        {
            

            return "adunit-f72214082048d75a"
        
        } 

        
        if(ibannerindex == 1)
        {
            return "adunit-b082954675b5f5ae";
   
        }

        if(ibannerindex >= 261 && ibannerindex <= 265)
        {
            return "adunit-67f51c46f406c712";
   
        }


        

         

        return "adunit-3ff888814acad0a5";
   
    }
    On_Banner_Recreated(ibannerindex)
    {
        MiddleGamePlatformAction.GetInstance().On_Banner_Recreated(ibannerindex);
 
    }
    On_Banner_Error(ibannerindex)
    {
        MiddleGamePlatformAction.GetInstance().On_Banner_Error(ibannerindex);
    }
    //ibannertype:1-普通banner,2:格子       
    Check_Create_Banner(ibannerindex,ibannertype, callback)
    {


        /*
        var self = this;

        if(this.m_banner_index_banner_map.hasKey(ibannerindex))
        {
            var banner = this.m_banner_index_banner_map.getData(ibannerindex);

            if(callback)
            {
                callback(true,ibannerindex, banner);
            }
            
            return;
        } 


        var bneed_pingbi_banner =  GlobalGameMng.GetInstance().Check_Banner_Index_Need_Pingbi(ibannerindex);
        if(bneed_pingbi_banner)
        {
            return;
        }

       
        this.On_Banner_Recreated(ibannerindex);

        //确定这个创建过了
        this.m_bannerindex_ensure_need_created_map.putData(ibannerindex,1);


        var banner_ubiinid = this.Get_Banner_Union_ID(ibannerindex,ibannertype);

        this.m_banner_index_type_map.putData(ibannerindex,ibannertype);


        var bannerpos = this.GetBanner_Pos(ibannerindex);
        var gezi_guanggao_obj = null;
       

           //刷新时间
        
           var banner_shuaixn_sec = GlobalGameMng.GetInstance().Get_BannerIndex_Shuaxin_Sec(ibannerindex);

           if(banner_shuaixn_sec >= 0 && banner_shuaixn_sec <= 30)
           {
               banner_shuaixn_sec = 32;
           }


        if(ibannertype == 1)
        {

            console.log("createGameBanner left="+bannerpos.x+",top="+bannerpos.y);
    
            if(banner_shuaixn_sec == -1)
            {
                gezi_guanggao_obj = wx.createBannerAd( 
                    {
                        
                        adUnitId:banner_ubiinid,  
                        style:{
                            left:bannerpos.x,
                            top:bannerpos.y ,
                            width: 300, 
                            height:80
                        }
                    
                    }
                ); 
            }
            else{
                gezi_guanggao_obj = wx.createBannerAd( 
                    {
                        
                        adUnitId:banner_ubiinid, 
                        adIntervals: banner_shuaixn_sec,
                        style:{
                            left:bannerpos.x,
                            top:bannerpos.y ,
                            width: 300,
                            adIntervals: banner_shuaixn_sec,
                            height:80
                        }
                    
                    }
                ); 

            }
           
            



            gezi_guanggao_obj.onError(
                (err)=>
                {
                
                    console.log("格子广告错误:"+JSON.stringify(err));
                    gezi_guanggao_obj.destroy();
                    self.m_banner_index_banner_map.RemoveKey(ibannerindex);

                    self.On_Banner_Error(ibannerindex);
                }
            );
        

            console.log("ibannerindex="+ibannerindex+",gezi_guanggao_obj="+gezi_guanggao_obj)
            //this.m_banner_index_banner_map.putData(ibannerindex,gezi_guanggao_obj);

          //  callback(true,ibannerindex,gezi_guanggao_obj);
        }
        else if(ibannertype == 2)
        {
            console.log("createGameBanner left="+bannerpos.x+",top="+bannerpos.y);
            if(banner_shuaixn_sec == -1)
            {

                gezi_guanggao_obj = wx.createCustomAd( 
                    {
                        
                        adUnitId:banner_ubiinid,
                        style:{
                            left:bannerpos.x,
                            top:bannerpos.y 
                        }
                    
                    }
                ); 
            }else{
                gezi_guanggao_obj = wx.createCustomAd( 
                    {
                        
                        adUnitId:banner_ubiinid,
                        adIntervals:banner_shuaixn_sec,
                        style:{
                            left:bannerpos.x,
                            adIntervals: banner_shuaixn_sec,
                            top:bannerpos.y 
                        }
                    
                    }
                ); 
            }
             
            gezi_guanggao_obj.onError(
                (err)=>
                {
                
                    console.log("格子广告错误:"+JSON.stringify(err));
                    gezi_guanggao_obj.destroy();
                    self.m_banner_index_banner_map.RemoveKey(ibannerindex);
                    self.On_Banner_Error(ibannerindex);
                }
            );
           
            //this.m_banner_index_banner_map.putData(ibannerindex,gezi_guanggao_obj);

          //  callback(true,ibannerindex,gezi_guanggao_obj);

        }else
        {
            callback(false);
            return;
        }


        let systemInfo  = wx.getSystemInfoSync();
        var windowWidth = systemInfo.windowWidth;
        var windowHeight = systemInfo.windowHeight;

        //真实分辨率
        var irealheight = this.Get_Real_Height();
           //真实分辨率 
           var ibilv_y = windowHeight/irealheight;

 
        if(gezi_guanggao_obj && gezi_guanggao_obj.onResize)
        {

            if(ibannerindex <= 10)
            {
               
                    gezi_guanggao_obj.onResize(res => {
        
                        gezi_guanggao_obj.style.left = (windowWidth -res.width )/2;
        
                        gezi_guanggao_obj.style.top =  windowHeight - res.height - 10;
                        //console.log(res.width, res.height)
                        //console.log(bannerAd.style.realWidth, bannerAd.style.realHeight)
                     
                    
                    });
                
        
            }
            else if(ibannerindex == 11)
            {
                //怪兽消除左上角
            }
            else if(ibannerindex == 101)
            {
                //大厅左边
               
            }else if(ibannerindex == 102)
            {
                //大厅右边
                gezi_guanggao_obj.onResize(res => {
        
                    gezi_guanggao_obj.style.left = windowWidth - res.width - 5;
    
                  //  gezi_guanggao_obj.style.top =  windowHeight - res.height - 2;
                    //console.log(res.width, res.height)
                    //console.log(bannerAd.style.realWidth, bannerAd.style.realHeight)
                 
                
                });
            }else if(ibannerindex == 103)
            {
                //大厅右边
                gezi_guanggao_obj.onResize(res => {
        
                    gezi_guanggao_obj.style.left = (windowWidth - res.width )/2;
    
                    gezi_guanggao_obj.style.top =  windowHeight - res.height - 1;
                    //console.log(res.width, res.height)
                    //console.log(bannerAd.style.realWidth, bannerAd.style.realHeight)
                 
                
                });
            }
            else if(ibannerindex == 19)
            {
                gezi_guanggao_obj.onResize(res => {
        
                    gezi_guanggao_obj.style.left = (windowWidth -res.width )/2;
    
                    gezi_guanggao_obj.style.top =  windowHeight - res.height - 8;
                    //console.log(res.width, res.height)
                    //console.log(bannerAd.style.realWidth, bannerAd.style.realHeight)
                 
                
                });
            } else if(ibannerindex == 31  )
            {
                gezi_guanggao_obj.onResize(res => {
        
                    gezi_guanggao_obj.style.left = (windowWidth -res.width )/2;

                    var iy = windowHeight/2 -res.height - 350* ibilv_y;

                    if(iy < 10)
                    {
                        iy=  10;
                    }
                    gezi_guanggao_obj.style.top = iy;
    
                  
                
                });
            }else if( ibannerindex == 32 || ibannerindex == 42 || ibannerindex == 45)
            {
                gezi_guanggao_obj.onResize(res => {
        
                    gezi_guanggao_obj.style.left = (windowWidth -res.width )/2;
    
                  
                
                });
            }else if(ibannerindex == 56)
            {
                gezi_guanggao_obj.onResize(res => {
                    gezi_guanggao_obj.style.left = (windowWidth -res.width )/2;
              
                 
                    var new_y =  windowHeight/2 - 300*ibilv_y  -res.height ;  
                    if(new_y < 5)
                    {
                        new_y = 5;
                    }
                    gezi_guanggao_obj.style.top =  new_y;

                
                });
            }
            else if(ibannerindex ==76)
            {
                gezi_guanggao_obj.onResize(res => {
                    gezi_guanggao_obj.style.left = (windowWidth -res.width )/2;
              
                    var new_y =  windowHeight/2 - 420*ibilv_y  -res.height ;  
                    if(new_y < 5)
                    {
                        new_y = 5;
                    }

                    gezi_guanggao_obj.style.top =  new_y;

                });
            } 
            else if(ibannerindex == 57)
            {
                gezi_guanggao_obj.onResize(res => {
        
                    gezi_guanggao_obj.style.left = (windowWidth -res.width )/2;
                  
                  
                
                });
            }
            else if(ibannerindex == 61 || ibannerindex == 161)
            {
                gezi_guanggao_obj.onResize(res => {
        
                    gezi_guanggao_obj.style.left = (windowWidth -res.width )/2;
                  
                  
                
                });
            }else if(ibannerindex == 62  )
            {
                gezi_guanggao_obj.onResize(res => {
        
                    gezi_guanggao_obj.style.left = (windowWidth -res.width )/2;
                  //  gezi_guanggao_obj.style.top =  windowHeight - res.height - 8;
             
                  
                   gezi_guanggao_obj.style.top =  windowHeight/2 - res.height  - 350*ibilv_y;
             
                });
            }else if(ibannerindex == 162)
            {
                gezi_guanggao_obj.onResize(res => {
        
                    gezi_guanggao_obj.style.left = (windowWidth -res.width )/2;
                  //  gezi_guanggao_obj.style.top =  windowHeight - res.height - 8;
             
                  
                   gezi_guanggao_obj.style.top =  windowHeight/2 - res.height  - 425*ibilv_y;
             
                });
            }
            else if(ibannerindex == 121  )
            {
                gezi_guanggao_obj.onResize(res => {
        
                    gezi_guanggao_obj.style.left = (windowWidth -res.width )/2;
                  //  gezi_guanggao_obj.style.top =  windowHeight - res.height - 8;
             
                  
                   gezi_guanggao_obj.style.top =  windowHeight - res.height  - 2;
             
                });
            }else if(ibannerindex == 122  )
            {
                gezi_guanggao_obj.onResize(res => {
        
                    gezi_guanggao_obj.style.left = (windowWidth -res.width )/2; 
             
                });
            }
            else if(ibannerindex == 71 || ibannerindex == 91)
            {
                gezi_guanggao_obj.onResize(res => {
        
                    gezi_guanggao_obj.style.left = windowWidth - res.width - 2; 
             
                  
                
                });
            } else if(ibannerindex == 81)
            {
                gezi_guanggao_obj.onResize(res => {
        
                    gezi_guanggao_obj.style.top = 860*ibilv_y - res.height - 2;
             
                  
                
                });
            } else if(ibannerindex == 83 || ibannerindex == 89 || ibannerindex == 39|| ibannerindex == 40 || ibannerindex == 68 
                || ibannerindex == 12 || ibannerindex == 51 || ibannerindex == 52  || ibannerindex == 73 || ibannerindex == 113)
            {
                gezi_guanggao_obj.onResize(res => {
        
                    gezi_guanggao_obj.style.left = (windowWidth -res.width )/2;

                  
                
                });
            } 
            else if(ibannerindex == 72 || ibannerindex == 82  || ibannerindex  == 83 
                ||ibannerindex == 88 ||ibannerindex == 38  || ibannerindex == 67 ||   ibannerindex == 112 ||ibannerindex == 14)
            {
                gezi_guanggao_obj.onResize(res => {
        
                    gezi_guanggao_obj.style.left = (windowWidth -res.width )/2;
                   
                   
                   
                        var newy= this.Get_Game_Inner_Banner_Bottom_Banner_Y(1,res.height);
         
 
                        gezi_guanggao_obj.style.top =  newy;
             
                  
                
                });
            }
        }
        

        if(gezi_guanggao_obj)
        {
           
            if(ibannerindex == 17  )
            {
                gezi_guanggao_obj.onClose(()=>
                {
                    self.Set_Banner_Need_Show(ibannerindex,false);

                    MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(11,false);

                })
    
                gezi_guanggao_obj.onHide(()=>
                {
                    self.Set_Banner_Need_Show(ibannerindex,false);

                    MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(11,false);

                })
    
    
            }
            else if(ibannerindex == 199 || ibannerindex == 198)
            {

                gezi_guanggao_obj.offClose();
                gezi_guanggao_obj.offHide();
            
                gezi_guanggao_obj.onClose(()=>
                {
                   // self.Set_Banner_Need_Show(ibannerindex,false);

                   MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(ibannerindex,false,true);

                    MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(ibannerindex,false);

                    gezi_guanggao_obj.destroy();
                    self.m_banner_index_banner_map.RemoveKey(ibannerindex);
              


                    if(GlobalGameMng.GetInstance().IS_Quanping_Gezi_Cahiping_Manual_Destroy_Need_Auto_ReCreate())
                    {
                        MiddleGamePlatformAction.GetInstance().Add_Manual_Destroyed_Banner_Index(ibannerindex);
                        console.log(ibannerindex+" 格子 销毁 ,需要自动创建");
                    }else{
                        console.log(ibannerindex+" 格子 销毁");
                    }
                 
                   
                })
    
                gezi_guanggao_obj.onHide(()=>
                {
                   // self.Set_Banner_Need_Show(ibannerindex,false);

                    MiddleGamePlatformAction.GetInstance().Set_Banner_Index_Show(ibannerindex,false,true);

                    MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(ibannerindex,false);
                    gezi_guanggao_obj.destroy();
                    self.m_banner_index_banner_map.RemoveKey(ibannerindex); 

                    if(GlobalGameMng.GetInstance().IS_Quanping_Gezi_Cahiping_Manual_Destroy_Need_Auto_ReCreate())
                    {
                        MiddleGamePlatformAction.GetInstance().Add_Manual_Destroyed_Banner_Index(ibannerindex);
                        console.log(ibannerindex+" 格子 销毁 ,需要自动创建");
                    }else{
                        console.log(ibannerindex+" 格子 销毁");
                    }
                    
                })
    
               
            }
             
        }
        
       


        console.log("ibannerindex="+ibannerindex+",gezi_guanggao_obj="+gezi_guanggao_obj)
        this.m_banner_index_banner_map.putData(ibannerindex,gezi_guanggao_obj);

        callback(true,ibannerindex,gezi_guanggao_obj);
        */
    }

 
     
    FD_Timer_Banner_Index(ibannerindex)
    {
         
    }


    Refresh_Banner_Change_Show(ibannerindex)
    {
        
        /*
        if(this.m_banner_index_banner_map.hasKey(ibannerindex))
        {
            var banner  = this.m_banner_index_banner_map.getData(ibannerindex);
         
            var ibanenrtype = this.Get_Banner_Type(ibannerindex);
            var bshow = this.Is_Banner_Show_Now(ibannerindex);

 

            var last_hide_eplasetick_not_engouh = false;

            if(this.m_banner_index_last_hide_tick_map.hasKey(ibannerindex))
            {
                var eplas_hide = Date.now() - this.m_banner_index_last_hide_tick_map.getData(ibannerindex);

                if(eplas_hide < 3000)
                {
                    last_hide_eplasetick_not_engouh = true;
                }
            }


            var last_show_eplasetick_not_engouh = false;

            if(this.m_banner_index_last_show_tick_map.hasKey(ibannerindex))
            {
                var eplas_show = Date.now() - this.m_banner_index_last_show_tick_map.getData(ibannerindex);

                if(eplas_show < 3000)
                {
                    last_show_eplasetick_not_engouh = true;
                }
            }

         
            if(ibanenrtype == 2)
            {
                if(bshow)
                {
                    if(!last_show_eplasetick_not_engouh)
                    {
                        if(!banner.isShow() || !this.Has_Banner_Showed(ibannerindex))
                        {
                            banner.show();
                            this.Set_Banner_Showed(ibannerindex);
    
                            this.m_banner_index_last_show_tick_map.putData(ibannerindex,Date.now());
           
                        }
                    }
                   
                   
                    

                }else{

                    if(!last_hide_eplasetick_not_engouh)
                    {
                        if(banner.isShow())
                        {
                            banner.hide();
    
                            this.m_banner_index_last_hide_tick_map.putData(ibannerindex,Date.now());
                            this.m_banner_index_last_show_tick_map.RemoveKey(ibannerindex);
                        } 
                    }
                    
                   

                }
            }else{
                if(bshow)
                {
                    if(!last_show_eplasetick_not_engouh)
                    {

                        if(!this.m_banner_index_last_show_tick_map.hasKey(ibannerindex))
                        {
                            banner.show();
                            this.Set_Banner_Showed(ibannerindex);
    
                            this.m_banner_index_last_show_tick_map.putData(ibannerindex,Date.now());
                        }
                        else{
                            var lastshowtick = this.m_banner_index_last_show_tick_map.getData(ibannerindex);
                            var ieplasertick = Date.now()  - lastshowtick;
    
                            if(ieplasertick > 300000)
                            {
                                banner.show();
                                this.Set_Banner_Showed(ibannerindex);
    
                                this.m_banner_index_last_show_tick_map.putData(ibannerindex,Date.now());
                            }
                        }

                    }
                    
                   

                }
                else
                {

                    if(!last_hide_eplasetick_not_engouh)
                    {

                        banner.hide();
                        this.m_banner_index_last_show_tick_map.RemoveKey(ibannerindex);
    
                        this.m_banner_index_last_hide_tick_map.putData(ibannerindex,Date.now());
                    }
                    
                }


            }
            


            if(bshow)
            {
                this.m_banner_index_last_hide_tick_map.RemoveKey(ibannerindex);
            }else{
                this.m_banner_index_last_show_tick_map.RemoveKey(ibannerindex);
          
            }

        
          
        }



        */


    }
 

}