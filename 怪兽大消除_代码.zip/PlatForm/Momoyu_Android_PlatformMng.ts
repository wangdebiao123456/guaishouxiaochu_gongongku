import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import IPlatformMng from "./IPlatformMng";


var PaySDKMng_On_Momoyu_Jili_Reward_Success = function(bsuc:string)
{
    if(bsuc == "0")
    {
        WatchVideoAdveseMng.GetInstance().OnVideFailEnd();

    }else{
        WatchVideoAdveseMng.GetInstance().OnVideoSuccessEnd();

    }
   
};


export default class Momoyu_Android_PlatformMng extends IPlatformMng
{
    constructor()
    {
        super();

        this.InitSDK();
    }
    Get_Chaping_Min_Jiange_Sec()
    {
        return 31;
    }
    Get_Storge_Type()
    {

        return 2;
    }
    InitSDK()
    {
        cc.On_Momoyu_Jili_Reward_Success = PaySDKMng_On_Momoyu_Jili_Reward_Success;
    }
    CheckShowChaiping()
    {
        jsb.reflection.callStaticMethod('org/cocos2dx/javascript/AppActivity',
            'Jin_Show_Chaiping','(I)V',1);

    }
    Watch_Com_Guanggao_ID(guanggaoname,in_cb,agv,callback)
    {
        jsb.reflection.callStaticMethod('org/cocos2dx/javascript/AppActivity',
        'Jin_Start_Jili_Shiping','(I)V',1);
    }
    PreLoad_Jili_Shiping(itype)
    {
        jsb.reflection.callStaticMethod('org/cocos2dx/javascript/AppActivity',
        'Jin_Preload_Jili_Shiping','(I)V',1);
    }
}