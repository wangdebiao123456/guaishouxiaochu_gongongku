

export default class PlatFormType{
 

    public static PlatFormType_Default = 9999999; //无 

    public static PlatFormType_WX = 1;  
    public static PlatFormType_233 = 2;  
    public static PlatFormType_HaiWai_Wangzhuan_Yueyou = 3;  
    public static PlatFormType_4399_H5_Xiaoyouxi = 4;  
    public static PlatFormType_4399_Xiaoyouxi_Hezi = 5;  
    public static PlatFormType_4399_APP = 6;  
    public static PlatFormType_LeTiantang_TapTap = 7;  
    public static PlatFormType_LeTiantang_IOS_AppStore = 8;  
    public static PlatFormType_HaoYouKuaiBao = 9;  
    public static PlatFormType_ByteDance = 10;  
    public static PlatFormType_Kuaishou_Xiaoyouxi = 11;  
    public static PlatFormType_QQ_Xiaoyouxi = 12;  
    public static PlatFormType_OPPO_Xiaoyouxi = 13;   
    public static PlatFormType_Huaiwei_Xiaoyouxi = 14;   
    public static PlatFormType_Vivo_Xiaoyouxi = 15;   
    public static PlatFormType_Momoyu_Android = 16;
    //穿山甲   
    public static PlatFormType_Chuangshanjia_common = 17;   
   
  
    
    
}

 