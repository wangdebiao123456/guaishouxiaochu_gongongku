import IPlatformMng from "./IPlatformMng";


export default class KuaiShouPlatformMng extends IPlatformMng
{
    m_last_luping_url:string = "";

    constructor()
    {
        super();

    }
    IS_Fenxiang_Btn_Show()
    {

        return true;
    }

    
    IS_Game_End_Xuanyao_Btn_Show()
    {
        return true;
    }
    Dating_Fenxiang()
    {
         var str=  this.Get_Dating_Fenxiang_Str();
        
         ks.shareAppMessage({
       
            title: "超好玩的怪兽消除游戏",
            desc: "好玩的消除小游戏,比某羊不香多了",
           
            success() {
              console.log("分享成功");
            },
            fail(e) {
              console.log("分享失败");
            },
          });
    }

    CheckShowChaiping()
    {
        let InterstitialAd = ks.createInterstitialAd({ adUnitId: '2300003324_02' })
        InterstitialAd.show()
        .then(() => console.log('插屏 广告显示'))
    }

    Watch_Com_Guanggao_ID(guanggaoname,in_cb,agv,callback)
    {

        let rewardedVideoAd = ks.createRewardedVideoAd({ adUnitId: '2300003324_01' })
        rewardedVideoAd.show()
        .then(() => console.log('激励视频 广告显示'))


        rewardedVideoAd.onClose(res => {
            // 用户点击了【关闭广告】按钮
            if (res && res.isEnded || res === undefined) {
              // 正常播放结束，可以下发游戏奖励
              callback(true);
            }
            else {
                // 播放中途退出，不下发游戏奖励
                callback(false);

                console.log('激励视频播放失败:'+JSON.stringify(res))
            }
        })


        rewardedVideoAd.onError(err => {
          console.log('激励视频播放err:'+err)
        })
    }


    Start_Luping()
    {

        var self = this;
        self.m_last_luping_url = "";

        const recorder = ks.getGameRecorder()

        // 设置录屏相关监听
        recorder.on('start', () => {
          // start 事件的回调函数的执行表示录制的真正开始
        })
        
        // 监听录屏过程中的错误，需根据错误码处理对应逻辑
        recorder.on('error', (err) => {
          // 录屏过程中，当收到onError的回调时，表明录制过程中存在异常，调试时可以根据err.code定位异常的原因
          // 相关errorCode含义见录屏相关错误码定义
        })
        
        // stop 事件的回调函数
        recorder.on('stop', res => {
          if (res && res.videoID) {
            self.m_last_luping_url = res.videoID;
            // 当录制成功时，会产生一个videoID，用于发布录屏(recorder.publishVideo)接口使用
           // console.log(`videoID is ${res.videoID}`)
            console.log(`录屏停止，录制成功`)
          } else {
            /****注意：没有videoID时不可展示分享录屏按钮，审核会过此case****/
            /****测试方法：点击右上角"..."按钮打开设置页面，关闭录屏开关，录屏不会产生videoID****/
            // 没有videoID时，可以通过onError回调获取录制失败的原因
            console.log(`录屏停止，录制失败`)
          }
        })
        
        // pause 事件的回调函数
        recorder.on('pause', () => {
          console.log('暂停录制')
        })
        
        // resume 事件的回调函数
        recorder.on('resume', () => {
          console.log('继续录制')
        })
        
        // abort 事件的回调函数，表示录制中的游戏画面已经被舍弃
        recorder.on('abort', () => {
          console.log('废弃已录制视频')
        })
        
        
        // 发起开始录制的调用，真正开始时会回调上面start的监听，开始失败则会回调error的监听
        recorder.start();
    }
    Stop_Luping()
    {

        const recorder = ks.getGameRecorder()
        recorder.stop();
    }

    Fengxiang_Youxi_Luping(stitle,sscontent,callback)
    {
        var self =this;
        if(!self.m_last_luping_url)
        {
        
          callback(false,"录屏时间过短,无法分享"); 
            return;
        }
        const recorder = ks.getGameRecorder()
   
        recorder.publishVideo({
            video: self.m_last_luping_url,
            callback: (error) => {
                if (error != null && error != undefined) {
                    callback(false,"分享失败");
                  //  console.log("分享录屏失败" + JSON.stringify(error));
                    return;
                }
                console.log("分享录屏成功");
            }
        });

    }

}