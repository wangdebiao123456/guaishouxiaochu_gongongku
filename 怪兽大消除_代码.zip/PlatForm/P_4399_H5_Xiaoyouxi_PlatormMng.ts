import IPlatformMng from "./IPlatformMng";

export default class P_4399_H5_Xiaoyouxi_PlatormMng extends IPlatformMng
{
    constructor()
    {
        super();

    }
    OnBtnGengduoYouxi()
    {
        window.h5api.showRecommend();
    }
    IS_Fenxiang_Btn_Show()
    {

        return true;
    }
    Dating_Fenxiang()
    {
        window.h5api.share();
    }
    IS_Game_End_Xuanyao_Btn_Show()
    {
        return false;
    }
    Watch_Com_Guanggao_ID(guanggaoname,in_cb,agv,callback)
    {

        this.Open_4399_H5_Xiaoyouxi_Shiping((bsuc)=>
        {
            if(!bsuc)
            {
                callback(false);

                return;
            }
            callback(true);
        });
    }
    //打开4399的h5小游戏视频
    Open_4399_H5_Xiaoyouxi_Shiping(callback)
    {
        var self = this;
        window.h5api.playAd((obj)=>
        {
            console.log("4399 obj.code="+obj.code);
            if (obj.code === 10000)
            {

            }
            else if (obj.code === 10001) {

                callback(true);
            }else{
                
            }
        });
        
        
    }

}