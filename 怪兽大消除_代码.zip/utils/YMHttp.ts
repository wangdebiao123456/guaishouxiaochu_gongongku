 
/**
 * Predefined variables
 * Name = YMHttp
 * DateTime = Wed Dec 22 2021 10:28:08 GMT+0800 (中国标准时间)
 * Author = eduwc
 * FileBasename = YMHttp.ts
 * FileBasenameNoExtension = YMHttp
 * URL = db://assets/script/yunmo/net/YMHttp.ts
 * ManualUrl = https://docs.cocos.com/creator/3.4/manual/zh/
 *
 */

export class YMHttp {
    private static _instance:YMHttp = null;

    public static getInstance():YMHttp
    {
        if(YMHttp._instance == null)
        {
            YMHttp._instance = new YMHttp();
        }
        return YMHttp._instance;
    }   



    static POSTData(url, dataStr, callback) 
     {
        // url = HttpUtil.baseUrl + url;

        console.log("POSTData dataStr="+dataStr);


        try{
            var xhr = cc.loader.getXMLHttpRequest();
            
            xhr.open("POST", url, true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
           // xhr.setRequestHeader("Access-Control-Allow-Origin", "*");

 
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4) {
                    let response = xhr.responseText;
                    if (xhr.status >= 200 && xhr.status < 300) {
                        let httpStatus = xhr.statusText;
                        // callback(true, JSON.parse(response));
                        console.log("成功 返回值="+response);

                       if(callback)
                       {
                          callback(  response);
                       }
                        
    
                    } else {
                     
                        console.log("失败 TTP连接 错误 url="+url+",xhr.status="+xhr.status)
                    }
                }
            };
            xhr.send(dataStr);
        }
        catch(e)
        {

        }

      
    }

    sendMessage_ZhongZhuan(url, value, callback)
    {
         var zhongzhuanurl = "https://dianjitaitan.zfgame123.com/Middle_Shouzu_Server.aspx";
       //  var zhongzhuanurl = "http://61.160.194.250:3120/Middle_Shouzu_Server.aspx";


     

        var svalue = value;

        if(typeof value === "string")
        {
            svalue = value;
        }else{
            svalue = JSON.stringify(value);
        }

        var all_content = "surl="+url+"###&&&scontent="+svalue;

        YMHttp. POSTData(zhongzhuanurl, all_content,  callback) ;
        return;

        /*
        var destres = {
            "surl":url,
            "scontent":value
        }
        */

        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4) {
                if (xhr.status >= 200 && xhr.status < 400) {
                    var response = xhr.responseText; 
                    callback(response);
                } else { 

                    console.log("HTTP连接 错误 url="+url+",xhr.status="+xhr.status)
                } 
            }
        };
        xhr.timeout = 5000;
       // xhr.open("POST", url, true);
        xhr.open("POST", zhongzhuanurl, true);

        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8")
        xhr.send(all_content)
       
      //  xhr.setRequestHeader("Content-Type", "application/json");
     
     
       // xhr.send(value);
 
     //   xhr.send(JSON.stringify(destres));


    }


    sendMessage(url, value, callback)
    {
        if(1> 0 )// cc.sys.isBrowser)
        {
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4) {
                    if (xhr.status >= 200 && xhr.status < 400) {
                        var response = xhr.responseText; 
                        callback(response);
                    } else { 
    
                        console.log("HTTP连接 错误 url="+url+",xhr.status="+xhr.status)
                    } 
                }
            };
            xhr.timeout = 5000;
            xhr.open("POST", url, true);
            xhr.setRequestHeader("Content-Type", "application/json");
            xhr.send(value);

            
        }else{
            this.sendMessage_ZhongZhuan(url, value, callback);

        }
     
        /*
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4) {
                if (xhr.status >= 200 && xhr.status < 400) {
                    var response = xhr.responseText;
                    YMLog.system("获得HTTP信息" + response)
                    callback(response);
                } else {
                    YMLog.system("HTTP连接失败");

                    console.log("HTTP连接 错误 url="+url+",xhr.status="+xhr.status)
                } 
            }
        };
        xhr.timeout = 5000;
        xhr.open("POST", url, true);
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.send(value);
        */
    }

    sendMessageHead(url, value, head, callback)
    {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4) {
                if (xhr.status >= 200 && xhr.status < 400) {
                    var response = xhr.responseText; 
                    callback(response);
                } else { 
                }
            }
        };
        xhr.timeout = 5000;
        xhr.open("POST", url, true);
        xhr.setRequestHeader("Content-Type", "application/json");

        for (const key in head) {
            if (Object.prototype.hasOwnProperty.call(head, key)) {
                const element = head[key];
                xhr.setRequestHeader(key, element);
            }
        }
        xhr.send(value);
    }


    sendBiaodanfunction (url, value, callback) {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.responseText) {
                var response = xhr.responseText
                let obj =  JSON.parse(response)
                callback(obj)    
            }
        };
        xhr.timeout = 5000
        xhr.open("POST", url, true)
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8")
        xhr.send(value)
    }

    getAjax (url3, value, callback) {
        var xhr3 = new XMLHttpRequest()
        xhr3.onreadystatechange = function () {
            if (xhr3.readyState == 4 && (xhr3.status >= 200 && xhr3.status < 400)) {
                var response = xhr3.responseText
                if(response){
                    response=JSON.parse(response)
                    callback(response)   
                } else {
                    console.log(url3, '返回失败response', response)
                } 
            }else {
                console.log(url3, '返回失败xhr3', xhr3)
            }
        };
        xhr3.open("GET", url3, true)
        xhr3.send()
    }
}
