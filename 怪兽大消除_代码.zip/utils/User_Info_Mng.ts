 
import MyLocalStorge from "../WDT/MyLocalStorge";
import WMap from "../WDT/WMap";
import XSC_Server_Request from "./XSC_Server_Request"; 
 

export default class User_Info_Mng
{

    static _instance:User_Info_Mng = null;
   

    static GetInstance() 
    {
        if (!User_Info_Mng._instance) {
            // doSomething
            User_Info_Mng._instance = new User_Info_Mng();
             
        }
        return User_Info_Mng._instance;
    }


    m_server_readed_guid_name_map = new WMap();


    m_user_id = 0;
    m_username = "";

    m_server_readed_guid_zhanli_fight_info_map = new WMap();
    m_server_readed_guid_zhanli_fight_info_readed_tick_map = new WMap();


    constructor()
    {

       this.Init_UserName();
    }

    IS_GUID_Zhanli_Fight_Info_Need_Refresh(sguid)
    {
        if(!this.m_server_readed_guid_zhanli_fight_info_map.hasKey(sguid))
        {
            return true;
        }

        var last_tick = this.m_server_readed_guid_zhanli_fight_info_readed_tick_map.getData(sguid);

        if(Date.now() - last_tick > 1000*600)
        {
            return true;
        }
        return false;
    }

    Set_Readed_Zhanli_Fight_Info(sguid,pinfo)
    {

       // var sfightinfo = pinfo.sfightinfo;

         
        this.m_server_readed_guid_zhanli_fight_info_map.putData(sguid,pinfo);
        this.m_server_readed_guid_zhanli_fight_info_readed_tick_map.putData(sguid,Date.now())
    }
    IS_GUID_Name_Exist(sguid)
    {
        if(this.m_server_readed_guid_name_map.hasKey(sguid))
        {
            return true;
        }

        return  false;
    }
    Post_Get_SGuid_Name( sguid,callback)
    {
        /*
        XSC_Server_Request.GetInstance().Poset_Server_Request(
            104,"",0,sguid,0,"",0,"",callback
        )
        */

    } 
    Set_Readed_User_Name(sguid,snickname)
    {
        this.m_server_readed_guid_name_map.putData(sguid,snickname);
    }
    Get_Guid_Name(sguid)
    {
        if(this.m_server_readed_guid_name_map.hasKey(sguid))
        {
            var sname = this.m_server_readed_guid_name_map.getData(sguid);
            return sname
        }

        

        return ""

    }

    Get_Guid_Zhanli_Fight_Info(sguid)
    {
        if(this.m_server_readed_guid_zhanli_fight_info_map.hasKey(sguid))
        {
            var fightinfo = this.m_server_readed_guid_zhanli_fight_info_map.getData(sguid);
            return fightinfo
        }

        

        return  null;

    }
 

    On_Readed_Server_UserID(userid)
    {
        this.m_user_id = userid;
        /*
        XSC_Server_Request.GetInstance().Poset_Server_Request(
            101,"",0,this.m_username,0,"",0,""
        )
        */

 
    }
    Post_Refresh_Paihangbang(ipaihangbang,score)
    {
        XSC_Server_Request.GetInstance().Poset_Server_Request(
            102,"",ipaihangbang,"",score,"",0,"",
            (err,response)=>
            {
                console.log("res="+response)
            }
        )
      
    }
  
    Init_UserName()
    {
        var lastuserrmae = MyLocalStorge.getItem("jsth_last_username");

        if(!lastuserrmae)
        {
            this.m_username = this.Get_Rand_User_Name();
        }else{
            this.m_username = lastuserrmae;
        }
        MyLocalStorge.setItem("jsth_last_username",this.m_username);
    }

    Get_Rand_User_Name()
    {
        var icount = 5+Math.floor(3*Math.random());

        var darr = "abcdefghijkmniopqrstuvwxyz_1234567890";

        var name_str = "";
        for(var ff=0;ff<icount;ff++)
        {
            var sd = "";
            if( ff== 0)
            {
                var irand1 = Math.floor(Math.random()*25);
                sd = darr.substr(irand1,1);
                name_str += sd;
            }else{

                var irand2 = Math.floor(Math.random()*(darr.length-1) );
                sd = darr.substr(irand2,1);
                name_str += sd;
            }

        }

        return name_str;
    }

    Get_User_ID()
    {
        return this.m_user_id;
    }

    Get_User_Name()
    {
        return this.m_username;
    }

}