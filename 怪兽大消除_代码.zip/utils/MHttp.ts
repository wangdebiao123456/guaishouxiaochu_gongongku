import { YMHttp } from "./YMHttp";

 
export class MHttp {
    static deviceId:string = ''
    /**渠道号 */
    static gamefrom:number = 0
    static addVerification:string = ''
    static isLoginOk:boolean = false

    
    static sendMessageHead(url, data,head, callfun){
    
        YMHttp.getInstance().sendMessageHead(url, data, head,(data)=>{
        
            if (callfun) callfun(JSON.parse(data))
        })
    }
}
 