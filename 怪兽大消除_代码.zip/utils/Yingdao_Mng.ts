 

export default class Yingdao_Mng
{
    public static  m_ins:Yingdao_Mng = null;

    public static GetInstance()
    {
        if(Yingdao_Mng.m_ins == null)
        {
            Yingdao_Mng.m_ins  =  new Yingdao_Mng();
        }

        return Yingdao_Mng.m_ins;
    }

 



    m_yingdao_step_info_define_config=  null;


    constructor()
    {

    }
    Set_Yingdao_Step_Info_Config(yingdao_step_info_define_config)
    {

        this.m_yingdao_step_info_define_config = yingdao_step_info_define_config;
    }
    
    Get_Main_Dt_Zhiying_Gk_Steps( cur_real_gk )
    {

         var ydsteps = this.m_yingdao_step_info_define_config["ydsteps"];
        var steplist = ydsteps["main_dt_"+cur_real_gk];

        return steplist;
    }
     
    Get_Luosi_Hecheng_Gk_Steps(  )
    {

         var ydsteps = this.m_yingdao_step_info_define_config["ydsteps"];
        var steplist = ydsteps["luosi_hecheng_game_5"];

        return steplist;
    }
    Get_Luosi_Paixu_Tiaozhanchang_Gk_Steps()
    {
        var ydsteps = this.m_yingdao_step_info_define_config["ydsteps"];
        var steplist = ydsteps["luosi_paixu_tiaozhan"];

        return steplist;
    }


}