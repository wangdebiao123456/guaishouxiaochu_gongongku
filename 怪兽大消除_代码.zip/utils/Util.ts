import MyLocalStorge from "../WDT/MyLocalStorge";
import WMap from "../WDT/WMap";

 
export default class Util
{
  
    static  NodeWorldPos(pnode,srcpt?){
        let parentnode=  pnode.parent;
        let worldpt = parentnode.convertToWorldSpaceAR(srcpt || pnode.getPosition());
        let newx = worldpt.x - 360;
        let newy = worldpt.y - 640;
        return  new cc.Vec2(newx,newy);
    }

    static  Get_Distance(pos1,pos2)
    {
        var xd = pos1.x - pos2.x;
        var yd = pos1.y - pos2.y;

        var dis = Math.sqrt(xd*xd+yd*yd)

        return dis;
    }
    static Rand_Digit_List(show_digit_arr)
    {
        var ilen = show_digit_arr.length;

        for(var ff=0;ff<ilen;ff++)
        {
            var ff_rand1 = Math.floor(ilen*Math.random());
            var ff_c1 = show_digit_arr[ff];
            var ff_c2 = show_digit_arr[ff_rand1];

            show_digit_arr[ff] = ff_c2;
            show_digit_arr[ff_rand1] = ff_c1;
            
        }

        return show_digit_arr;
    }
    static ISChaoGaoPing()
    {
        var winsize = cc.director.getWinSize();
        var cx = winsize.width;
        var cy=  winsize.height;

        let size1 = cc.view.getFrameSize();
        var cx2 = size1.width;
        var cy2=  size1.height;

        
        var icomss = cx/cy;
        var ireals = cx2/cy2;


        var caculate_topy = cy/2;
        if(ireals > icomss)
        {
            //宽比实际宽
            caculate_topy = cy/2;
        }
        else if(ireals < icomss)
        {
            //高比实际高

            caculate_topy = cy/2 * icomss/ireals;

        }else
        {
            caculate_topy = cy/2;
        }

       
     //   console.log("cx="+cx+",cy="+cy+",cx2="+cx2+",cy2="+cy2+",caculate_topy="+caculate_topy);
        
        if(caculate_topy >= 760)
        {
            return true;
        }

        return false;
    }


    static ShowTipTxtDlg(str,pnode,pos=null,idisplaytime = 1.2,izorder = 10){

        if(!pos)
        {
            //var caculate_topy = BaseUIUtils.Get_Cacu_Screen_Top_Y();
 

            pos = new cc.Vec2(0,500);
        }
        


        let self = this;
        let node = pnode ;
        cc.resources.load("preab/dlg/tipuidlg", function (err, prefab) {
            if (err) { return cc.error(err); }
            let ui = cc.instantiate(prefab);
            node.addChild(ui,izorder);
            Util.onLoadedTxtTipDlgOk(ui,str,pos,idisplaytime);
        });
    }

    static onLoadedTxtTipDlgOk(node,str,pos,idisplaytime){
        let txt = node.getChildByName("txt_info").getComponent(cc.Label);
        txt.string = str;
        node.setPosition(pos.x,pos.y);
        node.runAction(cc.sequence(cc.moveBy(0.2,0,-60),cc.delayTime(idisplaytime),cc.moveBy(0.2,0,60),cc.callFunc(function(){ node.destroy(); })));
    }
    static  ReadSysLocalStorgeStr(name){

        var str = MyLocalStorge.getItem(name);
        if(str)
        {
            return str;
        }
        return "";
    }
    
    static GetCurDayUnionD()
    {
        let date = new Date();
        let y = date.getFullYear();
        let m = date.getMonth() + 1;
        let d = date.getDate();

        return y*10000+m*100+d;
    }

    static GetCurDayUnion()
    {
        let date = new Date();
        let y = date.getFullYear();
        let m = date.getMonth() + 1;
        let d = date.getDate();

        return y*10000+m*100+d;
    }

  
    static Check_Read_Number(num)
    {
        if(!num)
        {
            return 0;
        }
        var imun = Number(num);
        if(isNaN(imun))
        {
            return 0;
        }



        return  imun;
    }
    
    static Format_Save_OBJ_Map( daoju_type_leftcount_map:WMap)
    {
        var save_arr = [];

        for(var ff=0;ff<daoju_type_leftcount_map.size();ff++)
        {
            var ff_t = daoju_type_leftcount_map.GetKeyByIndex(ff);
            var ff_c = daoju_type_leftcount_map.GetEntryByIndex(ff);

            save_arr.push(
                {
                    "k":ff_t,
                    "e":ff_c
                }
            )
        }

        return save_arr;
    }
    static Serize_Saved_OBJ_Map(savearr)
    {
        if(!savearr)
        {
            return new  WMap();
        }
        if(savearr.length ==0  || ! savearr.length)
        {
            return new  WMap();
        }

        var pmap=  new WMap();
        for(var ff=0;ff<savearr.length;ff++)
        {
            var ff_info  =savearr[ff];
            var ff_k = ff_info.k;
            var ff_e = ff_info.e;

            if(ff_k == undefined)
            {
                continue;
            }

            pmap.putData(ff_k,ff_e);
        }

        return pmap;
    }

    static Remove_From_Arr_Value(show_digit_arr:any[],destv)
    {
        
        for(var ff=show_digit_arr.length-1;ff >= 0;ff--)
        {
          
            var ff_c1 = show_digit_arr[ff];
          
            if(ff_c1 == destv)
            {
                show_digit_arr.splice(ff,1)
            }
            
        }
    }
}