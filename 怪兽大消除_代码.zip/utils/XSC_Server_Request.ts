 
import PlatFormType from "../PlatForm/PlatFormType";
import PlatFormMng from "../PlatForm/PlatFormMng"; 
import PlatFormParaMng from "../PlatForm/PlatFormParaMng"; 
import MyLocalStorge from "../WDT/MyLocalStorge";
import MyHttpPostInfoUtil from "../comfuncs/MyHttpPostInfoUtil";
 

export default class XSC_Server_Request
{
    static _instance:XSC_Server_Request = null;
    static GetInstance() 
    {
        if (!XSC_Server_Request._instance) {
            // doSomething
            XSC_Server_Request._instance = new XSC_Server_Request();
             
        }
        return XSC_Server_Request._instance;
    } 

    m_use_name = "";

    constructor() 
    {
    }
    newCreateGuid()
    {
        var guid = "";
        for (var i = 1; i <= 32; i++){
          var n = Math.floor(Math.random()*16.0).toString(16);
          guid +=   n;
          if((i==8)||(i==12)||(i==16)||(i==20))
            guid += "-";
        }
        return guid;    
    } 
    Get_PlatForm_Type()
    {
        return PlatFormMng.GetInstance().GetPlatFormType();
    }

    Get_Common_Saved_GUID()
    {
        var strguid = MyLocalStorge.getItem("jingshantianhua_localguid");
        if(!strguid)
        {
            var newguid=  this.newCreateGuid();
            MyLocalStorge.setItem("jingshantianhua_localguid",newguid);
            strguid = newguid;

        }  
        return strguid;
    }

    Change_Guid()
    {
        var newguid=  this.newCreateGuid();
        MyLocalStorge.setItem("jingshantianhua_localguid",newguid);

        
    }
    Get_Saved_GUID()
    {

        var strguid = PlatFormMng.GetInstance().Get_Saved_GUID();

        if(!strguid)
        {

            strguid = this.Get_Common_Saved_GUID()
        }
        
        return strguid;
         
    }

    Poset_Reg_User_Data(callback)
    {
        this.Poset_Server_Request( 1,"",1, "",  0, "", 0, "",  (bsuc,response)=>
        {
                callback(bsuc,response);
                 
        });
    }


    Get_Mail_Type_List(imailtype,callback)
    {
        this.Poset_Server_Request( 2,"",imailtype, "",  0, "", 0, "",  (bsuc,response)=>
        {
                 

                callback(bsuc,response);
        });
    }

    Lingqu_Mail_Info(imailtype,mailid,callback)
    {
        this.Poset_Server_Request( 3,"",mailid, "",  imailtype, "", 0, "",  (bsuc,response)=>
        {
                 
                callback(bsuc,response);
        });
    }

    Delete_All_Type_Mail(imailtype,callback)
    {
        this.Poset_Server_Request( 4,"",imailtype, "",  0, "", 0, "",  (bsuc,response)=>
        {
                 

                callback(bsuc,response);
        });
    }
    Lingqu_All_Type_Mail(imailtype,callback)
    {
        this.Poset_Server_Request( 5,"",imailtype, "",  0, "", 0, "",  (bsuc,response)=>
        {
              
                callback(bsuc,response);
        });
    }

    Post_Server_Call_Baxk(maintype,maintypeinfo,subtype, subtypeinfo,ivalue = 0,svalue="",ivalue2=0,svalue2="",callback = null)
    {
        XSC_Server_Request.GetInstance().Poset_Server_Request( maintype,maintypeinfo,subtype, subtypeinfo,ivalue ,svalue,ivalue2,svalue2, 
        (bsuc,response)=>
        {
            if(!bsuc)
            {
                callback(false,"网络链接失败")
                return;
            }

            var pobj = JSON.parse(response);

             
            if(!pobj)
            {
                callback(false,"数据失败")
                return;
            }
            if(!pobj.bsuc)
            {
                callback(false,pobj.failedreson)
                return;
            }

            

            callback(true,"",pobj);

        }
        );
    }
    Poset_Server_Request( maintype,maintypeinfo,subtype, subtypeinfo,ivalue = 0,svalue="",ivalue2=0,svalue2="",callback = null)
    {
     
  
        try{
            var sguid=  this.Get_Saved_GUID();
            var iplatform = this.Get_PlatForm_Type();

            var sversion = PlatFormParaMng.GetInstance().m_version_str;
  
    
            var jsons = {sguid:sguid,iplatform:iplatform,maintype:maintype,maintypeinfo:maintypeinfo,subtype:subtype,
                subtypeinfo:subtypeinfo,ivalue:ivalue,svalue:svalue, ivalue2:ivalue2,svalue2:svalue2,sversion:sversion };
    
            var postdata = JSON.stringify(jsons);


            var irand = Math.floor(Math.random()*100);
     

            // if(!cc.sys.isBrowser)
            {
                var urlp = "https://dianjitaitan.zfgame123.com/recv_huadouxiaoxiao.aspx";
                this.PostServerHTTPData(urlp,postdata,callback);
            }
          //  
        }catch(e)
        {}

  
    }

    PostServerHTTPData(urlp,postdata,callback)
    {
       //
        MyHttpPostInfoUtil.POSTData_Zhongzhuan(urlp,postdata,callback)
        
       //  HttpUtil.POSTData(urlp,postdata,callback)
    }

   
    Poset_Server_JS_Log( maintype,maintypeinfo,subtype, subtypeinfo,ivalue = 0,svalue="",ivalue2=0,svalue2="",callback = null)
    {
     
  
        try{
            var sguid=  this.Get_Saved_GUID();
            var iplatform = this.Get_PlatForm_Type();

            var sversion = PlatFormParaMng.GetInstance().m_version_str;
  
    
            var jsons = {sguid:sguid,iplatform:iplatform,maintype:maintype,maintypeinfo:maintypeinfo,subtype:subtype,
                subtypeinfo:subtypeinfo,ivalue:ivalue,svalue:svalue, ivalue2:ivalue2,svalue2:svalue2,sversion:sversion };
    
            var postdata = JSON.stringify(jsons);


            var irand = Math.floor(Math.random()*100);
            var urlp = "https://dianjitaitan.zfgame123.com/recv_huadouxiaoxiao.aspx?irand="+irand;
          
           // var urlp = "https://outercoms.zfgame123.com/zhongzhuan_guaishou_da_xiaochu.aspx?irand="+irand;

            // if(!cc.sys.isBrowser)
            {
                this.PostServerHTTPData(urlp,postdata,callback);
            }
          //  
        }catch(e)
        {}

  
    }
    Post_Server_Get_PaihangBang_Data(itype,callback)
    {
        XSC_Server_Request.GetInstance().Poset_Server_JS_Log(103, "获取排行榜数据", itype,
        "", 0, "", 0, "",   callback);
    }

    Check_Post_Request_Other_User_Info(sguid,callback)
    {
        XSC_Server_Request.GetInstance().Poset_Server_JS_Log(104, "获取其他用户昵称头像", 0,
             sguid, 0, "", 0, "",   callback);
    }
}