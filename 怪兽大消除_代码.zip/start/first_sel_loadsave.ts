import ComFunc from "../comfuncs/ComFunc";
import MyLocalStorge from "../WDT/MyLocalStorge";

 
 
 

const {ccclass, property} = cc._decorator;

@ccclass
export default class first_sel_loadsave extends cc.Component {

   
    m_cb = null;
    

    m_select_jinbi_type = 1;

    m_monster_low_hp = 0;



    
    onLoad () 
    {
        var restart = cc.find("panel/restart",this.node)
        restart.on("click",this.OnBtnRestart.bind(this));
        
        var loadprev = cc.find("panel/loadprev",this.node)
        loadprev.on("click",this.OnBtnLoadPrev.bind(this));

       
        for(var ff=1;ff<=2;ff++)
        {
            var ff_btn = cc.find("panel/sel/"+ff+"/bk",this.node)
            ff_btn.on("click",this.OnBtnLoadSelect.bind(this,ff));
    
            
        }
    
        var monster_low_hp_btn = cc.find("panel/sel/monster_low_hp/bk",this.node)
        monster_low_hp_btn.on("click",this.OnBtnMonster_Low_Hp.bind(this));

        var monster_low_hp_gou  = cc.find("panel/sel/monster_low_hp/gou",this.node)
        monster_low_hp_gou.active = false;

        this.Refresh_Info();
    }
    OnBtnMonster_Low_Hp()
    {
        var monster_low_hp_gou  = cc.find("panel/sel/monster_low_hp/gou",this.node);
        if(monster_low_hp_gou.active )
        {
            monster_low_hp_gou.active  = false;
            this.m_monster_low_hp = 0
        }else{
            monster_low_hp_gou.active  = true;
            this.m_monster_low_hp = 1;
        }
   
    }
    Refresh_Info()
    {
        for(var ff=1;ff<=2;ff++)
        {
            var ff_gou  = cc.find("panel/sel/"+ff+"/gou",this.node)
          
            if(this.m_select_jinbi_type == ff)
            {
                ff_gou.active = true;
            }else{
                ff_gou.active = false;
            }
        }
    
    }
    OnBtnLoadSelect(itype)
    {
       MyLocalStorge.setItem("first_jinbi_save_type",""+itype);

        this.m_select_jinbi_type = itype;
        this.Refresh_Info();
    }
    OnBtnRestart()
    {
        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb(1,this.m_select_jinbi_type );
        }
    }
    OnBtnLoadPrev()
    {
        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb(2,this.m_select_jinbi_type );
        }
    }
    SetInitData(paradata)
    {
        this.m_cb = paradata.cb;

        var itype = ComFunc.Check_Read_Number( MyLocalStorge.getItem("first_jinbi_save_type"));

        if(itype )
        {
            this.m_select_jinbi_type = itype;
        }

    }
}
