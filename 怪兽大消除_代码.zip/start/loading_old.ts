import PlatFormMng from "../PlatForm/PlatFormMng";
import PlatFormType from "../PlatForm/PlatFormType";
import GSXC_Game_Mng from "../Mng/GSXC_Game_Mng";
import PaoPaoLongMng from "../paopaolonggame/paopaolong/PaoPaoLongMng";
import HutuiAppInfoMng from "../PlatForm/HutuiAppInfoMng";
import ClientLogUtils from "../comfuncs/ClientLogUtils";
import GlobalGameMng from "../Mng/GlobalGameMng"; 
import BundleLoadUtils from "../comfuncs/BundleLoadUtils";
import PreLoadResMng from "../comfuncs/PreLoadResMng"; 
import PlatFormParaMng from "../PlatForm/PlatFormParaMng";
import MyLocalStorge from "../WDT/MyLocalStorge";
import ComFunc from "../comfuncs/ComFunc"; 
import GlobalConfig from "../pingpinggame/GlobalConfig";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class loading extends cc.Component
 {

 
    @property(cc.JsonAsset)
    ori_preload_json:cc.JsonAsset = null;
     

    
    @property(cc.JsonAsset)
    local_common_config: cc.JsonAsset = null;

    @property(cc.JsonAsset)
    local_tuijian_wx: cc.JsonAsset = null;



    m_b_in_progress = false;
    m_progress_start_tick = 0;
    m_prog=  null;


    m_b_first_enter_game =  false;
    

    m_b_config_loaded = false;
    m_b_loaded_game  = false;

    m_b_in_shilingtishi = false;

    m_load_start_tick = 0;

    m_preloadfile_config_inited = false;

    m_bk_loading_info_successed=  0;

    m_b_first_loaded_xc_game = 0;

    onLoad () 
    {

        this.m_b_in_progress = true;
        this.m_progress_start_tick = Date.now();
        this.m_prog=  cc.find("progress",this.node);

 

        this.m_load_start_tick = Date.now();

        var self = this;
        GSXC_Game_Mng.GetInstance().InitReadConfig(()=>
        {
            GSXC_Game_Mng.GetInstance().InitLoadTiles(()=>
            {
                self.m_b_config_loaded = true;
            })
            
        });
        


        var bfirstinit = MyLocalStorge.getItem("guaishou_daxiaochu_first_inited");

        if(bfirstinit == "finished")
        {

            this.m_b_first_loaded_xc_game = 0;
        }else{
            this.m_b_first_loaded_xc_game = 1;
        }


        if(this.m_b_first_loaded_xc_game)
        {

           // cc.director.preloadScene("huaduo_xiaoxiao");
        }

        HutuiAppInfoMng.GetInstance().Set_Default_Config(this.local_tuijian_wx.json);
        GlobalGameMng.GetInstance().Set_Default_Config(this.local_common_config.json);
       
       // this.InitEnter();
  

     

       // cc.assetManager.loadBundle("dating"); 
       // cc.assetManager.loadBundle("music"); 

      //  cc.assetManager.loadBundle("image"); 
      //  cc.assetManager.loadBundle("resources"); 
    
     // 
      cc.director.preloadScene("dating");
 
      cc.director.preloadScene("huaduo_xiaoxiao");
       GlobalGameMng.GetInstance().Start_CountDown_Add_Tili();
    //   cc.director.preloadScene("game");
     
        PreLoadResMng.GetInstance().Set_Origianl_Preload_File(this.ori_preload_json.json);
      
       

/*
        if(PlatFormMng.GetInstance().Check_Show_YonghuXieyi())
        { 
            var xieyiqianshued = cc.sys.localStorage.getItem("guaishou_aixiaochu_xieyiqianshued");
            if(xieyiqianshued == "1")
            {
                this.InitEnter();
            }else{
                var pnode = cc.instantiate(this.yonghuxieyidlg);
                this.node.addChild(pnode,30);
                var yonghuxieyi = pnode.getComponent("yonghuxieyi");
                yonghuxieyi.SetInitData(this.OnYonghuXieyiConfirm.bind(this),true);
            }
     
          
            
        }else{

            this.InitEnter();
        }
        */

 
        PaoPaoLongMng.GetInstance().InitLoadLevelInfo();
        HutuiAppInfoMng.GetInstance().LoadRemoteConfig(()=>{});

        GlobalGameMng.GetInstance().Load_Game_Common_Config(()=>{});
    
        GlobalGameMng.GetInstance().Get_Self_Reg_Day();
        GlobalGameMng.GetInstance().Get_Self_Reg_Tick();
        var strguid = PlatFormMng.GetInstance().Get_Saved_GUID();


        this.Init_All_Bundles();

        var self = this;
        PreLoadResMng.GetInstance().Load_Game_PreloadFile_Config(()=>
        {
            self.On_PreloadFile_Config_Readed();
        })

       // this.scheduleOnce(this.FD_Check_LoadFile_Toolong.bind(this),2);

        this.scheduleOnce(this.FD_Check_Must_To_Main.bind(this),2);
  

        PlatFormMng.GetInstance().Check_WX_Login_Read_OpenId(()=>{
            ClientLogUtils.GetInstance().Poset_Server_JS_Log(1, "初始页面", 1,
            "初始化load", 0, "", 0, "");
        });
     

        this.Check_WX_Update();

        var vlabel =  cc.find("v",this.node);
        vlabel.getComponent(cc.Label).string = ""+PlatFormParaMng.GetInstance().m_cur_version;

    }
    FD_Check_LoadFile_Toolong()
    { 

        if(!this.m_preloadfile_config_inited )
        { 
            
            var preloadfile_config = PreLoadResMng.GetInstance().Get_Cur_Valid_Server_PreloadFile_Config();

            var config_readed = 0;
            if(preloadfile_config)
            {
                    
                config_readed = 1;
            }


            if(config_readed)
            {
                this.On_PreloadFile_Config_Readed();

            }else{
                this.InitChangeToMain();
           
            }

            var usertick = Date.now() - this.m_load_start_tick;
            var ise_sec = Math.floor(usertick/1000);
          
            ClientLogUtils.GetInstance().Poset_Server_JS_Log(82, "配置文件读取失败",
                 this.m_bk_loading_info_successed,"成功加载:"+this.m_bk_loading_info_successed,ise_sec, "用时:"+ise_sec+"秒",
                     config_readed, "读取到配置:"+config_readed);
           
        }
    }
    On_PreloadFile_Config_Readed()
    {
        this.m_preloadfile_config_inited = true;



        var preloadfile_config = PreLoadResMng.GetInstance().Get_Cur_Valid_Server_PreloadFile_Config();

        if(!preloadfile_config)
        {
            console.log("On_PreloadFile_Config_Readed !preloadfile_config")
          
            this.InitChangeToMain();
            return;
        }


        var preload_list = preloadfile_config.preload;
        var load_list = preloadfile_config.load;

        if(!preload_list)
        {
            preload_list = [];
        }

        if(!load_list)
        {
            load_list = [];
        }


        if(preload_list.length == 0 && load_list.length == 0)
        {
            console.log("preload_list.length == 0 && load_list.length == 0");
            this.InitChangeToMain();
            return;
        }


        console.log("preload_list.length ="+preload_list.length +",load_list.length ="+load_list.length );

        var self = this;

        PreLoadResMng.GetInstance().Bk_Load_All_PreloadFile_Res_List(()=>
        {
            self.m_bk_loading_info_successed = 1;
            self.InitChangeToMain();
        
        });


        var bk_load_max_sec = preloadfile_config.bk_load_max_sec;
        if(!bk_load_max_sec)
        {
            bk_load_max_sec = 2;
        }

        this.scheduleOnce(this.FD_Check_Must_To_Main.bind(this),bk_load_max_sec);
    
       // var dd:cc.AssetManager.Bundle;
      //  dd.preload()
 
  
    }
    FD_Check_Must_To_Main()
    {
        console.log("FD_Check_Must_To_Main");
        this.InitChangeToMain();
    }
    Init_All_Bundles()
    {
        BundleLoadUtils.GetInstance().CheckLoadedBundle("image",()=>{
            console.log("加载bundle image 成功")

        });
        BundleLoadUtils.GetInstance().CheckLoadedBundle("music",()=>{
            console.log("加载bundle music 成功")

        });
        BundleLoadUtils.GetInstance().CheckLoadedBundle("otherimage",()=>{
            console.log("加载bundle otherimage 成功")
        });
        BundleLoadUtils.GetInstance().CheckLoadedBundle("resources",()=>{
            console.log("加载bundle resources 成功")
        });
        BundleLoadUtils.GetInstance().CheckLoadedBundle("dating",()=>{
            console.log("加载bundle main 成功")
        });



    }


    InitChangeToMain()
    {
        
        console.log("InitChangeToMain");
  
        this.schedule(this.FD_Change_To_Main.bind(this), 0.5);

    }


    Check_WX_Update()
    {
        
        if(PlatFormMng.GetInstance().GetPlatFormType() != PlatFormType.PlatFormType_WX)
        {
            //return;
        }

        PlatFormMng.GetInstance().Check_Update();


        
    }

    OnShilingtishiEnd()
    {
        
        this.m_b_in_shilingtishi = false;
    }


    OnBtnShilingTishi()
    {
        /*
        var ptishi = cc.instantiate(this.shilingtishidlg);
        var shilingtishidlg = ptishi.getComponent("shilingtishidlg");
        shilingtishidlg.SetCallback(this);
        this.node.addChild(ptishi,10);

        this.m_b_in_shilingtishi = true;
        */
    }
    OnYonghuXieyiConfirm()
    {
         cc.sys.localStorage.setItem("guaishou_aixiaochu_xieyiqianshued","1");
        
        this.InitEnter();
    }
    InitEnter()
    {

  
        //this.schedule(this.FD_Change_To_Main.bind(this),2);

    }
    FD_Change_To_Game()
    {
       
    }
    FD_Change_To_Main()
    {
        if(this.m_b_loaded_game)
        {
            return;
        }
       

      

        this.m_b_loaded_game = true;

        var config_first_game_enter_game = GlobalGameMng.GetInstance().Get_Default_First_Enter_Game_Mode();


        if(this.m_b_first_loaded_xc_game)
        {
            if(config_first_game_enter_game == 0)
            {
                cc.director.loadScene("dating");
            }else if(config_first_game_enter_game == 2){
                GlobalConfig.GetIns().Set_Show_WupingType(1);
                GlobalConfig.GetIns().Enter_Game_Mode(2);
 
                cc.director.loadScene("huaduo_xiaoxiao" );
            }else{
                GlobalConfig.GetIns().Set_Show_WupingType(2);
                GlobalConfig.GetIns().Enter_Game_Mode(4);
                cc.director.loadScene("huaduo_xiaoxiao" );
            }
          

            MyLocalStorge.setItem("guaishou_daxiaochu_first_inited","finished");
        }else{
            cc.director.loadScene("dating");

        }
    
        var usertick = Date.now() - this.m_load_start_tick;
        var ise_sec = Math.floor(usertick/1000);
        var preloadfile_config = PreLoadResMng.GetInstance().Get_Cur_Valid_Server_PreloadFile_Config();

        var config_readed = 0;
        if(preloadfile_config)
        {
            config_readed = 1;
        }

        ClientLogUtils.GetInstance().Poset_Server_JS_Log(81, "加载进入大厅",
        this.m_bk_loading_info_successed,"成功加载:"+this.m_bk_loading_info_successed,ise_sec, "用时:"+ise_sec+"秒",
            config_readed, "读取到配置:"+config_readed);
 
    }

    update(){
 
      

        var self = this;
        

        if(this.m_b_in_progress){
            var ieplasetick = Date.now() - this.m_progress_start_tick ;
            var iprogress = Math.min(ieplasetick/30000,1);
            if(ieplasetick > 10000)
            {
                 //this.m_progress_start_tick =  Date.now();
            }

            if(iprogress >= 0.95)
            {
                iprogress = 0.95;
            }
            this.m_prog.getComponent(cc.ProgressBar).progress  = iprogress;


            var prob_c = Math.floor(iprogress*100);

            var prolb = cc.find("prolb",this.node);
            prolb.getComponent(cc.Label).string = "正在加载资源("+prob_c+"%)..";

        }
    }
    




}
