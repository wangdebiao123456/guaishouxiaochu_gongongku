import ClientLogUtils from "../comfuncs/ClientLogUtils";
import LeoGameInfoMng from "../comfuncs/LeoGameInfoMng";
import PreLoadResMng from "../comfuncs/PreLoadResMng";
import GlobalGameMng from "../Mng/GlobalGameMng";
import GSXC_Game_Mng from "../Mng/GSXC_Game_Mng";
import PaoPaoLongMng from "../paopaolonggame/paopaolong/PaoPaoLongMng";
import GlobalConfig from "../pingpinggame/GlobalConfig";
import HutuiAppInfoMng from "../PlatForm/HutuiAppInfoMng";
import PlatFormMng from "../PlatForm/PlatFormMng";
import PlatFormParaMng from "../PlatForm/PlatFormParaMng";
import Yingdao_Mng from "../utils/Yingdao_Mng";
import MyLocalStorge from "../WDT/MyLocalStorge"; 

 
 

const {ccclass, property} = cc._decorator;

@ccclass
export default class loading extends cc.Component {

   
    m_b_in_progress = false;
    m_progress_start_tick = 0;
    m_prog:cc.Node =  null;
    m_b_loaded_game = false;


    m_b_yingdao = 0;

    
    @property(cc.JsonAsset)
    game_config: cc.JsonAsset = null;
  
    @property(cc.JsonAsset)
    yingdao_step_info_define_config: cc.JsonAsset = null;
  


     

    
 
 
    
    @property(cc.JsonAsset)
    local_common_config: cc.JsonAsset = null;

    @property(cc.JsonAsset)
    local_tuijian_wx: cc.JsonAsset = null;


    m_b_config_loaded = false;

    m_b_first_entered_luosi_hecheng = 0;
    
    onLoad () 
    {

        this.m_prog=  cc.find("jindu/loadingtiao",this.node);
        cc.director.preloadScene("dating");
        cc.director.preloadScene("luosi_hecheng")
        //cc.director.preloadScene("huaduo_xiaoxiao");

        var bentered_luosi_hecheng = MyLocalStorge.getItem("first_entered_luosi_hecheng");
        if(bentered_luosi_hecheng == "1")
        {
            this.m_b_first_entered_luosi_hecheng = 1;
        }
         
        var self = this;
        
        
       
        HutuiAppInfoMng.GetInstance().Set_Default_Config(this.local_tuijian_wx.json);
        GlobalGameMng.GetInstance().Set_Default_Config(this.local_common_config.json);
   

        Yingdao_Mng.GetInstance().Set_Yingdao_Step_Info_Config(this.yingdao_step_info_define_config.json)
   
        PaoPaoLongMng.GetInstance().InitLoadLevelInfo();
        HutuiAppInfoMng.GetInstance().LoadRemoteConfig(()=>{});

        GlobalGameMng.GetInstance().Load_Game_Common_Config(()=>{});
    
        GlobalGameMng.GetInstance().Get_Self_Reg_Day();
        GlobalGameMng.GetInstance().Get_Self_Reg_Tick();
        var strguid = PlatFormMng.GetInstance().Get_Saved_GUID();


        //this.InitEnter();

        PlatFormMng.GetInstance().Check_WX_Login_Read_OpenId(()=>{
            ClientLogUtils.GetInstance().Poset_Server_JS_Log(1, "初始页面", 1,
            "初始化load", 0, "", 0, "");
        });

      //  LeoGameInfoMng.GetIns().Check_Post_Read_OpenId();


        LeoGameInfoMng.GetIns().Check_WX_Load_From_Openid();
     
        this.InitEnter();

        
        GSXC_Game_Mng.GetInstance().InitReadConfig(()=>
        {
            GSXC_Game_Mng.GetInstance().InitLoadTiles(()=>
            {
                self.m_b_config_loaded = true;
            })
            
        });
        var vlabel =  cc.find("v",this.node);
        vlabel.getComponent(cc.Label).string = "版本:"+PlatFormParaMng.GetInstance().m_version_str;
    
    }
    Init_Info(iret)
    {
         
        if(iret == 1)
        {
            MyLocalStorge.removeAllItem();
        }
 
  
        this.InitEnter();
         
    }
    
    InitEnter()
    {
        GlobalConfig.GetIns().Set_Game_Config(this.game_config.json);
    
        if(GlobalConfig.GetIns().m_yingdao_finished)
        {
            this.m_b_yingdao = 0;
          //  cc.director.preloadScene("dating")
    
        }else{
            this.m_b_yingdao = 1;
            GlobalConfig.GetIns().On_Start_Yingdao_Enter();
            //cc.director.preloadScene("jsth_game")
    
        }



        this.m_b_in_progress = true;
        this.m_progress_start_tick = Date.now();
        this.scheduleOnce(this.FD_Check_LoadFile_Toolong.bind(this),1);

    }
    FD_Check_LoadFile_Toolong()
    {

        this.FD_Change_To_Main();
    }
     
    FD_Change_To_Main()
    {
        if(this.m_b_loaded_game)
        {
            return;
        }
       

     

        this.m_b_loaded_game = true; 
        cc.director.loadScene("dating")
       
        
     
        /*
        if(this.m_b_yingdao)
        {

           
            GlobalConfig.GetIns().Set_Show_WupingType(1);
            GlobalConfig.GetIns().Enter_Game_Mode(2);
            cc.director.loadScene("huaduo_xiaoxiao")
  
        }else
        {
            cc.director.loadScene("dating")
  
        }
      
        */
     
       
    }
    update(){
 
    
        var self = this;
        

        if(this.m_b_in_progress){
            var ieplasetick = Date.now() - this.m_progress_start_tick ;
            var iprogress = Math.min(ieplasetick/30000,1);
            if(ieplasetick > 10000)
            {
                 //this.m_progress_start_tick =  Date.now();
            }

            if(iprogress >= 0.95)
            {
                iprogress = 0.95;
            }
            this.m_prog.getComponent(cc.Sprite).fillRange  = iprogress;


            var prob_c = Math.floor(iprogress*100);

            var prolb = cc.find("prolb",this.node);
            prolb.getComponent(cc.Label).string = "正在加载资源"+"("+prob_c+"%)..";

 


        }
    }
}
