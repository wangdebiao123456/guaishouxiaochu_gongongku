import PlatFormType from "../PlatForm/PlatFormType"; 
import PlatFormMng from "../PlatForm/PlatFormMng"; 

export default class MyLocalStorge 
{
    static setItem( strkey, strvalue="")
    {
        var ineed_andoird_storg = PlatFormMng.GetInstance().Get_Storge_Type();

        if(ineed_andoird_storg == 2)
        { 
            var stwrpath = jsb.fileUtils.getWritablePath();
            jsb.fileUtils.writeStringToFile(strvalue, stwrpath+strkey+'.json')
        }
        else{
            cc.sys.localStorage.setItem(strkey,strvalue);
        }
    }
    static removeAllItem()
    {
        var ineed_andoird_storg = PlatFormMng.GetInstance().Get_Storge_Type();
  
        if(ineed_andoird_storg == 2)
        {
            
        }
        else{
            cc.sys.localStorage.clear();
        }
        
    }
    static  newCreateGuid()
    {
        var guid = "";
        for (var i = 1; i <= 32; i++){
          var n = Math.floor(Math.random()*16.0).toString(16);
          guid +=   n;
          if((i==8)||(i==12)||(i==16)||(i==20))
            guid += "-";
        }
        return guid;    
    } 
    static getItem( strkey, defaiultv="")
    {
        var ineed_andoird_storg = PlatFormMng.GetInstance().Get_Storge_Type();

        if(ineed_andoird_storg == 2)
        { 
            var stwrpath = jsb.fileUtils.getWritablePath(); 
            var strinfo = jsb.fileUtils.getStringFromFile(stwrpath+strkey+'.json');

            if(!strinfo)
            {
                strinfo = defaiultv;
            }

            return strinfo;
        }
        else{
            return cc.sys.localStorage.getItem(strkey,defaiultv);
        }
    }
    
    static removeItem(strkey)
    {
        var ineed_andoird_storg = PlatFormMng.GetInstance().Get_Storge_Type();
        if(ineed_andoird_storg == 2)
        {
            var stwrpath = jsb.fileUtils.getWritablePath(); 
             jsb.fileUtils.removeFile(stwrpath+strkey+'.json');

        }else{
            cc.sys.localStorage.removeItem(strkey);
        }

       
    }
 
}