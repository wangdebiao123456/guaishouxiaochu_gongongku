import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import PlatFormMng from "../PlatForm/PlatFormMng";
import WMap from "./WMap";
import GlobalGameMng from "../Mng/GlobalGameMng";
import ClientLogUtils from "../comfuncs/ClientLogUtils";
import ComFunc from "../comfuncs/ComFunc";

export default class BannerGuangaoMng 
{

    static _instance:BannerGuangaoMng = null;
    static GetInstance() 
    {
        if (!BannerGuangaoMng._instance) {
            // doSomething
            BannerGuangaoMng._instance = new BannerGuangaoMng();
             
        }
        return BannerGuangaoMng._instance;
    }
    
  
    m_b_in_wx = 1;
    m_last_guangao_show_tick = 0;
    m_cur_banner_id_index = 0;  
    m_b_banner_cur_scence_need_show = 1;

    m_gezi_guanggao_obj=  null;

    m_last_gezi_error_tick = 0;

    m_file_path_texture_map = new WMap();
    m_appid_navaiged_tick_map = new WMap();
    m_valid_tubiao_img_event_map = new WMap();

    m_readed_remote_json = null;
  
    m_last_show_quanping_gezi_chaiping_tick = 0;

    m_all_inner_game_show_icon_shaing_list = [];

    m_chaping_gg = null;
    m_b_loading_chaiping = 0;


    m_start_tick = Date.now();
    m_last_show_chaping_tick = Date.now();


    m_binited_scence_info = 0;

    m_cur_enter_scence = 0;

    m_b_has_from_1037 = 0;
    m_b_now_from_1037 = 0;


    m_b_has_from_1095 = 0;
    m_b_now_from_1095 = 0;

    constructor()
    {
       
       

    }
   
    InitFromScenceInfo()
    {
        /*
        if(this.m_binited_scence_info )
        {
            return;
        }


        this.m_b_has_from_1037  = cc.sys.localStorage.getItem("shaonaomukuai_b_has_from_1037",0);
        if(!this.m_b_has_from_1037)
        {
            this.m_b_has_from_1037 = 0;
        }


        this.m_b_has_from_1095  = cc.sys.localStorage.getItem("shaonaomukuai_b_has_from_1095",0);
        if(!this.m_b_has_from_1095)
        {
            this.m_b_has_from_1095 = 0;
        }




        this.m_binited_scence_info  = 1;

        
        var obj = wx.getLaunchOptionsSync();
        var enter_scene = obj.scene;

        
        this.m_cur_enter_scence = enter_scene;

        console.log("InitFromScenceInfo enter_scene="+enter_scene);

        if(enter_scene == 1037)
        {
            this.m_b_has_from_1037 = 1;
            this.m_b_now_from_1037 = 1;

            cc.sys.localStorage.setItem("shaonaomukuai_b_has_from_1037",1);

        }
        else if(enter_scene == 1095)
        {
            this.m_b_has_from_1095 = 1;
            this.m_b_now_from_1095 = 1;

            cc.sys.localStorage.setItem("shaonaomukuai_b_has_from_1095",1);

        }
        else{
            this.m_b_now_from_1037 = 0;
        }

        */
    }

     
 
    CheckShowChaiping(ichaipingtype = 0)
    {

        var pingbi_all_chaping = GlobalGameMng.GetInstance().IS_ChaiPing_Pingbi_All();

        if(pingbi_all_chaping)
        {
            return;
        }

        var pingbi_all_first_reg_day = GlobalGameMng.GetInstance().IS_ChaiPing_Pingbi_First_Reg_Day();

        if(pingbi_all_first_reg_day)
        {
            var curdayunion = ComFunc.GetCurDayUnion();
            var self_reg_day = GlobalGameMng.GetInstance().Get_Self_Reg_Day();

            if(self_reg_day == curdayunion)
            {
                return;
            }
        }

       
        //首先，判断type是否ok
        var bvalid_chaipingtype=  GlobalGameMng.GetInstance().IS_ChaiPing_Type_Valid(ichaipingtype);

        if(!bvalid_chaipingtype)
        {
            console.log("chaipingtype="+ichaipingtype+",无效类型，不弹出")
            return;
        }

        
        var iplatfroam_chaping_jiange_sec=  GlobalGameMng.GetInstance().Get_Chaping_Min_Jiange_Sec();
        
        //PlatFormMng.GetInstance().Get_Chaping_Min_Jiange_Sec();

        
        if(Date.now() - this.m_start_tick < iplatfroam_chaping_jiange_sec*1000)
        {
            console.log('Date.now() - this.m_start_tick < 15*1000')
            return;
        }

        if(Date.now() - this.m_last_show_chaping_tick < iplatfroam_chaping_jiange_sec*1000)
        {
            console.log('Date.now() - this.m_last_show_chaping_tick < 15*1000')
            return;
        }
        this.m_last_show_chaping_tick = Date.now();
        PlatFormMng.GetInstance().CheckShowChaiping(ichaipingtype);
         


        ClientLogUtils.GetInstance().Poset_Server_JS_Log(78, "弹出插屏", ichaipingtype,
            "插屏类型:"+ichaipingtype, 0, "", 0, "");

            
    }
        
    GetRandColor()
    {
        var irand1 = Math.floor(Math.random()*6)+1;

        if(irand1 == 1)
        {
            return cc.color(255,0,0);
        }
        if(irand1 == 2)
        {
            return cc.color(255,103,146);
        }

        if(irand1 == 3)
        {
            return cc.color(67,202,45);
        }

        if(irand1 == 4)
        {
            return cc.color(210,89,255);
        }

        if(irand1 == 5)
        {
            return cc.color(249,118,61);
        }


        if(irand1 == 6)
        {
            return cc.color(52,111,218);
        }



        return cc.color(255,103,146);
    }
    
    Check_Show_Quanping_Chaiping_Gezi(itype,isubgametype,ilevel)
    {
        /*
        console.log("Check_Show_Quanping_Chaiping_Gezi itype="+itype+",isubgametype="+isubgametype)
     
        var quanping_gezi_chaiping_config = GlobalGameMng.GetInstance().Get_Quanping_Gezi_Chaiping_Config();
        if(!quanping_gezi_chaiping_config)
        {
            return;
        }


        if(GlobalGameMng.GetInstance().In_Shenhe())
        {
            return;
        }

        var in_shenhe = quanping_gezi_chaiping_config.in_shenhe;
        if(in_shenhe)
        {
            return;
        }

        var valid_type_arr =  quanping_gezi_chaiping_config.valid_type_arr;
        if(!ComFunc.arrayShuzuContain(valid_type_arr,itype))
        {
            return;
        }

        var valid_subgametype_range =  quanping_gezi_chaiping_config.valid_subgametype_range;
        if(   valid_subgametype_range  )
        {

            var bvalidinrange = false;


            for(var gg=0;gg<valid_subgametype_range.length;gg++)
            {
                var gg_info  = valid_subgametype_range[gg];
                if(gg_info.length == 2)
                {
                    var gg_1 = gg_info[0];
                    var gg_2 = gg_info[1];
                    

                    if(gg_1 <= isubgametype && isubgametype <= gg_2 )
                    {
                        bvalidinrange = true;
                    }
                }
            }

            if(!bvalidinrange)
            {
                console.log("全屏插屏格子 !bvalidinrange")
                return;
            }
    
        }

        var  level_min = quanping_gezi_chaiping_config.level_min;

        if(level_min > ilevel && ilevel > 0)
        {
            return;
        }


       
        var subgame_level_valid = true;


        if(itype == 2)
        {
            var subgame_level_valid_config = quanping_gezi_chaiping_config.subgame_level_valid;

            for(var tt=0;tt<subgame_level_valid_config.length;tt++)
            {
                var tt_info = subgame_level_valid_config[tt];
    
                var srange = tt_info.srange;
    
                var subgame_in_range  = ComFunc.Is_In_Arr_Range_Arr(srange,isubgametype);
    
                 if(subgame_in_range )
                 {
                    var minl = tt_info.minl;
                    var jiangel = tt_info.jiangel;
    
    
                    if(ilevel < minl)
                    {
                        subgame_level_valid = false;
                    }
                    else{
    
                        if(jiangel >= 1)
                        {
                            var chajul = ilevel - minl;
    
                            if(chajul % jiangel == 0)
                            {
                                subgame_level_valid = true;
                            }else{
                                subgame_level_valid = false;
                            }
                        }
    
                    }
    
                 }
    
            }
            
          
        }else{
            var dating_level_valid_config = quanping_gezi_chaiping_config.dating_level_valid;

            for(var tt=0;tt<dating_level_valid_config.length;tt++)
            {
                var tt_info = dating_level_valid_config[tt];
    
                var srange = tt_info.srange;
    
                var subgame_in_range  = ComFunc.Is_In_Arr_Range_Arr(srange,isubgametype);
    
                 if(subgame_in_range )
                 {
                    var minl = tt_info.minl;
                    var jiangel = tt_info.jiangel;
    
    
                    if(ilevel < minl)
                    {
                        subgame_level_valid = false;
                    }
                    else{
    
                        if(jiangel >= 1)
                        {
                            var chajul = ilevel - minl;
    
                            if(chajul % jiangel == 0)
                            {
                                subgame_level_valid = true;
                            }else{
                                subgame_level_valid = false;
                            }
                        }
    
                    }
    
                 }
    
            }
        }

        
        if(!subgame_level_valid)
        {
            console.log("!subgame_level_valid level="+ilevel);
            return;
        }

        var min_sec_after_reg = quanping_gezi_chaiping_config.min_sec_after_reg;

        var after_reg_sec = GlobalGameMng.GetInstance().Get_After_Start_Reg_Sec();
        if(after_reg_sec < min_sec_after_reg)
        {
            return;
        }

        var min_jiange_sec = quanping_gezi_chaiping_config.min_jiange_sec;

        var min_sec_after_startgame = quanping_gezi_chaiping_config.min_sec_after_startgame;

        if(Date.now() - this.m_start_tick < min_sec_after_startgame*1000)
        { 
            return;
        }

        if(Date.now() - this.m_last_show_quanping_gezi_chaiping_tick < min_jiange_sec*1000)
        { 
            return;
        }

        this.m_last_show_quanping_gezi_chaiping_tick = Date.now();
        console.log("全屏插屏格子显示")
          
        MiddleGamePlatformAction.GetInstance().Check_Show_Quanping_Gezi_ChaiPing(itype);

        ClientLogUtils.GetInstance().Poset_Server_JS_Log(79, "弹出全屏格子插屏", itype,
            "类型:"+itype, isubgametype, "", ilevel, "");

 
            */
    }

 
}