import SoundManager from "../comfuncs/SoundManager";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";
import GlobalGameMng from "../Mng/GlobalGameMng";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class fanhuidating_queren extends cc.Component {
 
    // 
    m_cb = null;

    m_last_btn_click_tick = 0;
    

    m_fanhui_dating_queren_mode = 0;


    onLoad () 
    {

        var btn_cancel = cc.find("node_ui/bottom/btn_cancel",this.node);
        var btn_cancel2 = cc.find("node_ui/bottom2/btn_cancel",this.node);
      
        btn_cancel.on("click",this.OnBtnCancel.bind(this));
        btn_cancel2.on("click",this.OnBtnCancel.bind(this));


        var btn_fanhui = cc.find("node_ui/bottom/btn_fanhui",this.node);
        var btn_fanhui2 = cc.find("node_ui/bottom2/btn_fanhui",this.node);

        btn_fanhui.on("click",this.OnBtnFanhuiDating.bind(this));
        btn_fanhui2.on("click",this.OnBtnFanhuiDating.bind(this));
        



        this.m_fanhui_dating_queren_mode = GlobalGameMng.GetInstance().Get_Cur_Process_FanhuiDating_Queren_Dlg_Mode();


        
        var bottom = cc.find("node_ui/bottom",this.node);
        var bottom2 = cc.find("node_ui/bottom2",this.node);
  

        if(this.m_fanhui_dating_queren_mode == 2)
        {
            bottom.active = false;
            bottom2.active = true;

        }else{
            bottom.active = true;
            bottom2.active = false;

        }
        

        
        this.Show_All_Btns(false);

        var idealyshowsec = GlobalGameMng.GetInstance().Get_FanhuiDating_Queren_Dlg_Dealy_Show_Btn_Sec();
        
        this.scheduleOnce(this.FD_InitShow.bind(this),idealyshowsec);

        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(15,true);
   
        BannerGuangaoMng.GetInstance().CheckShowChaiping(22);
       
    }
    FD_InitShow()
    {
        this.Show_All_Btns(true);

    }
    Show_All_Btns(bshow)
    {
        var btn_cancel = cc.find("node_ui/bottom/btn_cancel",this.node);
        var btn_cancel2 = cc.find("node_ui/bottom2/btn_cancel",this.node);
      
  
        var btn_fanhui = cc.find("node_ui/bottom/btn_fanhui",this.node);
        var btn_fanhui2 = cc.find("node_ui/bottom2/btn_fanhui",this.node);
  

        btn_cancel.active = bshow;
        btn_cancel2.active = bshow;

        btn_fanhui.active = bshow;
        btn_fanhui2.active = bshow;

    }
   
    SetInitData(paradata)
    {
        this.m_cb = paradata.cb;

        MiddleGamePlatformAction.GetInstance().Set_FanhuiDating_Queren_Dlg_Gezi_Sgow(true);
        MiddleGamePlatformAction.GetInstance().Set_Game_Libao_Dlg_Gezi_Sgow(false);
    }
    Check_Btn_Enough_Tick()
    {
        if(this.m_last_btn_click_tick > 0)
        {
            if(Date.now() - this.m_last_btn_click_tick < 1000)
            {
                return false;
            }
        }
        this.m_last_btn_click_tick = Date.now();
        return true;
    }
    OnBtnCancel()
    {
        if(!this.Check_Btn_Enough_Tick())
        {
            return;
        }
        SoundManager.GetInstance().Play_Effect('com/clickbtn')
        MiddleGamePlatformAction.GetInstance().Set_FanhuiDating_Queren_Dlg_Gezi_Sgow(false);
        if(this.m_cb)
        {
            this.m_cb(0);
        }
        this.node.destroy();
    }

    OnBtnFanhuiDating()
    {
        if(!this.Check_Btn_Enough_Tick())
        {
            return;
        }
        SoundManager.GetInstance().Play_Effect('com/clickbtn')
        MiddleGamePlatformAction.GetInstance().Set_FanhuiDating_Queren_Dlg_Gezi_Sgow(false);
        if(this.m_cb)
        {
            this.m_cb(1);
        }
      //  this.node.destroy();
    }




}
