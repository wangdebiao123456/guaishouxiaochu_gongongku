import GlobalGameMng from "../Mng/GlobalGameMng";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";

 
 



const {ccclass, property} = cc._decorator;

@ccclass
export default class more_guangao_dlg extends cc.Component {

  
    m_cb = null;
    
    onLoad () 
    {
        var fanhui_btn = cc.find("panel/fanhui/btn",this.node);
        fanhui_btn.on("click",this.OnBtnExit.bind(this))
        fanhui_btn.active = false;


        var idealyshowsec = GlobalGameMng.GetInstance().Get_QuanpingGuangao_Dlg_Dealy_Show_Btn_Sec();
      

        this.scheduleOnce(this.FD_Show_Close.bind(this),idealyshowsec);
        BannerGuangaoMng.GetInstance().CheckShowChaiping(11);




    }
    OnBtnExit()
    {
        MiddleGamePlatformAction.GetInstance().Show_More_Guangao_Dlg_Banner(false);
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(30,false);


        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb();
        }
    }
    FD_Show_Close()
    {
        var fanhui_btn = cc.find("panel/fanhui/btn",this.node);
        fanhui_btn.active = true;
    }

    SetInitData(paradata)
    {
        this.m_cb = paradata.cb;

        MiddleGamePlatformAction.GetInstance().Show_More_Guangao_Dlg_Banner(true);
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(30,true);
    }
}
