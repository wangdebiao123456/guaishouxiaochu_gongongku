import fanpaiXiaoXiaoMng from "../fanpaixiaoxiaole/fanpaiXiaoXiaoMng";
import LianLianKanGameMng from "../lianliankan/LianLianKanGameMng";
import MishiTaoTouMng from "../mishitaotou/MishiTaoTouMng";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";
import XiaoMieXingxingMng from "../xiaomiexingxing/XiaoMieXingxingMng";
import YidongDongwuMng from "../yidongdongwuxiaochu/YidongDongwuMng";
import DianjiGuaishouMng from "../dianjiguaishou/DianjiGuaishouMng";
import ComCodeFuncMng from "../Mng/ComCodeFuncMng";
import ComFunc from "../comfuncs/ComFunc";
import GlobalData from "../huamukuai/GlobalData";
import HMK_GK_Mng from "../huamukuai/HMK_GK_Mng";
import PaoPaoLongMng from "../paopaolonggame/paopaolong/PaoPaoLongMng";
import FlayBirdGameMng from "../flapybirdgame/FlayBirdGameMng";
import GlobalGameMng from "../Mng/GlobalGameMng";


const {ccclass, property} = cc._decorator;

@ccclass
export default class more_wanfa extends cc.Component {

     
    //
    m_last_enter_game_btn_click_tick = 0;
    onLoad () {

        var guanbi1 = cc.find("panel1/gb",this.node);
        var guanbi2 = cc.find("panel2/gb",this.node);
        var guanbi3 = cc.find("panel3/gb",this.node);
      

        guanbi1.on("click",this.OnBtnExit.bind(this))
        guanbi2.on("click",this.OnBtnExit.bind(this))
        guanbi3.on("click",this.OnBtnExit.bind(this))
       


        var mstt1 = cc.find("panel1/mstt",this.node);
        var mstt2 = cc.find("panel2/mstt",this.node);
        var mstt3 = cc.find("panel3/mstt",this.node);
         
        
        mstt1.on("click",this.OnBtnMishiTaotou.bind(this))
        mstt2.on("click",this.OnBtnMishiTaotou.bind(this))
        mstt3.on("click",this.OnBtnMishiTaotou.bind(this))
       

        var xiaomiexingxing1 = cc.find("panel1/xiaomiexingxing",this.node);
        var xiaomiexingxing2 = cc.find("panel2/xiaomiexingxing",this.node);
        var xiaomiexingxing3 = cc.find("panel3/xiaomiexingxing",this.node);
         
        xiaomiexingxing1.on("click",this.OnBtnXiaoMieXingXing.bind(this))
        xiaomiexingxing2.on("click",this.OnBtnXiaoMieXingXing.bind(this))
        xiaomiexingxing3.on("click",this.OnBtnXiaoMieXingXing.bind(this))
     

        var guaishoulainliankan1 = cc.find("panel1/guaishoulainliankan",this.node);
        var guaishoulainliankan2 = cc.find("panel2/guaishoulainliankan",this.node);
        var guaishoulainliankan3 = cc.find("panel3/guaishoulainliankan",this.node);
        

        guaishoulainliankan1.on("click",this.OnBtnLainLianKan.bind(this))
        guaishoulainliankan2.on("click",this.OnBtnLainLianKan.bind(this))
        guaishoulainliankan3.on("click",this.OnBtnLainLianKan.bind(this))
      
        
        var guaishoutiaoyue_btn1 = cc.find("panel1/guaishoutiaoyue",this.node);
        var guaishoutiaoyue_btn2 = cc.find("panel2/guaishoutiaoyue",this.node);
        var guaishoutiaoyue_btn3 = cc.find("panel3/guaishoutiaoyue",this.node);
      
        guaishoutiaoyue_btn1.on("click",this.OnBtnFangkuaiTiaoyue.bind(this));
        guaishoutiaoyue_btn2.on("click",this.OnBtnFangkuaiTiaoyue.bind(this));
        guaishoutiaoyue_btn3.on("click",this.OnBtnFangkuaiTiaoyue.bind(this));
     
        
       var eluosifangkuai1 = cc.find("panel1/eluosifangkuai",this.node);
       var eluosifangkuai2 = cc.find("panel2/eluosifangkuai",this.node);
       var eluosifangkuai3 = cc.find("panel3/eluosifangkuai",this.node);
         
       eluosifangkuai1.on("click",this.OnBtnELuoSiFangkuai.bind(this))
       eluosifangkuai2.on("click",this.OnBtnELuoSiFangkuai.bind(this))
       eluosifangkuai3.on("click",this.OnBtnELuoSiFangkuai.bind(this))
      

       var yidongdongwu1 = cc.find("panel1/yidongdongwu",this.node);
       var yidongdongwu2 = cc.find("panel2/yidongdongwu",this.node);
       var yidongdongwu3 = cc.find("panel3/yidongdongwu",this.node);
       
       yidongdongwu1.on("click",this.OnBtnYidongGuaishouXiaochu.bind(this))
       yidongdongwu2.on("click",this.OnBtnYidongGuaishouXiaochu.bind(this))
       yidongdongwu3.on("click",this.OnBtnYidongGuaishouXiaochu.bind(this))
       




       var fanpaixiaoxiaole1 = cc.find("panel1/fanpaixiaoxiaole",this.node);
       var fanpaixiaoxiaole2 = cc.find("panel2/fanpaixiaoxiaole",this.node);
       var fanpaixiaoxiaole3 = cc.find("panel3/fanpaixiaoxiaole",this.node);
      
       fanpaixiaoxiaole1.on("click",this.OnBtnFanpaiXiaoxiaoLe.bind(this))
       fanpaixiaoxiaole2.on("click",this.OnBtnFanpaiXiaoxiaoLe.bind(this))
       fanpaixiaoxiaole3.on("click",this.OnBtnFanpaiXiaoxiaoLe.bind(this))
      
       var dianjiguaishou1 = cc.find("panel1/dianjiguaishou",this.node);
       var dianjiguaishou2 = cc.find("panel2/dianjiguaishou",this.node);
       var dianjiguaishou3 = cc.find("panel3/dianjiguaishou",this.node);
        
       dianjiguaishou1.on("click",this.OnBtnDianjiGuaishou.bind(this));
       dianjiguaishou2.on("click",this.OnBtnDianjiGuaishou.bind(this));
       dianjiguaishou3.on("click",this.OnBtnDianjiGuaishou.bind(this));
    
       var huamukuai1 = cc.find("panel1/huamukuai",this.node);
       var huamukuai2 = cc.find("panel2/huamukuai",this.node);
       var huamukuai3 = cc.find("panel3/huamukuai",this.node);
       
       huamukuai1.on("click",this.OnBtnHuaMuKuai.bind(this));
       huamukuai2.on("click",this.OnBtnHuaMuKuai.bind(this));
       huamukuai3.on("click",this.OnBtnHuaMuKuai.bind(this));
      


       
       var shuzihuarongdao1 = cc.find("panel1/shuzihuarongdao",this.node);
       var shuzihuarongdao2 = cc.find("panel2/shuzihuarongdao",this.node);
       var shuzihuarongdao3 = cc.find("panel3/shuzihuarongdao",this.node);
      
       
       
       shuzihuarongdao1.on("click",this.OnBtnShuziHuaRongDao.bind(this));
       shuzihuarongdao2.on("click",this.OnBtnShuziHuaRongDao.bind(this));
       shuzihuarongdao3.on("click",this.OnBtnShuziHuaRongDao.bind(this));
     
 
 
 
       BannerGuangaoMng.GetInstance().CheckShowChaiping(17);
         
    }

    SetDating_Show_Mode( process_gamebtn_caidan_mode)
    {
        if(process_gamebtn_caidan_mode > 3 || process_gamebtn_caidan_mode < 1)
        {
            process_gamebtn_caidan_mode = 1;
        }
        var moshi_3_show_mukuai_game = GlobalGameMng.GetInstance().IS_Dating_Mode_3_More_Wanfa_Show_Mukuai_Yuoxi();
       
        process_gamebtn_caidan_mode = 3;
        moshi_3_show_mukuai_game = 1;

        for(var ff=1;ff<=3;ff++)
        {
            var ff_ndoe = cc.find("panel"+ff,this.node);

            if(!ff_ndoe)
            {
                continue;
            }

            if(ff == process_gamebtn_caidan_mode)
            {
                ff_ndoe.active = true;
            }else{
                ff_ndoe.active = false;
            }

        }



        if(process_gamebtn_caidan_mode == 3)
        {
            //模式3，单独配置，是否显示木块两个游戏
        
            if(!moshi_3_show_mukuai_game)
            {
                var huamukuai=  cc.find("panel3/huamukuai",this.node);
                var shuzihuarongdao=  cc.find("panel3/shuzihuarongdao",this.node);
                huamukuai.active  =false;
                shuzihuarongdao.active  =false;
                
            }
       
        }
 
    }
    Hide_Dating_Gezi_Show()
    {
        MiddleGamePlatformAction.GetInstance().Hide_Dating_Gezi_Show();
      

    }
    OnBtnFlapyBirdMode()
    {
        if(!this.Check_Enter_Game_Btn_Enough_Tick())
        {
            return;
        }
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(6))
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();
        FlayBirdGameMng.GetInstance().SetFromGameStart(false);
        ComFunc.RealLoadScence("flapybirdgame",0,0);
  
    }
    OnBtnShuziHuaRongDao()
    {
        ComFunc.OpenNewDialog(this.node,"preab/shuzihuarogndao/shuzihuarongdao_sel_mode","shuzihuarongdao_sel_mode",{
            parentgame:this

        });

        
        MiddleGamePlatformAction.GetInstance().Show_Qiandao_Banners(false);
    }
    Check_Has_Tili_Enter_Subgame_And_Kouchu(isbugametype)
    {

        var bsuc = ComCodeFuncMng.Check_Has_Tili_Enter_Subgame_And_Kouchu(isbugametype,this.node)

        return bsuc;
    }
    Check_Enter_Game_Btn_Enough_Tick()
    {
        if(this.m_last_enter_game_btn_click_tick > 0)
        {
            if(Date.now() - this.m_last_enter_game_btn_click_tick < 1000)
            {
                return false;
            }
        }
        this.m_last_enter_game_btn_click_tick = Date.now();
        return true;
    }
    OnBtnYidongGuaishouXiaochu()
    {
        if(!this.Check_Enter_Game_Btn_Enough_Tick())
        {
            return;
        }
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(10))
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();

        YidongDongwuMng.GetInstance().InitFromDating();
     //   cc.director.loadScene("yidongguaishouxiaochu");

        ComFunc.RealLoadScence("yidongguaishouxiaochu",0,0);

  
    }
    OnBtnFangkuaiTiaoyue()
    {
        if(!this.Check_Enter_Game_Btn_Enough_Tick())
        {
            return;
        }
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(7))
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();
      //  cc.director.loadScene("tiaodongfangkuai");
  

        ComFunc.RealLoadScence("tiaodongfangkuai",0,0);

    }
    OnBtnExit()
    {
        this.node.destroy();
    }
    OnBtnMishiTaotou()
    {
        if(!this.Check_Enter_Game_Btn_Enough_Tick())
        {
            return;
        }
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(3))
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();
        MishiTaoTouMng.GetInstance().SetFromDatingEnetr(true);
       // cc.director.loadScene("mishitaotougame");


        
        ComFunc.RealLoadScence("mishitaotougame",0,0);
    }
    OnBtnXiaoMieXingXing()
    {
        if(!this.Check_Enter_Game_Btn_Enough_Tick())
        {
            return;
        }
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(4))
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();
        XiaoMieXingxingMng.GetInstance().InitFromDating();
        
     //   cc.director.loadScene("xiaomiexingxing");

        ComFunc.RealLoadScence("xiaomiexingxing",0,0);
    }

    OnBtnLainLianKan()
    {
        if(!this.Check_Enter_Game_Btn_Enough_Tick())
        {
            return;
        }
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(5))
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();

        LianLianKanGameMng.GetInstance().InitFromDating();
       // cc.director.loadScene("lianliankangame");

        
        ComFunc.RealLoadScence("lianliankangame",0,0);
    }
    OnBtnFanpaiXiaoxiaoLe()
    {
        if(!this.Check_Enter_Game_Btn_Enough_Tick())
        {
            return;
        }
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(11))
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();

        fanpaiXiaoXiaoMng.GetInstance().InitFromDating();
      // cc.director.loadScene("fanpaixiaoxiaole");

        
        ComFunc.RealLoadScence("fanpaixiaoxiaole",0,0);
    }
    OnBtnELuoSiFangkuai()
    {
        if(!this.Check_Enter_Game_Btn_Enough_Tick())
        {
            return;
        }
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(8))
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();

        //cc.director.loadScene("RussinFangkuai");

        ComFunc.RealLoadScence("RussinFangkuai",0,0);
    }

    OnBtnDianjiGuaishou()
    {
        if(!this.Check_Enter_Game_Btn_Enough_Tick())
        {
            return;
        }
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(12))
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();
        DianjiGuaishouMng.GetInstance().InitFromDating();

     //   cc.director.loadScene("dianjiguaishou");

        ComFunc.RealLoadScence("dianjiguaishou",0,0);
    }


    OnBtnPaopaolong()
    {
        if(!this.Check_Enter_Game_Btn_Enough_Tick())
        {
            return;
        }
        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(2))
        {
            return;
        }


        var last_gk = PaoPaoLongMng.GetInstance().Get_Max_Can_Enter_GK();

        if(!last_gk || isNaN(last_gk))
        {
            last_gk = 1;
        }
        this.Hide_Dating_Gezi_Show();
        PaoPaoLongMng.GetInstance().LoadLevelConfig(last_gk,(error,pobj)=>
        {
            if(error)
            {
                console.log("关卡配置错误");
                return;
            }
 
            if(!pobj)
            {
                console.log("关卡配置错误");
                return;
            }



            PaoPaoLongMng.GetInstance().m_last_enter_level = last_gk;
            PaoPaoLongMng.GetInstance().m_enter_level = last_gk;
            PaoPaoLongMng.GetInstance().m_enter_level_config = pobj;
 
            ComFunc.RealLoadScence("pplgame",0,0);
          
        });
 
    }

    Real_Start_Goto_Game(isubgametype,igk)
    {

        if(!this.Check_Has_Tili_Enter_Subgame_And_Kouchu(isubgametype))
        {
            return;
        }
        this.Hide_Dating_Gezi_Show();

        
        
         
        if(isubgametype  > 100 && isubgametype < 120)
        {

          //  var imode = isubgametype - 100;
           // shuziHuaRongDaoLogicMng.GetInstance().m_select_shuzihuarongdao_mode_type =  imode;
           // shuziHuaRongDaoLogicMng.GetInstance().m_select_shuzihuarongdao_gk =    igk;
    
           // cc.director.loadScene("shuzihuarongdao");

        }  
        else if(isubgametype  > 130 && isubgametype < 140)
        {

            GlobalData.GetInstance().m_select_enter_hmk_nandu = isubgametype - 130;
            GlobalData.GetInstance().m_select_enter_hmk_gk = igk;
          //  cc.director.loadScene("huamukuai");

            var scename  = "huamukuai";
    
            ComFunc.RealLoadScence(scename,0,0);
        }
    }

    OnBtn_Select_Subgame_Nandu(igametype)
    {


        var self = this;
        ComFunc.OpenNewDialog(this.node,"preab/common/com_sel_nandu","com_sel_nandu", { parentgame:this, 
            isubgametype:igametype ,
            cb:(inandu)=>
        {
           
            self.On_Select_Subgame_Nandu(igametype,inandu);
            //self.GoToLevel(isubgametype,lv);

        }});
          
        MiddleGamePlatformAction.GetInstance().Show_Qiandao_Banners(false);
    }
    On_Select_Subgame_Nandu(igametype,inandu)
    {
        var irealsubgametype = igametype;

        if(igametype == 1)
        {
            irealsubgametype = HMK_GK_Mng.GetInstance().Get_Mode_GameType(inandu);
        }


        var igk = GlobalData.GetInstance().Get_SubGametype_Max_Can_Enter_GK(irealsubgametype);
   
   
        this.Real_Start_Goto_Game(irealsubgametype,igk);
    }
    OnBtnHuaMuKuai()
    {
       
        var igk = GlobalData.GetInstance().Get_SubGametype_Max_Can_Enter_GK(131);
       if(igk >= 3)
        {
            //第三关后，点击开始选关

         //   this.OnBtn_Select_SubgAme_GK(1);

            //首先，选择难度
 
            this.OnBtn_Select_Subgame_Nandu(1);

            return;
        }
       
        this.Real_Start_Goto_Game(131,igk);
      
    }
}
