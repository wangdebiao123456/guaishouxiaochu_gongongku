
const {ccclass, property} = cc._decorator;

@ccclass
export default class comdlg extends cc.Component {

   
    m_cb = null;
    
    onLoad () 
    {
        var cancel = cc.find("node_ui/cancel",this.node);
        cancel.on("click",this.OnBtnExit.bind(this))

        

    }

   
    SetInitData(paradata)
    {
        this.m_cb = paradata.cb;

    }
    OnBtnExit()
    {
        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb();
        }
    }


}
