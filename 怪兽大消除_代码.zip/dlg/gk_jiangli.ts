import SoundManager from "../comfuncs/SoundManager";
import GSXC_Game_Mng from "../Mng/GSXC_Game_Mng";



const {ccclass, property} = cc._decorator;

@ccclass
export default class gk_jiangli extends cc.Component {

    node_ui = null;
    m_cb = null;

    // 
    onLoad () {

        this.node_ui = cc.find("node_ui",this.node);
        var btn_get = cc.find("node_ui/btn_get",this.node);
        btn_get.on("click",this.OnBtnLingqu.bind(this));
 
        this.node_ui.scale = 0.6
        this.node_ui.opacity=0
        cc.tween(this.node_ui).to(0.25, { scale: 1,opacity:255 }, { easing: 'sineOut' }).start()
    }
    SetInitData(paradata)
    {
        this.m_cb = paradata.cb;

    }
    OnBtnLingqu()
    {
        SoundManager.GetInstance().Play_Effect('com/clickbtn');

        GSXC_Game_Mng.GetInstance().itemHint+=2
        GSXC_Game_Mng.GetInstance().itemShuffle+=2
        GSXC_Game_Mng.GetInstance().itemUndo+=2
        GSXC_Game_Mng.GetInstance().Save_Game_Basic_Info();

        if(this.m_cb)
        {
            this.m_cb();
        }
        this.node.destroy();
    }
}
