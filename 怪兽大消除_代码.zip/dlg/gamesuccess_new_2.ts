

import PlatFormMng from "../PlatForm/PlatFormMng";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction"; 
import PlatFormType from "../PlatForm/PlatFormType";
import BaseUIUtils from "../comfuncs/BaseUIUtils";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";
import ClientLogUtils from "../comfuncs/ClientLogUtils"; 
import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng"; 
import ComFunc from "../comfuncs/ComFunc"; 
import MyLocalStorge from "../WDT/MyLocalStorge";


import WMap from "../WDT/WMap";
import SoundManager from "../comfuncs/SoundManager";
import GlobalGameMng from "../Mng/GlobalGameMng";
import ComCodeFuncMng from "../Mng/ComCodeFuncMng";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class gamesuccess_new_2 extends cc.Component {

   
 
    node_ui:cc.Node

    m_enter_level = 0;
    m_cb = null;

    m_isubgametype = 1;
    m_star = 0;

    m_gk_jiangli = [];

    m_b_need_shuangbei_Selected=  0;

    m_b_chongwan = false;

    m_tuijianwe_dest_info_map = new WMap();
    m_last_tuijian_change_tick_map = new WMap();

    
    m_last_click_jixuyouxi_tick = 0;

    m_click_jixu_youxi_count = 0;


    //1:default menu .2:双倍menu ,3:首先default,点击后边双倍
    m_game_success_dlg_use_default_menu_type = 0;
    m_cur_menu_type = 0;

    
    onLoad () 
    {

      


        SoundManager.GetInstance().Pause_Background_Music();

        SoundManager.GetInstance().Play_Effect('com/victory');

        this.scheduleOnce(this.FD_StopLuping.bind(this),0.3);
        
 
    
        var btn_share=  cc.find("node_ui/top/btn_share",this.node);
        var btn_next =  cc.find("node_ui/bottom/default_menu/btn_next",this.node);
        var btn_restart=  cc.find("node_ui/top/btn_restart",this.node);

        var shuangbeilqu=  cc.find("node_ui/bottom/shuangbeilqu",this.node);

        var btn_paihang=  cc.find("node_ui/top/btn_paihang",this.node);
        var btn_add_tili =  cc.find("node_ui/bottom/tili/jia",this.node);

        var shungbeilq_gouxuan_btn =  cc.find("node_ui/bottom/default_menu/shungbeilq",this.node);
        shungbeilq_gouxuan_btn.on("click",this.OnBtnShuangbeiGouxuan.bind(this))
 
        
        var prseq1 = cc.sequence(cc.scaleTo(0.6,1.1),cc.scaleTo(0.6,0.9))
        shuangbeilqu.runAction(cc.repeatForever(prseq1));
        

        btn_share.on("click",this.click_share.bind(this));
        btn_next.on("click",this.OnBtnJixuYouxi.bind(this));
        btn_restart.on("click",this.click_restart.bind(this));
        shuangbeilqu.on("click",this.click_Shuangbei.bind(this));

        btn_paihang.on("click",this.OnBtnPaihangBang.bind(this));
        btn_add_tili.on("click",this.OnBtnAddTili.bind(this));

 
        
        var putonglingqu_btn =  cc.find("node_ui/bottom/shuangbei_menu/putonglingqu",this.node);
        putonglingqu_btn.on("click",this.OnBtnPutongLingqu.bind(this));
    

        var shuangbeilqu_btn =  cc.find("node_ui/bottom/shuangbei_menu/shuangbeilqu",this.node);
        shuangbeilqu_btn.on("click",this.OnBtn_Shaungbei_Lingqu.bind(this));
    
        

        var guangquan =  cc.find("node_ui/top/guangquan",this.node);
        var pseq = cc.repeatForever(cc.rotateBy(0.1,10))
        guangquan.runAction(pseq);





        this.m_game_success_dlg_use_default_menu_type = GlobalGameMng.GetInstance().Get_Gamesuc_Dlg_Use_Default_Menu_Type();
        
        if(this.m_game_success_dlg_use_default_menu_type == 4)
        {
            if(this.m_b_need_shuangbei_Selected)
            {
                this.m_cur_menu_type = 1;
            }else{
                this.m_cur_menu_type = 2;
            }
        }
        else if(this.m_game_success_dlg_use_default_menu_type == 2)
        {
            this.m_cur_menu_type = 2;
        }else{
            this.m_cur_menu_type = 1;
        }
        
        this.Refresh_Menu();
 
        var tili_node = cc.find("node_ui/bottom/tili",this.node);
    
        if(GlobalGameMng.GetInstance().IS_All_Tili_Hide())
        {
            tili_node.active = false;
        }else{
            tili_node.active = true;
        }


        this.Show_All_Btns(false);

        var idealyshowsec = GlobalGameMng.GetInstance().Get_GameSuc_Dlg_Dealy_Show_Btn_Sec();
       
        this.scheduleOnce(this.FD_InitShow.bind(this),idealyshowsec);


        MiddleGamePlatformAction.GetInstance().Check_BK_Create_GameSuc_EndLingqu_Banners();
    
   
         BannerGuangaoMng.GetInstance().CheckShowChaiping(21);
    }
    Refresh_Menu()
    {
        var default_menu = cc.find("node_ui/bottom/default_menu",this.node);
        var shuangbei_menu = cc.find("node_ui/bottom/shuangbei_menu",this.node);

        if(this.m_cur_menu_type == 2)
        {
            shuangbei_menu.active = true;
            default_menu.active = false;

        }else{
            shuangbei_menu.active = false;
            default_menu.active = true;

        }
        
    }
    FD_InitShow()
    {
        this.Show_All_Btns(true);
    }
    Show_All_Btns(bshow)
    {

        var btn_share=  cc.find("node_ui/top/btn_share",this.node);
        var btn_next =  cc.find("node_ui/bottom/default_menu/btn_next",this.node);
        var btn_restart=  cc.find("node_ui/top/btn_restart",this.node);
        var btn_paihang=  cc.find("node_ui/top/btn_paihang",this.node);
 

        var btn_putonglingqu =  cc.find("node_ui/bottom/shuangbei_menu/putonglingqu",this.node);
        var btn_shuangbeilqu =  cc.find("node_ui/bottom/shuangbei_menu/shuangbeilqu",this.node);
 


        

        btn_share.active = bshow;
        btn_next.active = bshow;
        btn_restart.active = bshow;
        btn_paihang.active = bshow;

        btn_putonglingqu.active = bshow;
        btn_shuangbeilqu.active = bshow;
 

        var all_paihangbang_hide = GlobalGameMng.GetInstance().IS_All_Paihangbang_Hide();

        if(all_paihangbang_hide)
        {
            btn_paihang.active = false;


           
        }

        if(this.m_isubgametype >30 && this.m_isubgametype < 40)
        {
            btn_paihang.active = false;

        }
    }
    Init_Top_Tuijian_Guangao()
    {
        var othergame_node = cc.find("node_ui/bottom/othergame",this.node);


        var bshow = GlobalGameMng.GetInstance().IS_GameSuc_Dlg_Tuijianwei_Show();

        if(!bshow)
        {
            othergame_node.active = false;
            return;
        }
    
        if(PlatFormMng.GetInstance().GetPlatFormType() == PlatFormType.PlatFormType_Default)
        {
            othergame_node.active = false;
            return;
        }

        var pos1 = this.m_isubgametype + 11000 ;
        var pos2 =  this.m_isubgametype + 12000 ;


        var pos_arr = [pos1,pos2];
        ComCodeFuncMng.Init_Com_Two_Guangao(this,this.node,othergame_node,pos_arr);


    }
    OnBtnShuangbeiGouxuan()
    {
        if(this.m_b_need_shuangbei_Selected)
        {
            this.m_b_need_shuangbei_Selected = 0;
        }else{
            this.m_b_need_shuangbei_Selected= 1;
        }

        this.Set_Last_Shuangbei_Gouxuan_V(this.m_b_need_shuangbei_Selected);
        this.Refresh_Gouxuan();

              
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(16, "胜利页面勾选", this.m_b_need_shuangbei_Selected,
             GlobalGameMng.GetInstance().Get_Game_Type_Name(this.m_isubgametype), this.m_isubgametype, "",this.m_enter_level, "");
 
    }
    
    Set_Last_Shuangbei_Gouxuan_V(igouxuaned)
    {
        var obj = {
            gouxuaned:igouxuaned
        }
    
           
        var last_v = "guaishoudaxiaochu_gamesuc_dlg_"+this.m_isubgametype+"_gouxuan";
    
        var str = JSON.stringify(obj);
        MyLocalStorge.setItem(last_v,str);
    }

    Get_Last_Shuangbei_Gouxuan_V()
    {
        var last_v = "guaishoudaxiaochu_gamesuc_dlg_"+this.m_isubgametype+"_gouxuan";

        var prevstr = MyLocalStorge.getItem(last_v,"");

        if(!prevstr)
        {
            return [0,0];
        }


        var pobj = JSON.parse(prevstr);
        if(!pobj)
        {
            return [0,0];
        }

        var gouxuaned = pobj.gouxuaned;
        if(!gouxuaned)
        {
            gouxuaned = 0;
        }
        return [1,gouxuaned];
    }
    Refresh_Gouxuan()
    {
        var gou_ndoe=  cc.find("node_ui/bottom/default_menu/shungbeilq/gou",this.node);
        gou_ndoe.active =    this.m_b_need_shuangbei_Selected ? true:false;
    }

    FD_StopLuping()
    {
        MiddleGamePlatformAction.GetInstance().Stop_Luping();
    }

    Find_Type_C(gk_jiangli,itype)
    {

        for(var ff=0;ff<gk_jiangli.length;ff++)
        {
            var ff_info = gk_jiangli[ff];

            if(ff_info.t == itype)
            {
                return ff_info.c;
            }
        }

        return 0;
    }
    Refresh_Info()
    {
        
        var itili = GlobalGameMng.GetInstance().Get_Tili();
        var imaxtili = GlobalGameMng.GetInstance().Get_Max_Tili();

        var tili_c_label = cc.find("node_ui/bottom/tili/c",this.node);
        tili_c_label.getComponent(cc.Label).string = ""+itili+"/"+imaxtili;

    }
    SetInitData(paradata)
    {
        this.m_cb = paradata.cb;

        var isubgametype = paradata.isubgametype;

        this.m_isubgametype = paradata.isubgametype;

        this.m_enter_level = paradata.ilevel;
        this.m_star = paradata.star;

        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(2);
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(2,true);
 
        MiddleGamePlatformAction.GetInstance().Hide_Other_In_Game_Dlg_Gezi_Show(3);
 
       
 
        this.node_ui = cc.find("node_ui",this.node);
     
        this.node_ui.x=600
        cc.tween(this.node_ui).to(0.25,{x:0},{easing:'backOut'}).start()
  

        var levelinfo = cc.find("node_ui/top/levelinfo",this.node);
        levelinfo.getComponent(cc.Label).string = "恭喜成功过关第"+this.m_enter_level+"关";
 


        var iguoguangcount = GlobalGameMng.GetInstance().Get_GameType_GK_Guoguang_Count(isubgametype, this.m_enter_level);
        var bfistwin = true;
        if(iguoguangcount > 0)
        {
            bfistwin = false;
        }
        
        var gk_jiangli = GlobalGameMng.GetInstance().Get_Game_Gk_Winned_Jiangli(isubgametype,this.m_enter_level,bfistwin,iguoguangcount);
      
        if(paradata.gkjiangli && paradata.gkjiangli.length > 0)
        {
            //gk_jiangli = paradata.gkjiangli
        }
      
        this.m_gk_jiangli = gk_jiangli;


        

        this.Refresh_Info(); 


        var gamename_ndoe = cc.find("node_ui/top/gamename",this.node);
        gamename_ndoe.getComponent(cc.Label).string = GlobalGameMng.GetInstance().Get_Game_Type_Name(this.m_isubgametype);


        var jiangli_ndoe = cc.find("node_ui/bottom/jiangli",this.node);
        if(gk_jiangli.length == 0)
        {
            jiangli_ndoe.active = false;
        }
        else{
            jiangli_ndoe.active = true;

            var jinbi_node = cc.find("node_ui/bottom/jiangli/jinbi",this.node);

            var find_type_c1 = this.Find_Type_C(gk_jiangli,1);
            jinbi_node.getChildByName("c").getComponent(cc.Label).string = ""+find_type_c1;

            if(find_type_c1 == 0)
            {
                jinbi_node.active = false;
            }else{
                jinbi_node.active = true;
            }




            var find_type_c4 = this.Find_Type_C(gk_jiangli,4);

            var xunzhang_node = cc.find("node_ui/bottom/jiangli/xunzhang",this.node);
            xunzhang_node.getChildByName("c").getComponent(cc.Label).string = ""+find_type_c4;

            if(find_type_c4 == 0)
            {
                xunzhang_node.active = false;
            }else{
                xunzhang_node.active = true;
            } 

            if(gk_jiangli.length  == 1)
            {
                jinbi_node.x = 0;
            }

        }


        //距离上次播放视频
        var ieplase_sec_from_last_watch_video = WatchVideoAdveseMng.GetInstance().Get_Jiange_Sec_From_Last_Play_Video();

        var idefault_gouxuan = GlobalGameMng.GetInstance().Get_Gamesuc_Dlg_Default_Gouxuan();
        var inext_gouxuan_type = GlobalGameMng.GetInstance().Get_Gamesuc_Dlg_Next_Gouxuan_Type();
        var irecheck_need_gk = GlobalGameMng.GetInstance().Get_Gamesuc_Dlg_ReCheck_Gouxuan_Need_GK();
        var ifirst_gouxuan_need_min_gk = GlobalGameMng.GetInstance().Get_Gamesuc_Dlg_First_Gouxuan_Need_Min_GK();


        

        var gametype_config = GlobalGameMng.GetInstance().Get_Gamesuc_Dlg_Per_Game_Type_GouxuanBtn_Config(this.m_isubgametype);

        var config_need_min_jiange_sec_from_last_watch_video = GlobalGameMng.GetInstance().Get_Game_Suc_Dlg_Minsec_Jiange_From_Last_Watch_Video();


        if(gametype_config)
        {
            idefault_gouxuan  = gametype_config[1];
            inext_gouxuan_type  = gametype_config[2];
            irecheck_need_gk  = gametype_config[3];
            ifirst_gouxuan_need_min_gk= gametype_config[4];
        }



        var last_gouxuaned_v = this.Get_Last_Shuangbei_Gouxuan_V();


        if(!last_gouxuaned_v[0])
        {

            this.m_b_need_shuangbei_Selected = idefault_gouxuan;
        }
        else
        {
            var last_gouxuan_v = last_gouxuaned_v[1];

            if(inext_gouxuan_type == 1)
            {
                this.m_b_need_shuangbei_Selected = 1;

            }
            else if(inext_gouxuan_type == 2)
            {
                //使用上次的勾选结果
                this.m_b_need_shuangbei_Selected = last_gouxuan_v;

            }
            else if(inext_gouxuan_type == 0)
            {
                this.m_b_need_shuangbei_Selected = 0;
            }
            else if(inext_gouxuan_type == 3)
            {
                //使用上次的勾选结果，但是超过irecheck_need_gk关没有选上后，自动勾选

                if(!last_gouxuan_v)
                {
                    this.Add_gamesuc_dlg_gouxuan_Jiange_GK();

                    //间隔几个关卡
                    var qd_jiange_gk_info = this.GetLast_gamesuc_dlg_gouxuan_Jiange_GK();
                    var ijaingegk = qd_jiange_gk_info[1];
        
                    if(ijaingegk > irecheck_need_gk)
                    {
                        last_gouxuan_v = 1;
                        this.Remove_gamesuc_dlg_gouxuan_jiange_GK();
                    
                    }
                }
                

                  //使用上次的勾选结果,但是间隔几关以后就必须重新勾选上
                  this.m_b_need_shuangbei_Selected = last_gouxuan_v;

                 

            }
            else if(inext_gouxuan_type == 4)
            {
                //从mingk开始，每间隔多少关自动勾选

                if(this.m_enter_level < ifirst_gouxuan_need_min_gk)
                {
                    this.m_b_need_shuangbei_Selected = 0;
                }else if(this.m_enter_level == ifirst_gouxuan_need_min_gk)
                {
                    this.m_b_need_shuangbei_Selected = 1;
                }
                else{

                    var iaddcc = this.m_enter_level - ifirst_gouxuan_need_min_gk;

                    if(iaddcc%irecheck_need_gk == 0)
                    {
                        this.m_b_need_shuangbei_Selected = 1;
                    }else{
                        this.m_b_need_shuangbei_Selected = 0;
                    }

                }


            } 
            else if(inext_gouxuan_type == 5)
            {
                //大于mingk后，每间隔recheck次打勾
                if(this.m_enter_level < ifirst_gouxuan_need_min_gk)
                {
                    this.m_b_need_shuangbei_Selected = 0;
                }else 
                {

                    this.Add_gamesuc_dlg_gouxuan_Jiange_GK();

                    //间隔几个关卡
                    var qd_jiange_gk_info = this.GetLast_gamesuc_dlg_gouxuan_Jiange_GK();
                    var ijaingegk = qd_jiange_gk_info[1];
        
                    if(ijaingegk >= irecheck_need_gk)
                    {
                        this.m_b_need_shuangbei_Selected = 1;
                        this.Remove_gamesuc_dlg_gouxuan_jiange_GK();
                    
                    }
                    else{
                        this.m_b_need_shuangbei_Selected = 0;
                    }

                }

            }
            else{
                this.m_b_need_shuangbei_Selected = last_gouxuan_v;
            }
        }
 

        if(config_need_min_jiange_sec_from_last_watch_video > 0 )
        {
            if(config_need_min_jiange_sec_from_last_watch_video > ieplase_sec_from_last_watch_video)
            {
                this.m_b_need_shuangbei_Selected = 0;
            }
        }

        this.Set_Last_Shuangbei_Gouxuan_V(this.m_b_need_shuangbei_Selected);

        this.Refresh_Gouxuan();



        var game_success_dlg_use_default_menu_type = GlobalGameMng.GetInstance().Get_Gamesuc_Dlg_Use_Default_Menu_Type();

        if(game_success_dlg_use_default_menu_type == 4)
        {

            if(this.m_b_need_shuangbei_Selected)
            {
                this.m_cur_menu_type = 1;
            }else{
                this.m_cur_menu_type = 2;
            }
            this.Refresh_Menu();
        } 



 
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(12000+isubgametype, "玩法胜利", this.m_enter_level,
        "第"+this.m_enter_level+"关胜利", 0, "", 0, "");

        //GlobalGameMng.GetInstance().On_GameType_GK_Guoguang(this.m_isubgametype,this.m_enter_level);
    

        this.Init_Top_Tuijian_Guangao();

    }
    Add_gamesuc_dlg_gouxuan_Jiange_GK()
    {
        var pinfo = this.GetLast_gamesuc_dlg_gouxuan_Jiange_GK();
        var prevgk = pinfo[1];
        var newgk = prevgk+1;

        var obj = {
            ijiangegk:newgk
        }

        var last_v = "guaishoudaxiaochu_gamesuc_"+this.m_isubgametype+"_jiange_gk";
  
        var str = JSON.stringify(obj);
        MyLocalStorge.setItem(last_v,str);
    }

    GetLast_gamesuc_dlg_gouxuan_Jiange_GK()
    {
        var last_v = "guaishoudaxiaochu_gamesuc_"+this.m_isubgametype+"_jiange_gk";
  
        var prevstr = MyLocalStorge.getItem(last_v,"");

        if(!prevstr)
        {
            return [0,0];
        }


        var pobj = JSON.parse(prevstr);
        if(!pobj)
        {
            return [0,0];
        }

        var ijiangegk = pobj.ijiangegk;
        if(!ijiangegk)
        {
            ijiangegk = 0;
        }
        return [1,ijiangegk];
    }

    Remove_gamesuc_dlg_gouxuan_jiange_GK()
    {

        var last_v = "guaishoudaxiaochu_gamesuc_"+this.m_isubgametype+"_jiange_gk";
        MyLocalStorge.removeItem(last_v);
    }
 



    OnSelectOtherPaihangbangType()
    {
        
        var self = this;
    
        ComFunc.OpenNewDialog(this.node,"preab/dlg/select_paihang_type","select_paihang_type", 
         { 
            cb:(iseltype)=>
            {

                self.OnSelectPaihangbangType(iseltype);
                
            }});

    }
    OnBtnAddTili()
    {
        SoundManager.GetInstance().Play_Effect('com/clickbtn')
      
        var self = this;
        ComCodeFuncMng.Show_Goumai_Tili_Dlg(2,this.node,(bsuc)=>
        { 
            self.Refresh_Info();
        });
        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);
 
    }
    On_Paihangbang_Dlg_Close()
    {

    }
    OnSelectPaihangbangType(iseltype)
    {

        if(iseltype == 0)
        {
            return;
        }
        var self = this;
    
       
        ComFunc.OpenNewDialog(this.node,"preab/dlg/paihangbang","paihangbang", 
         { 
            iseltype:iseltype,
            cb:(chooseother)=>
            {

                if(chooseother > 0)
                {
                    self.OnSelectOtherPaihangbangType();
                }else{

                    self.On_Paihangbang_Dlg_Close();
                }
                 
            
            }});
    }
    OnBtnPaihangBang()
    {
        SoundManager.GetInstance().Play_Effect('com/clickbtn')
      
       this.OnSelectPaihangbangType(this.m_isubgametype);
       MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);

    }
    Linhqu_Next(ibeishu)
    {
  
      //  MiddleGamePlatformAction.GetInstance().Hide_Bottom_Banner();

    
        this.Lingquiangli(ibeishu);
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(2,false);

     
 
        this.m_cb(1,this.m_b_chongwan);

     

        this.node.destroy();
    }

    OnBtnPutongLingqu()
    {
        var self = this;

        if(!ComCodeFuncMng.Check_Has_Tili_Enter_Subgame_And_Kouchu(this.m_isubgametype,this.node,()=>
            {
                self.Refresh_Info();
            })
        )
        {
            MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);

            return;
        }

        this.Refresh_Info();
        this.click_next() ;
    }
    

    OnBtn_Shaungbei_Lingqu()
    {
        this.click_Shuangbei();
    }



    click_JixuYouxi()
    {

        SoundManager.GetInstance().Play_Effect('com/clickbtn');

        if(this.m_last_click_jixuyouxi_tick > 0)
        {
            if(Date.now() - this.m_last_click_jixuyouxi_tick < 1000)
            {
                return;
            }
        }

        this.m_last_click_jixuyouxi_tick  = Date.now();

        this.m_click_jixu_youxi_count++;


        if(this.m_b_need_shuangbei_Selected)
        {
            this.click_Shuangbei();

          
            if(this.m_click_jixu_youxi_count >= 2)
            {
                this.m_b_need_shuangbei_Selected = 0;
                this.Refresh_Gouxuan();
            }

            return;
        }


        var self = this;

        if(!ComCodeFuncMng.Check_Has_Tili_Enter_Subgame_And_Kouchu(this.m_isubgametype,this.node,()=>
            {
                self.Refresh_Info();
            })
        )
        {
            MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);

            return;
        }

        this.Refresh_Info();
        this.click_next() ;
    }
    OnBtnJixuYouxi()
    {
        this.m_b_chongwan = false;
        this.click_JixuYouxi();


        if(this.m_game_success_dlg_use_default_menu_type == 3 || this.m_game_success_dlg_use_default_menu_type == 4)
        {
            if(this.m_click_jixu_youxi_count >= 2)
            {
                this.m_cur_menu_type = 2;
            }
        }
        this.Refresh_Menu();
    }
    OnBtnChongWan()
    {
        this.m_b_chongwan = true;
        this.click_JixuYouxi();
    }
    click_next() {

        this.RealLingqu(1);
     
    //  this.Linhqu_Next(1);

        
    }
    Lingquiangli(ibeishu)
    {

        
        GlobalGameMng.GetInstance().Add_DaojuType_Count_List(this.m_gk_jiangli,ibeishu);

        //发送勋章排行数据
        //GlobalGameMng.GetInstance().Send_Server_Xunzhang_Paihangbang();

        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);

    
    }
    FD_LignquShuangbei_Success()
    {
        /*
        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);

        var ibeishu = 3;
        
        var self = this;
        ComFunc.Open_Get_Daoju_Award_Dlg(this.node, this.m_gk_jiangli, ibeishu,
        ()=>
        {
            self.Linhqu_Next(3);
        });


*/
        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);

        var ibeishu = 3;
        
        var self = this;

        self.RealLingqu(3);


        //this.Linhqu_Next(3);
    }
    RealLingqu(ibeishu)
    {
        
        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);
        this.Show_All_Btns(false);


        this.Lingquiangli(ibeishu);

        
        var icomlqu_needshow_lq_dlg = GlobalGameMng.GetInstance().Get_GameSuc_dlg_Com_Lignqu_Need_Show_GameLingqu_Dlg();

        var bshowlq = false;

        if(icomlqu_needshow_lq_dlg)
        {
            bshowlq = true;
        }else
        {
            if(ibeishu > 1)
            {
                bshowlq = true;
            }
        }

        var self = this;

        if(bshowlq)
        {
            ComFunc.OpenNewDialog(this.node,"preab/common/game_end_lingqu","game_end_lingqu", 
            {
                daojulist: this.m_gk_jiangli, 
                ibeishu:ibeishu,
                isubgametype:this.m_isubgametype,
                cb:()=>
                {
                    self.On_Real_Lingqu_End();
    
                }
    
            });
        }else{
            self.On_Real_Lingqu_End();
        }
        
    }
    On_Real_Lingqu_End()
    {
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(2,false);

        this.m_cb(1);

     

        this.node.destroy();
    }

    click_Shuangbei()
    {
        SoundManager.GetInstance().Play_Effect('com/clickbtn');

   
        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node, 
            ()=>
            {
                MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);
            },
            "游戏胜利双倍",
                (bsuc,arg,  ierrorcode,errordesc)=>
        {
            if(!bsuc)
            {

                console.log("胜利框 !bsuc ierrorcode="+ierrorcode+",errordesc="+errordesc);

                var uncheck_aotu_type =  GlobalGameMng.GetInstance().Get_Game_Suc_Dlg_Auto_Uncheck_Gouxuan_Type();

                if(uncheck_aotu_type == 1)
                {
                    self.m_b_need_shuangbei_Selected = 0;
                    self.Refresh_Gouxuan();
                }
                else if(uncheck_aotu_type == 2)
                {
                    self.m_b_need_shuangbei_Selected = 0;
                    self.m_cur_menu_type = 2;
                    self.Refresh_Gouxuan();
                    self.Refresh_Menu();
                }


                return;
            }
           // BaseUIUtils.ShowTipTxtDlg("3倍领取成功",self.node);
           
            self.On_Watch_Shuangbei_Success();

           

        }, this.m_isubgametype);


    
    }
    On_Watch_Shuangbei_Success()
    {

        var self=  this;

        self.scheduleOnce(this.FD_LignquShuangbei_Success.bind(this),0.1)

        var btn_next =  cc.find("node_ui/bottom/default_menu/btn_next",self.node);
        var btn_restart=  cc.find("node_ui/top/btn_restart",self.node);

        var shuangbeilqu=  cc.find("node_ui/bottom/shuangbeilqu",self.node);

        btn_next.getComponent(cc.Button).interactable = false;
        btn_restart.getComponent(cc.Button).interactable = false;
        shuangbeilqu.getComponent(cc.Button).interactable = false;

        ClientLogUtils.GetInstance().Poset_Server_JS_Log(20000+self.m_isubgametype, 
            "游戏双倍日志", self.m_enter_level,
        "第"+self.m_enter_level+"关", 0, "", 0, "");
    }
    On_Open_Close_FanhuiDating_Queren(bopen)
    {
        if(bopen)
        {
            MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);
    
        }
        else{

            MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(2);

        }

    }
    click_restart()
    {
        SoundManager.GetInstance().Play_Effect('com/clickbtn')
      
        var self = this;

        if(GlobalGameMng.GetInstance().IS_Game_Success_Dlg_FanhuiDating_Need_Queren())
        {

            this.On_Open_Close_FanhuiDating_Queren(1)


            ComFunc.OpenNewDialog(this.node,"preab/fanhuidating_queren","fanhuidating_queren",
            {  
                cb:(iselresult)=>
                {
                            
                    if(iselresult > 0)
                    {
                        //返回大厅
                        self.RealFanhuiDating();
                    }
                    else{

                        self.On_Open_Close_FanhuiDating_Queren(0);
                    }
                   
                    
                        
                        
                }}
            );
            
        }else{

            this.RealFanhuiDating();
        }

    }

    RealFanhuiDating()
    { 
      
        MiddleGamePlatformAction.GetInstance().Stop_Luping();
    
    //    MiddleGamePlatformAction.GetInstance().Hide_Bottom_Banner();

        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(2,false);


        this.Lingquiangli(1);

        this.node.destroy(); 

        ComFunc.RealLoadScence("dating");

    }

    Get_Game_Success_Fenxiang_Str()
    {
        var isubgamename = GlobalGameMng.GetInstance().Get_Game_Type_Name(this.m_isubgametype);

        return  "我在"+isubgamename+"玩法里，第"+this.m_enter_level+"关"+"闯关成功,真是太厉害啦，你也来试试吧";
   
      
    }
    Get_Game_Success_Title_Str()
    {
        var isubgamename = GlobalGameMng.GetInstance().Get_Game_Type_Name(this.m_isubgametype);
        return  isubgamename+"第"+this.m_enter_level+"关闯关成功啦";
 
        
    }
    click_share()
    {
        SoundManager.GetInstance().Play_Effect('com/clickbtn')
      
        var strfenxiangstr = this.Get_Game_Success_Fenxiang_Str();
        var strtile = this.Get_Game_Success_Title_Str();

        var strtyip =strfenxiangstr;// "我在怪兽消除游戏里，第"+this.m_enter_level+"关"+"闯关成功,真是太厉害啦，你也来试试吧";

       
    
        if(PlatFormMng.GetInstance().GetPlatFormType() == PlatFormType.PlatFormType_ByteDance
        
        || PlatFormMng.GetInstance().GetPlatFormType() == PlatFormType.PlatFormType_Kuaishou_Xiaoyouxi)
        {
            var self = this;
            PlatFormMng.GetInstance().Fengxiang_Youxi_Luping(strtile,strtyip,
            (bsuc,errmsg)=>
            {
                if(bsuc)
                {  
                    BaseUIUtils.ShowTipTxtDlg("分享成功",this.node);
                  //  BaseUIUtils.ShowTipTxtDlg("分享成功",self.node)
                }else{
                    BaseUIUtils.ShowTipTxtDlg(""+errmsg,this.node);
                    //BaseUIUtils.ShowTipTxtDlg("分享失败",self.node)
                }
                
            });
        }else{
           // PlatFormMng.GetInstance().Share_Msg("超好玩的消除小游戏",strtyip);
           PlatFormMng.GetInstance().Share_Msg(strtile,strtyip);

        }
    }
    click_home() {
        SoundManager.GetInstance().Play_Effect('com/clickbtn')
      
      //  MiddleGamePlatformAction.GetInstance().Hide_Bottom_Banner();

       // Core.win.open(GameConst.winPath.MenuWin, null, true)
    }
   
}


 