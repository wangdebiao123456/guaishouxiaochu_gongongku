import GSXC_Game_Mng from "../Mng/GSXC_Game_Mng";
import Tile from "../game/Tile";
 

const {ccclass, property} = cc._decorator;

@ccclass
export default class gamehelp extends cc.Component {

    node_box: cc.Node
    showTiles: any = []
    oldPos: any = []
    node_ui:cc.Node
    
    onLoad () 
    {
        var bk= cc.find("bk",this.node);
       // bk.on("click",this.OnBtnClose.bind(this));

        var btn_continue= cc.find("node_ui/btn_continue",this.node);
        btn_continue.on("click",this.OnBtnClose.bind(this));
        var btn_cancel= cc.find("node_ui/cancel",this.node);
        btn_cancel.on("click",this.OnBtnClose.bind(this));
 
        this.node_box = cc.find("node_ui/node_box",this.node);
        this.node_ui = cc.find("node_ui",this.node);
     

        
        
        this.node_ui.scale = 0.6
        this.node_ui.opacity=0
        cc.tween(this.node_ui).to(0.25, { scale: 1,opacity:255 }, { easing: 'sineOut' }).start()


        for (let i = 0; i < 30; i++) {
            let tile = GSXC_Game_Mng.GetInstance().getTile('Tile')
            tile.node.parent = this.node_box            
            tile.node.x = i % 10 * 48 - 220
            tile.node.y = -Math.floor(i / 10) * 48 + 100
            tile.node.scale = 0.55
            tile.type = Math.floor(Math.random() * 40)
            tile.node.zIndex=i
            tile.setDark(true)
        }
        for (let i = 0; i < 18; i++) {
            let tile = GSXC_Game_Mng.GetInstance().getTile('Tile')
            tile.node.parent = this.node_box
            tile.node.x = i % 9 * 48 - 220 + 24
            tile.node.y = -Math.floor(i / 9) * 48 + 100 - 24
            tile.node.scale = 0.55
            tile.node.zIndex=30+i

            if (i == 10 || i == 16 || i == 12) {
                tile.type = 0
                this.showTiles.push(tile.node)
                this.oldPos.push(tile.node.position)
            } else {
                tile.type = Math.floor(Math.random() * 40)
            }
        }

        this.playHelpAnim()

    }
    playHelpAnim() {
        this.showTiles[0].scale=0.55
        this.showTiles[1].scale=0.55
        this.showTiles[2].scale=0.55

        this.showTiles[0].position=this.oldPos[0]
        this.showTiles[1].position=this.oldPos[1]
        this.showTiles[2].position=this.oldPos[2]

        cc.tween(this.showTiles[0]).delay(0.9).to(0.5,{x:0-140,y:-162}).start()
        cc.tween(this.showTiles[1]).delay(1.3).to(0.5,{x:48-140,y:-162}).start()
        cc.tween(this.showTiles[2]).delay(1.7).to(0.5,{x:96-140,y:-162}).delay(0.1).call(()=>
        {
            cc.tween(this.showTiles[0]).to(0.2,{scale:0}).start()
            cc.tween(this.showTiles[1]).to(0.2,{scale:0}).start()
            cc.tween(this.showTiles[2]).to(0.2,{scale:0}).delay(0.8).call(()=>
            {
                this.playHelpAnim()
            }).start()
        }).start()
    }
    OnBtnClose()
    {
       
        let all=this.node_box.children
        for(const temp of all)
        {
            let tile=temp.getComponent("Tile")
            if(tile)
                tile.recycle()
        }
     


        this.node.destroy();

    }
   
    

}
