import BannerGuangaoMng from "../WDT/BannerGuangaoMng";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
 
import SoundManager from "../comfuncs/SoundManager";
import PlatFormMng from "../PlatForm/PlatFormMng";
import ClientLogUtils from "../comfuncs/ClientLogUtils";
import GlobalGameMng from "../Mng/GlobalGameMng";
import ComFunc from "../comfuncs/ComFunc";
import ComCodeFuncMng from "../Mng/ComCodeFuncMng";
import WMap from "../WDT/WMap";
import PlatFormType from "../PlatForm/PlatFormType";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class game_fail_new extends cc.Component {

     
    m_isubgametype = 0;
    m_igk = 0;

    m_cb = null;
    m_itype=  0;
    
    m_fenxiangstr = "";

    m_last_btn_click_tick = 0;

     
    m_tuijianwe_dest_info_map = new WMap();
    m_last_tuijian_change_tick_map = new WMap();


    onLoad () 
    {

 
       
        var chongwanbenguang = cc.find("node_ui/bottom/chongxintiaozhan",this.node);
        chongwanbenguang.on("click",this.OnBtnChongWanBrnGuang.bind(this));

        var fanhuidating = cc.find("node_ui/top/fanhuidating",this.node);
        fanhuidating.on("click",this.OnBtnFanhuiDating.bind(this));
        var btn_paihang=  cc.find("node_ui/top/btn_paihang",this.node);

        btn_paihang.on("click",this.OnBtnPaihangBang.bind(this));
        var btn_add_tili =  cc.find("node_ui/bottom/tili/jia",this.node);

        btn_add_tili.on("click",this.OnBtnAddTili.bind(this));



        var tili_node = cc.find("node_ui/bottom/tili",this.node);
    
        if(GlobalGameMng.GetInstance().IS_All_Tili_Hide())
        {
            tili_node.active = false;
        }else{
            tili_node.active = true;
        }
        
      //  var fenxiang = cc.find("node_ui/menu/fenxiang",this.node);
      //  fenxiang.on("click",this.OnBtnFexXiang.bind(this));


      this.Show_All_Btns(false);

      var idealyshowsec = GlobalGameMng.GetInstance().Get_GameFail_Dlg_Dealy_Show_Btn_Sec();
     
      this.scheduleOnce(this.FD_InitShow.bind(this),idealyshowsec);


      MiddleGamePlatformAction.GetInstance().Hide_Bottom_Banner()
      
        BannerGuangaoMng.GetInstance().CheckShowChaiping(27);
        MiddleGamePlatformAction.GetInstance().Stop_Luping();

       // MiddleGamePlatformAction.GetInstance().Check_Show_Bottom_Banner();
       MiddleGamePlatformAction.GetInstance().Ensure_Create_Gamefail_Continue_Next_Banner();
      

    }
    FD_InitShow()
    {
        this.Show_All_Btns(true);

    }
    Show_All_Btns(bshow)
    {
        var chongwanbenguang = cc.find("node_ui/bottom/chongxintiaozhan",this.node); 

        var fanhuidating = cc.find("node_ui/top/fanhuidating",this.node); 
        var btn_paihang=  cc.find("node_ui/top/btn_paihang",this.node);

     
        chongwanbenguang.active = bshow;
        fanhuidating.active = bshow;
        btn_paihang.active = bshow;


        var all_paihangbang_hide = GlobalGameMng.GetInstance().IS_All_Paihangbang_Hide();

        btn_paihang.active = false;

    }

    SetInitData(paradata)
    {
        this.m_cb = paradata.cb;

        var strtip = paradata.strtip;
        this.m_isubgametype = paradata.isubgametype;
        this.m_igk = paradata.igk;

        if(paradata.fenxiangstr)
        {
            this.m_fenxiangstr = paradata.fenxiangstr;

        }
        var tipnode=  cc.find("node_ui/top/tip",this.node);
        
        if(strtip)
        {
            tipnode.getComponent(cc.Label).string = strtip;
        }else{

            tipnode.getComponent(cc.Label).string = "第"+this.m_igk+"关失败";
        }


        var gamename_ndoe = cc.find("node_ui/top/gamename",this.node);
        gamename_ndoe.getComponent(cc.Label).string = GlobalGameMng.GetInstance().Get_Game_Type_Name(this.m_isubgametype);

        this.Refresh_Info();

        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(3);
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(4,true);

        MiddleGamePlatformAction.GetInstance().Hide_Other_In_Game_Dlg_Gezi_Show(4);
 
        this.Init_Top_Tuijian_Guangao();
 
    }
    Init_Top_Tuijian_Guangao()
    {
        var othergame_node = cc.find("node_ui/bottom/othergame",this.node);

        var bshow = GlobalGameMng.GetInstance().IS_GameFail_Dlg_Tuijianwei_Show();

        if(!bshow)
        {
            othergame_node.active = false;
            return;
        }
        if(PlatFormMng.GetInstance().GetPlatFormType() == PlatFormType.PlatFormType_Default)
        {
            othergame_node.active = false;
            return;
        }

        
        var pos1 = this.m_isubgametype + 31000 ;
        var pos2 =  this.m_isubgametype +32000 ;


        var pos_arr = [pos1,pos2];
        ComCodeFuncMng.Init_Com_Two_Guangao(this,this.node,othergame_node,pos_arr);


    }
    OnBtnAddTili()
    {
        SoundManager.GetInstance().Play_Effect('com/clickbtn')
      
        var self = this;
        ComCodeFuncMng.Show_Goumai_Tili_Dlg(2,this.node,(bsuc)=>
        { 
            self.Refresh_Info();
        });
        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);
 
    }
    Refresh_Info()
    {
        
        var itili = GlobalGameMng.GetInstance().Get_Tili();
        var imaxtili = GlobalGameMng.GetInstance().Get_Max_Tili();

        var tili_c_label = cc.find("node_ui/bottom/tili/c",this.node);
        tili_c_label.getComponent(cc.Label).string = ""+itili+"/"+imaxtili;

    }

    RealFanhuiDating()
    {
        MiddleGamePlatformAction.GetInstance().Hide_Bottom_Banner()
        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(4,false);

        
       PlatFormMng.GetInstance().Stop_Luping();
 
    

       
       var isubgametype = this.m_isubgametype;

       ComFunc.RealLoadScence("dating",isubgametype,2);


       ClientLogUtils.GetInstance().Poset_Server_JS_Log(14000+isubgametype, "关卡失败返回大厅", this.m_igk,
       "第"+this.m_igk+"关", 0, "", 0, "");
    }

    On_Open_Close_FanhuiDating_Queren(bopen)
    {
        if(bopen)
        {
            MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);
    
        }
        else{

            MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(3);

        }

    }
    Check_Btn_Enough_Tick()
    {
        if(this.m_last_btn_click_tick > 0)
        {
            if(Date.now() - this.m_last_btn_click_tick < 1000)
            {
                return false;
            }
        }
        this.m_last_btn_click_tick = Date.now();
        return true;
    }
    OnBtnFanhuiDating()
    {

        if(!this.Check_Btn_Enough_Tick())
        {
            return;
        }

        SoundManager.GetInstance().Play_Effect('com/clickbtn')
      
        var self = this;

        if(GlobalGameMng.GetInstance().IS_Game_Fail_Dlg_FanhuiDating_Need_Queren())
        {

            this.On_Open_Close_FanhuiDating_Queren(1)


            ComFunc.OpenNewDialog(this.node,"preab/fanhuidating_queren","fanhuidating_queren",
            {  
                cb:(iselresult)=>
                {
                            
                    if(iselresult > 0)
                    {
                        //返回大厅
                        self.RealFanhuiDating();
                    }
                    else{

                        self.On_Open_Close_FanhuiDating_Queren(0);
                    }
                   
                    
                        
                        
                }}
            );
            
        }else{

            this.RealFanhuiDating();
        }


       
    }


 

    Real_ChongwanBenGuang()
    {
        this.Refresh_Info();
        MiddleGamePlatformAction.GetInstance().Hide_Bottom_Banner()
        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(4,false);
 
       
        this.node.destroy();
        if(this.m_cb)
        {
            this.m_cb();
        } 


        var isubgametype = this.m_isubgametype;
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(15000+isubgametype, "关卡失败重玩本关", this.m_igk,
        "第"+this.m_igk+"关", 0, "", 0, "");
    }

    OnBtnChongWanBrnGuang()
    {
        
        if(!this.Check_Btn_Enough_Tick())
        {
            return;
        }
        SoundManager.GetInstance().Play_Effect('com/clickbtn');




        var self = this;

        if(!ComCodeFuncMng.Check_Has_Tili_Enter_Subgame_And_Kouchu(this.m_isubgametype,this.node,()=>
            {
                self.Refresh_Info();
            })
        )
        {
            MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);

            return;
        }


        var bshow_next_dlg = GlobalGameMng.GetInstance().Get_GameFail_Dlg_Need_Show_Continue_Next_Dlg();


        if(bshow_next_dlg)
        {
            MiddleGamePlatformAction.GetInstance().Hide_Bottom_Banner()
            MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);
          
            ComFunc.OpenNewDialog(this.node,"preab/gamefail_continue_game","gamefail_continue_game", 
            {
                isubgametype: this.m_isubgametype, 
                igk:this.m_igk,


                cb:()=>
                {
                    self.Real_ChongwanBenGuang();
    
                }
    
            });
        }else{
            this.Real_ChongwanBenGuang();
      
        }

        
    }

    OnBtnFexXiang()
    {
        SoundManager.GetInstance().Play_Effect('com/clickbtn')
      
        if(!this.m_fenxiangstr)
        {
            this.m_fenxiangstr = "看我在怪兽大消除游戏玩法里的战绩";
        }
        PlatFormMng.GetInstance().Share_Msg("游戏战绩",this.m_fenxiangstr);

    }

     
     
     
    close()
    {

        this.node.destroy();
    }

    OnBtnPaihangBang()
    {
        SoundManager.GetInstance().Play_Effect('com/clickbtn')
      
        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);

       this.OnSelectPaihangbangType(this.m_isubgametype);
    }

    On_Paihangbang_Dlg_Close()
    {

    }
    OnSelectOtherPaihangbangType()
    {
        
        var self = this;
    
        ComFunc.OpenNewDialog(this.node,"preab/dlg/select_paihang_type","select_paihang_type", 
         { 
            cb:(iseltype)=>
            {

                self.OnSelectPaihangbangType(iseltype);
                
            }});

    }
    OnSelectPaihangbangType(iseltype)
    {

        if(iseltype == 0)
        {
            return;
        }
        var self = this;
    
       
        ComFunc.OpenNewDialog(this.node,"preab/dlg/paihangbang","paihangbang", 
         { 
            iseltype:iseltype,
            cb:(chooseother)=>
            {

                if(chooseother > 0)
                {
                    self.OnSelectOtherPaihangbangType();
                }else{

                    self.On_Paihangbang_Dlg_Close();
                }
                 
            
            }});
    }



}
