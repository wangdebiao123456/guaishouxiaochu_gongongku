import SoundManager from "../comfuncs/SoundManager";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class select_paihang_type extends cc.Component {

 
    m_cb = null;
    
    onLoad () 
    {


        var cancel = cc.find("node_ui/exit",this.node);
        cancel.on("click",this.OnBtnExit.bind(this));

        var xunzhang = cc.find("node_ui/typelist/xunzhang",this.node);
        xunzhang.on("click",this.OnBtnSelGameType.bind(this,1001));

        var sxcg = cc.find("node_ui/typelist/sxcg",this.node);
        sxcg.on("click",this.OnBtnSelGameType.bind(this,1));

        var sxtz = cc.find("node_ui/typelist/sxtz",this.node);
        sxtz.on("click",this.OnBtnSelGameType.bind(this,9));


        var ppl = cc.find("node_ui/typelist/ppl",this.node);
        ppl.on("click",this.OnBtnSelGameType.bind(this,2));

        var mishitaotou = cc.find("node_ui/typelist/mishitaotou",this.node);
        mishitaotou.on("click",this.OnBtnSelGameType.bind(this,3));

        
        var fanpaixiaoxiaole = cc.find("node_ui/typelist/fanpaixiaoxiaole",this.node);
        fanpaixiaoxiaole.on("click",this.OnBtnSelGameType.bind(this,11));

        var lianliankan = cc.find("node_ui/typelist/lianliankan",this.node);
        lianliankan.on("click",this.OnBtnSelGameType.bind(this,5));

        
        var shuzixiaochu = cc.find("node_ui/typelist/shuzixiaochu",this.node);
        shuzixiaochu.on("click",this.OnBtnSelGameType.bind(this,12));

        
    
        var huamukuai = cc.find("node_ui/typelist/huamukuai",this.node);
        huamukuai.on("click",this.OnBtnSelGameType.bind(this,131));



        var shuzihuarongdao = cc.find("node_ui/typelist/shuzihuarongdao",this.node);
        shuzihuarongdao.on("click",this.OnBtnSelGameType.bind(this,103));


        
        var eluosifk = cc.find("node_ui/typelist/eluosifk",this.node);
        eluosifk.on("click",this.OnBtnSelGameType.bind(this,8));


        var guaishouyidongxiaochu = cc.find("node_ui/typelist/guaishouyidongxiaochu",this.node);
        guaishouyidongxiaochu.on("click",this.OnBtnSelGameType.bind(this,10));

        var guaishouduobi = cc.find("node_ui/typelist/guaishouduobi",this.node);
        guaishouduobi.on("click",this.OnBtnSelGameType.bind(this,6));

        var guaishoutiaoyue = cc.find("node_ui/typelist/guaishoutiaoyue",this.node);
        guaishoutiaoyue.on("click",this.OnBtnSelGameType.bind(this,7));

        var xiaomiexingxing = cc.find("node_ui/typelist/xiaomiexingxing",this.node);
        xiaomiexingxing.on("click",this.OnBtnSelGameType.bind(this,4));

        

        var huaduoxiaoxiao = cc.find("node_ui/typelist/huaduoxiaoxiao",this.node);
        huaduoxiaoxiao.on("click",this.OnBtnSelGameType.bind(this,32));

        var guaishouxiaoxiao = cc.find("node_ui/typelist/guaishouxiaoxiao",this.node);
        guaishouxiaoxiao.on("click",this.OnBtnSelGameType.bind(this,34));


        

        BannerGuangaoMng.GetInstance().CheckShowChaiping(18);
        
    }
    OnBtnExit()
    {
       
        SoundManager.GetInstance().Play_Effect('com/clickbtn')
       
        this.node.destroy();
       
        if(this.m_cb)
        {
            this.m_cb(0);
        } 

     
    }
    OnBtnSelGameType(itype)
    {
        SoundManager.GetInstance().Play_Effect('com/clickbtn')
       
        this.node.destroy();
       
        if(this.m_cb)
        {
            this.m_cb(itype);
        } 
    }

    SetInitData(paradata)
    {
        this.m_cb = paradata.cb;

    }
    
}
