import ClientLogUtils from "../comfuncs/ClientLogUtils"; 
import SoundManager from "../comfuncs/SoundManager";
import GlobalGameMng from "../Mng/GlobalGameMng";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction"; 


const {ccclass, property} = cc._decorator;

@ccclass
export default class watch_video_fail extends cc.Component 
{

    m_cb = null;
    m_i_watch_type  = 0;

    m_start_tick = 0;

    m_all_init_sec = 0;

    
    onLoad () 
    {
        var exit_btn = cc.find("node_ui/top/exit",this.node);
        
        exit_btn.on("click",this.OnBtnTuichu.bind(this));

        this.m_start_tick = Date.now();

        var tuichu_node = cc.find("node_ui/tuichu",this.node)
        tuichu_node.active = false;
      
        var cancel_btn = cc.find("node_ui/tuichu/cancel",this.node);
        cancel_btn.on("click",this.OnBtnTuichu_Cancel.bind(this));

        var queding_btn = cc.find("node_ui/tuichu/queding",this.node);
        queding_btn.on("click",this.OnBtnTuichu_Queding.bind(this));

        var lingqu_btn = cc.find("node_ui/top/lingqu",this.node);
        lingqu_btn.on("click",this.OnBtn_Lingqu.bind(this));

        MiddleGamePlatformAction.GetInstance().Set_Pause_Dlg_Gezi_Sgow(false);
        MiddleGamePlatformAction.GetInstance().Set_Game_Libao_Dlg_Gezi_Sgow(false);
  
        MiddleGamePlatformAction.GetInstance().Set_FanhuiDating_Queren_Dlg_Gezi_Sgow(false);
        MiddleGamePlatformAction.GetInstance().Show_Qiandao_Banners(false);

        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);


      
        this.schedule(this.FD_Timer.bind(this),0.5);
    }
    SetInitData(paradata)
    {
        this.m_cb =paradata.cb;
        this.m_i_watch_type = paradata.i_watch_type;

        this.m_all_init_sec = GlobalGameMng.GetInstance().Get_Watch_Video_Fail_Need_Show_Error_Lingqu_Dlg_Left_Sec(this.m_i_watch_type);


        var title2 = cc.find("node_ui/top/title2",this.node);
        title2.getComponent(cc.Label).string  ="在本页面等待"+this.m_all_init_sec+"秒后可获得视频奖励";
        

        var leftt = cc.find("node_ui/top/yuan/leftt",this.node);
        leftt.getComponent(cc.Label).string  ="剩:"+this.m_all_init_sec+"秒" ;
        

        var clock_c = cc.find("node_ui/top/clock/c",this.node);
        clock_c.getComponent(cc.Label).string  =""+this.m_all_init_sec+"" ;
        

        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(191,true);
        MiddleGamePlatformAction.GetInstance().Show_Watch_Fail_Deal_Dlg_Gezi_Show(true);



        ClientLogUtils.GetInstance().Poset_Server_JS_Log( 93 ,"进入观看视频失败",
            this.m_i_watch_type , "", this.m_all_init_sec, "",0,"");


    }

    OnBtn_Lingqu()
    {
        var ileft_c = this.Get_Left_C();

        if(ileft_c > 0)
        {
            return;
        }
 
        this.node.destroy();
        if(this.m_cb)
        {
            this.m_cb(1);
        }

        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(191,false);
        MiddleGamePlatformAction.GetInstance().Show_Watch_Fail_Deal_Dlg_Gezi_Show(false);

        SoundManager.GetInstance().Play_Effect("com/huoquwuping");

        ClientLogUtils.GetInstance().Poset_Server_JS_Log( 95 ,"视频失败领取奖励",
             this.m_i_watch_type , "", this.m_all_init_sec, "",0,"");

    }
    OnBtnTuichu_Queding()
    {
        this.node.destroy();

        var ileft_c = this.Get_Left_C();
 

        if(this.m_cb)
        {
            if(ileft_c > 0)
            {
                this.m_cb(0);

                ClientLogUtils.GetInstance().Poset_Server_JS_Log( 97 ,"视频失败中途退出",
                this.m_i_watch_type , "", ileft_c, "剩余:"+ileft_c+"秒",0,"");
            }else{
                this.m_cb(1);


                ClientLogUtils.GetInstance().Poset_Server_JS_Log( 96 ,"视频失败领取奖励",
                 this.m_i_watch_type , "", this.m_all_init_sec, "",0,"");
            }
        }
     
        
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(191,false);
        MiddleGamePlatformAction.GetInstance().Show_Watch_Fail_Deal_Dlg_Gezi_Show(false);

    }
    OnBtnTuichu_Cancel()
    {
        var tuichu_node = cc.find("node_ui/tuichu",this.node)
        tuichu_node.active = false;
    }
    OnBtnTuichu()
    {
        var tuichu_node = cc.find("node_ui/tuichu",this.node)
        tuichu_node.active = true;

    }
   

    Get_Left_C()
    {
        var ieplasetick = Date.now() - this.m_start_tick;
        var ileft_c = Math.floor(this.m_all_init_sec - ieplasetick/1000);

        if(ileft_c < 0 )
        {
            ileft_c = 0;
        }

        return ileft_c;
    }


    FD_Timer()
    {
          
        var ileft_c = this.Get_Left_C();
 


        var leftt = cc.find("node_ui/top/yuan/leftt",this.node);
        leftt.getComponent(cc.Label).string  ="剩:"+ileft_c+"秒" ;
        

        var clock_c = cc.find("node_ui/top/clock/c",this.node);
        clock_c.getComponent(cc.Label).string  =""+ileft_c+"" ;

        

        
     
        if(ileft_c <= 0)
        {
            var lock_node = cc.find("node_ui/top/lingqu/lock",this.node);
            var exit_btn = cc.find("node_ui/top/exit",this.node);
            var clock_node = cc.find("node_ui/top/clock",this.node);
            var title2 = cc.find("node_ui/top/title2",this.node);

            var yuan_node = cc.find("node_ui/top/yuan",this.node);
          
            lock_node.active = false;
            exit_btn.active = false;
            clock_node.active = false;
            yuan_node.active  =false;

            leftt.getComponent(cc.Label).string  ="点击领取" ;
            title2.getComponent(cc.Label).string  ="请点击下方领取按钮领取视频奖励" ;
            
        }
      
    }
}
