import HMK_GK_Mng from "../huamukuai/HMK_GK_Mng";
import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import BaseUIUtils from "../comfuncs/BaseUIUtils";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import GlobalGameMng from "../Mng/GlobalGameMng";
import GlobalData from "../huamukuai/GlobalData";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class com_sel_nandu extends cc.Component {

   
    m_cb = null;

    m_haumukuai_jiesuo_need_shiping = 1;
    
    onLoad () 
    {
        var exit_btn = cc.find("node_ui/exit",this.node);
        exit_btn.on("click",this.OnBtnExit.bind(this))



       
        for(var ff=1;ff<=5;ff++)
        {
            var ff_node = cc.find("node_ui/mode/"+ff,this.node);
            ff_node.on("click",this.OnBtnSelNandu.bind(this,ff));

            //var ff_xuanguang_node = cc.find("node_ui/mode/"+ff+"/xuanguang",this.node);
          //  ff_xuanguang_node.on("click",this.OnBtnXuanguang.bind(this,ff));


            var ff_cur_gk = ff_node.getChildByName("curgk");

            var isubgametype = 130+ff;
       
            var max_gk = GlobalData.GetInstance().Get_SubGametype_Max_Can_Enter_GK(isubgametype);

            ff_cur_gk.getComponent(cc.Label).string = "第"+max_gk+"关";
        }

        this.m_haumukuai_jiesuo_need_shiping = GlobalGameMng.GetInstance().Get_Huamukuai_Jiesuo_Nandu_Need_Shiping();

        this.Refresh_Jiesuo_Flags();

        
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(15,true);
   
        BannerGuangaoMng.GetInstance().CheckShowChaiping(2);
    }

    OnBtnXuanguang(inandu)
    {
        this.RealSelNandu(inandu,1);

    }

    RealSelNandu(inandu,bxuanguang = 0)
    {
        var bjiesuoed = HMK_GK_Mng.GetInstance().IS_ModeType_Jiesuoed(inandu);

        if(!this.m_haumukuai_jiesuo_need_shiping)
        {
            bjiesuoed = true;
        }
        var self=  this;
        if(!bjiesuoed)
        {
            
            WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
                this.node,       
                ()=>
                {

                },"视频解锁难度",(bsuc,arg,  ierrorcode,errordesc)=>
            {
                if(!bsuc)
                { 
                    return;
                }
                HMK_GK_Mng.GetInstance().Set_ModeType_Jiesuoed(inandu);
                BaseUIUtils.ShowTipTxtDlg("难度模式解锁成功",self.node);

                self.Refresh_Jiesuo_Flags();
            },"");


            return;
        }

        this.m_cb (inandu,bxuanguang);
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(15,false);


        if(bxuanguang)
        {
            this.node.destroy();
        }
    }


    SetInitData(paradata)
    {
        this.m_cb  = paradata.cb;
      

    }
    OnBtnExit()
    {
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(15,false);
   
        this.node.destroy();
    }

    Refresh_Jiesuo_Flags()
    {

        for(var ff=2;ff<=5;ff++)
        {
            var ff_locked_node = cc.find("node_ui/mode/"+ff+"/locked",this.node);
     
            var bjiesuoed = HMK_GK_Mng.GetInstance().IS_ModeType_Jiesuoed(ff);

            if(!this.m_haumukuai_jiesuo_need_shiping)
            {
                bjiesuoed = true;
            }

            if(bjiesuoed)
            {
                ff_locked_node.active = false;
            }else{
                ff_locked_node.active = true;
            }

        }
    }
    OnBtnSelNandu(inandu)
    {
        var bjiesuoed = HMK_GK_Mng.GetInstance().IS_ModeType_Jiesuoed(inandu);
        if(!this.m_haumukuai_jiesuo_need_shiping)
        {
            bjiesuoed = true;
        }
        
        var self=  this;
        if(!bjiesuoed)
        {

            WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
                this.node,       
                ()=>
                {

                },
                "视频解锁难度",(bsuc)=>
            {
                if(!bsuc)
                {
                    return;
                }
                HMK_GK_Mng.GetInstance().Set_ModeType_Jiesuoed(inandu);
                BaseUIUtils.ShowTipTxtDlg("难度模式解锁成功",this.node);

                self.Refresh_Jiesuo_Flags();
            },"");


            return;
        }

        this.m_cb (inandu);
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(15,false);
   

       // this.scheduleOnce(this.FD_Close.bind(this),1)
       
    }
    FD_Close()
    {
        this.node.destroy();
    }

}
