import BaseUIUtils from "../comfuncs/BaseUIUtils";
import BundleLoadUtils from "../comfuncs/BundleLoadUtils";
import ClientLogUtils from "../comfuncs/ClientLogUtils";
import ComFunc from "../comfuncs/ComFunc";
import SoundManager from "../comfuncs/SoundManager";
import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import GlobalGameMng from "../Mng/GlobalGameMng";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";

 

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class com_guoguang_success extends cc.Component {
 

  //  m_money = 0;
 //   m_xingxing = 0;
    m_callback = null;
     m_gk = 1;

    m_b_selected = 0;
 
    m_guoguang_jl = [];

    
    @property(cc.Prefab)
    choujiang_dlg: cc.Prefab = null;


    m_isubgametype  = 0;
    
    onLoad () 
    {

        var lingqubtn = cc.find("panel/menu/lingqubtn",this.node)
        lingqubtn.on("click",this.OnBtnLingqu.bind(this))
        
        var nextbtn = cc.find("panel/menu/putonglingqu",this.node)
        nextbtn.on("click",this.OnBtnNext.bind(this))
       

        var exitbtn = cc.find("panel/exitbtn",this.node)
        exitbtn.on("click",this.OnBtnNext.bind(this))
       
       // var choujiang = cc.find("panel/menu/choujiang",this.node)
      //  choujiang.on("click",this.OnBtn_ChouJiang.bind(this))
       
        
        var guangquan =  cc.find("panel/guangquan",this.node);
        var pseq = cc.repeatForever(cc.rotateBy(0.1,10))
        guangquan.runAction(pseq);


        this.schedule(this.FD_Timer.bind(this),0.3)

        SoundManager.GetInstance().Play_Effect('com/victory');

        BannerGuangaoMng.GetInstance().CheckShowChaiping(12);
     
    }
    SetInfo(pinfo)
    {
        this.m_callback = pinfo.callback;
       // this.m_xingxing = pinfo.xingxing;
       // this.m_money  = pinfo.money;

       this.m_isubgametype = pinfo.isubgametype;
         this.m_gk = pinfo.gk;
 
         this.m_guoguang_jl  = pinfo.guoguang_jl;

        

        this.Refresh_Info();
    }
    OnBtnNext()
    {
        if(this.m_b_selected)
        {
            return;
        }
        this.m_b_selected = 1;
        this.RealLingqu(1);
              
    }
    RealLingqu(ibeishu)
    {
        var awrad = this.m_guoguang_jl;
        /*
        var awrad = [

            {
                "t":1,
                "c": this.m_money
            },
            {
                "t":2,
                "c": this.m_xingxing
            }
        ]
        */


        GlobalGameMng.GetInstance().Add_DaojuType_Count_List(awrad,ibeishu)

      //  GlobalConfig.GetIns().Common_Add_Award_List(awrad,ibeishu);
    
        var self = this;
        this.node.destroy();

        if(this.m_callback)
        {
            this.m_callback(ibeishu);
        }

       



        var isubgametype = this.m_isubgametype;
        var subgamegame = GlobalGameMng.GetInstance().Get_Game_Type_Name(isubgametype);
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(11000 + isubgametype, "过关成功领取奖励", this.m_gk,
             "第"+this.m_gk+"关", ibeishu, ibeishu+"倍奖励", 0, subgamegame);

    }
    OnBtnLingqu()
    {
        if(this.m_b_selected)
        {
            return;
        }
        this.m_b_selected = 1;



        var game_Type_name = GlobalGameMng.GetInstance().Get_Game_Type_Name(this.m_isubgametype);

        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node,
            ()=>
            {
            
            },
            
            "过关双倍",(bsuc)=>
        {
            if(!bsuc)
            {
                self.m_b_selected = 0;

                BaseUIUtils.ShowTipTxtDlg("观看视频失败",self.node);
              //  self.RealLingqu(1);
                return;
            }


            self.RealLingqu(10);

        },"","",null,game_Type_name+"过关10倍奖励");
    }


    Refresh_Info()
    {
        /*
        var wuping_1_c_label = cc.find("panel/wuping/1/c",this.node);
        wuping_1_c_label.getComponent(cc.Label).string = "x"+this.m_money;


        var wuping_2_c_label = cc.find("panel/wuping/2/c",this.node);
        wuping_2_c_label.getComponent(cc.Label).string = "x"+this.m_xingxing;

        */


        for(var ff=1;ff<=2;ff++)
        {
            var wuping_ff_node = cc.find("panel/wuping/"+ff,this.node);

            if(ff > this.m_guoguang_jl.length)
            {
                wuping_ff_node.active = false;
            }else{
                wuping_ff_node.active = true;

                var ff_jl = this.m_guoguang_jl[ff-1];
                var ff_t=  ff_jl.t;
                var ff_c=  ff_jl.c;
                
                wuping_ff_node.getChildByName("c").getComponent(cc.Label).string = "x"+ff_c;
                var icon_node = wuping_ff_node.getChildByName("icon");

                var icon_sfilename = GlobalGameMng.GetInstance().Get_Aawrd_Daoju_Icon(ff_t);
                BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("resources",icon_node,icon_sfilename,{width:80,height:80})
            }
     
        }

        if(this.m_guoguang_jl.length  == 1)
        {
            var wuping_1_node = cc.find("panel/wuping/"+1,this.node);
            wuping_1_node.x = 0;
        }

        var jinbi_c_label = cc.find("panel/top/addjinbi/c",this.node);
        jinbi_c_label.getComponent(cc.Label).string = ""+GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(1)


        var xx_c_label = cc.find("panel/top/addxingxing/c",this.node);
        xx_c_label.getComponent(cc.Label).string = ""+GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(2)


        var addzuanshi_c_label = cc.find("panel/top/addzuanshi/c",this.node);
        addzuanshi_c_label.getComponent(cc.Label).string = ""+GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(5)


        
        
    }
    FD_Timer()
    {
        this.Refresh_LuckDraw_Info();
    }
    
    Refresh_LuckDraw_Info()
    {

        /*
        var left_t_label = cc.find("panel/menu/choujiang/t",this.node);

        var left_info = GlobalGameMng.GetInstance().Get_LuckDraw_Save_Data();

        

        if(left_info.cjcount >= 10)
        {
            left_t_label.getComponent(cc.Label).string = "已抽完";
            return;
        }
     
        var ineed_eplase_sec = ComFunc.Get_Choujiang_Mianfei_Need_Sec();
        
        var curday_last_luckdraw_finished_elapse_sec = GlobalGameMng.GetInstance().m_curday_last_luckdraw_finished_elapse_sec;

        if(curday_last_luckdraw_finished_elapse_sec >= ineed_eplase_sec)
        {
            left_t_label.getComponent(cc.Label).string = "可抽取";
            return;
        }


        var lefsec = Math.ceil(ineed_eplase_sec - curday_last_luckdraw_finished_elapse_sec);
        left_t_label.getComponent(cc.Label).string =  ComFunc.FormatLeftSecStr(lefsec);
      
        */
    }

    
    OnBtn_ChouJiang()
    {
 

        /*
        var self  = this;
        var pndoe = cc.instantiate(this.choujiang_dlg);
        var choujiang_dlg = pndoe.getComponent("choujiang_dlg");
        choujiang_dlg.SetInitData(
            {
                
                cb:()=>
                {
                    self.Refresh_Info();
                }
            }

        );
        this.node.addChild(pndoe,20);
        */
    }
}
