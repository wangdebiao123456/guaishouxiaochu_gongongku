import ClientLogUtils from "../comfuncs/ClientLogUtils";
import SoundManager from "../comfuncs/SoundManager";
import GlobalGameMng from "../Mng/GlobalGameMng";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class com_gamefail extends cc.Component 
{
   
    m_isubgametype = 0;
    m_igk = 0;

    m_cb = null;
    m_itype=  0;
    
    m_fenxiangstr = "";


    onLoad () 
    {

        var fanhuidating = cc.find("panel/exitbtn",this.node);
        fanhuidating.on("click",this.OnBtnFanhuiDating.bind(this));
     


        var okbtn = cc.find("panel/okbtn",this.node);
        okbtn.on("click",this.OnBtnQueding.bind(this));
     

        BannerGuangaoMng.GetInstance().CheckShowChaiping(12);
     
        
    }

    OnBtnFanhuiDating()
    {
        cc.director.loadScene("dating");

        
        SoundManager.GetInstance().Play_Click_Btn_Effect();

        var isubgametype=  this.m_isubgametype;
        var gametypename= GlobalGameMng.GetInstance().Get_Game_Type_Name(isubgametype);

        ClientLogUtils.GetInstance().Poset_Server_JS_Log(14000+isubgametype, "关卡失败返回大厅", this.m_igk,
        "第"+this.m_igk+"关", 0, "", 0, gametypename);
    }
    SetInfo(paradata)
    {
        this.m_cb = paradata.cb;

        var strtip = paradata.strtip;
        this.m_isubgametype = paradata.isubgametype;
        this.m_igk = paradata.igk;

        var tipnode=  cc.find("panel/info/stip2",this.node);
        
        if(strtip)
        {
            tipnode.getComponent(cc.Label).string = strtip;
        }else{

            tipnode.getComponent(cc.Label).string = "第"+this.m_igk+"关失败";
        }


        var gamename_ndoe = cc.find("panel/info/gamename",this.node);
        gamename_ndoe.getComponent(cc.Label).string = GlobalGameMng.GetInstance().Get_Game_Type_Name(this.m_isubgametype);



        var tiaozhanstr_ndoe = cc.find("panel/info/tiaozhanstr",this.node);
     
        tiaozhanstr_ndoe.getComponent(cc.Label).string =  "是否重新挑战?"
 
 

    }
    OnBtnQueding()
    {
        
        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb(1)
        }


        SoundManager.GetInstance().Play_Click_Btn_Effect();

        var isubgametype=  this.m_isubgametype;
        var gametypename= GlobalGameMng.GetInstance().Get_Game_Type_Name(isubgametype);

        ClientLogUtils.GetInstance().Poset_Server_JS_Log(15000+isubgametype, "关卡失败重玩本关", this.m_igk,
        "第"+this.m_igk+"关", 0, "", 0, gametypename);
    }
}
