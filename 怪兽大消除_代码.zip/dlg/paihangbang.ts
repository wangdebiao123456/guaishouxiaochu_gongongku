import BaseUIUtils from "../comfuncs/BaseUIUtils";
import ClientLogUtils from "../comfuncs/ClientLogUtils";
import SoundManager from "../comfuncs/SoundManager";
import GlobalGameMng from "../Mng/GlobalGameMng";
import PlatFormMng from "../PlatForm/PlatFormMng";
import ZhanghaoMng from "../PlatForm/ZhanghaoMng";
import WMap from "../WDT/WMap";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class paihangbang extends cc.Component {

   
    m_iseltype = 0;
    m_cb = null;

    @property(cc.Prefab)
    paihangbang_list_item:cc.Prefab = null;
  
    m_paihangbang_info_list = [];

    sv_content = null;

    m_self_score = 0;
    m_self_in_paiming = -1;

    m_all_paihangbang_node_item_list = [];
    

    m_sguid_posted_map = new WMap();
    m_b_need_refreshed = false;

    onLoad () 
    {

        
        var cancel = cc.find("node_ui/exit",this.node);
        cancel.on("click",this.OnBtnExit.bind(this));

 
        var qtpaihang = cc.find("node_ui/qtpaihang",this.node);
        qtpaihang.on("click",this.OnBtnQitaPaihang.bind(this));


 
        var fenxiang = cc.find("node_ui/fenxiang",this.node);
        fenxiang.on("click",this.OnBtnFenxiang.bind(this));



        var loading_node = cc.find("node_ui/loadingtip/loading",this.node);
       var pseq = cc.repeatForever(cc.rotateBy(0.1,30))
       loading_node.runAction(pseq);


       this.schedule(this.FD_Check_Need_Refresh.bind(this),1);

      
       
       BannerGuangaoMng.GetInstance().CheckShowChaiping(13);



       var self = this;

       wx.requirePrivacyAuthorize(
           {
                success: res => {
                    // 非标准API的方式处理用户个人信息

                    self.RequireYongyhuXinxin();
                },
                fail: () => {},
                complete:() => {}
            }
        );




       /*
        if(  !ZhanghaoMng.GetInstance().IS_User_Info_Inited())
        {
           
            ZhanghaoMng.GetInstance().Init_Get_User_Info();
        }
        */
        
    }

    RequireYongyhuXinxin()
    {
        ZhanghaoMng.GetInstance().Check_Init_Read_User_Info();

    }

    Get_PaihangBangName(iseltype)
    {
        var spaihangname = "勋章排行";
        if(iseltype < 1000)
        {
            spaihangname =  GlobalGameMng.GetInstance().Get_Game_Type_Name(this.m_iseltype) +"排行";

        }else{

        }

        return spaihangname;
    }

    
    SetInitData(paradata)
    {
        this.m_cb = paradata.cb;
        this.m_iseltype = paradata.iseltype;


        var titlename_node = cc.find("node_ui/titlename",this.node);
    

        var selfnode = cc.find("node_ui/selfnode",this.node);
        selfnode.active = false;
        
        this.sv_content = cc.find("node_ui/sc/view/content",this.node)
        
        var spaihangname =  this.Get_PaihangBangName(this.m_iseltype )
        
      
        titlename_node.getComponent(cc.Label).string = spaihangname;
        var loadingtip_node = cc.find("node_ui/loadingtip",this.node);
        loadingtip_node.active = true;


        this.Post_Get_Paihang_Data(this.m_iseltype);

    }
    On_Get_Paihangbang_Failed()
    {

        BaseUIUtils.ShowTipTxtDlg("获取排行数据失败,请稍后再试试!",this.node);
        var loading_node = cc.find("node_ui/loadingtip/loading",this.node);
        loading_node.active = false;

        var loadingtip_t = cc.find("node_ui/loadingtip/t",this.node);
        loadingtip_t.getComponent(cc.Label).string = "获取排行榜数据失败,请稍后再来";
        
    }
    Post_Get_Paihang_Data( iseltype)
    {
        var self = this;
        GlobalGameMng.GetInstance().Post_Server_Get_PaihangBang_Data(iseltype,
            (bsuc,response)=>
            {
                  
                if(!bsuc)
                {
                    self.On_Get_Paihangbang_Failed();

                    return;
                }

                self.On_PaihangBang_Info_Readed(response);
                //{"itype":1001,"icount":3,"objlist":[{"sguid":"d67e378f-00e4-2bd3-7f21-d2e079d8ea43","imaxscore":160},{"sguid":"280d9b81-136c-5840-beec-d6ba69f8cf4a","imaxscore":120},{"sguid":"738a885f-78f4-ced4-79c9-3a7c7a145277","imaxscore":60}]}
            
        });

    }
    On_PaihangBang_Info_Readed(response)
    {

        var obj =  null;
        try{
            obj = JSON.parse(response);
        }catch(e)
        {

        }

        if(!obj || obj.itype == undefined || !obj.objlist)
        {
            BaseUIUtils.ShowTipTxtDlg("获取排行数据数据错误,请稍后再试试!",this.node);
            var loading_node = cc.find("node_ui/loadingtip/loading",this.node);
            loading_node.active = false;
    
            var loadingtip_t = cc.find("node_ui/loadingtip/t",this.node);
            loadingtip_t.getComponent(cc.Label).string = "获取排行数据数据错误,请稍后再来";
            return;
        }
        
        var icount = obj.icount;
        if(icount == 0)
        {
            BaseUIUtils.ShowTipTxtDlg("该排行榜暂无数据",this.node);
            var loading_node = cc.find("node_ui/loadingtip/loading",this.node);
            loading_node.active = false;
    
            var loadingtip_t = cc.find("node_ui/loadingtip/t",this.node);
            loadingtip_t.getComponent(cc.Label).string = "该排行榜暂无数据";
            return;
        }


        var selfnode = cc.find("node_ui/selfnode",this.node);
        selfnode.active = true;
        
  
        var loadingtip_node = cc.find("node_ui/loadingtip",this.node);
        loadingtip_node.active = false;


        this.Refresh_Show_Paihang_List( obj.req_user_score, obj.objlist);

      
    }

    Get_Score_Desc(imaxscore)
    {
        if(this.m_iseltype == 1001)
        {
            return "最高勋章:"+imaxscore;
        }else if(this.m_iseltype == 8)
        {
            return "最高积分:"+imaxscore;
        }else if(this.m_iseltype == 22) 
        {
            return "最大数:"+imaxscore;
        }else if(this.m_iseltype == 9 || this.m_iseltype == 31 || this.m_iseltype == 35 || this.m_iseltype == 21)
        {
            return "挑战成功:"+imaxscore+"次";
        }else{
            return "最高过关:"+imaxscore+"关";
        }

    }

    Check_Post_Request_Other_User_Info(sguid)
    {
        if(this.m_sguid_posted_map.hasKey(sguid))
        {
            return;
        }

        this.m_sguid_posted_map.putData(sguid,1);

        var self = this;
        GlobalGameMng.GetInstance().Check_Post_Request_Other_User_Info(sguid,
            (bsuc,response)=>
            {
                if(!bsuc)
                {
                    return;
                }

                 

                var jobj = JSON.parse(response);

                if(!jobj)
                {
                    return;
                }
            
                self.On_Readed_Other_User_Basic_Info(jobj.existed,jobj.sguid,jobj.snickname,jobj.stouxiangurl);
            }
        
        )

    }

    FD_Check_Need_Refresh()
    {
        if(!this.m_b_need_refreshed)
        {
            return;
        }

        this.m_b_need_refreshed = false;
        if(!this.m_paihangbang_info_list)
        {
            return;
        }

        this.Refresh_Show_Paihang_List(this.m_self_score, this.m_paihangbang_info_list);
    }
    On_Readed_Other_User_Basic_Info( existed, sguid, snickname, stouxiangurl)
    {
        GlobalGameMng.GetInstance().On_Readed_Other_User_Basic_Info( existed, sguid, snickname, stouxiangurl)

        this.m_b_need_refreshed = true;
        //this.Refresh_Show_Paihang_List(this.m_self_score, this.m_paihangbang_info_list);
    }
    Refresh_Show_Paihang_List(self_score, objlist)
    {

        this.m_self_score = self_score;
        var selg_guid = ClientLogUtils.GetInstance().Get_Saved_GUID();

        var self_in_paiming = -1;

        this.m_paihangbang_info_list = objlist;

        for(var ff=0;ff<this.m_all_paihangbang_node_item_list.length;ff++)
        {
            var ff_node = this.m_all_paihangbang_node_item_list[ff];
            ff_node.active = false;
        }
    
        for(let i=0;i<this.m_paihangbang_info_list.length;i++){
            let periteminfo = this.m_paihangbang_info_list[i];
            var sguid = periteminfo.sguid;
            var imaxscore = periteminfo.imaxscore;
            var imingci = i+1;

            if(selg_guid == sguid)
            {
                this.m_self_score = imaxscore;
                self_in_paiming = imingci;
            }

            var p_i_node = null;
            if(i >= this.m_all_paihangbang_node_item_list.length)
            {
                let pnode= cc.instantiate(this.paihangbang_list_item);
                this.sv_content.addChild(pnode,19);
                this.m_all_paihangbang_node_item_list[i] = pnode;
                p_i_node = pnode;
            }else{
                p_i_node = this.m_all_paihangbang_node_item_list[i];
            }

         
            p_i_node.active = true;
            p_i_node.setPosition(0,-60-115*i);

            var   scoreinfo_node = cc.find("scoreinfo",p_i_node);
            scoreinfo_node.getComponent(cc.Label).string = this.Get_Score_Desc(imaxscore);

            var   top3_node = cc.find("paiming/top3",p_i_node);
            var   mingci_node = cc.find("paiming/mingci",p_i_node);
         
           
            mingci_node.getComponent(cc.Label).string = ""+imingci;

            if(imingci  <= 3)
            {
                top3_node.active = true;
                mingci_node.active = false;

                BaseUIUtils.ShowIconNodePicFilename(top3_node,"dating/paihang/"+imingci,{cx:63,cy:63})
            }else{
                top3_node.active = false;
                mingci_node.active = true;
            }


            var other_user_info = GlobalGameMng.GetInstance().Query_Other_User_Nick_Touxiang_Info(sguid);

            var bexisted = 0;
            if(other_user_info)
            {
                bexisted = other_user_info.existed;
            }


            var  name_node = cc.find("name",p_i_node);
            var  touxiang_node = cc.find("touxiang",p_i_node);
       
            if(!bexisted)
            {
                name_node.getComponent(cc.Label).string = "用户";
                BaseUIUtils.ShowIconNodePicFilename(touxiang_node,"game/default_touxiang",{cx:82,cy:82})
       
                this.Check_Post_Request_Other_User_Info(sguid);
            }
            else{
                name_node.getComponent(cc.Label).string =other_user_info.snickname;

                var stouxiangurl = other_user_info.stouxiangurl;

                if(stouxiangurl)
                {   
                    BaseUIUtils.Show_Remote_Touxiang(touxiang_node,stouxiangurl,{cx:82,cy:82});

                   
                }else{
                    BaseUIUtils.ShowIconNodePicFilename(touxiang_node,"game/default_touxiang",{cx:82,cy:82})
       
                }
              
            }
            

        }


        this.sv_content.setContentSize(this.sv_content.width,  115*objlist.length+10);


        var self_chengji = cc.find("node_ui/selfnode/chengji",this.node);
        self_chengji.getComponent(cc.Label).string = this.Get_Score_Desc(this.m_self_score);


        var self_paiming = cc.find("node_ui/selfnode/paiming",this.node);

        if(self_in_paiming > 0)
        {
            self_paiming.getComponent(cc.Label).string = "排名:第"+self_in_paiming+"名";

        }else{
            self_paiming.getComponent(cc.Label).string = "排名:>50名";

        }


        this.m_self_in_paiming= self_in_paiming;
   

        var self_nickname = cc.find("node_ui/selfnode/nickname",this.node);

        var snicnname = ZhanghaoMng.GetInstance().Get_Self_Show_Nickname();
        self_nickname.getComponent(cc.Label).string  = ""+snicnname;
        
        var self_touxiang = cc.find("node_ui/selfnode/tx/default_touxiang",this.node);

        var self_touxiangurl = ZhanghaoMng.GetInstance().Get_Self_Touxiang_URL();
        if(self_touxiangurl)
        {
            BaseUIUtils.Show_Remote_Touxiang(self_touxiang,self_touxiangurl,{cx:90,cy:90});

              
        }else{
            BaseUIUtils.ShowIconNodePicFilename(touxiang_node,"game/default_touxiang",{cx:90,cy:90})
       
        }

    }
    
    OnBtnExit()
    {
       
        SoundManager.GetInstance().Play_Effect('com/clickbtn')
       
        this.node.destroy();
       
        if(this.m_cb)
        {
            this.m_cb(0);
        } 

     
    }

    OnBtnQitaPaihang()
    {
        SoundManager.GetInstance().Play_Effect('com/clickbtn')
       
        this.node.destroy();
       
        if(this.m_cb)
        {
            this.m_cb(1);
        } 

    }

    OnBtnFenxiang()
    {

        var paihangbangname = this.Get_PaihangBangName(this.m_iseltype)

        var strfenxiangstr = "";
        var strtile =  "";


        if(this.m_self_in_paiming > 0)
        {
            strtile=  "我在"+paihangbangname+"排名:"+this.m_self_in_paiming+","+""+this.Get_Score_Desc(this.m_self_score)+",太厉害了";
            strfenxiangstr=  strtile;

        }else{
            strtile=  ""+paihangbangname+"排名分享,"+"我的成绩:"+this.Get_Score_Desc(this.m_self_score)+"";;
            strfenxiangstr=  strtile;

        }



        PlatFormMng.GetInstance().Share_Msg(strtile,strfenxiangstr);

    }
    
}
