import BaseUIUtils from "../comfuncs/BaseUIUtils";
import ComFunc from "../comfuncs/ComFunc";
import SoundManager from "../comfuncs/SoundManager";
import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import GlobalGameMng from "../Mng/GlobalGameMng";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";


const {ccclass, property} = cc._decorator;

@ccclass
export default class goumai_tili extends cc.Component {

     

    m_cb = null;

    m_perci_goumai_tili = 5;
    
    onLoad () 
    {
        var exit_btn = cc.find("node_ui/exit",this.node);
        exit_btn.on("click",this.OnBtnExit.bind(this));

        var comgoumai_btn = cc.find("node_ui/comgoumai",this.node);
        comgoumai_btn.on("click",this.OnBtnCommonGoumaiTili.bind(this));

        var lianxugoumai_btn = cc.find("node_ui/lianxugoumai",this.node);
        lianxugoumai_btn.on("click",this.OnBtnLianxuGoumaiTili.bind(this));


 
        var lianxugoumai_48huor_btn = cc.find("node_ui/48huor",this.node);
        lianxugoumai_48huor_btn.on("click",this.OnBtnLianxuGoumai_48huor_Tili.bind(this));

       
     
        BannerGuangaoMng.GetInstance().CheckShowChaiping(10);

        this.schedule(this.Refresh_Info.bind(this),0.3)
         
    }
     
    SetInitData(paradata)
    {
        this.m_cb = paradata.cb;

        var title = cc.find("node_ui/bt/title",this.node);
     
        this.m_perci_goumai_tili = GlobalGameMng.GetInstance().Get_PerCi_Goumai_Tili();
        
        var itype = paradata.itype;
        if(itype == 1)
        {
            title.getComponent(cc.Label).string = "体力不足";
        }else{
            title.getComponent(cc.Label).string = "购买体力";
        }

        this.Refresh_Info();
        
    }
    OnBtnExit()
    {
        SoundManager.GetInstance().Play_Effect('com/clickbtn')
      //  MiddleGamePlatformAction.GetInstance().Set_FanhuiDating_Queren_Dlg_Gezi_Sgow(false);
        if(this.m_cb)
        {
            this.m_cb(0);
        }
        this.node.destroy();
    }
    

    Refresh_Info()
    {
        var tili_info = cc.find("node_ui/tili_info",this.node);
        tili_info.getComponent(cc.Label).string = "现有体力:"+GlobalGameMng.GetInstance().Get_Tili();

        var comgoumai_tipo1 = cc.find("node_ui/comgoumai/tip",this.node);
        comgoumai_tipo1.getComponent(cc.Label).string = "普通观看一次视频体力+"+this.m_perci_goumai_tili;

        var comgoumai_tipo2 = cc.find("node_ui/comgoumai/desc",this.node);
        comgoumai_tipo2.getComponent(cc.Label).string = "观看体力+"+this.m_perci_goumai_tili;
 

        var lianxugoumai_btn = cc.find("node_ui/lianxugoumai",this.node);


        var huode_node = cc.find("node_ui/lianxugoumai/huode",this.node);
        var lefttime_node = cc.find("node_ui/lianxugoumai/lefttime",this.node);
    
        var huode_desc_label = cc.find("node_ui/lianxugoumai/huode/desc",this.node);
    

        var tili_cost_label = cc.find("node_ui/tili_cost",this.node);
        tili_cost_label.getComponent(cc.Label).string = "进入游戏场一次需扣体力:"+GlobalGameMng.GetInstance().Get_Enter_Game_PerCi_Sub_Tili();

 

         //连续观看无限体力剩余时间
        var ileft_wuxian_tili_sec = GlobalGameMng.GetInstance().Get_Lianxu_Video_Wuxian_Tili_Left_Sec();

        if(ileft_wuxian_tili_sec > 0)
        {
            lefttime_node.active = true;
            huode_node.active = false;
            lianxugoumai_btn.getComponent(cc.Button).interactable = false;

            this.Refresh_Left_Wuxian_Tili_Sec();
        }
        else
        {

            lefttime_node.active = false;
            huode_node.active = true;
            lianxugoumai_btn.getComponent(cc.Button).interactable = true;

            huode_desc_label.getComponent(cc.Label).string = "获得 "+GlobalGameMng.GetInstance().m_lianxu_guangkan_wuxian_tili_video_count+"/3";
        }


        var huode_48huor_node = cc.find("node_ui/48huor/huode",this.node);
        var lefttime_48huor_node = cc.find("node_ui/48huor/lefttime",this.node);
    
        var huode_48huor_desc_label = cc.find("node_ui/48huor/huode/desc",this.node);
        var lianxugoumai_48huor_btn = cc.find("node_ui/48huor",this.node);
    

        var ileft_wuxian_tili_48huor_sec = GlobalGameMng.GetInstance().Get_Lianxu_Video_Wuxian_48huor_Tili_Left_Sec();

        if(ileft_wuxian_tili_48huor_sec > 0)
        {
            lefttime_48huor_node.active = true;
            huode_48huor_node.active = false;
            lianxugoumai_48huor_btn.getComponent(cc.Button).interactable = false;

            this.Refresh_Left_Wuxian_48huor_Tili_Sec();
        }
        else
        {

            lefttime_48huor_node.active = false;
            huode_48huor_node.active = true;
            lianxugoumai_48huor_btn.getComponent(cc.Button).interactable = true;

            huode_48huor_desc_label.getComponent(cc.Label).string = "获得 "+GlobalGameMng.GetInstance().m_lianxu_guangkan_wuxian_48huor_tili_video_count+"/5";
        }




    }

    Refresh_Left_Wuxian_Tili_Sec()
    {
        var ileft_wuxian_tili_sec = GlobalGameMng.GetInstance().Get_Lianxu_Video_Wuxian_Tili_Left_Sec();
        var lefttime = cc.find("node_ui/lianxugoumai/lefttime/t2",this.node);

        lefttime.getComponent(cc.Label).string = ComFunc.FormatLeftSecStr(ileft_wuxian_tili_sec);
    }
    Refresh_Left_Wuxian_48huor_Tili_Sec()
    {
        var ileft_wuxian_tili_sec = GlobalGameMng.GetInstance().Get_Lianxu_Video_Wuxian_48huor_Tili_Left_Sec();
        var lefttime = cc.find("node_ui/48huor/lefttime/t2",this.node);

        lefttime.getComponent(cc.Label).string = ComFunc.FormatLeftSecStr(ileft_wuxian_tili_sec);
    }
    RealGoumai_Common_Tili()
    {
        GlobalGameMng.GetInstance().Add_Tili(this.m_perci_goumai_tili);
        BaseUIUtils.ShowTipTxtDlg("购买体力成功",this.node);

        this.Refresh_Info();
    }
    
    RealGoumai_Lianxu_Tili()
    {
        GlobalGameMng.GetInstance().On_Watch_Lianxu_Wuxian_Tili_Video_Suc();
        var ileft_wuxian_tili_sec = GlobalGameMng.GetInstance().Get_Lianxu_Video_Wuxian_Tili_Left_Sec();

        if(ileft_wuxian_tili_sec > 0)
        {
            BaseUIUtils.ShowTipTxtDlg("获得24小内无限体力!",this.node);

        }else{
            BaseUIUtils.ShowTipTxtDlg("连续观看一次成功",this.node);

        }
     
        this.Refresh_Info();
    }
    RealGoumai_Lianxu_48huor_Tili()
    {
        GlobalGameMng.GetInstance().On_Watch_Lianxu_Wuxian_48huor_Tili_Video_Suc();
        var ileft_wuxian_tili_sec = GlobalGameMng.GetInstance().Get_Lianxu_Video_Wuxian_48huor_Tili_Left_Sec();

        if(ileft_wuxian_tili_sec > 0)
        {
            BaseUIUtils.ShowTipTxtDlg("获得48小内无限体力!",this.node);

        }else{
            BaseUIUtils.ShowTipTxtDlg("连续观看一次成功",this.node);

        }
     
        this.Refresh_Info();
    }
    OnBtnCommonGoumaiTili()
    {   


         SoundManager.GetInstance().Play_Effect('com/clickbtn')
    
         var itilinow = GlobalGameMng.GetInstance().Get_Tili();

         if(itilinow >= GlobalGameMng.GetInstance().Get_Max_Tili())
         {
            BaseUIUtils.ShowTipTxtDlg("体力已满",this.node);

    
            return;
         }

        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(this.node, 
            ()=>
            {

            },"普通购买体力",(bsuc)=>
        {
                if(!bsuc)
                {
                    return;
                }
    
    
                self.RealGoumai_Common_Tili();
    
        });

    }
    OnBtnLianxuGoumai_48huor_Tili()
    {

        var ileft_wuxian_tili_sec1 = GlobalGameMng.GetInstance().Get_Lianxu_Video_Wuxian_Tili_Left_Sec();
        if(ileft_wuxian_tili_sec1 > 0 )
        {

            BaseUIUtils.ShowTipTxtDlg("已有24小时无限体力",this.node);
            return;
        }


        SoundManager.GetInstance().Play_Effect('com/clickbtn')
        var ileft_wuxian_tili_sec = GlobalGameMng.GetInstance().Get_Lianxu_Video_Wuxian_48huor_Tili_Left_Sec();

        if(ileft_wuxian_tili_sec > 0 )
        {

            return;
        }

        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(this.node, 
            ()=>
            {

            },"连续购买48小时体力",(bsuc)=>
        {
                if(!bsuc)
                {
                    return;
                }
    
    
                self.RealGoumai_Lianxu_48huor_Tili();
    
        });
    }

    //连续获得体力
    OnBtnLianxuGoumaiTili()
    {
        SoundManager.GetInstance().Play_Effect('com/clickbtn');

        var ileft_wuxian_tili_sec1 = GlobalGameMng.GetInstance().Get_Lianxu_Video_Wuxian_48huor_Tili_Left_Sec();

        if(ileft_wuxian_tili_sec1 > 0 )
        {
            BaseUIUtils.ShowTipTxtDlg("已有48小时无限体力",this.node);
       
            return;
        }

        var ileft_wuxian_tili_sec = GlobalGameMng.GetInstance().Get_Lianxu_Video_Wuxian_Tili_Left_Sec();

        if(ileft_wuxian_tili_sec > 0 )
        {

            return;
        }

        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(this.node, 
            ()=>
            {

            },"连续购买体力",(bsuc)=>
        {
                if(!bsuc)
                {
                    return;
                }
    
    
                self.RealGoumai_Lianxu_Tili();
    
        });
    }
}
