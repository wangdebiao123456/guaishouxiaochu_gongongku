import BannerGuangaoMng from "../WDT/BannerGuangaoMng";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
 
import SoundManager from "../comfuncs/SoundManager";
import PlatFormMng from "../PlatForm/PlatFormMng";
import ClientLogUtils from "../comfuncs/ClientLogUtils";
import ComFunc from "../comfuncs/ComFunc";
import GlobalGameMng from "../Mng/GlobalGameMng";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class gamefail extends cc.Component {

     
    m_isubgametype = 0;
    m_igk = 0;

    m_cb = null;
    m_itype=  0;
    
    m_fenxiangstr = "";
    onLoad () 
    {

 
       
        var chongwanbenguang = cc.find("node_ui/menu/chongwanbenguang",this.node);
        chongwanbenguang.on("click",this.OnBtnChongWanBrnGuang.bind(this));

        var fanhuidating = cc.find("node_ui/menu/fanhuidating",this.node);
        fanhuidating.on("click",this.OnBtnFanhuiDating.bind(this));


        var fenxiang = cc.find("node_ui/menu/fenxiang",this.node);
        fenxiang.on("click",this.OnBtnFexXiang.bind(this));

        this.Show_All_Btns(false);

        var idealyshowsec = GlobalGameMng.GetInstance().Get_GameFail_Dlg_Dealy_Show_Btn_Sec();
       
        this.scheduleOnce(this.FD_InitShow.bind(this),idealyshowsec);


         
        MiddleGamePlatformAction.GetInstance().Stop_Luping();

        MiddleGamePlatformAction.GetInstance().Check_Show_Bottom_Banner();
        MiddleGamePlatformAction.GetInstance().Hide_Other_In_Game_Dlg_Gezi_Show(4);



    }
    FD_InitShow()
    {
        this.Show_All_Btns(true);

    }
    Show_All_Btns(bshow)
    {
        var chongwanbenguang = cc.find("node_ui/menu/chongwanbenguang",this.node);
        var fanhuidating = cc.find("node_ui/menu/fanhuidating",this.node);
        var fenxiang = cc.find("node_ui/menu/fenxiang",this.node);
    
        chongwanbenguang.active = bshow;
        fanhuidating.active = bshow;
        fenxiang.active = bshow;

    }

    SetInitData(paradata)
    {
        this.m_cb = paradata.cb;

        var strtip = paradata.strtip;
        this.m_isubgametype = paradata.isubgametype;
        this.m_igk = paradata.igk;

        if(paradata.fenxiangstr)
        {
            this.m_fenxiangstr = paradata.fenxiangstr;

        }
      
        if(strtip)
        {
            var tipnode=  cc.find("node_ui/tip",this.node);
            tipnode.getComponent(cc.Label).string = strtip;
        }


 
    }

    Get_Goumai_Daoju_Type_Count(itype)
    {

        if(itype == 1)
        {
            return 5;
        }
        else if(itype == 2)
        {
            return 2;
        } 
        else if(itype == 3)
        {
            return 5;
        }
        else if(itype == 4)
        {
            return 3;
        }





        return 3;
    }

    UpdateInfo()
    {
         

        
    }

    OnBtnFanhuiDating()
    {
        MiddleGamePlatformAction.GetInstance().Hide_Bottom_Banner()

        SoundManager.GetInstance().Play_Effect('com/clickbtn')
       
       PlatFormMng.GetInstance().Stop_Luping();
     //  cc.director.loadScene("dating");

      
       
       var isubgametype = this.m_isubgametype;
       ClientLogUtils.GetInstance().Poset_Server_JS_Log(14000+isubgametype, "关卡失败返回大厅", this.m_igk,
       "第"+this.m_igk+"关", 0, "", 0, "");


       ComFunc.RealLoadScence("dating",isubgametype,2);

    }

    OnBtnChongWanBrnGuang()
    {
        MiddleGamePlatformAction.GetInstance().Hide_Bottom_Banner()

        SoundManager.GetInstance().Play_Effect('com/clickbtn')
       
        this.node.destroy();
        if(this.m_cb)
        {
            this.m_cb();
        } 


        var isubgametype = this.m_isubgametype;
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(15000+isubgametype, "关卡失败重玩本关", this.m_igk,
        "第"+this.m_igk+"关", 0, "", 0, "");
        
    }

    OnBtnFexXiang()
    {

        if(!this.m_fenxiangstr)
        {
            this.m_fenxiangstr = "看我在怪兽大消除游戏玩法里的战绩";
        }
        PlatFormMng.GetInstance().Share_Msg("游戏战绩",this.m_fenxiangstr);

    }

     
    RealGoumai()
    {
        
        MiddleGamePlatformAction.GetInstance().Hide_Bottom_Banner()

        if(this.m_cb)
        {
            this.m_cb(1);
        } 
        this.close()
    }
     
    close()
    {

        this.node.destroy();
    }
}
