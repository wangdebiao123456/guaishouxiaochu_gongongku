import SoundManager from "../utils/SoundManager";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class game_shezhi_dlg extends cc.Component {

    m_cb = null;
    
    onLoad () 
    {
        var exitbtn = cc.find("panel/exitbtn",this.node)
        exitbtn.on("click",this.OnBtnExit.bind(this))
        
        var jixubtn = cc.find("panel/menu/jixubtn",this.node)
        jixubtn.on("click",this.OnBtnJixu.bind(this))
        
        var renshubtn = cc.find("panel/menu/renshubtn",this.node)
        renshubtn.on("click",this.OnBtnRenshu.bind(this))
     
        

        for(var ff=1;ff<=3;ff++)
        {
            var ff_btn = cc.find("panel/set/"+ff+"/btn",this.node)
            var ff_invalid_btn = cc.find("panel/set/"+ff+"/invalid",this.node);


            ff_btn.on("click",this.OnBtnClose.bind(this,ff))
            ff_invalid_btn.on("click",this.OnBtnOpen.bind(this,ff))
      
        }


        this.Refresh();
    }
    OnBtnOpen(iindex)
    {
        if(iindex == 1)
        {
            SoundManager.GetInstance().m_bk_music_sound_volum  = 1;
        }
        if(iindex == 2)
        {
            SoundManager.GetInstance().m_effect_sound_volum  = 1;
        }
        if(iindex == 3)
        {
            SoundManager.GetInstance().m_zhengdong  = 1;
        }


        this.Refresh();
    }
    OnBtnClose(iindex)
    {
        if(iindex == 1)
        {
            SoundManager.GetInstance().m_bk_music_sound_volum  = 0;
        }
        if(iindex == 2)
        {
            SoundManager.GetInstance().m_effect_sound_volum  = 0;
        }
        if(iindex == 3)
        {
            SoundManager.GetInstance().m_zhengdong  = 0;
        }


        this.Refresh();
    }
    OnBtnRenshu()
    {
        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb(1);
        }
    }
    OnBtnExit()
    {
        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb(0);
        }
    }
    OnBtnJixu()
    {
        this.OnBtnExit();

    }
    Refresh()
    {
        var music_btn = cc.find("panel/set/1/btn",this.node)
        var music_invalid_btn = cc.find("panel/set/1/invalid",this.node)
    
        var sound_btn = cc.find("panel/set/2/btn",this.node)
        var sound_invalid_btn = cc.find("panel/set/2/invalid",this.node)
    
        var zd_btn = cc.find("panel/set/3/btn",this.node)
        var zd_invalid_btn = cc.find("panel/set/3/invalid",this.node)
    

        if(SoundManager.GetInstance().m_bk_music_sound_volum == 0)
        {
            music_btn.active = false;
            music_invalid_btn.active = true

        }else{
            music_btn.active = true;
            music_invalid_btn.active = false

        }
    

        if(SoundManager.GetInstance().m_effect_sound_volum == 0)
        {
            sound_btn.active = false;
            sound_invalid_btn.active = true

        }else{
            sound_btn.active = true;
            sound_invalid_btn.active = false

        }

        if(SoundManager.GetInstance().m_zhengdong == 0)
        {
            zd_btn.active = false;
            zd_invalid_btn.active = true

        }else{
            zd_btn.active = true;
            zd_invalid_btn.active = false

        }


    }
    SetInitData(paradata)
    {
        this.m_cb  = paradata.cb;

    }
}
