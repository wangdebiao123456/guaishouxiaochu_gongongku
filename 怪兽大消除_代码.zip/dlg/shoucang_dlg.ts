import ComFunc from "../comfuncs/ComFunc";
import LeoGameInfoMng from "../comfuncs/LeoGameInfoMng";
import GlobalGameMng from "../Mng/GlobalGameMng";
import MyLocalStorge from "../WDT/MyLocalStorge";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class shoucang_dlg extends cc.Component {

   

    
    m_cb = null;
    
    onLoad () 
    {
        var lingqujianglibtn = cc.find("panel/lingqujianglibtn",this.node)
        lingqujianglibtn.on("click",this.onBtnLingqu.bind(this))


    }

    onBtnLingqu()
    {
        var jl_lqed = this.Get_Jiangli_Lingqued();

        if(jl_lqed)
        {
            return;
        }

        var jl = [
            {
                "t":5,
                "c":100
            }
        ]
        GlobalGameMng.GetInstance().Add_DaojuType_Count_List(jl,1);

        this.Set_Jiangli_Lingqued();

        var self = this;
        ComFunc.Open_Get_Daoju_Award_Dlg(this.node, jl, 1, null);
    
        this.Refresh_Info();
    }

    Get_Jiangli_Lingqued()
    {
        var stritem = "gsxc_add_shoucang_jl_lq";
        var strinfi = MyLocalStorge.getItem(stritem);

        if(strinfi == "1")
        {
            return true;
        }

        return false;
    }
    Set_Jiangli_Lingqued()
    {
        var stritem = "gsxc_add_shoucang_jl_lq";
         MyLocalStorge.setItem(stritem,"1");
 
         
    }
    Refresh_Info()
    {
      
        var bfromzhuomian = LeoGameInfoMng.GetIns().m_b_lanuch_from_shoucang;
        var jl_lqed = this.Get_Jiangli_Lingqued()


        var lingqujianglibtn = cc.find("panel/lingqujianglibtn",this.node)
        var yilingqu = cc.find("panel/yilingqu",this.node);

        if(jl_lqed)
        {
            yilingqu.active = true;
            lingqujianglibtn.active = false;
        }else{

            if(bfromzhuomian)
            {
                yilingqu.active = false;
                lingqujianglibtn.active = true;
            }
            else{
                yilingqu.active = false;
                lingqujianglibtn.active = false;
            }
            
           
        }
        
        
    }
    SetInitData(paradata)
    {
        this.m_cb = paradata.cb;
        LeoGameInfoMng.GetIns().Get_WX_Lanuch_Scece_Info();

        this.Refresh_Info()

   

    }
    
}
