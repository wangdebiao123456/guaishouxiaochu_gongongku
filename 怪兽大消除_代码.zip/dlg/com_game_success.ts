import BaseUIUtils from "../comfuncs/BaseUIUtils";
import BundleLoadUtils from "../comfuncs/BundleLoadUtils";
import ClientLogUtils from "../comfuncs/ClientLogUtils";
import ComFunc from "../comfuncs/ComFunc";
import LeoGameInfoMng from "../comfuncs/LeoGameInfoMng";
import SoundManager from "../comfuncs/SoundManager";
import ComCodeFuncMng from "../Mng/ComCodeFuncMng";
import GlobalGameMng from "../Mng/GlobalGameMng";
import PlatFormMng from "../PlatForm/PlatFormMng";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";

 
 
 
 
const {ccclass, property} = cc._decorator;

@ccclass
export default class com_game_success extends cc.Component {

   // m_money = 0;
  //  m_xingxing = 0;
    
    m_fenshu = 0;

    m_start_tick = 0;

    m_start_sound_played = 0;

    m_animate_end = 0;
    m_gk = 1;
    m_isubgametype = 0;


    m_ibeishu = 1;

    m_guoguang_jl = [];
    m_cb = null;


    m_b_geteed_fenxiang_jiangli = 0;


    onLoad () 
    {

        this.m_start_tick = Date.now();

        var okbtn = cc.find("panel/okbtn",this.node)
        okbtn.on("click",this.OnBtnOk.bind(this));


        var btn_fanhuidating = cc.find("panel/btn_fanhuidating",this.node)
        btn_fanhuidating.on("click",this.OnBtnFanhuiDating.bind(this));

        var button_share = cc.find("panel/button_share",this.node)
        button_share.on("click",this.OnBtnFenXiang.bind(this));


        var btn_paihangbang = cc.find("panel/btn_paihangbang",this.node)
        btn_paihangbang.on("click",this.OnBtn_PaihangBang.bind(this));
 
        
        SoundManager.GetInstance().Play_Effect("com/huoquwuping");


      //  var tishi_node = cc.find("exitbtn/tishi",this.node);

      //  var pseq = cc.sequence(cc.scaleTo(0.5,1.1),cc.scaleTo(0.5,1))
      //  tishi_node.runAction(cc.repeatForever(pseq))


       /// SoundManager.GetInstance().Play_Effect("huaduoppingping/jbibianhua");
        this.Refresh_Info();
        BannerGuangaoMng.GetInstance().CheckShowChaiping(12);
     
    }
    Get_SubGameType()
    {
        return this.m_isubgametype;
    }
    OnBtn_PaihangBang()
    {

        ComCodeFuncMng.OnBtn_PaihangBang(this,this.node,this.Get_SubGameType())
      
    }
    
    Notify_WX_Show_Hide_Event(bshow)
    {
        if(!LeoGameInfoMng.GetIns().m_b_in_share_msg)
        {
            return;
        }

        if(this.m_b_geteed_fenxiang_jiangli)
        {
            return;
        }

        LeoGameInfoMng.GetIns().m_b_in_share_msg = 0;
        this.m_b_geteed_fenxiang_jiangli = 1;


 

        var awrad =  this.m_guoguang_jl;

        GlobalGameMng.GetInstance().Add_DaojuType_Count_List(awrad);
        ComFunc.Open_Get_Daoju_Award_Dlg(this.node, awrad, 1, ()=>{});



        this.Refresh_Info();

    }

    protected onDestroy()
    {
        LeoGameInfoMng.GetIns().m_b_in_share_msg=  0;     
        LeoGameInfoMng.GetIns().Remove_WX_Show_Hide_Event_Lisnter(this)
    }
    OnBtnFenXiang()
    {
        var self  =this;

        if(!this.m_b_geteed_fenxiang_jiangli)
        {
            LeoGameInfoMng.GetIns().m_b_in_share_msg=  1;

            LeoGameInfoMng.GetIns().Add_WX_Show_Hide_Event_Lisnter(this)
     
        }
      

        var sgamename = GlobalGameMng.GetInstance().Get_Game_Type_Name(this.m_isubgametype)
    
        PlatFormMng.GetInstance().Share_Msg("超好玩，超多玩法,快来一起玩吧","我在"+sgamename+"中"+"第"+this.m_gk+"关成功啦,超好玩，超多玩法,快来一起玩吧");

    }
    OnBtnFanhuiDating()
    {
        cc.director.loadScene("dating");

        
        SoundManager.GetInstance().Play_Click_Btn_Effect();


        var isubgametype = this.m_isubgametype;
        var subgamegame = GlobalGameMng.GetInstance().Get_Game_Type_Name(isubgametype);
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(21000 + isubgametype, "游戏胜利返回大厅", this.m_gk,
             "第"+this.m_gk+"关", 0, "", 0, subgamegame);


 
    }
    SetInfo(pinfo)
    {
        this.m_fenshu = pinfo.fenshu;
        this.m_gk = pinfo.igk;
 
        this.m_guoguang_jl  = pinfo.guoguang_jl;

        this.m_isubgametype  = pinfo.isubgametype;
     
 

       // this.m_xingxing = pinfo.xingxing;
      //  this.m_money  = pinfo.money;
     
        this.m_cb = pinfo.cb;

        var ibeishu = pinfo.ibeishu;

        if(ibeishu && ibeishu > 1)
        {
            this.m_ibeishu = ibeishu;
        }

        var button_share = cc.find("panel/button_share",this.node)
   
        if(ibeishu >= 2)
        {
            BaseUIUtils.ShowTipTxtDlg("获得"+ibeishu+"倍奖励成功",this.node);
            button_share.active = false;
        }

        var stip1 = cc.find("panel/stip1",this.node)
        stip1.getComponent(cc.Label).string = "第"+this.m_gk+"关过关获得奖励"
        
        var sgamename = cc.find("panel/sgamename",this.node)
        sgamename.getComponent(cc.Label).string =  GlobalGameMng.GetInstance().Get_Game_Type_Name(this.m_isubgametype)
        

 
    }

    OnBtnOk()
    {
     
        this.node.destroy();
 
        if(this.m_cb)
        {
            this.m_cb(1);
        }
        
        SoundManager.GetInstance().Play_Click_Btn_Effect();


        var isubgametype = this.m_isubgametype;
        var subgamegame = GlobalGameMng.GetInstance().Get_Game_Type_Name(isubgametype);
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(22000 + isubgametype, "游戏胜利进入下一关", this.m_gk,
             "第"+this.m_gk+"关", 0, "", 0, subgamegame);

    }

    
    
    Refresh_Info()
    {
        /*
        var wuping_1_c_label = cc.find("panel/wuping/1/c",this.node);
        wuping_1_c_label.getComponent(cc.Label).string = "x"+this.m_money;


        var wuping_2_c_label = cc.find("panel/wuping/2/c",this.node);
        wuping_2_c_label.getComponent(cc.Label).string = "x"+this.m_xingxing;

        */

        for(var ff=1;ff<=2;ff++)
        {
            var wuping_ff_node = cc.find("panel/wuping/"+ff,this.node);

            if(ff > this.m_guoguang_jl.length)
            {
                wuping_ff_node.active = false;
            }else{
                wuping_ff_node.active = true;

                var ff_jl = this.m_guoguang_jl[ff-1];
                var ff_t=  ff_jl.t;
                var ff_c=  ff_jl.c * this.m_ibeishu;
                
                wuping_ff_node.getChildByName("c").getComponent(cc.Label).string = "x"+ff_c;
                var icon_node = wuping_ff_node.getChildByName("icon");

                var icon_sfilename = GlobalGameMng.GetInstance().Get_Aawrd_Daoju_Icon(ff_t);
                BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("resources",icon_node,icon_sfilename,{width:80,height:80})
            }
     
        }

        if(this.m_guoguang_jl.length  == 1)
        {
            var wuping_1_node = cc.find("panel/wuping/"+1,this.node);
            wuping_1_node.x = 0;
        }


        var jinbi_c_label = cc.find("panel/top/addjinbi/c",this.node);
        jinbi_c_label.getComponent(cc.Label).string = ""+GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(1)


        var xx_c_label = cc.find("panel/top/addxingxing/c",this.node);
        xx_c_label.getComponent(cc.Label).string = ""+GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(2)


        var addzuanshi_c_label = cc.find("panel/top/addzuanshi/c",this.node);
        addzuanshi_c_label.getComponent(cc.Label).string = ""+GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(5)

        var button_share_tip = cc.find("panel/button_share/tip",this.node);
        
        if(this.m_b_geteed_fenxiang_jiangli)
        {
            button_share_tip.getComponent(cc.Label).string = "已获得分享奖励";
        }else{
            button_share_tip.getComponent(cc.Label).string = "分享再次获得过关奖励";
        }

    }



     
}
