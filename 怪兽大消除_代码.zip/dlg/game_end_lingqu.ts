 
import BaseUIUtils from "../comfuncs/BaseUIUtils";
import SoundManager from "../comfuncs/SoundManager"; 
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction"; 
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";
import GlobalGameMng from "../Mng/GlobalGameMng";
import WMap from "../WDT/WMap";
import ComCodeFuncMng from "../Mng/ComCodeFuncMng";
 
const {ccclass, property} = cc._decorator;

@ccclass
export default class game_end_lingqu extends cc.Component {

    m_last_btn_click_tick = 0;
    m_cb = null;

    
    m_tuijianwe_dest_info_map = new WMap();
    m_last_tuijian_change_tick_map = new WMap();

    m_isubgametype = 0;
    onLoad () 
    {
        var lq = cc.find("panel/top/lq",this.node);
        var exit = cc.find("panel/top/exit",this.node);
      
        lq.on("click",this.OnBtnExit.bind(this));
        exit.on("click",this.OnBtnExit.bind(this));

        lq.active = false;
        exit.active = false;

        this.scheduleOnce(this.FD_Show_Guangao.bind(this),0.02);
     
        SoundManager.GetInstance().Play_Effect("com/huoquwuping",2);

        BannerGuangaoMng.GetInstance().CheckShowChaiping(23);
   
        var idealyshowsec = GlobalGameMng.GetInstance().Get_GameSuc_LingquWuping_Dlg_Dealy_Show_Btn_Sec();
        this.scheduleOnce(this.FD_InitShow.bind(this),idealyshowsec);

        
      
    }
    FD_InitShow()
    {
        var exit = cc.find("panel/top/exit",this.node);
      
        var lq = cc.find("panel/top/lq",this.node);
        lq.active = true;
        exit.active = true;

    }
    FD_Show_Guangao()
    {

      //  BannerGuangaoMng.GetInstance().On_Show_Dlg_Banner_Guangao_Event(true,true,false,false);

      
         
    }

    Get_Node_Pos(alllen,i)
    {
        if(alllen == 1)
        {
            return new cc.Vec2(0,0);
        }

        if(alllen == 2)
        {
            if(i == 0)
            {
                return new cc.Vec2(-150,0);
            }
            return new cc.Vec2(150,0);
        }


        if(alllen == 3)
        {
            if(i == 0)
            {
                return new cc.Vec2(-300,0);
            }
            if(i == 2)
            {
                return new cc.Vec2(300,0);
            }
            return new cc.Vec2(0,95);
        }


        if(alllen == 4)
        {
            if(i == 0)
            {
                return new cc.Vec2(-75,0);
            }
            else if(i == 1)
            {
                return new cc.Vec2(75,0);
            }
            else if(i == 2)
            {
                return new cc.Vec2(-150-75,0);
            }
            return new cc.Vec2(150+75,0);
        }
        
        if(alllen == 5)
        {
            if(i == 0)
            {
                return new cc.Vec2(-150,0);
            }
            else if(i == 1)
            {
                return new cc.Vec2(150,0);
            }
            else if(i == 2)
            {
                return new cc.Vec2(-300,0);
            } else if(i == 3)
            {
                return new cc.Vec2(0,0);
            }else if(i == 4)
            {
                return new cc.Vec2(300,0);
            }
            return new cc.Vec2(300,0);
        }
        
        if(alllen >= 6)
        {
            if(i == 0)
            {
                return new cc.Vec2(0,0);
            }
            else if(i == 1)
            {
                return new cc.Vec2(150,0);
            }
            else if(i == 2)
            {
                return new cc.Vec2(-150,0);
            } else if(i == 3)
            {
                return new cc.Vec2(300,0);
            }else if(i == 4)
            {
                return new cc.Vec2(-300,0);
            }else if(i == 5)
            {
                return new cc.Vec2(-450,0);
            }
            return new cc.Vec2(450,0);
        }
        
    }
    Init_Top_Tuijian_Guangao()
    {
        var othergame_node = cc.find("panel/othergame",this.node);

        var bshow = GlobalGameMng.GetInstance().IS_Game_End_Lingqu_Dlg_Tuijianwei_Show();

        if(!bshow)
        {
            othergame_node.active = false;
            return;
        }


        var pos1 = this.m_isubgametype + 21000 ;
        var pos2 = this.m_isubgametype + 22000 ;


        var pos_arr = [pos1,pos2];
        ComCodeFuncMng.Init_Com_Two_Guangao(this,this.node,othergame_node,pos_arr);


    }
    SetInitData(paradata)
    {
        this.m_cb = paradata.cb;


        var isubgametype = paradata.isubgametype;
        this.m_isubgametype = isubgametype;


        this.SetAward(paradata.daojulist, paradata.ibeishu);

        MiddleGamePlatformAction.GetInstance().Show_GameEnd_Lingqu_Dlg_Banners(true);
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(56,true);

        this.Init_Top_Tuijian_Guangao();
  
        var title_t = cc.find("panel/top/gx/t",this.node);
        if(paradata.ibeishu > 1)
        {
            title_t.getComponent(cc.Label).string = "游戏结算奖励 ("+paradata.ibeishu+"倍)";

            BaseUIUtils.ShowTipTxtDlg("恭喜获得"+paradata.ibeishu+"倍奖励",this.node);
        }else{
            title_t.getComponent(cc.Label).string = "游戏结算奖励"; 
        }
 
    }
    SetAward(daojulist, multiple)
    {
        
        for (let i = 1; i <= 6; i++) 
        { 

            var ff_ndoe = cc.find("panel/top/wuping/"+i,this.node);
            ff_ndoe.active = false;
        }
        for (let i = 0; i < daojulist.length; i++) 
        {
            var t = daojulist[i].t;
            var c = multiple*daojulist[i].c;


            var ff_ndoe = cc.find("panel/top/wuping/"+(i+1),this.node);
            if(!ff_ndoe)
            {
                continue;
            }
            ff_ndoe.active = true;
            var name_ndoe = ff_ndoe.getChildByName("name");
          

            name_ndoe.getComponent(cc.Label).string = GlobalGameMng.GetInstance().Get_DaojuType_Show_Name(t);
      
            var reward_ndoe = ff_ndoe.getChildByName("reward");
            reward_ndoe.getComponent(cc.Label).string =  ""+c;
 
            var sicon = GlobalGameMng.GetInstance().Get_Aawrd_Daoju_Icon(t);
       
            var zs_ndoe = ff_ndoe.getChildByName("zs");
    

            BaseUIUtils.ShowIconNodePicFilename(zs_ndoe,sicon);

         //   var newpos = this.Get_Node_Pos(daojulist.length,i)
          //  ff_ndoe.setPosition(newpos);
        }

        var wuping_ndoe = cc.find("panel/top/wuping",this.node);
        wuping_ndoe.x=  0;
        if(daojulist.length%2 == 0)
        {
            wuping_ndoe.x = -60;
        }
    }
 
    Check_Btn_Enough_Tick()
    {
        if(this.m_last_btn_click_tick > 0)
        {
            if(Date.now() - this.m_last_btn_click_tick < 1000)
            {
                return false;
            }
        }
        this.m_last_btn_click_tick = Date.now();
        return true;
    }
    OnBtnExit()
    {

        if(!this.Check_Btn_Enough_Tick())
        {
            return;
        }
       // BannerGuangaoMng.GetInstance().On_Hide_Dlg_Banner_Guangao_Event();
       MiddleGamePlatformAction.GetInstance().Show_GameEnd_Lingqu_Dlg_Banners(false);
       MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(56,false);


        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb();
        }
        SoundManager.GetInstance().Play_Effect('com/clickbtn')
      
    }
}
