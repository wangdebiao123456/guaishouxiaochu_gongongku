

const {ccclass, property} = cc._decorator;

@ccclass
export default class shilingtishidlg extends cc.Component {
 

    m_plister = null;
    
    
    onLoad () {

        var guangbi=  cc.find("panel/guangbi",this.node);
        guangbi.on("click",this.OnBtnExit.bind(this));
        

    }

    SetCallback(plister)
    {
        this.m_plister = plister;

    }

    OnBtnExit()
    {
        this.node.destroy();

        if(this.m_plister)
        {
            this.m_plister.OnShilingtishiEnd();
        }

    }
    



}
