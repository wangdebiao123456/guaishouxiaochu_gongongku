import PlatFormMng from "../PlatForm/PlatFormMng";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import SoundManager from "../comfuncs/SoundManager";
import GSXC_Game_Mng from "../Mng/GSXC_Game_Mng";
import PlatFormType from "../PlatForm/PlatFormType";
import BaseUIUtils from "../comfuncs/BaseUIUtils";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";
import ClientLogUtils from "../comfuncs/ClientLogUtils";
import ComFunc from "../comfuncs/ComFunc";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class gamesuccess extends cc.Component {

   
    node_star1: cc.Node
    node_star2: cc.Node
    node_star3: cc.Node
    node_ui:cc.Node

    m_enter_level = 0;
    m_cb = null;

    m_isubgametype = 1;
    m_star = 0;

    onLoad () 
    {

      



        SoundManager.GetInstance().Play_Effect('com/victory');

        this.scheduleOnce(this.FD_StopLuping.bind(this),0.3);
        



        var btn_share=  cc.find("node_ui/btn_share",this.node);
        var btn_next =  cc.find("node_ui/btn_next",this.node);
        var btn_restart=  cc.find("node_ui/btn_restart",this.node);


        btn_share.on("click",this.click_share.bind(this));
        btn_next.on("click",this.click_next.bind(this));
        btn_restart.on("click",this.click_restart.bind(this));
         
        var bshow_xuanyao = PlatFormMng.GetInstance().IS_Game_End_Xuanyao_Btn_Show();

        if(!bshow_xuanyao)
        {
            btn_share.active = false;

            btn_next.x = 100;
            btn_restart.x = -100;

        }else{

        }

        MiddleGamePlatformAction.GetInstance().Check_Show_Bottom_Banner();

        BannerGuangaoMng.GetInstance().CheckShowChaiping(21);
    }

    FD_StopLuping()
    {
        MiddleGamePlatformAction.GetInstance().Stop_Luping();
    }
    SetInitData(paradata)
    {
        this.m_cb = paradata.cb;

        this.m_isubgametype = paradata.isubgametype;

        this.m_enter_level = paradata.ilevel;
        this.m_star = paradata.star;

        this.node_star1 = cc.find("node_ui/star_1/node_star1",this.node);
        this.node_star2 = cc.find("node_ui/star_2/node_star2",this.node);
        this.node_star3 = cc.find("node_ui/star_3/node_star3",this.node);
        this.node_ui = cc.find("node_ui",this.node);
        
         
        this.node_ui.x=600
        cc.tween(this.node_ui).to(0.25,{x:0},{easing:'backOut'}).start()
 
        this.node_star1.active = this.m_star >= 1
        this.node_star2.active = this.m_star >= 2
        this.node_star3.active = this.m_star >= 3

        this.node_star1.opacity = this.node_star2.opacity = this.node_star3.opacity = 0


        for (let i = 1; i <= this.m_star; i++) {
            let node = this['node_star' + i]
            //做一个从大变小的动画
            node.scale = 3
            cc.tween(node).delay((i - 1) * 0.4 + 0.25).call(()=>
            {
                SoundManager.GetInstance().Play_Effect('com/star'+i)
            }).to(0.25, { scale: 1, opacity: 255 }).start()
        }
     

        var levelinfo = cc.find("node_ui/levelinfo",this.node);
        levelinfo.getComponent(cc.Label).string = "恭喜成功过关第"+this.m_enter_level+"关";


        

        var isubgametype = this.m_isubgametype;
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(12000+isubgametype, "玩法胜利", this.m_enter_level,
        "第"+this.m_enter_level+"关胜利", 0, "", 0, "");

        
    }
    click_next() {


        
        MiddleGamePlatformAction.GetInstance().Hide_Bottom_Banner();

        //this.data.callback&&this.data.callback();


        this.m_cb(1);


        this.close();


        
    }
    click_restart()
    {
      //  Core.win.open(GameConst.winPath.GameWin, null, true);
        MiddleGamePlatformAction.GetInstance().Stop_Luping();
    
        MiddleGamePlatformAction.GetInstance().Hide_Bottom_Banner();

       // this.m_cb(0);

        //this.data.callback&&this.data.callback()
        this.close();

       // cc.director.loadScene("dating");

     //  ComFunc.RealLoadScence("dating");
       ComFunc.RealLoadScence("dating",this.m_isubgametype,1);

    }

    Get_Game_Success_Fenxiang_Str()
    {
        if(this.m_isubgametype == 1)
        {
            return  "我在怪兽消除玩法里，第"+this.m_enter_level+"关"+"闯关成功,真是太厉害啦，你也来试试吧";
        }

        if(this.m_isubgametype == 9)
        {
            return  "我在消除超难模式玩法里,闯关成功,真是太厉害啦，你也来试试吧";
        }
        if(this.m_isubgametype == 2)
        {
            return  "我在泡泡龙玩法第"+this.m_enter_level+"关"+"闯关成功,真是太厉害啦，你也来试试吧";
        }
        if(this.m_isubgametype == 3)
        {
            return  "我在密室逃脱玩法第"+this.m_enter_level+"关"+"闯关成功,真是太厉害啦，你也来试试吧";
        }

        if(this.m_isubgametype == 4)
        {
            return  "我在消灭星星玩法第"+this.m_enter_level+"关"+"闯关成功,真是太厉害啦，你也来试试吧";
        }


        if(this.m_isubgametype == 5)
        {
            return  "我在连连看玩法第"+this.m_enter_level+"关"+"闯关成功,真是太厉害啦，你也来试试吧";
        }


        
        if(this.m_isubgametype == 6)
        {
            return  "我在怪兽闪避玩法第"+this.m_enter_level+"关"+"闯关成功,真是太厉害啦，你也来试试吧";
        }

         
        if(this.m_isubgametype == 7)
        {
            return  "我在怪兽跳跃玩法第"+this.m_enter_level+"关"+"闯关成功,真是太厉害啦，你也来试试吧";
        }

        if(this.m_isubgametype == 8)
        {
            return  "经典方块玩法第"+this.m_enter_level+"关"+"闯关成功,真是太厉害啦，你也来试试吧";
        }

        return "";
    }
    Get_Game_Success_Title_Str()
    {

        if(this.m_isubgametype == 1)
        {
            return  "怪兽消除第"+this.m_enter_level+"关闯关成功啦";
        }

        if(this.m_isubgametype == 2)
        {
            return  "泡泡龙第"+this.m_enter_level+"关闯关成功啦";
        }
        if(this.m_isubgametype == 3)
        {
            return  "密室逃脱第"+this.m_enter_level+"关闯关成功啦";
        }
        if(this.m_isubgametype == 4)
        {
            return  "消灭星星第"+this.m_enter_level+"关闯关成功啦";
        }
        if(this.m_isubgametype == 5)
        {
            return  "连连看第"+this.m_enter_level+"关闯关成功啦";
        }


        if(this.m_isubgametype == 9)
        {
            return  "消除超难模式闯关成功啦";
        }
        return "";
    }
    click_share()
    {

        var strfenxiangstr = this.Get_Game_Success_Fenxiang_Str();
        var strtile = this.Get_Game_Success_Title_Str();

        var strtyip =strfenxiangstr;// "我在怪兽消除游戏里，第"+this.m_enter_level+"关"+"闯关成功,真是太厉害啦，你也来试试吧";

       
    
        if(PlatFormMng.GetInstance().GetPlatFormType() == PlatFormType.PlatFormType_ByteDance
        
        || PlatFormMng.GetInstance().GetPlatFormType() == PlatFormType.PlatFormType_Kuaishou_Xiaoyouxi)
        {
            var self = this;
            PlatFormMng.GetInstance().Fengxiang_Youxi_Luping(strtile,strtyip,
            (bsuc,errmsg)=>
            {
                if(bsuc)
                {  
                    BaseUIUtils.ShowTipTxtDlg("分享成功",this.node);
                  //  BaseUIUtils.ShowTipTxtDlg("分享成功",self.node)
                }else{
                    BaseUIUtils.ShowTipTxtDlg(""+errmsg,this.node);
                    //BaseUIUtils.ShowTipTxtDlg("分享失败",self.node)
                }
                
            });
        }else{
           // PlatFormMng.GetInstance().Share_Msg("超好玩的消除小游戏",strtyip);
           PlatFormMng.GetInstance().Share_Msg(strtile,strtyip);

        }
    }
    click_home() {
        MiddleGamePlatformAction.GetInstance().Hide_Bottom_Banner();

       // Core.win.open(GameConst.winPath.MenuWin, null, true)
    }
    close()
    {
        this.node.destroy();
    }
}
