import ClientLogUtils from "../comfuncs/ClientLogUtils";
import SoundManager from "../comfuncs/SoundManager";
import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";
import GlobalGameMng from "../Mng/GlobalGameMng";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class com_fuhuo extends cc.Component {
    m_last_btn_click_tick = 0;
    
    m_isubgametype = 0;
    m_igk = 0;
    m_cb = null;

    m_fuhuo_daojishi_all_sec = 5;
  //  m_fuhuo_dlg_elpse_tick =  0;

    m_fuhuo_dlg_daojishi_ended = false;
    m_last_daojishi_tick = 0;
    
    onLoad () 
    {

        var cancel = cc.find("node_ui/cancel",this.node);
        cancel.on("click",this.OnBtnExit.bind(this));

        var goumai = cc.find("node_ui/goumai",this.node);
        goumai.on("click",this.OnBtnFuHuo.bind(this));

     
        BannerGuangaoMng.GetInstance().CheckShowChaiping(31);
       
        MiddleGamePlatformAction.GetInstance().Check_BK_Create_GameFail_Banners();
      //  MiddleGamePlatformAction.GetInstance().Check_Show_Bottom_Banner();
   

        this.m_last_daojishi_tick = Date.now();
        this.schedule(this.FD_Timer.bind(this),0.3);

        this.FD_Timer();
    }
    Check_Btn_Enough_Tick()
    {
        if(this.m_last_btn_click_tick > 0)
        {
            if(Date.now() - this.m_last_btn_click_tick < 1000)
            {
                return false;
            }
        }
        this.m_last_btn_click_tick = Date.now();
        return true;
    }
    FD_Timer()
    {

        if(this.m_fuhuo_dlg_daojishi_ended)
        {
            return;
        }

        if(this.m_last_daojishi_tick == 0)
        {
            return;
        }
        var ieplasetick = Date.now() - this.m_last_daojishi_tick;

        var ieplasec  = Math.floor(ieplasetick/1000);

        var ilefesec = this.m_fuhuo_daojishi_all_sec - ieplasec;
        if(ilefesec <= 0)
        {
            ilefesec = 0;
        }


        var leftt_label =  cc.find("node_ui/yuan/leftt",this.node);
        leftt_label.getComponent(cc.Label).string = ""+ ilefesec;
        

        if(ilefesec <= 0)
        {
            this.m_fuhuo_dlg_daojishi_ended = true;
            this.On_Daojishi_Ended();
        }

    }
    OnBtnExit()
    {
        
        if(!this.Check_Btn_Enough_Tick())
        {
            return;
        }
        SoundManager.GetInstance().Play_Effect('com/clickbtn')
      
        MiddleGamePlatformAction.GetInstance().Hide_Bottom_Banner();

        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(3,false);
 
       
        this.node.destroy();
       
        if(this.m_cb)
        {
            this.m_cb(0);
        } 

     
    }

    On_Daojishi_Ended()
    {

        

        var yuan_btn = cc.find("node_ui/yuan",this.node);
        var cancel_btn = cc.find("node_ui/cancel",this.node);

        yuan_btn.active = false;
     
        var bshowcancelbtn = GlobalGameMng.GetInstance().Get_Fuhuo_Dlg_End_Show_Cancel_Btn();

        var gametype_config = GlobalGameMng.GetInstance().Get_Fuhuo_Dlg_End_Show_Cancel_Btn_Per_Game_Type_Config(this.m_isubgametype);

        if(gametype_config)
        {
            bshowcancelbtn = gametype_config[1];
        }




        if(bshowcancelbtn)
        {
            cancel_btn.active = true;
     
        }
        else{
            this.OnBtnExit();

        }

    }

    
    SetInitData(paradata)
    {
        this.m_cb = paradata.cb;
        this.m_isubgametype = paradata.isubgametype;
        this.m_igk = paradata.igk;

        var tip_node = cc.find("node_ui/tip",this.node);
        var strtip  = paradata.strtip;

        if(strtip)
        {
            tip_node.getComponent(cc.Label).string = strtip;
        }
        
        this.m_fuhuo_daojishi_all_sec = GlobalGameMng.GetInstance().Get_Fuhuo_Dlg_Daojishi_All_Sec();
   
        var gametype_config = GlobalGameMng.GetInstance().Get_Fuhuo_Dlg_End_Show_Cancel_Btn_Per_Game_Type_Config(this.m_isubgametype);


        if(gametype_config)
        {
            this.m_fuhuo_daojishi_all_sec = gametype_config[2];
        }


        var leftt_label =  cc.find("node_ui/yuan/leftt",this.node);
        leftt_label.getComponent(cc.Label).string = ""+ this.m_fuhuo_daojishi_all_sec;


        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(3,true);

        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(1);

        MiddleGamePlatformAction.GetInstance().Hide_Other_In_Game_Dlg_Gezi_Show(5);

        
    }
    OnBtnFuHuo()
    {
        SoundManager.GetInstance().Play_Effect('com/clickbtn');
        this.m_fuhuo_dlg_daojishi_ended = true;

        var yuan_btn = cc.find("node_ui/yuan",this.node);
        var cancel_btn = cc.find("node_ui/cancel",this.node);

        yuan_btn.active = false;
     
        var isubgametype = this.m_isubgametype;
        var sgametypename = GlobalGameMng.GetInstance().Get_Game_Type_Name(isubgametype);
  
        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node, 
            ()=>
            {
                MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);
    
            },
            "复活",(bsuc)=>
        {
          
            if(!bsuc)
            {
                cancel_btn.active = true;
     
                return;
            }


            self.RealFuHuo();

        }, this.m_isubgametype,"",null,"复活:"+sgametypename);
    }
    RealFuHuo()
    {
         MiddleGamePlatformAction.GetInstance().Hide_Bottom_Banner()
         MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);
         MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(3,false);

        if(this.m_cb)
        {
            this.m_cb(1);
        } 
        this.node.destroy();


   
        var isubgametype = this.m_isubgametype;
        ClientLogUtils.GetInstance().Poset_Server_JS_Log(13000+isubgametype, "玩家复活选择", this.m_igk,
        "第"+this.m_igk+"关选择复活", this.m_isubgametype, ""+this.m_isubgametype, 0, "");
    }

   
}
