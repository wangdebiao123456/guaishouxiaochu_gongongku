import BannerGuangaoMng from "../WDT/BannerGuangaoMng";
import MiddleGamePlatformAction from "../PlatForm/MiddleGamePlatformAction";
import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import SoundManager from "../comfuncs/SoundManager";
import PlatFormMng from "../PlatForm/PlatFormMng";
import ClientLogUtils from "../comfuncs/ClientLogUtils";
import ComFunc from "../comfuncs/ComFunc";
import GlobalGameMng from "../Mng/GlobalGameMng";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class game_fuhuo extends cc.Component {

   
    m_last_btn_click_tick = 0;
    m_cb = null;
    m_itype=  0;
    m_bchaonan=  false;

    m_isubgametype = 0;
    
    onLoad () 
    {


        var cancel = cc.find("node_ui/cancel",this.node);
        cancel.on("click",this.OnBtnExit.bind(this));
       
        var goumai = cc.find("node_ui/goumai",this.node);
        goumai.on("click",this.OnBtnGoumai.bind(this));

        var fanhuidating = cc.find("node_ui/fanhuidating",this.node);
        fanhuidating.on("click",this.OnBtnExit.bind(this));



        this.Show_All_Btns(false);

        var idealyshowsec = 0.2;
       
        this.scheduleOnce(this.FD_InitShow.bind(this),idealyshowsec);





        MiddleGamePlatformAction.GetInstance().Check_BK_Create_GameFail_Banners();
 
        BannerGuangaoMng.GetInstance().CheckShowChaiping(32);
        MiddleGamePlatformAction.GetInstance().Stop_Luping();

     //   MiddleGamePlatformAction.GetInstance().Check_Show_Bottom_Banner();

     
    }

    FD_InitShow()
    {
        this.Show_All_Btns(true);
    }
    Show_All_Btns(bshow)
    {
        var goumai = cc.find("node_ui/goumai",this.node);
     
        var fanhuidating = cc.find("node_ui/fanhuidating",this.node);
  

        goumai.active = bshow;
        fanhuidating.active = bshow;
        

    }
    Check_Btn_Enough_Tick()
    {
        if(this.m_last_btn_click_tick > 0)
        {
            if(Date.now() - this.m_last_btn_click_tick < 1000)
            {
                return false;
            }
        }
        this.m_last_btn_click_tick = Date.now();
        return true;
    }
    SetInitData(paradata)
    {
        this.m_cb = paradata.cb;

        this.m_bchaonan = paradata.bchaonan;


        var tipstr1 = paradata.stip1;
        var tipstr2 = paradata.stip2;

        this.m_isubgametype = paradata.isubgametype;


        var tip1_label = cc.find("node_ui/caoweiyiman",this.node)
        var tip2_label = cc.find("node_ui/tip",this.node)

        if(tipstr1)
        {
            tip1_label.getComponent(cc.Label).string = tipstr1
        }

        if(tipstr2)
        {
            tip2_label.getComponent(cc.Label).string = tipstr2
        }


        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(4);
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(3,true);

        MiddleGamePlatformAction.GetInstance().Hide_Other_In_Game_Dlg_Gezi_Show(6);





    }

    Get_Goumai_Daoju_Type_Count(itype)
    {

        if(itype == 1)
        {
            return 5;
        }
        else if(itype == 2)
        {
            return 2;
        } 
        else if(itype == 3)
        {
            return 5;
        }
        else if(itype == 4)
        {
            return 3;
        }





        return 3;
    }

    UpdateInfo()
    {
         

        
    }

    OnBtnFanhuiDating()
    {
        
        if(!this.Check_Btn_Enough_Tick())
        {
            return;
        }
        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);
        MiddleGamePlatformAction.GetInstance().Hide_Bottom_Banner()

        SoundManager.GetInstance().Play_Effect('com/clickbtn')
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(3,false);

       PlatFormMng.GetInstance().Stop_Luping();
      // cc.director.loadScene("dating");

      // ComFunc.RealLoadScence("dating");

       ComFunc.RealLoadScence("dating",1,3);


    }
    OnBtnExit()
    {
        
        if(!this.Check_Btn_Enough_Tick())
        {
            return;
        }
        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);
    
        MiddleGamePlatformAction.GetInstance().Hide_Bottom_Banner()
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(3,false);

       
        this.close();
       
        if(this.m_cb)
        {
            this.m_cb(0);
        } 

        SoundManager.GetInstance().Play_Effect('com/clickbtn')
  
    }
    RealGoumai()
    {
        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);
    
        MiddleGamePlatformAction.GetInstance().Hide_Bottom_Banner()
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(3,false);

        if(this.m_cb)
        {
            this.m_cb(1);
        } 
        this.close();

 
    }
    OnBtnGoumai()
    {
        var gametypename = GlobalGameMng.GetInstance().Get_Game_Type_Name(this.m_isubgametype)


        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node,  
            ()=>
            {
                MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);
     
            },
            
            "三消消复活",(bsuc)=>
        {
            if(!bsuc)
            {
                return;
            }


            self.RealGoumai();

        }, this.m_bchaonan ? 9:1,"",null,gametypename+"复活");
    }
    close()
    {

        this.node.destroy();
    }
}
