import BaseUIUtils from "../../comfuncs/BaseUIUtils";
import BundleLoadUtils from "../../comfuncs/BundleLoadUtils";
import ComFunc from "../../comfuncs/ComFunc";
import SoundManager from "../../comfuncs/SoundManager";
import WatchVideoAdveseMng from "../../comfuncs/WatchVideoAdveseMng";
import tankuang from "../../dlg/tankuang";
import GlobalGameMng from "../../Mng/GlobalGameMng";
import MiddleGamePlatformAction from "../../PlatForm/MiddleGamePlatformAction"; 
import BannerGuangaoMng from "../../WDT/BannerGuangaoMng";
import GlobalConfig from "../GlobalConfig";

 
 
const {ccclass, property} = cc._decorator;

@ccclass
export default class huoqu_daoju_dlg extends cc.Component {

    m_callback = null;

    m_idaojutype = 0;


    m_tiaozhan_all_can_skill_count = 0;
    m_tiaozhan_skill_use_count = 0;

    m_b_not_show_get_jiangli_dlg = 0;
 
    m_bTiaozhanchang = 0;

    m_isubgametype = 0;
    
    onLoad () 
    {

        var jinbigoumai = cc.find("panel/center/jinbigoumai",this.node)
        jinbigoumai.on("click",this.OnBtnJinbiGoumai.bind(this))
        
        var mianfeibtn = cc.find("panel/center/mianfeibtn",this.node)
        mianfeibtn.on("click",this.OnBtn_Shiping_Goumai.bind(this))
       

        var tankuang:tankuang = this.node.getComponent("tankuang");
        tankuang.Set_Close_Lisnter(this);



        
      //  MiddleGamePlatformAction.GetInstance().Hide_Other_In_Game_Dlg_Gezi_Show(6);
        BannerGuangaoMng.GetInstance().CheckShowChaiping(9);

    }
    Exit_Node()
    {
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(12,false);
        MiddleGamePlatformAction.GetInstance().Set_SanXiaoxiao_GoumaiDaouju_Dlg_Gezi_Sgow(false);
  
        this.node.destroy();
        if(this.m_callback)
        {
            this.m_callback(1);
        }
    }
    OnBtn_Shiping_Goumai()
    {
        var game_Type_name = GlobalGameMng.GetInstance().Get_Game_Type_Name(this.m_isubgametype);

        var daojuname = GlobalGameMng.GetInstance().Get_DaojuType_Show_Name(this.m_idaojutype);


        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node,
            ()=>
            {
            
            },
            
            "获取道具",(bsuc)=>
        {
            if(!bsuc)
            {
                return;
            }


            self.Real_Huoqu();

            SoundManager.GetInstance().ResumeBkMusic();
        },"","",null,game_Type_name+"获取道具:"+daojuname);

        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(12,false);
        MiddleGamePlatformAction.GetInstance().Set_SanXiaoxiao_GoumaiDaouju_Dlg_Gezi_Sgow(false);
  
    }
    Real_Huoqu()
    {
        var icangetc = 2; 
      
        if(this.m_idaojutype == 24 || this.m_idaojutype == 22)
        {
              icangetc = 1;  
          
        }


        if(this.m_idaojutype == 51 || this.m_idaojutype == 52  || this.m_idaojutype == 53)
        {
              icangetc = 1;  
          
        }

        GlobalConfig.GetIns().Change_Self_DaojuType_Count(this.m_idaojutype,icangetc);

        var awrd = [{"t":this.m_idaojutype,"c":icangetc}];

        
        var self = this;

        if(this.m_b_not_show_get_jiangli_dlg)
        {
            self.Exit_Node();


            SoundManager.GetInstance().Play_Effect("com/huoquwuping")

        }else{
            ComFunc.Open_Get_Daoju_Award_Dlg(this.node, awrd, 1, ()=>
            {
                self.Exit_Node();
            });
        }

      
    }
    OnBtnJinbiGoumai()
    {

             
        var icangetc = 2;
        var cost_jinbi = 200;
      
        if(this.m_idaojutype == 24 || this.m_idaojutype == 22)
        {
              icangetc = 1;
              cost_jinbi = 300;
          
        }


        if(this.m_idaojutype == 51 || this.m_idaojutype == 52  || this.m_idaojutype == 53)
        {
              icangetc = 1;
              cost_jinbi = 200;
          
        }



        var self_jinbi = GlobalConfig.GetIns().Get_Self_DestType_Daoju_Count(1);
        if(self_jinbi < cost_jinbi)
        {

            BaseUIUtils.ShowTipTxtDlg("金币不足",this.node);
            return;
        }
        GlobalConfig.GetIns().Change_Self_DaojuType_Count(1,-1*cost_jinbi);



        this.Real_Huoqu();

        /*
        GlobalConfig.GetIns().Change_Self_DaojuType_Count(this.m_idaojutype,icangetc);

        var awrd = [{"t":this.m_idaojutype,"c":icangetc}];

        

        var self = this;
        ComFunc.Open_Get_Daoju_Award_Dlg(this.node, awrd, 1, ()=>
        {
            self.Exit_Node();
        });

        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(12,false);
        MiddleGamePlatformAction.GetInstance().Set_SanXiaoxiao_GoumaiDaouju_Dlg_Gezi_Sgow(false);
  */


    }
   
    On_Tankuang_Real_Exit()
    {
        this.OnBtnExit();
    }
   
    OnBtnExit()
    {
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(12,false);
        MiddleGamePlatformAction.GetInstance().Set_SanXiaoxiao_GoumaiDaouju_Dlg_Gezi_Sgow(false);
  
        this.node.destroy()
        if(this.m_callback)
        {
            this.m_callback(0);
        }
    }

    SetInfo(pinfo)
    {
        this.m_callback = pinfo.callback;

        this.m_idaojutype = pinfo.idaojutype;

        this.m_isubgametype  = pinfo.isubgametype;

        this.m_tiaozhan_all_can_skill_count = pinfo.tiaozhan_all_can_skill_count;

        this.m_tiaozhan_skill_use_count = pinfo.tiaozhan_skill_use_count;
        this.m_bTiaozhanchang = pinfo.bTiaozhanchang;

        if(pinfo.not_show_get_jiangli_dlg)
        {
            this.m_b_not_show_get_jiangli_dlg = pinfo.not_show_get_jiangli_dlg;

        }
  
 
        this.Refresh_Info(); 

        MiddleGamePlatformAction.GetInstance().Set_SanXiaoxiao_GoumaiDaouju_Dlg_Gezi_Sgow(true);

        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(12,true);
        MiddleGamePlatformAction.GetInstance().Hide_Other_In_Game_Dlg_Gezi_Show(9);
    }
    Refresh_Info()
    {
        var icon_node = cc.find("panel/center/icon",this.node);
        var info_node = cc.find("panel/center/info",this.node);
        var title_node = cc.find("panel/bg/title",this.node);
 

        var center_c_node = cc.find("panel/center/c",this.node);
 
        
        BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("resources",icon_node,"daoju/com/"+this.m_idaojutype,{width:80,height:80})
          
        var icangetc = 2;
        var cost_jinbi = 200;

        var swuping = "花朵";

        if(GlobalConfig.GetIns().m_enter_mode == 4 || GlobalConfig.GetIns().m_enter_mode == 5)
        {
            swuping = "怪兽";
        }

        var str_add_tion_addstr = "";

        if(this.m_tiaozhan_all_can_skill_count > 0 && this.m_bTiaozhanchang )
        {
            var ileft_can_use_count = this.m_tiaozhan_all_can_skill_count - this.m_tiaozhan_skill_use_count;

            if(ileft_can_use_count <= 0)
            {
               ileft_can_use_count=  0;
            }

              str_add_tion_addstr = "\n(本次挑战剩余"+ileft_can_use_count+"/"+this.m_tiaozhan_all_can_skill_count+"次)";

        }

        
        if(this.m_idaojutype  == 24)
        {
            title_node.getComponent(cc.Label).string = "刷新";
            info_node.getComponent(cc.Label).string = "试试这个道具，重置"+swuping+"位置" + str_add_tion_addstr;
            icangetc = 1;
        
            cost_jinbi = 200;
        }
        else if(this.m_idaojutype  == 21)
        {
            title_node.getComponent(cc.Label).string = "提示";
            info_node.getComponent(cc.Label).string = "试试这个道具，消除3个"+swuping  + str_add_tion_addstr;
        } 
        else if(this.m_idaojutype  == 22)
        {
            title_node.getComponent(cc.Label).string = "刷子";
            info_node.getComponent(cc.Label).string = "试试这个道具，变换9个"+swuping  + str_add_tion_addstr;
            icangetc = 1;
        
            cost_jinbi = 200;
        }else if(this.m_idaojutype  == 23)
        {
            title_node.getComponent(cc.Label).string = "冰冻";
            info_node.getComponent(cc.Label).string = "试试这个道具，冻结30秒" + str_add_tion_addstr;

        }else if(this.m_idaojutype  == 51)
        {
            title_node.getComponent(cc.Label).string = "回撤";
            info_node.getComponent(cc.Label).string = "试试这个道具，撤回最近一次动作" + str_add_tion_addstr;

            icangetc = 1;
        
            cost_jinbi = 200;
        }else if(this.m_idaojutype  == 52)
        {
            title_node.getComponent(cc.Label).string = "刷新";
            info_node.getComponent(cc.Label).string = "试试这个道具，刷新所有螺丝" + str_add_tion_addstr;
            icangetc = 1;
        
            cost_jinbi = 200;
        }else if(this.m_idaojutype  == 53)
        {
            title_node.getComponent(cc.Label).string = "调整";
            info_node.getComponent(cc.Label).string = "试试这个道具，调整任意一个螺丝位置" + str_add_tion_addstr;
            icangetc = 1;
        
            cost_jinbi = 200;
        }



        center_c_node.getComponent(cc.Label).string = "x"+icangetc;

        var jinbigoumai_c_node = cc.find("panel/center/jinbigoumai/c",this.node);
        jinbigoumai_c_node.getComponent(cc.Label).string = ""+cost_jinbi;
        

        
        var cur_jinbi_c = GlobalConfig.GetIns().Get_Self_DestType_Daoju_Count(1);
        var addjinbi_c_node = cc.find("panel/top/addjinbi/c",this.node);
        addjinbi_c_node.getComponent(cc.Label).string = ""+cur_jinbi_c;
    

        
    }
    
}
