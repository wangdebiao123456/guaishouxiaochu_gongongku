import ComFunc from "../../comfuncs/ComFunc";
import WatchVideoAdveseMng from "../../comfuncs/WatchVideoAdveseMng";
import GlobalConfig from "../GlobalConfig";

 

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class guoguang_jiangli_dlg extends cc.Component {

    m_b_selected = 0;
   
    m_xingxing = 0;
    m_callback = null;
    m_gk = 1;
    m_huakuai_x = -200;

    m_cur_beishu = 2;

    m_fx =  1;


    m_speed = 300;


    @property(cc.Node)
    m_huakuai_node = null;
    
    onLoad () 
    {
        var lingqubtn = cc.find("panel/menu/lingqubtn",this.node)
        lingqubtn.on("click",this.OnBtnLingqu.bind(this))
        
        var nextbtn = cc.find("panel/menu/nextbtn",this.node)
        nextbtn.on("click",this.OnBtnNext.bind(this))
        

        var tishi_node = cc.find("panel/jindu/tishi",this.node);

        var pseq = cc.sequence(cc.scaleTo(0.5,1.1),cc.scaleTo(0.5,1))
        tishi_node.runAction(cc.repeatForever(pseq))

 
    }
    RealLingqu(ibeishu)
    {
        var awrad = [
            {
                "t":2,
                "c": this.m_xingxing
            }
        ]
        GlobalConfig.GetIns().Common_Add_Award_List(awrad,ibeishu);
    
        var self = this;

        
        if(ibeishu > 1)
        {
            ComFunc.Open_Get_Daoju_Award_Dlg(this.node, awrad, ibeishu, ()=>
            {
                self.node.destroy();

                if(self.m_callback)
                {
                    self.m_callback(ibeishu);
                }
            });


        }else{

            this.node.destroy();

            if(this.m_callback)
            {
                this.m_callback(ibeishu);
            }
        }


    }
    OnBtnNext()
    {
        if(this.m_b_selected)
        {
            return;
        }
        this.m_b_selected = 1;
        this.RealLingqu(1);
              
    }
    OnBtnLingqu()
    {
        if(this.m_b_selected)
        {
            return;
        }
        this.m_b_selected = 1;

        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node,
            ()=>
            {
            
            },
            
            "过关奖励",(bsuc)=>
        {
            if(!bsuc)
            {
                self.RealLingqu(1);
                return;
            }


            self.RealLingqu(self.m_cur_beishu);

        });
    }

    SetInfo(pinfo)
    {
        this.m_callback = pinfo.callback;
        this.m_xingxing = pinfo.xingxing;
        this.m_gk = pinfo.gk;

        this.Refresh_Info();
    }
    Refresh_Info()
    {
        var xingxing_label = cc.find("panel/xingxing",this.node)
        xingxing_label.getComponent(cc.Label).string = ""+this.m_xingxing;

        var nextc = GlobalConfig.GetIns().Get_Next_Can_Lingqu_BX_Xingxing_Count();

        var ixingxingc = GlobalConfig.GetIns().Get_Self_DestType_Daoju_Count(2);

        var jindu_c_label = cc.find("panel/jindu/c",this.node)
        jindu_c_label.getComponent(cc.Label).string =  ixingxingc +"/"+nextc;
 
        var iprogress = 1;
        if(ixingxingc < nextc)
        {
            iprogress = ixingxingc/nextc;
        }
        var jindu_bar = cc.find("panel/jindu/jindu_bar",this.node)
        jindu_bar.getComponent(cc.Sprite).fillRange = iprogress;

        
        var icon_baoxiang_hongdian = cc.find("panel/jindu/icon_baoxiang/hongdian",this.node)
        icon_baoxiang_hongdian.active = false;

        var jindu_tishi = cc.find("panel/jindu/tishi",this.node)
        jindu_tishi.active = false;

        var jindu_tishi_tip = cc.find("panel/jindu/tishi/tip",this.node)
    
        var bfirst_one = 0;
      //  if(GlobalConfig.GetIns().m_enter_mode == 2)

      /*
        {
            if(this.m_gk == 1)
            {
                bfirst_one = 1;
                jindu_tishi.active = true;
                jindu_tishi_tip.getComponent(cc.Label).string = "集满星星可在大厅领取宝箱奖励";

            }
        }

        */
             
     
        var next_lingqu_xingxing = GlobalConfig.GetIns().Get_Next_Can_Lingqu_BX_Xingxing_Count();
        var xingxing_count = GlobalConfig.GetIns().Get_Self_DestType_Daoju_Count(2);
    
 

        var beed_roatte = 0;

        if(!bfirst_one)
        {
         
            var can_add_xingxing = this.m_xingxing ;
            
            if(can_add_xingxing < 10)
            {
                can_add_xingxing = 10;
            } 


            if(xingxing_count >= next_lingqu_xingxing)
            {
                icon_baoxiang_hongdian.active = true;

                jindu_tishi.active = true;
                jindu_tishi_tip.getComponent(cc.Label).string = "宝箱已集满,大厅领取宝箱奖励";
                beed_roatte = 1;
            
            }else if(xingxing_count + can_add_xingxing >= next_lingqu_xingxing)
            {
                jindu_tishi.active = true;
                jindu_tishi_tip.getComponent(cc.Label).string = "星星宝箱即将集满";
                beed_roatte = 1;

            }

        }
    
        if(beed_roatte)
        {
            var icon_baoxiang = cc.find("panel/jindu/icon_baoxiang",this.node);

            var animate_node = cc.find("panel/animate_node",this.node);
 
            animate_node.stopAllActions();
            icon_baoxiang.angle  = 0;
         
            var pseq = cc.sequence(cc.targetedAction(icon_baoxiang,cc.rotateTo(0.1,-20)),
                 cc.targetedAction(icon_baoxiang,cc.rotateTo(0.2,20)),
                 cc.targetedAction(icon_baoxiang,cc.rotateTo(0.2,-20)),
                 cc.targetedAction(icon_baoxiang,cc.rotateTo(0.2,20)),
                 cc.targetedAction(icon_baoxiang,cc.rotateTo(0.2,-20)),
                 cc.targetedAction(icon_baoxiang,cc.rotateTo(0.1, 0)),
              
                 cc.delayTime(3)
            )

            animate_node.runAction(cc.repeatForever(pseq))
    
        }
    }


    update(dt)
    {
        if(this.m_b_selected)
        {
            return;
        }

        var movex = this.m_fx*this.m_speed*dt;

        this.m_huakuai_x += movex;

        if(this.m_huakuai_x > 210)
        {
            this.m_huakuai_x  = 210;
            this.m_fx = -1;
        }
        else if(this.m_huakuai_x  < -210)
        {
            this.m_huakuai_x  = -210;
            this.m_fx = 1;
        }


        this.m_huakuai_node.x =  this.m_huakuai_x;

        var ibeishu =  2;
        if(this.m_huakuai_x < 0)
        {
            ibeishu =  2;
        }
        else if(this.m_huakuai_x < 100)
        {
            ibeishu =  3;
        }else if(this.m_huakuai_x < 170)
        {
            ibeishu =  4;
        }else{
            ibeishu =  5;
        }

        this.m_cur_beishu = ibeishu;

        var lignqu_beishu  = cc.find("panel/menu/lingqubtn/c",this.node);
        
       

    lignqu_beishu.getComponent(cc.Label).string = "x"+ibeishu+"领取"


        var xx_c_label  = cc.find("panel/top/addxingxing/c",this.node);
        
        xx_c_label.getComponent(cc.Label).string =  ""+ GlobalConfig.GetIns().Get_Self_DestType_Daoju_Count(2);


        
    }
    
}
