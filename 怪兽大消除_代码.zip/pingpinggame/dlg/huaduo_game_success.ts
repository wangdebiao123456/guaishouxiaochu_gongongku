import SoundManager from "../../comfuncs/SoundManager";
import GlobalGameMng from "../../Mng/GlobalGameMng";
import MiddleGamePlatformAction from "../../PlatForm/MiddleGamePlatformAction"; 
import BannerGuangaoMng from "../../WDT/BannerGuangaoMng";
import GlobalConfig from "../GlobalConfig";

 
 
 
const {ccclass, property} = cc._decorator;

@ccclass
export default class huaduo_game_success extends cc.Component {

    
    
    m_fenshu = 0;

    m_start_tick = 0;

    m_start_sound_played = 0;

    m_animate_end = 0;
    m_gk = 1;


    onLoad () 
    {

        this.m_start_tick = Date.now();

        var okbtn = cc.find("panel/okbtn",this.node)
        okbtn.on("click",this.OnBtnOk.bind(this));


        var exitbtn = cc.find("panel/exitbtn",this.node)
        exitbtn.on("click",this.OnBtnExit.bind(this));

      //  var tishi_node = cc.find("exitbtn/tishi",this.node);

      //  var pseq = cc.sequence(cc.scaleTo(0.5,1.1),cc.scaleTo(0.5,1))
      //  tishi_node.runAction(cc.repeatForever(pseq))

   
        SoundManager.GetInstance().Play_Effect("huaduoppingping/jbibianhua");
        this.Refresh_Info();
        
        BannerGuangaoMng.GetInstance().CheckShowChaiping(12);
    }
    OnBtnExit()
    {
        cc.director.loadScene("dating");

        
        SoundManager.GetInstance().Play_Click_Btn_Effect();
    }
    SetInfo(pinfo)
    {
        this.m_fenshu = pinfo.fenshu;
        this.m_gk = pinfo.gk;

        var ibeishu = pinfo.ibeishu;

        if(ibeishu == 1)
        {
            SoundManager.GetInstance().Play_Effect("com/huoquwuping");

        }
      

        MiddleGamePlatformAction.GetInstance().Set_Show_Game_End_Tankuang_Index(0);
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(3,false);

        MiddleGamePlatformAction.GetInstance().Hide_Other_In_Game_Dlg_Gezi_Show(6);

        GlobalConfig.GetIns().Add_Cunqian_Guan_Money(this.m_fenshu);

    }

    OnBtnOk()
    {
     

        GlobalConfig.GetIns().Enter_Game_Mode(GlobalConfig.GetIns().m_enter_mode)
        cc.director.loadScene("huaduo_xiaoxiao");

        
        SoundManager.GetInstance().Play_Click_Btn_Effect();
    }

    
    
    Refresh_Info()
    {
        var maxfen = cc.find("panel/info/maxfen",this.node)
        maxfen.getComponent(cc.Label).string = GlobalConfig.GetIns().m_max_jifen+"";



        var okbtn = cc.find("panel/okbtn",this.node)
    
        var exitbtn = cc.find("panel/exitbtn",this.node);

        var tishi = exitbtn.getChildByName("tishi");
        tishi.active = false;

        
        var exit_hongdian = exitbtn.getChildByName("hongdian");
         
        exit_hongdian.active = false;


        
        var jinbi_c_label = cc.find("panel/top/addjinbi/c",this.node);
        jinbi_c_label.getComponent(cc.Label).string = ""+GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(1)


        var xx_c_label = cc.find("panel/top/addxingxing/c",this.node);
        xx_c_label.getComponent(cc.Label).string = ""+GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(2)


        /*
         if(GlobalConfig.GetIns().m_enter_mode == 2 )
         {
            var igk = this.m_gk ;

            var gk_jiesuo_wanfa = GlobalConfig.GetIns().Find_Gk_Jiesuo_Wanfa_Name(igk);

            if(gk_jiesuo_wanfa)
            {
                exit_hongdian.active = true;
                tishi.getChildByName("tip").getComponent(cc.Label).string = gk_jiesuo_wanfa+"玩法已解锁";
                tishi.active = true;

                GlobalConfig.GetIns().m_last_win_not_show_jiesuo_wanfa_gk = igk
            }

               
 
         }
         */

         var maxfen = cc.find("panel/info/maxfen",this.node)
         maxfen.getComponent(cc.Label).string = ""+GlobalConfig.GetIns().m_max_jifen;
    }

    update(dt)
    {
        if(this.m_start_tick == 0)
        {
            return;
        }
        if(this.m_animate_end)
        {
            return;
        }

        var allneedtick = 800 ;
      

        var eplasetick = Date.now() - this.m_start_tick;


      
        var fenshu = cc.find("panel/info/fenshu",this.node)
      
        if(eplasetick >= allneedtick)
        {
             fenshu.getComponent(cc.Label).string = ""+this.m_fenshu;
      
             this.m_animate_end = 1;


             SoundManager.GetInstance().Play_Effect("huaduoppingping/end_jb_change");

            return;
        }

        var change_c =   Math.floor( this.m_fenshu*(eplasetick/allneedtick) );
        var scinfo = change_c ;
        fenshu.getComponent(cc.Label).string = ""+scinfo;
     

    }
}
