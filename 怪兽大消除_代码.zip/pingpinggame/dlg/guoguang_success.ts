import BaseUIUtils from "../../comfuncs/BaseUIUtils";
import BundleLoadUtils from "../../comfuncs/BundleLoadUtils";
import ComFunc from "../../comfuncs/ComFunc";
import WatchVideoAdveseMng from "../../comfuncs/WatchVideoAdveseMng";
import GlobalGameMng from "../../Mng/GlobalGameMng";
import BannerGuangaoMng from "../../WDT/BannerGuangaoMng";
import GlobalConfig from "../GlobalConfig";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class guoguang_success extends cc.Component {
 

    m_money = 0;
    m_xingxing = 0;
    m_callback = null;
    m_gk = 1;

    m_b_selected = 0;

    m_hide_sanbei_tankuang = 0;

    m_guoguang_jl = [];

    m_isubgametype = 0;
    
    onLoad () 
    {

        var lingqubtn = cc.find("panel/menu/lingqubtn",this.node)
        lingqubtn.on("click",this.OnBtnLingqu.bind(this))
        
        var nextbtn = cc.find("panel/menu/nextbtn",this.node)
        nextbtn.on("click",this.OnBtnNext.bind(this))
       
        BannerGuangaoMng.GetInstance().CheckShowChaiping(9);

    }
    SetInfo(pinfo)
    {
        this.m_callback = pinfo.callback;
       // this.m_xingxing = pinfo.xingxing;
       // this.m_money  = pinfo.money;

       this.m_guoguang_jl  = pinfo.guoguang_jl;

       this.m_isubgametype = pinfo.isubgametype;

        this.m_gk = pinfo.gk;

        this.m_hide_sanbei_tankuang = pinfo.hide_sanbei_tankuang;

        this.Refresh_Info();
    }
    OnBtnNext()
    {
        if(this.m_b_selected)
        {
            return;
        }
        this.m_b_selected = 1;
        this.RealLingqu(1);
              
    }
    RealLingqu(ibeishu)
    {
        var awrad = [

            {
                "t":1,
                "c": this.m_money
            },
            {
                "t":2,
                "c": this.m_xingxing
            }
        ]
        GlobalConfig.GetIns().Common_Add_Award_List(awrad,ibeishu);
    
        var self = this;

        
        if(ibeishu > 1  && !this.m_hide_sanbei_tankuang)
        {
            ComFunc.Open_Get_Daoju_Award_Dlg(this.node, awrad, ibeishu, ()=>
            {
                self.node.destroy();

                if(self.m_callback)
                {
                    self.m_callback(ibeishu);
                }
            });


        }else{

            this.node.destroy();

            if(this.m_callback)
            {
                this.m_callback(ibeishu);
            }
        }


    }
    OnBtnLingqu()
    {
        if(this.m_b_selected)
        {
            return;
        }
        this.m_b_selected = 1;

        var game_Type_name = GlobalGameMng.GetInstance().Get_Game_Type_Name(this.m_isubgametype);
 
        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node,
            ()=>
            {
            
            },
            
            "过关奖励双倍",(bsuc)=>
        {
            if(!bsuc)
            {
                self.m_b_selected = 0;

                BaseUIUtils.ShowTipTxtDlg("观看视频失败",self.node);
               // self.RealLingqu(1);
                return;
            }


            self.RealLingqu(3);

        },"","",null,game_Type_name+"过关双倍,第"+this.m_gk+"关");
    }


    Refresh_Info()
    {
       // var wuping_1_c_label = cc.find("panel/wuping/1/c",this.node);
      //  wuping_1_c_label.getComponent(cc.Label).string = "x"+this.m_money;


      //  var wuping_2_c_label = cc.find("panel/wuping/2/c",this.node);
      //  wuping_2_c_label.getComponent(cc.Label).string = "x"+this.m_xingxing;



        for(var ff=1;ff<=2;ff++)
        {
            var wuping_ff_node = cc.find("panel/wuping/"+ff,this.node);

            if(ff > this.m_guoguang_jl.length)
            {
                wuping_ff_node.active = false;
            }else{
                wuping_ff_node.active = true;

                var ff_jl = this.m_guoguang_jl[ff-1];
                var ff_t=  ff_jl.t;
                var ff_c=  ff_jl.c;
                
                wuping_ff_node.getChildByName("c").getComponent(cc.Label).string = "x"+ff_c;
                var icon_node = wuping_ff_node.getChildByName("icon");

                var icon_sfilename = GlobalGameMng.GetInstance().Get_Aawrd_Daoju_Icon(ff_t);
                BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("resources",icon_node,icon_sfilename,{width:80,height:80})
            }
     
        }

        if(this.m_guoguang_jl.length  == 1)
        {
            var wuping_1_node = cc.find("panel/wuping/"+1,this.node);
            wuping_1_node.x = 0;
        }

        
        var jinbi_c_label = cc.find("panel/top/addjinbi/c",this.node);
        jinbi_c_label.getComponent(cc.Label).string = ""+GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(1)


        var xx_c_label = cc.find("panel/top/addxingxing/c",this.node);
        xx_c_label.getComponent(cc.Label).string = ""+GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(2)


       
        
    }
}
