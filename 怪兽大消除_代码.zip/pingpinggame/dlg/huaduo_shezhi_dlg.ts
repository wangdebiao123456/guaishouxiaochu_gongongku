import SoundManager from "../../comfuncs/SoundManager";
import tankuang from "../../dlg/tankuang";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class huaduo_shezhi_dlg extends cc.Component {

   
    

    m_callback = null;
    
    
    onLoad () 
    {
        var guangbibtn = cc.find("panel/menu/guangbibtn",this.node)
       // guangbibtn.on("click",this.OnBtnExit.bind(this))
    
        
        var fanhuibtn = cc.find("panel/menu/fanhuibtn",this.node)
        fanhuibtn.on("click",this.OnBtnGoback.bind(this))
     

        var chonglaibtn = cc.find("panel/menu/chonglaibtn",this.node)
        chonglaibtn.on("click",this.OnBtnChonglai.bind(this))
     
 
        
        var fenxiangbtn = cc.find("panel/menu/fenxiangbtn",this.node)
        fenxiangbtn.on("click",this.OnBtnFenXiang.bind(this))
     
       
   
        var slider_sound = cc.find("panel/yliang/slider_sound",this.node);
        slider_sound.on('slide', this.OnSliderSound, this); 


         

        var slider_music = cc.find("panel/yliang/slidermusic",this.node);
        slider_music.on('slide', this.OnSliderMusic, this); 


        this.Refresh_Info();
 
        var tankuang:tankuang = this.node.getComponent("tankuang");
        tankuang.Set_Close_Lisnter(this);

        SoundManager.GetInstance().Play_Click_Btn_Effect();
    }
    OnSliderMusic(tg){
        //this.pro_music.progress = tg.progress;
      //  this.m_SoundMgr.SetBackGroundMusicVolum(tg.progress);

        var iprogress = Number(tg.progress);
        var prig = cc.find("panel/yliang/slidermusic/progress",this.node);
        prig.getComponent(cc.Sprite).fillRange = iprogress;
        
        SoundManager.GetInstance().SetBackGroundMusicVolum(iprogress);
    }
    
    OnSliderSound(tg)
    {
       // this.pro_sound.progress = tg.progress;
        //this.m_SoundMgr.SetEffectSoundVolum(tg.progress);
            var iprogress = Number(tg.progress);
            var prig = cc.find("panel/yliang/slider_sound/progress",this.node);
            prig.getComponent(cc.Sprite).fillRange = iprogress;
            
            SoundManager.GetInstance().SetEffectSoundVolum(iprogress);

    }
    OnBtnFenXiang()
    {
        wx.shareAppMessage({
            title: "怪兽大消除,日常休闲玩玩这款好玩的游戏"
          });
       // PlatFormMng.GetInstance().Share_Msg("彩色幻想","日常休闲玩玩这款好玩的游戏")
    }
    On_TK_Real_Exit()
    {
        this.OnBtnExit();
    }
    On_Tankuang_Real_Exit()
    {
        this.OnBtnExit(); 
    }
    OnBtnZhengdongKaiguang()
    {
       
        

        this.Refresh_Info();
        SoundManager.GetInstance().Play_Click_Btn_Effect();
    }
    OnBtnSoundKaiguang()
    {
      

        this.Refresh_Info();

        SoundManager.GetInstance().Play_Click_Btn_Effect();
    }
    OnBtnExit()
    {
        this.node.destroy();

        if(this.m_callback)
        {
            this.m_callback();
        }

        SoundManager.GetInstance().Play_Click_Btn_Effect();
    }
    SetInfo(pinfo)
    {
        this.m_callback = pinfo.callback;

    }

    OnBtnGoback()
    {
       
        cc.director.loadScene("dating");
        SoundManager.GetInstance().Play_Click_Btn_Effect();
    }

    OnBtnChonglai()
    {

        //GlobalConfig.GetIns().Clear_Cur_Mode_Save_Game_Shuju();

        cc.director.loadScene("huaduo_xiaoxiao");
        SoundManager.GetInstance().Play_Click_Btn_Effect();
    }

    Refresh_Info()
    {
        var btn1_unchecked = cc.find("panel/menu/btn1/unchecked",this.node)
        var btn1_checked = cc.find("panel/menu/btn1/checked",this.node)
    
        var btn2_unchecked = cc.find("panel/menu/btn2/unchecked",this.node)
        var btn2_checked = cc.find("panel/menu/btn2/checked",this.node)
     


        var slider_sound = cc.find("panel/yliang/slider_sound",this.node);
        slider_sound.getComponent(cc.Slider).progress = SoundManager.GetInstance().GetEffectSoundVolum();

        

        var slider_sound_progress = cc.find("panel/yliang/slider_sound/progress",this.node); 
        slider_sound_progress.getComponent(cc.Sprite).fillRange = SoundManager.GetInstance().GetEffectSoundVolum();
    

        var slider_music = cc.find("panel/yliang/slidermusic",this.node); 
        slider_music.getComponent(cc.Slider).progress = SoundManager.GetInstance().GetBackGroundMusicVolum();


        var slider_music_progress = cc.find("panel/yliang/slidermusic/progress",this.node); 
        slider_music_progress.getComponent(cc.Sprite).fillRange = SoundManager.GetInstance().GetBackGroundMusicVolum();
        


    }
}
