 
const {ccclass, property} = cc._decorator;

@ccclass
export default class huaban_suikai extends cc.Component {

 
    
    
    m_wk_color = cc.color(255,215,0)
    m_wk_color_index = 0; 
    
    onLoad () 
    {

    }
    SetInfo(paradata)
    {
        this.m_wk_color_index = paradata.wk_color_index;
        this.m_wk_color = paradata.wk_color;

        var baise_node = cc.find("particle/baise",this.node);
        var para_systerm =  baise_node.getComponent(cc.ParticleSystem)
        para_systerm.resetSystem();


        var end_aplha = 20;
        para_systerm.startColor =   cc.color(this.m_wk_color.r,this.m_wk_color.g,this.m_wk_color.b,255);
        para_systerm.endColor =  cc.color(this.m_wk_color.r,this.m_wk_color.g,this.m_wk_color.b,end_aplha);




        /*
        this.m_wk_color_index = paradata.wk_color_index;

        var baise_node = cc.find("particle/baise",this.node);
        var para_systerm =  baise_node.getComponent(cc.ParticleSystem)
        para_systerm.resetSystem();


        var end_aplha = 20;

        if(this.m_wk_color_index == 1)
        {
          
        para_systerm.startColor =   cc.color(204,0,9,255);
        para_systerm.endColor = cc.color(230,10,39,end_aplha);
        } 
        else  if(this.m_wk_color_index == 2)
        {
            para_systerm.startColor =   cc.color(255,212,43,255);
            para_systerm.endColor =   cc.color(255,212,43,end_aplha);
 
        }  else  if(this.m_wk_color_index == 3)
        {
            para_systerm.startColor =   cc.color(255,186,176,255);   
             para_systerm.endColor =   cc.color(255,186,176,end_aplha);
 
        }else  if(this.m_wk_color_index == 4)
        {
            para_systerm.startColor =  cc.color(217,174,224,255);
            para_systerm.endColor =   cc.color(217,174,224,end_aplha);
        }
        else  if(this.m_wk_color_index == 5)
        {
            para_systerm.startColor =   cc.color(230,234,247,255);
            para_systerm.endColor =  cc.color(230,234,247,end_aplha);
        } else  if(this.m_wk_color_index == 6)
        {
            para_systerm.startColor =   cc.color(195,113,56,255);
            para_systerm.endColor =  cc.color(195,113,56,end_aplha);
        }else  if(this.m_wk_color_index == 7)
        {
            para_systerm.startColor =   cc.color(2,148,255,255);
            para_systerm.endColor =  cc.color(2,148,255,end_aplha);
        }



        */
         
    }
    
}
