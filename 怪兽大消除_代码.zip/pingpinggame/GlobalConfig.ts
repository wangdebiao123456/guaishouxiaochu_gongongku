import ComFunc from "../comfuncs/ComFunc"; 
import SoundManager from "../comfuncs/SoundManager";
import GlobalGameMng from "../Mng/GlobalGameMng";
import User_Info_Mng from "../utils/User_Info_Mng";
import Util from "../utils/Util";
import MyLocalStorge from "../WDT/MyLocalStorge"; 
import WMap from "../WDT/WMap";

 

export class Huayuan_Di_Hua_State
{
    Get_Saved_Info(diindex)
    {
        var star = {
            di_index:diindex,
            hua_state:this.hua_state,
            hua_state_total_need_sec:this.hua_state_total_need_sec,
            hua_state_elapse_sec:this.hua_state_elapse_sec
        }

        return star;
    }
    static Parse_From(tt_info)
    {
        if(!tt_info)
        {
            return null;
        }
        var hua_state=  tt_info.hua_state;
        if(!hua_state)
        {
            return null;
        }
        var hua_state_total_need_sec=  tt_info.hua_state_total_need_sec;
        var hua_state_elapse_sec=  tt_info.hua_state_elapse_sec;
    
        var stateinfo = new Huayuan_Di_Hua_State();
        stateinfo.hua_state = hua_state;
        stateinfo.hua_state_total_need_sec = hua_state_total_need_sec;
        stateinfo.hua_state_elapse_sec = hua_state_elapse_sec;


        return stateinfo;

    }
    //1:种子，2：发芽，3：花朵积累金币，4：积累金币成功
    hua_state = 1;
    hua_state_total_need_sec = 300;
    hua_state_elapse_sec = 0;
}


export default class GlobalConfig
{
    public static  m_ins:GlobalConfig = null;

    public static GetIns()
    {
        if(GlobalConfig.m_ins == null)
        {
            GlobalConfig.m_ins  =  new GlobalConfig();
        }

        return GlobalConfig.m_ins;
    }
    m_b_first_libao_dlg_poped = 0;
    m_b_first_sign_dlg_poped=  0;

    m_pingping_huaduo_sprite_frame_list = [];
    m_pingping_dongwu_sprite_frame_list = [];


    m_all_in_bag_daoju_type_leftcount_map = new WMap();
    m_sound_opend = 1;
    m_zhengdong_opend = 1;

    m_max_jifen = 0;
 

    m_total_shiping_count =0;

    m_xingyun_libao_start_tick  = 0;
    m_xingyun_libao_lingqued = 0;

    m_cunqianguan_monmey = 0;

    m_max_win_gk = 0;

    m_max_winnied_tiaozhanchang_gk = 0;


    m_max_win_guaishou_gk = 0;

    m_queryed_other_user_nick_touxiang_info_map =  new WMap();

    m_zhuanpan_zuanshi_shiping_count=  0;
    m_cur_day_zhuanpan_action_index = 0;
    m_last_zhuanpan_zuanshi_jiangli_lingqu_day_union = 0;
    m_last_zhuanpan_action_day_union = 0;

    m_last_yaoqianshu_yaoqian_day_union = 0;
    m_yaoqianshu_today_count = 0;


    m_last_lingqued_bx_guoguang_gk = 0;
    m_last_lingqued_bx_xingxing = 0;
    m_last_lingqued_bx_shiping_count = 0;

    m_game_config = null;

    m_enter_mode = 1;
    m_enter_mode_gk = 1;



    //梦幻花园level
    m_menghuan_huayuan_level = 0;

    m_yingdao_finished = 0;
    m_b_yingdao = 0;
    m_yd_finished_gk = 0;


    //存钱罐取款数目
    m_cunqianguan_qukuang_count = 0;


    m_tiaozhan_mode_max_jifen = 0;



    m_bozhong_hua_jiesuoed_map = new WMap();
    m_bozhong_hua_count_map = new WMap();

    m_huayuan_di_index_hua_type_map = new WMap();
    m_huayuan_di_index_hua_state_info_map = new WMap();


    m_last_save_mode1_info = null;
    m_last_save_mode2_info = null;
    m_huayuan_lisnter  = null;


    //1:花朵，2：怪兽
    m_xiaoxiao_game_show_wuping_type = 1;


    m_last_win_not_show_jiesuo_wanfa_gk = 0;

    constructor()
    {

        this.Init_Read_All_Save_Info();

    }
    Set_Show_WupingType(wupingtype)
    {

        this.m_xiaoxiao_game_show_wuping_type = wupingtype;
    }
    Set_Huayuan_Lisnter(pp)
    {
        this.m_huayuan_lisnter = pp;

    }

    Get_Bozhong_State_Need_Sec(istate)
    {
         
        var inedssec = 300;
        if(istate == 1)
        {
            inedssec =   300;
        } 
        else if(istate == 2)
        {
            inedssec =   60*60;
        }else if(istate == 3)
        {
            inedssec =   10*60;
        }else if(istate == 4)
        {
            inedssec =   1;
        }

        return inedssec;
    }

    Set_Bozhong_Zhongzi_State_Change_To(diindex,inewstate)
    {
        var old_state = this.Get_Huayuan_Di_State(diindex);
        var old_state_status = 0;
        if(old_state)
        {
            old_state_status  = old_state.hua_state;
        }

        var pstate = new Huayuan_Di_Hua_State();
        pstate.hua_state = inewstate;
        pstate.hua_state_elapse_sec = 0;

        var inedssec = this.Get_Bozhong_State_Need_Sec(inewstate)
       
        pstate.hua_state_total_need_sec = inedssec;

        
        this.m_huayuan_di_index_hua_state_info_map.putData(diindex,pstate);
              

        if(this.m_huayuan_lisnter)
        {
            this.m_huayuan_lisnter.Notify_Huayuan_Zhongzi_Di_State_Change(diindex,old_state_status,inewstate);
        }
    }
    Get_Huayuan_Di_State(iidnex):Huayuan_Di_Hua_State
    {
        if(this.m_huayuan_di_index_hua_type_map.hasKey(iidnex))
        {

            if(!this.m_huayuan_di_index_hua_state_info_map.hasKey(iidnex))
            {
                var pstate = new Huayuan_Di_Hua_State();
                

                this.m_huayuan_di_index_hua_state_info_map.putData(iidnex,pstate);
            }
        }

        var old_stte = this.m_huayuan_di_index_hua_state_info_map.getData(iidnex);
        return old_stte;
    }
    Change_Huayuan_Di_Hua(di_index1,di_index2)
    {
        if(di_index1 == di_index2)
        {
            return;
        }
        var di_hua1 = 0;
        var di_hua2 = 0;
        

        if(this.m_huayuan_di_index_hua_type_map.hasKey(di_index1))
        {
            di_hua1 = this.m_huayuan_di_index_hua_type_map.getData(di_index1);
        } 
        
        if(this.m_huayuan_di_index_hua_type_map.hasKey(di_index2))
        {
            di_hua2 = this.m_huayuan_di_index_hua_type_map.getData(di_index2);
        }


        if(di_hua2 > 0)
        {
            this.m_huayuan_di_index_hua_type_map.putData(di_index1,di_hua2);

        }else{
            this.m_huayuan_di_index_hua_type_map.RemoveKey(di_index1);

        }
    

        if(di_hua1 > 0)
        {
            this.m_huayuan_di_index_hua_type_map.putData(di_index2,di_hua1)

        }else{
            this.m_huayuan_di_index_hua_type_map.RemoveKey(di_index2)

        }


        var state1 = this.m_huayuan_di_index_hua_state_info_map.getData(di_index1)
        var state2 = this.m_huayuan_di_index_hua_state_info_map.getData(di_index2)

        if(state1)
        {
            this.m_huayuan_di_index_hua_state_info_map.putData(di_index2,state1)
        }else{
            this.m_huayuan_di_index_hua_state_info_map.RemoveKey(di_index2)
        }

        if(state2)
        {
            this.m_huayuan_di_index_hua_state_info_map.putData(di_index1,state2)
        }else{
            this.m_huayuan_di_index_hua_state_info_map.RemoveKey(di_index1)
        }


    }
    On_YaoqianShu_Yaoqian()
    {
        if(this.m_last_yaoqianshu_yaoqian_day_union !=  ComFunc.GetCurDayUnion())
        {
            this.m_last_yaoqianshu_yaoqian_day_union = ComFunc.GetCurDayUnion();
            this.m_yaoqianshu_today_count = 0;
        
        }

        this.m_yaoqianshu_today_count++;
    }
    Clear_Hua_Count(hua_index)
    {
        this.m_bozhong_hua_count_map.RemoveKey(hua_index);
    }
    On_Bozhong_Hua(hua_index)
    {
        var prevc = 0;
        if(this.m_bozhong_hua_count_map.hasKey(hua_index))
        {
            prevc = this.m_bozhong_hua_count_map.getData(hua_index);
        }

        prevc--;
        if(prevc <= 0)
        {
            prevc = 0;
        }

        this.m_bozhong_hua_count_map.putData(hua_index, prevc);

        this.m_menghuan_huayuan_level = this.m_huayuan_di_index_hua_type_map.size()+1;


        var find_empty_index = 0;

        for(var ff=1;ff<= this.m_menghuan_huayuan_level;ff++)
        {
             if(!this.m_huayuan_di_index_hua_type_map.hasKey(ff))
             {
                find_empty_index = ff;
             }
        }

        this.m_huayuan_di_index_hua_type_map.putData(find_empty_index,hua_index);

        var pstate = new Huayuan_Di_Hua_State();
        pstate.hua_state = 1;
        pstate.hua_state_total_need_sec = this.Get_Bozhong_State_Need_Sec(1)
        pstate.hua_state_elapse_sec = 0;

        this.m_huayuan_di_index_hua_state_info_map.putData(find_empty_index,pstate)

        
        if(this.m_huayuan_lisnter)
        {
            this.m_huayuan_lisnter.Notify_Huayuan_Zhongzi_Di_State_Change(find_empty_index,0,1);
        }
    }

    Get_Bozhong_Hua_Count(iindex)
    {
        var prevc = 0;
        if(this.m_bozhong_hua_count_map.hasKey(iindex))
        {
            prevc = this.m_bozhong_hua_count_map.getData(iindex);
        }

        return prevc;
    }

    UnLock_And_Get_Bozhong_Hua(iindex)
    {
        this.m_bozhong_hua_jiesuoed_map.putData(iindex,1);

        var prevc = 0;
        if(this.m_bozhong_hua_count_map.hasKey(iindex))
        {
            prevc = this.m_bozhong_hua_count_map.getData(iindex);
        }
        this.m_bozhong_hua_count_map.putData(iindex,1+ prevc)

    }
    Add_CunqianGuan_QuKuang_Count()
    {

        this.m_cunqianguan_qukuang_count++;

      //  GameTaskMng.GetIns().Add_Meiri_Renwu_Item_TaskType_Finished_Count(8,1)
    }


    Get_Game_Mode_Enter_Gk(gamemode)
    {
        if(gamemode == 2)
        {
            return this.m_max_win_gk+1;
        } 

        if(gamemode == 4)
        {
            return this.m_max_win_guaishou_gk+1;
        }

        return this.m_max_win_gk+1;
    }

    Enter_Game_Mode(gamemode)
    {
        this.m_enter_mode = gamemode;
        if(gamemode == 2)
        {
            this.m_enter_mode_gk = this.m_max_win_gk+1;
        } 
        else if(gamemode == 4)
        {
            this.m_enter_mode_gk = this.m_max_win_guaishou_gk+1;
        }
        else{
            this.m_enter_mode_gk = 1;//this.m_max_winnied_tiaozhanchang_gk+1;
    
            
        }

        
    }

    On_Dating_Baoxiang_Jl_Lingqued(iindex)
    {
        if(iindex == 1)
        {
            var next_lingqu_guoguang_gk = GlobalConfig.GetIns().Get_Next_Can_Lingqu_BX_Gk_Count();

            this.m_last_lingqued_bx_guoguang_gk = next_lingqu_guoguang_gk;
        }
        else if(iindex == 2)
        {
            var next_lingqu_xingxing = GlobalConfig.GetIns().Get_Next_Can_Lingqu_BX_Xingxing_Count();

            this.m_last_lingqued_bx_xingxing = next_lingqu_xingxing;
             
        } 
        else if(iindex == 3)
        {
            var next_lingqu_shiping_c = GlobalConfig.GetIns().Get_Next_Can_Lingqu_BX_Shiping_Count();

            this.m_last_lingqued_bx_shiping_count = next_lingqu_shiping_c;
        }
    }
    Add_Watch_Success_Count()
    {
        this.m_total_shiping_count++;
    }

    Update_Zhongzi_Dt(dt)
    {
        var iszie = this.m_huayuan_di_index_hua_state_info_map.size();

        for(var ff=0;ff<iszie;ff++)
        {
            var ff_state:Huayuan_Di_Hua_State = this.m_huayuan_di_index_hua_state_info_map.GetEntryByIndex(ff);
            var ff_index = this.m_huayuan_di_index_hua_state_info_map.GetKeyByIndex(ff);

            if(!ff_state)
            {
                continue;
            }
            
            ff_state.hua_state_elapse_sec += dt;

            if(ff_state.hua_state_elapse_sec  >= ff_state.hua_state_total_need_sec)
            {

                if(ff_state.hua_state == 1 || ff_state.hua_state == 2 || ff_state.hua_state == 3)
                {
                    this.Set_Bozhong_Zhongzi_State_Change_To(ff_index,ff_state.hua_state +1)
                }

                /*
                if(ff_state.hua_state == 1)
                {
                    ff_state.hua_state  = 2;
                    ff_state.hua_state_elapse_sec = 0;
                    ff_state.hua_state_total_need_sec = this.Get_Bozhong_State_Need_Sec(2)
                }else if(ff_state.hua_state == 2)
                {
                    ff_state.hua_state  = 3;
                    ff_state.hua_state_elapse_sec = 0;
                    ff_state.hua_state_total_need_sec = this.Get_Bozhong_State_Need_Sec(3)
                }else if(ff_state.hua_state == 3)
                {
                    ff_state.hua_state  = 4;
                    ff_state.hua_state_elapse_sec = 0;
                    ff_state.hua_state_total_need_sec = this.Get_Bozhong_State_Need_Sec(4)
                }
                */

            }
        }
    }
    Update_Tick(dt)
    {
        if(this.m_last_zhuanpan_action_day_union != ComFunc.GetCurDayUnion())
        {
            this.m_cur_day_zhuanpan_action_index = 0;
            this.m_last_zhuanpan_action_day_union = ComFunc.GetCurDayUnion();
            this.m_zhuanpan_zuanshi_shiping_count = 0;
            this.m_last_zhuanpan_zuanshi_jiangli_lingqu_day_union = 0;
        }
        if(this.m_last_zhuanpan_zuanshi_jiangli_lingqu_day_union  > 0 && this.m_last_zhuanpan_zuanshi_jiangli_lingqu_day_union != ComFunc.GetCurDayUnion())
        {
            this.m_zhuanpan_zuanshi_shiping_count = 0;
            this.m_last_zhuanpan_zuanshi_jiangli_lingqu_day_union = 0;
        }


        if(this.m_last_yaoqianshu_yaoqian_day_union !=  ComFunc.GetCurDayUnion())
        {
            this.m_last_yaoqianshu_yaoqian_day_union = ComFunc.GetCurDayUnion();
            this.m_yaoqianshu_today_count = 0;
        
        }

        this.Update_Zhongzi_Dt(dt);
    }
    Add_Zhuanpan_Action()
    {
        if(this.m_last_zhuanpan_action_day_union != ComFunc.GetCurDayUnion())
        {
            this.m_cur_day_zhuanpan_action_index = 0;
        }
        this.m_cur_day_zhuanpan_action_index++;
        this.m_last_zhuanpan_action_day_union = ComFunc.GetCurDayUnion();


        if(this.m_last_zhuanpan_zuanshi_jiangli_lingqu_day_union  > 0 && this.m_last_zhuanpan_zuanshi_jiangli_lingqu_day_union != ComFunc.GetCurDayUnion())
        {
            this.m_zhuanpan_zuanshi_shiping_count = 0;
            this.m_last_zhuanpan_zuanshi_jiangli_lingqu_day_union = 0;
        }

        this.m_zhuanpan_zuanshi_shiping_count ++;


    }
    On_Zhuanpan_Zuanshi_Jl_Lingqued()
    {
        this.m_last_zhuanpan_zuanshi_jiangli_lingqu_day_union = ComFunc.GetCurDayUnion();
    }
    Get_Next_Can_Lingqu_BX_Shiping_Count()
    {
        if(this.m_last_lingqued_bx_shiping_count ==0 ){
            return 10;
        }

        var prevc = Math.floor(this.m_last_lingqued_bx_shiping_count /10);

        return (prevc+1)*10;

        /*
        if(this.m_last_lingqued_bx_shiping_count ==0 ){
            return 10;
        }

        var prevc = Math.floor(this.m_last_lingqued_bx_shiping_count /10);

        return (prevc+1)*10;
        */
    }
    Get_Next_Can_Lingqu_BX_Gk_Count()
    {
        if(this.m_last_lingqued_bx_guoguang_gk <=0 ){
            return 5;
        }  

        if(this.m_last_lingqued_bx_guoguang_gk <=5 ){
            return 10;
        }  
        if(this.m_last_lingqued_bx_guoguang_gk <=10 ){
            return 20;
        }  
        else if(this.m_last_lingqued_bx_guoguang_gk <=20 ){
            return 30;
        }   
        else if(this.m_last_lingqued_bx_guoguang_gk <=30 ){
            return 40;
        }else{
            
            var prevc = Math.floor(this.m_last_lingqued_bx_guoguang_gk /10);

            return (prevc+1)*10;
        }

        
        /*
        if(this.m_last_lingqued_bx_guoguang_gk ==0 ){
            return 20;
        }



        var prevc = Math.floor(this.m_last_lingqued_bx_guoguang_gk /20);

        return (prevc+1)*20;
        */
    }
    Get_Next_Can_Lingqu_BX_Xingxing_Count()
    {
        if(this.m_last_lingqued_bx_xingxing <=0 ){
            return 500;
        }
        if(this.m_last_lingqued_bx_xingxing <=500 ){
            return 1000;
        }  
        else if(this.m_last_lingqued_bx_xingxing <=1000 ){
            return 2000;
        }   
        else if(this.m_last_lingqued_bx_xingxing <=2000 ){
            return 3000;
        }else{
            
            var prevc = Math.floor(this.m_last_lingqued_bx_xingxing /1000);

            return (prevc+1)*1000;
        }

        /*
        if(this.m_last_lingqued_bx_xingxing ==0 ){
            return 1000;
        }

        var prevc = Math.floor(this.m_last_lingqued_bx_xingxing /1000);

        return (prevc+1)*1000;
        */
    }

    On_Readed_Other_User_Basic_Info( existed, sguid, snickname, stouxiangurl)
    {
        if(existed)
        {
            var pinfo = {existed:existed,snickname:snickname,stouxiangurl:stouxiangurl};

            this.m_queryed_other_user_nick_touxiang_info_map.putData(sguid,pinfo);
        }else{
            var pinfo2 = {existed:existed,snickname:"用户",stouxiangurl:""};

            this.m_queryed_other_user_nick_touxiang_info_map.putData(sguid,pinfo2);
        }
      
    }
    
    Get_Xingyun_Libao_Left_Sec()
    {
        if(this.m_xingyun_libao_start_tick == 0)
        {
            this.m_xingyun_libao_start_tick = Date.now();
        }

        var left_tick = Date.now() - this.m_xingyun_libao_start_tick;
        var left_sec = 3600*24 - Math.floor(left_tick/1000);

        if(left_sec <= 0)
        {
            left_sec = 0;
        }

        return left_sec;
    }

    SetSoundOpen(soundkai)
    {
        this.m_sound_opend = soundkai;
        SoundManager.GetInstance().m_sound_kai = soundkai;
    }



    Get_DaojuType_Show_Name(t)
    {
        return "";
    }

    Get_Aawrd_Daoju_Icon(t)
    {
        return "game/daoju/"+t;
    }

    Save_Game_Basic_Info()
    {
        this.Save_All_Info();
    }
    Change_Self_DaojuType_Count(idaojutype,icount){


        var ff_t = idaojutype;
        var ff_c = icount;


        if(idaojutype == 1 || idaojutype == 2 || idaojutype == 5 || idaojutype == 6)
        {
           return GlobalGameMng.GetInstance().Change_Self_DaojuType_Count(idaojutype,icount);
        }
        if(idaojutype == 51 || idaojutype == 52 || idaojutype == 53 || idaojutype == 54)
        {
           return GlobalGameMng.GetInstance().Change_Self_DaojuType_Count(idaojutype,icount);
        }


        if(!this.m_all_in_bag_daoju_type_leftcount_map.hasKey(ff_t)){



            if(ff_c < 0)
            {
                ff_c=  0;
            }
            this.m_all_in_bag_daoju_type_leftcount_map.putData(ff_t,ff_c);
        }else{
            var iprevc = this.m_all_in_bag_daoju_type_leftcount_map.getData(ff_t);

            var inewc = ff_c + iprevc;
            if(inewc <= 0)
            {
                inewc = 0;
            }
            this.m_all_in_bag_daoju_type_leftcount_map.putData(ff_t,inewc);
        }

        if(idaojutype == 2 && icount > 0)
        {
           // GameTaskMng.GetIns().Add_Meiri_Renwu_Item_TaskType_Finished_Count(7,icount)
        }

     
        this.Save_All_Info();
      
    }
    Get_Self_DestType_Daoju_Count(idaojutype){
        
        
        if(idaojutype == 1 || idaojutype == 2  || idaojutype == 5 ||   idaojutype == 6)
        {
           return GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(idaojutype);
        }

        if(idaojutype == 51 || idaojutype == 52  || idaojutype == 53 ||   idaojutype == 54)
        {
           return GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(idaojutype);
        }



        var inewcc = 0;
        if(this.m_all_in_bag_daoju_type_leftcount_map.hasKey(idaojutype)){
            var icc = this.m_all_in_bag_daoju_type_leftcount_map.getData(idaojutype);
            return icc;
        }
        else{

         
            this.m_all_in_bag_daoju_type_leftcount_map.putData(idaojutype,inewcc);
        }



        return inewcc;
    }


    Save_All_Info()
    {

        var hua_state_list =[ ];

        for(var ff=0;ff<this.m_huayuan_di_index_hua_state_info_map.size();ff++)
        {
            var ff_index = this.m_huayuan_di_index_hua_state_info_map.GetKeyByIndex(ff);
            var ff_info:Huayuan_Di_Hua_State = this.m_huayuan_di_index_hua_state_info_map.GetEntryByIndex(ff);
            var save_info = ff_info.Get_Saved_Info(ff_index);
            hua_state_list.push(save_info);
        }

        var basicinfo = 
        {  
           
            m_all_in_bag_daoju_type_leftcount_map:Util.Format_Save_OBJ_Map(this.m_all_in_bag_daoju_type_leftcount_map),
            m_max_jifen:this.m_max_jifen,

          
            m_total_shiping_count:this.m_total_shiping_count,
            m_xingyun_libao_start_tick:this.m_xingyun_libao_start_tick,
            m_xingyun_libao_lingqued:this.m_xingyun_libao_lingqued,


            m_cunqianguan_monmey:this.m_cunqianguan_monmey,
            m_max_win_gk:this.m_max_win_gk,
            m_max_win_guaishou_gk:this.m_max_win_guaishou_gk,
            m_max_winnied_tiaozhanchang_gk:this.m_max_winnied_tiaozhanchang_gk,
            m_zhuanpan_zuanshi_shiping_count:this.m_zhuanpan_zuanshi_shiping_count,
            m_cur_day_zhuanpan_action_index:this.m_cur_day_zhuanpan_action_index,
            m_last_zhuanpan_zuanshi_jiangli_lingqu_day_union:this.m_last_zhuanpan_zuanshi_jiangli_lingqu_day_union,
            m_last_zhuanpan_action_day_union:this.m_last_zhuanpan_action_day_union,
            m_menghuan_huayuan_level:this.m_menghuan_huayuan_level,

            m_yaoqianshu_today_count:this.m_yaoqianshu_today_count,
            m_last_yaoqianshu_yaoqian_day_union:this.m_last_yaoqianshu_yaoqian_day_union,
            m_last_lingqued_bx_guoguang_gk:this.m_last_lingqued_bx_guoguang_gk,
            m_last_lingqued_bx_xingxing:this.m_last_lingqued_bx_xingxing,
            m_last_lingqued_bx_shiping_count:this.m_last_lingqued_bx_shiping_count ,
            m_yingdao_finished:this.m_yingdao_finished
            
            ,
            m_cunqianguan_qukuang_count:this.m_cunqianguan_qukuang_count,
            m_tiaozhan_mode_max_jifen:this.m_tiaozhan_mode_max_jifen,
            m_bozhong_hua_jiesuoed_map:Util.Format_Save_OBJ_Map(this.m_bozhong_hua_jiesuoed_map),
            m_bozhong_hua_count_map:Util.Format_Save_OBJ_Map(this.m_bozhong_hua_count_map),
            m_huayuan_di_index_hua_type_map:Util.Format_Save_OBJ_Map(this.m_huayuan_di_index_hua_type_map),
            huayuan_di_index_hua_state_info_list: hua_state_list
        };

  
         
 
    
         //各个宝物的数目   
      
      
        MyLocalStorge.setItem("huadouxiaoxiao_global_base_info",JSON.stringify(basicinfo));

       // GameTaskMng.GetIns().Save_All_Info();

        this.Save_Duiju_Info();
    }
    Save_Duiju_Info()
    {
        if(this.m_last_save_mode1_info && this.m_last_save_mode1_info.m_enter_mode)
        {
            MyLocalStorge.setItem("huadouxiaoxiao_last_save_mode1_info",JSON.stringify(this.m_last_save_mode1_info));
        }else{
            MyLocalStorge.removeItem("huadouxiaoxiao_last_save_mode1_info");
        }


        if(this.m_last_save_mode2_info && this.m_last_save_mode2_info.m_enter_mode)
        {
            MyLocalStorge.setItem("huadouxiaoxiao_last_save_mode2_info",JSON.stringify(this.m_last_save_mode2_info));
        }else{
            MyLocalStorge.removeItem("huadouxiaoxiao_last_save_mode2_info");
        }
    }
    

    Init_Read_Save_Mode_Ju_Info()
    {
        var mode_ju_1_info = MyLocalStorge.getItem("huadouxiaoxiao_last_save_mode1_info");
        if(mode_ju_1_info)
        {
            var pobj = JSON.parse(mode_ju_1_info);

            if(pobj && pobj.m_enter_mode && pobj.m_enter_mode == 1)
            {
                this.m_last_save_mode1_info = pobj;
            }
        }


        var mode_ju_2_info = MyLocalStorge.getItem("huadouxiaoxiao_last_save_mode2_info");
        if(mode_ju_2_info)
        {
            var pobj2 = JSON.parse(mode_ju_2_info);

            if(pobj2 && pobj2.m_enter_mode && pobj2.m_enter_mode == 2)
            {
                this.m_last_save_mode2_info = pobj2;
            }
        }
    }
    Init_Read_All_Save_Info()
    {
       // GameTaskMng.GetIns().Init_Read_All_Save_Info();
        this.Init_Read_Save_Mode_Ju_Info();
        var previnfo = cc.sys.localStorage.getItem("huadouxiaoxiao_global_base_info","");

        var saveobj = null;
        if(!previnfo)
        {

        }
        else{
            try{
                saveobj = JSON.parse(previnfo);
            }catch(e)
            {

            }
           
        }

        var bhasprevdata = false;

        if(saveobj)
        {
            bhasprevdata = true;
            
        }



        if(!bhasprevdata)
        {
            this.m_all_in_bag_daoju_type_leftcount_map.putData(21,1);
            this.m_all_in_bag_daoju_type_leftcount_map.putData(22,1);
            this.m_all_in_bag_daoju_type_leftcount_map.putData(23,1);
            this.m_all_in_bag_daoju_type_leftcount_map.putData(24,1);
            
        }
        else
        {
 
            this.m_all_in_bag_daoju_type_leftcount_map = Util.Serize_Saved_OBJ_Map(saveobj.m_all_in_bag_daoju_type_leftcount_map)
          



            this.m_max_jifen = Util.Check_Read_Number(saveobj.m_max_jifen)
            this.m_total_shiping_count = Util.Check_Read_Number(saveobj.m_total_shiping_count)
            this.m_xingyun_libao_start_tick = Util.Check_Read_Number(saveobj.m_xingyun_libao_start_tick)
            this.m_xingyun_libao_lingqued = Util.Check_Read_Number(saveobj.m_xingyun_libao_lingqued)
 
 

            this.m_cunqianguan_monmey = Util.Check_Read_Number(saveobj.m_cunqianguan_monmey)
            this.m_max_win_gk = Util.Check_Read_Number(saveobj.m_max_win_gk)
            this.m_max_winnied_tiaozhanchang_gk = Util.Check_Read_Number(saveobj.m_max_winnied_tiaozhanchang_gk)
            
            this.m_max_win_guaishou_gk = Util.Check_Read_Number(saveobj.m_max_win_guaishou_gk)
         
            this.m_zhuanpan_zuanshi_shiping_count = Util.Check_Read_Number(saveobj.m_zhuanpan_zuanshi_shiping_count)
            this.m_cur_day_zhuanpan_action_index = Util.Check_Read_Number(saveobj.m_cur_day_zhuanpan_action_index)
            this.m_last_zhuanpan_zuanshi_jiangli_lingqu_day_union = Util.Check_Read_Number(saveobj.m_last_zhuanpan_zuanshi_jiangli_lingqu_day_union)
            this.m_last_zhuanpan_action_day_union = Util.Check_Read_Number(saveobj.m_last_zhuanpan_action_day_union)
       
 
            this.m_yaoqianshu_today_count = Util.Check_Read_Number(saveobj.m_yaoqianshu_today_count);
            this.m_last_yaoqianshu_yaoqian_day_union = Util.Check_Read_Number(saveobj.m_last_yaoqianshu_yaoqian_day_union);
            this.m_last_lingqued_bx_guoguang_gk = Util.Check_Read_Number(saveobj.m_last_lingqued_bx_guoguang_gk)
            this.m_last_lingqued_bx_xingxing = Util.Check_Read_Number(saveobj.m_last_lingqued_bx_xingxing)
            this.m_last_lingqued_bx_shiping_count = Util.Check_Read_Number(saveobj.m_last_lingqued_bx_shiping_count)
        
            this.m_yingdao_finished = Util.Check_Read_Number(saveobj.m_yingdao_finished)
        
            this.m_menghuan_huayuan_level = Util.Check_Read_Number(saveobj.m_menghuan_huayuan_level)
        
            this.m_cunqianguan_qukuang_count = Util.Check_Read_Number(saveobj.m_cunqianguan_qukuang_count)
            this.m_tiaozhan_mode_max_jifen = Util.Check_Read_Number(saveobj.m_tiaozhan_mode_max_jifen)
         
      
            this.m_bozhong_hua_jiesuoed_map = Util.Serize_Saved_OBJ_Map(saveobj.m_bozhong_hua_jiesuoed_map)
            this.m_bozhong_hua_count_map = Util.Serize_Saved_OBJ_Map(saveobj.m_bozhong_hua_count_map)
            this.m_huayuan_di_index_hua_type_map = Util.Serize_Saved_OBJ_Map(saveobj.m_huayuan_di_index_hua_type_map)
        
            
            var huayuan_di_index_hua_state_info_list = saveobj.huayuan_di_index_hua_state_info_list;
            if(!huayuan_di_index_hua_state_info_list)
            {
                huayuan_di_index_hua_state_info_list =[] ;
            }

            this.m_huayuan_di_index_hua_state_info_map.clear();
            for(var tt=0;tt<huayuan_di_index_hua_state_info_list.length;tt++)
            {
                var tt_info = huayuan_di_index_hua_state_info_list[tt];
                var tt_di_index = tt_info.di_index;

                var tt_state_info = Huayuan_Di_Hua_State.Parse_From(tt_info);
                if(tt_state_info)
                {
                    this.m_huayuan_di_index_hua_state_info_map.putData(tt_di_index,tt_state_info);
                }
            }

        }
 
 
 
        
    }
    Common_Add_Award_List(awarddaoju,ibeishu =1)
    {
        for(var ff=0;ff<awarddaoju.length;ff++){
            var ff_info =  awarddaoju[ff];
            var ff_t = ff_info.t;
            var ff_c = ff_info.c  ;
             var icount=  ff_c*ibeishu;

             this.Change_Self_DaojuType_Count(ff_t,icount);
         
        }

        
        this.Save_Game_Basic_Info();
    }

    Query_Other_User_Nick_Touxiang_Info(sguid)
    {
        if(this.m_queryed_other_user_nick_touxiang_info_map.hasKey(sguid))
        {
            var pinfo =  this.m_queryed_other_user_nick_touxiang_info_map.getData(sguid);
            return pinfo;
        }

        return null;
    }
    On_Guoguang_Gk(igk)
    {
        if(this.m_enter_mode == 1)
        {
            if(this.m_max_winnied_tiaozhanchang_gk < igk)
            {
                this.m_max_winnied_tiaozhanchang_gk = igk;
            } 
        }
        else if(this.m_enter_mode == 4)
        {
            if(this.m_max_win_guaishou_gk < igk)
            {
                this.m_max_win_guaishou_gk = igk;
            } 
        }else{

            if(this.m_max_win_gk < igk)
            {
                this.m_max_win_gk = igk;
            }
            
        }
     
        this.Save_All_Info();
    }
    Post_Server_Max_Fenshu_Pihang()
    {
         User_Info_Mng.GetInstance().Post_Refresh_Paihangbang(2,this.m_max_win_gk)
    }
    Add_Cunqian_Guan_Money(iaddm)
    {
        this.m_cunqianguan_monmey += iaddm;

        
    }
    /*
    Get_Gk_Guoguang_Need_Fen(igk)
    { 
    
        if(igk <= 10)
        {
            return 70+10*igk;
        }


        return 200+30*(igk-11);

    }
    */

    On_Start_Yingdao_Enter()
    {
        this.m_enter_mode = 2;
        this.m_b_yingdao = 1;
        this.m_yd_finished_gk = 0;
    }

    Set_Game_Config(game_config)
    {
        this.m_game_config = game_config;
    }

    Get_GK_Guoguang_Tiaojian_Info(guoguang_gk)
    {
 
        if(guoguang_gk > 15)
        {
            if(guoguang_gk%2 == 0)
            {
                var iaddc = Math.floor((guoguang_gk - 16)/2)*20;

                var ineedfen = 400+iaddc;
                return  {
                    "gk":guoguang_gk,"t":1,"fen":ineedfen
                }
            }
            else{

                var rand_color =  Util.Rand_Digit_List([1,2,3,4,5,6]);
                var iaddc = Math.floor((guoguang_gk - 15)/2)*2;

                var ineedfen = 20+iaddc;
                var ned_color_list = rand_color.slice(0,3);
                
                var need_oclo_info_Arr = [];

                for(var tt=0;tt<ned_color_list.length;tt++)
                {
                    var tt_c = ned_color_list[tt];
                    var tt_info  = {
                        "t":tt_c,
                        "c":ineedfen
                    }

                    need_oclo_info_Arr.push(tt_info);
                }

                var obj =
                {
                    "gk":guoguang_gk,"t":2,"needcolor":need_oclo_info_Arr
                }

                return obj;
            }

        }

        var gk_tj = this.m_game_config.gk_tj;


        for(var ff =0;ff<gk_tj.length;ff++)
        {
            var fF_info  = gk_tj[ff];
            if(fF_info.gk == guoguang_gk)
            {
                return fF_info;
            }
        }




        return  {
            "gk":guoguang_gk,"t":1,"fen":400
        }

    }

    Get_Menghuan_Huayuan_Level()
    {
        return this.m_menghuan_huayuan_level;
    }


    Get_Chengjiu_Item_List(itab)
    {
        var node_item_info = "chengjiu_main";
        if(itab == 2)
        {
            node_item_info = "chengjiu_meiri";
        }
 
        return this.m_game_config[node_item_info];
    }

    On_Game_Fail_Jifen( enter_mode, all_jifen)
    {
        if(enter_mode == 1)
        {
            //挑战模式

            if(this.m_tiaozhan_mode_max_jifen < all_jifen)
            {
                this.m_tiaozhan_mode_max_jifen = all_jifen;
            }

          //  GameTaskMng.GetIns().On_Tiaozhan_Mode_Game_Fail_Jifen(all_jifen);
        }

    }

    Is_CurDay_Can_Sign()
    {
        var bhasdata = false;
        var last_sign_day = 0;
        var last_sign_day_index=  0;
        var br_qd_data_str = Util.ReadSysLocalStorgeStr("huadouxiaoxiao_sign_data");

        if(br_qd_data_str)
        {
            var br_qd_data = JSON.parse(br_qd_data_str);

            if(br_qd_data)
            {
                bhasdata = true;
                last_sign_day = br_qd_data.sign_day_union;
                last_sign_day_index=  br_qd_data.sign_day_index;
            }
        }

        var b_cur_day_signed = 0;

        var curdayunion = ComFunc.GetCurDayUnionD();
        if(bhasdata)
        {
            if(curdayunion == last_sign_day)
            {
                 b_cur_day_signed = 1; 
            }else{

                var icurdayindex=  last_sign_day_index+1;
                if(icurdayindex >= 8)
                {
                    icurdayindex = 1;
                }

                b_cur_day_signed = 0; 
            }
        }
        else
        {
            b_cur_day_signed = 0; 

        }

        if(b_cur_day_signed)
        {
            return false;
        }

        return true;
    }
    Set_Max_Jifen_Show(showfenshu)
    {
        if(this.m_max_jifen < showfenshu)
        {
            this.m_max_jifen = showfenshu;
        }
        
    }
    Clear_Cur_Mode_Save_Game_Shuju()
    {
        if(GlobalConfig.GetIns().m_enter_mode == 1)
        {
            this.m_last_save_mode1_info =   null;
        }
        if(GlobalConfig.GetIns().m_enter_mode == 2)
        {
            this.m_last_save_mode2_info = null;
        }

        this.Save_All_Info();
        
    }

    Save_Cur_Mode_Game_Duiju_Info(pobj)
    {
        if(!pobj)
        {
            return;
        }
        if(GlobalConfig.GetIns().m_enter_mode == 1)
        {
            this.m_last_save_mode1_info =   pobj;
        }

        if(GlobalConfig.GetIns().m_enter_mode == 2)
        {
            this.m_last_save_mode2_info =   pobj;
        }

        this.Save_All_Info();
       
    }

    Get_Prev_Save_Ju_Info()
    {
        var previnfo = null;

        if(GlobalConfig.GetIns().m_enter_mode == 1)
        {
            previnfo  = this.m_last_save_mode1_info ;
        }

        if(GlobalConfig.GetIns().m_enter_mode == 2)
        {
            previnfo  =  this.m_last_save_mode2_info ;
        }

        if(!previnfo)
        {
            return null;
        }

        if(GlobalConfig.GetIns().m_enter_mode == 2)
        {
            var guoguang_gk = GlobalConfig.GetIns().m_enter_mode_gk;

            if(guoguang_gk != previnfo.m_enter_mode_gk)
            {
                return null;
            }
        }

        if(previnfo.m_enter_mode  != GlobalConfig.GetIns().m_enter_mode)
        {
            return null;
        }

        return previnfo;
    }

    Find_Gk_Jiesuo_Wanfa_Name(igk)
    {
        if(igk  == 19)
        {
            return "挑战模式";
        }

        var jiesuoname_list = [
            "",
            "怪兽消消","三消消闯关",
            "三消消挑战","怪兽连连看",
            "泡泡龙","俄罗斯方块",
            "怪兽躲避","翻牌消消乐",
            "怪兽跳跃","密室逃脱",
            "消灭星星","移动怪兽消除",
            "数字华容道","滑木块",
            "数字消除"
        ];

        var sname = jiesuoname_list[igk];
        if(!sname)
        {
            sname = "";
            
        }

        return sname;
    }


    Get_Guoguang_Gk_Jiangli_Jinbi(ilv)
    {

        if(this.m_enter_mode == 1)
        {
            return 50;
        }

        if(this.m_enter_mode == 2)
        {
             
            if(ilv >= this.m_max_win_gk )
            {
                if(ilv%4 == 0)
                {
                    return 40;
                }
                return 20;
            }

            return 20;
        }
        if(this.m_enter_mode ==4)
        {
            if(ilv >= this.m_max_win_guaishou_gk )
            {
                if(ilv%4 == 0)
                {
                    return 40;
                }
                return 20;
            }

            return 10;
        }

        return 20;
    }
}