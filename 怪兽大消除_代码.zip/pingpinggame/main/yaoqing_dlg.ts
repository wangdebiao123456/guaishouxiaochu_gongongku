import ComFunc from "../../comfuncs/ComFunc";
import LeoGameInfoMng from "../../comfuncs/LeoGameInfoMng";
import MyHttpPostInfoUtil from "../../comfuncs/MyHttpPostInfoUtil";
import SoundManager from "../../comfuncs/SoundManager";
import tankuang from "../../dlg/tankuang";
import GlobalGameMng from "../../Mng/GlobalGameMng";
import PlatFormMng from "../../PlatForm/PlatFormMng";
import Util from "../../utils/Util";
import MyLocalStorge from "../../WDT/MyLocalStorge";
import GlobalConfig from "../GlobalConfig";

 

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class yaoqing_dlg extends cc.Component {

    
    m_last_saved_readed_yaoqinged_friend_count = 0;

    m_callback = null;

    onLoad () 
    {
        var yaoqinghaoyoubtn = cc.find("panel/yaoqinghaoyoubtn",this.node);
        yaoqinghaoyoubtn.on("click",this.OnBtnYaoqing.bind(this))
        
        this.m_last_saved_readed_yaoqinged_friend_count=  this.Reade_Prev_Yaoqing_Haoyou_Count();
 
        this.Post_Get_Yaoqing_Haoyou_Count();

        this.Refresh_Info();

        for(var ff=1;ff<=3;ff++)
        { 
 
            var ff_lingqu = cc.find("panel/"+ff+"/lingqu/lingqubtn",this.node)
            ff_lingqu.on("click",this.OnBtnLingqu.bind(this,ff))

        }

        SoundManager.GetInstance().Play_Click_Btn_Effect();
    
        var tankuang:tankuang = this.node.getComponent("tankuang");
        tankuang.Set_Close_Lisnter(this);
 
     }
   
     On_Tankuang_Real_Exit()
     {
         this.OnBtnExit();
     }
     OnBtnExit()
     {
         this.node.destroy();
         LeoGameInfoMng.GetIns().m_b_in_share_msg=  0;
   
         LeoGameInfoMng.GetIns().Remove_WX_Show_Hide_Event_Lisnter(this)

     }

     Get_Award(iindexz)
     {

        if(iindexz == 1)
        {
            return [
                {
                    "t":1,
                    "c":100
                },
                {
                    "t":6,
                    "c":3
                }
            ]
        }

        if(iindexz == 2)
        {
            return [
                {
                    "t":5,
                    "c":200
                },
                {
                    "t":6,
                    "c":6
                }
            ]
        }
        if(iindexz == 3)
        {
            return [
                {
                    "t":5,
                    "c":600
                },
                {
                    "t":6,
                    "c":12
                }
            ]
        }
        return [
            {
                "t":1,
                "c":100
            },
            {
                "t":6,
                "c":3
            }
        ]
     }
    OnBtnLingqu(iindexz)
    {
        var ff_need_day = 1;
        if(iindexz == 2)
        {
            ff_need_day = 3;
        }else if(iindexz == 3)
        {
            ff_need_day = 5;
        }
        var blingqued = this.Is_Yaoqing_Haoyou_Count_Jiangli_Lingqued(ff_need_day)

        if(blingqued)
        {
            return;
        }

        this.Set_Yaoqing_Haoyou_Count_Jiangli_Lingqued(ff_need_day);

        var awrad = this.Get_Award(iindexz);
        
        
        GlobalGameMng.GetInstance().Add_DaojuType_Count_List(awrad,1);

        /*
        var lqjbi = 100;
        if(iindexz == 2)
        {
            lqjbi = 300;
        }else if(iindexz == 3)
        {
            lqjbi = 500;
        }

        GlobalConfig.GetIns().Change_Self_DaojuType_Count(1,lqjbi);
        */


     //   var awrad = [{"t":1,"c":lqjbi}]



        ComFunc.Open_Get_Daoju_Award_Dlg(this.node, awrad, 1, ()=>{});
        this.Refresh_Info();
    }
    Refresh_Info()
    {
        for(var ff=1;ff<=3;ff++)
        {
            var ff_need_day = 1;
            if(ff == 2)
            {
                ff_need_day = 3;
            }else if(ff == 3)
            {
                ff_need_day = 5;
            }


            var ff_weiwancheng = cc.find("panel/"+ff+"/weiwancheng",this.node)
            var ff_lingqu = cc.find("panel/"+ff+"/lingqu",this.node)
            var ff_yiwancheng = cc.find("panel/"+ff+"/yiwancheng",this.node);

            ff_weiwancheng.active=  false;
            ff_lingqu.active=  false;
            ff_yiwancheng.active=  false;
            

            if(this.m_last_saved_readed_yaoqinged_friend_count >= ff_need_day)
            {
                var blingqued = this.Is_Yaoqing_Haoyou_Count_Jiangli_Lingqued(ff_need_day)

                if(blingqued)
                {
                    ff_yiwancheng.active=  true;
            
                    ff_yiwancheng.getChildByName("c").getComponent(cc.Label).string = "已领取\n("+this.m_last_saved_readed_yaoqinged_friend_count+"/"+ff_need_day+")"

                }
                else{
                    ff_lingqu.active=  true;
        
                }
            }
            else{
                ff_weiwancheng.active = true;

                ff_weiwancheng.getChildByName("c").getComponent(cc.Label).string = "邀请("+this.m_last_saved_readed_yaoqinged_friend_count+"/"+ff_need_day+")"
            }
            
        }


        var yaoqinghaoyoubtn_lingqed = cc.find("panel/yaoqinghaoyoubtn/lingqu",this.node)
        var last_lq_day = this.Get_Last_Share_Haoyou_Lingqu_Jiangli_Day();


        if(last_lq_day  == Util.GetCurDayUnion())
        {
            yaoqinghaoyoubtn_lingqed.active = true;
     
        }else{
            yaoqinghaoyoubtn_lingqed.active = false;
        }
        
    }


    Set_Yaoqing_Haoyou_Count_Jiangli_Lingqued(icount)
    {
        var str = "jsth_yaoqing_haoyou_jiangli_lqed_"+icount;
        MyLocalStorge.setItem(str,"ok");
    }
    Is_Yaoqing_Haoyou_Count_Jiangli_Lingqued(icount)
    {
        var str = "jsth_yaoqing_haoyou_jiangli_lqed_"+icount;
        var sinfo = MyLocalStorge.getItem(str);

        if(sinfo == "ok")
        {
            return 1;
        }
        return 0;
    }

    Set_Last_Share_Haoyou_Lingqu_Jiangli_Day()
    {
        var curdayunion = Util.GetCurDayUnion();

        var obj  = {
            iday:curdayunion
        }

        var strinfgo = JSON.stringify(obj);

        var skey = "jsth_last_yaoqing_haoyou_lingqu_Day_jl_union";
        MyLocalStorge.setItem(skey,strinfgo);
    }
    Get_Last_Share_Haoyou_Lingqu_Jiangli_Day()
    {
        var str = "jsth_last_yaoqing_haoyou_lingqu_Day_jl_union";
        var sinfo = MyLocalStorge.getItem(str);

        if(!sinfo)
        {
            return 0;
        }
        var obj = JSON.parse(sinfo);
        if(!obj)
        {
            return 0;
        }

        var iday = obj.iday;
        return iday;
    }


    Reade_Prev_Yaoqing_Haoyou_Count()
    {
        var str = "jsth_prev_yaoqing_haoyou_count";
        var sinfo = MyLocalStorge.getItem(str);

        if(!sinfo)
        {
            return 0;
        }

        var obj = JSON.parse(sinfo);
        if(!obj)
        {
            return 0;
        }

        var icount = obj.icount;
        return icount;
    }
    Save_Prev_Yaoqing_Haoyou_Count()
    {
        var str = "jsth_prev_yaoqing_haoyou_count";
        var obj = {
            icount:this.m_last_saved_readed_yaoqinged_friend_count
        }

        var strinfo = JSON.stringify(obj);
        var skey = "jsth_prev_yaoqing_haoyou_count";
        MyLocalStorge.setItem(skey,strinfo);
    }
    On_Readed_Server_Yaoqing_Haoyou_Count(icount)
    {
        console.log("On_Readed_Server_Yaoqing_Haoyou_Count icount="+icount)
        this.m_last_saved_readed_yaoqinged_friend_count=  icount;
        this.Save_Prev_Yaoqing_Haoyou_Count()
      
        this.Refresh_Info();
    }
    Post_Get_Yaoqing_Haoyou_Count()
    {
         
         
        var self = this;
        var obj =
        {
            itype:1,
            uid: LeoGameInfoMng.GetIns().m_wx_openid, 
            wxappid:"wx0718c2639902aedc"
         };


        var str = JSON.stringify(obj);
        MyHttpPostInfoUtil.POSTData( 'https://dianjitaitan.zfgame123.com/get_yaoqing_haoyou_info.aspx',str,
        (bsuc,response)=>
        {
           
            if(!bsuc)
            { 
                return;
            }

            var resobj = JSON.parse(response);

            var icount = resobj.icount;

            self.On_Readed_Server_Yaoqing_Haoyou_Count(icount);

        });
    }
  
    SetInfo(pinfo)
    {
        this.m_callback = pinfo.callback;

    } 

    Notify_WX_Show_Hide_Event(bshow)
    {
        if(!LeoGameInfoMng.GetIns().m_b_in_share_msg)
        {
            return;
        }

        LeoGameInfoMng.GetIns().m_b_in_share_msg = 0;

        this.Set_Last_Share_Haoyou_Lingqu_Jiangli_Day();

        var lqjbi = 50;
        GlobalConfig.GetIns().Change_Self_DaojuType_Count(1,lqjbi);


        var awrad = [{"t":1,"c":lqjbi}]
        ComFunc.Open_Get_Daoju_Award_Dlg(this.node, awrad, 1, ()=>{});
        this.Refresh_Info();

    }
    OnBtnYaoqing()
    {
        var self  =this;
        
        var last_lq_day = this.Get_Last_Share_Haoyou_Lingqu_Jiangli_Day();


        if(last_lq_day  != Util.GetCurDayUnion())
        {
            LeoGameInfoMng.GetIns().m_b_in_share_msg=  1;

            LeoGameInfoMng.GetIns().Add_WX_Show_Hide_Event_Lisnter(this)
     
        }

      
        PlatFormMng.GetInstance().Share_Msg("怪兽大消除","超多玩法，花朵与怪兽消除");


        /*
        wx.shareAppMessage({
            title: "彩色幻想,日常休闲玩玩这款好玩的游戏"
          }); 
          */
    }
}
