import Util from "../../utils/Util";
import GlobalConfig from "../GlobalConfig";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class test_mng extends cc.Component {

    

    
    onLoad () 
    {

        var gk_add_btn = cc.find("panel/test/gk_add_btn",this.node)
        gk_add_btn.on("click",this.OnBtnTestAddGk.bind(this))
      
        var gk_desc_btn = cc.find("panel/test/gk_desc_btn",this.node)
        gk_desc_btn.on("click",this.OnBtnTestSubGk.bind(this))
      


        var jinbi = cc.find("panel/test/jinbi",this.node)
        jinbi.on("click",this.OnBtnJinbi.bind(this))
      
 

      
    }
    OnBtnAddDaoju20(idaojuc)
    {
        GlobalConfig.GetIns().Change_Self_DaojuType_Count(idaojuc,20)
 
        Util.ShowTipTxtDlg("道具+20成功",this.node);
    }
    SetInfo(p)
    {

    }
    OnBtnTestAddZhongzi()
    {
        
        GlobalConfig.GetIns().Change_Self_DaojuType_Count(16,10)
 
        Util.ShowTipTxtDlg("种子+10",this.node);
        
    }
    OnBtnTestAddGk()
    {

        GlobalConfig.GetIns().m_max_win_gk++;
        GlobalConfig.GetIns().Save_All_Info();
        Util.ShowTipTxtDlg("关卡+1",this.node);
         
    }
    OnBtnTestSubGk()
    {
        GlobalConfig.GetIns().m_max_win_gk--;
        if(GlobalConfig.GetIns().m_max_win_gk <= 0)
        {
            GlobalConfig.GetIns().m_max_win_gk = 0;
        }
        GlobalConfig.GetIns().Save_All_Info();
        Util.ShowTipTxtDlg("关卡+1",this.node);
    }
    OnBtnJinbi()
    {
        
        GlobalConfig.GetIns().Change_Self_DaojuType_Count(1,500)
        GlobalConfig.GetIns().Save_All_Info();
        Util.ShowTipTxtDlg("金币+500",this.node);
         
    }

    OnBtnXingxing()
    {
        GlobalConfig.GetIns().Change_Self_DaojuType_Count(2,200)
        GlobalConfig.GetIns().Save_All_Info();
        Util.ShowTipTxtDlg("星星+200",this.node);
    }
}
