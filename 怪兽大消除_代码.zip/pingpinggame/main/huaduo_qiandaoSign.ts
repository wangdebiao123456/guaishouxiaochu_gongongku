import ComFunc from "../../comfuncs/ComFunc";
import SoundManager from "../../comfuncs/SoundManager";
import WatchVideoAdveseMng from "../../comfuncs/WatchVideoAdveseMng";
import tankuang from "../../dlg/tankuang";
import GlobalGameMng from "../../Mng/GlobalGameMng";
import MiddleGamePlatformAction from "../../PlatForm/MiddleGamePlatformAction";
import Util from "../../utils/Util";
import BannerGuangaoMng from "../../WDT/BannerGuangaoMng";
import MyLocalStorge from "../../WDT/MyLocalStorge";
import GlobalConfig from "../GlobalConfig";

 

const {ccclass, property} = cc._decorator;

@ccclass
export default class qiandaoSign extends cc.Component {

    m_callback = null;
    
    m_b_cur_day_signed = 0;
    m_cur_day_sign_day_index=  0;

    m_cur_day_sign_day_signed_count = 0;

    m_b_need_shuangbei_Selected = 0;
    m_last_btn_click_tick = 0;

    onLoad () 
    {
        var btn_exit = cc.find("panel/exit",this.node);
     //   btn_exit.on("click",this.OnBtnExit.bind(this));

  
     var btn_get= cc.find("panel/menu1/lingqu",this.node);
      
     btn_get.on("click",this.OnBtnLingu.bind(this));

        var btn_shungbeilq= cc.find("panel/menu1/shungbeilq",this.node);
        
        btn_shungbeilq.on("click",this.OnBtnShuangbei.bind(this));

            
        var menu2_putong = cc.find("panel/menu2/putonglingqu",this.node);
        var menu2_shuangbei = cc.find("panel/menu2/shuangbeilqu",this.node);
    
        menu2_putong.on("click",this.OnBtn_PutongLignqu.bind(this));
        menu2_shuangbei.on("click",this.OnBtn_Sanbei_Lingqu.bind(this));



        var zaici_lingqu = cc.find("panel/menu2/zaici_lingqu",this.node);
        zaici_lingqu.on("click",this.OnBtn_Zaici_Sanbei_Lingqu.bind(this));

        
        /*
        var idefault_gouxuan = GlobalGameMng.GetInstance().Get_Qiandao_Default_Gouxuan();

        var inext_gouxuan_type = GlobalGameMng.GetInstance().Get_Qiandao_Next_Gouxuan_Type();

        var last_gouxuaned_v = this.Get_Last_Shuangbei_Gouxuan_V();


        if(!last_gouxuaned_v[0])
        {

            this.m_b_need_shuangbei_Selected = idefault_gouxuan;
        }
        else
        {
            var last_gouxuan_v = last_gouxuaned_v[1];

            if(inext_gouxuan_type == 1)
            {
                this.m_b_need_shuangbei_Selected = 1;

            }
            else if(inext_gouxuan_type == 2)
            {
                this.m_b_need_shuangbei_Selected = last_gouxuan_v;

            }
            else if(inext_gouxuan_type == 0)
            {
                this.m_b_need_shuangbei_Selected = 0;
            }else{
                this.m_b_need_shuangbei_Selected = last_gouxuan_v;
            }
        }
 
        this.Set_Last_Shuangbei_Gouxuan_V(this.m_b_need_shuangbei_Selected );
 
        */


        var bhasdata = false;
        var last_sign_day = 0;
        var last_sign_day_index=  0;
        var last_sign_day_signed_count=  0;
        
        var br_qd_data_str = Util.ReadSysLocalStorgeStr("huadouxiaoxiao_sign_data");

        if(br_qd_data_str)
        {
            var br_qd_data = JSON.parse(br_qd_data_str);

            if(br_qd_data)
            {
                bhasdata = true;
                last_sign_day = br_qd_data.sign_day_union;
                last_sign_day_index=  br_qd_data.sign_day_index;
                last_sign_day_signed_count = br_qd_data.last_sign_day_signed_count;
            }
        }


        var curdayunion = Util.GetCurDayUnionD();
        if(bhasdata)
        {
            if(curdayunion == last_sign_day)
            {
                this.m_b_cur_day_signed = 1;
                this.m_cur_day_sign_day_index=  last_sign_day_index;
                this.m_cur_day_sign_day_signed_count = last_sign_day_signed_count;
            }else{

                var icurdayindex=  last_sign_day_index+1;
                if(icurdayindex >= 8)
                {
                    icurdayindex = 1;
                }

                this.m_b_cur_day_signed = 0;
                this.m_cur_day_sign_day_index=  icurdayindex;
                this.m_cur_day_sign_day_signed_count = 0;
            }
        }
        else
        {
            this.m_b_cur_day_signed = 0;
            this.m_cur_day_sign_day_index=  1;
            this.m_cur_day_sign_day_signed_count = 0;
        }

        this.Refresh();
      
        var tankuang:tankuang = this.node.getComponent("tankuang");
        tankuang.Set_Close_Lisnter(this);


         this.Show_All_Btns(true);
       // var idealyshowsec = GlobalGameMng.GetInstance().Get_Qiandao_Dlg_Dealy_Show_Btn_Sec();
       
       // this.scheduleOnce(this.FD_InitShow.bind(this),idealyshowsec);
        BannerGuangaoMng.GetInstance().CheckShowChaiping(12);
      
 
     }

     OnBtnLingu()
    {
        SoundManager.GetInstance().Play_Click_Btn_Effect();
    
        if(this.m_b_need_shuangbei_Selected)
        {
           this.OnBtn_Sanbei_Lingqu();

        }else{
            this.OnBtn_PutongLignqu();

        }
    }

 

     FD_InitShow()
    {
        this.Show_All_Btns(true);

    }


    Show_All_Btns(bshow)
    {
        var exit = cc.find("panel/exit",this.node);
        var qiandao_menu_type = 2;//GlobalGameMng.GetInstance().Get_Qiandao_Menu_Type();
        var qiandao_menu1 = cc.find("panel/menu1",this.node);
        var qiandao_menu2 = cc.find("panel/menu2",this.node);
   




        exit.active = bshow;


        if(!bshow)
        {
            qiandao_menu1.active = false;
            qiandao_menu2.active = false;

        }else{
        
            if(qiandao_menu_type == 2)
            {
                 qiandao_menu1.active = false;
                 qiandao_menu2.active = true;
     
     
            }else{
                 qiandao_menu1.active = true;
                 qiandao_menu2.active = false;
     
            }
        }


      
 

        
    }
     Get_Last_Shuangbei_Gouxuan_V()
    {
        var last_v = "guaishoudaxiaochu_shaungbei_qiandao_gouxuan";

        var prevstr = MyLocalStorge.getItem(last_v,"");

        if(!prevstr)
        {
            return [0,0];
        }


        var pobj = JSON.parse(prevstr);
        if(!pobj)
        {
            return [0,0];
        }

        var gouxuaned = pobj.gouxuaned;
        if(!gouxuaned)
        {
            gouxuaned = 0;
        }
        return [1,gouxuaned];
    }

     OnBtnShuangbei()
     {
 
         if(this.m_b_need_shuangbei_Selected )
         {
             this.m_b_need_shuangbei_Selected  = 0;
         }else{
             this.m_b_need_shuangbei_Selected  = 1;
         } 
 
         this.Set_Last_Shuangbei_Gouxuan_V(this.m_b_need_shuangbei_Selected  ?  1:0);
         this.Refresh();
     }
     Set_Last_Shuangbei_Gouxuan_V(igouxuaned)
     {
         var obj = {
             gouxuaned:igouxuaned
         }
         var last_v = "guaishoudaxiaochu_shaungbei_qiandao_gouxuan";
 
         var str = JSON.stringify(obj);
         MyLocalStorge.setItem(last_v,str);
     }
 


     On_Tankuang_Real_Exit()
     {
         this.OnBtnExit();
     }
    Refresh()
    {
        
        var lingqu_t = cc.find("panel/menu1/lingqu/t",this.node);
     
        if(this.m_b_cur_day_signed)
        {
            lingqu_t.getComponent(cc.Label).string = "已 领 取";
            lingqu_t.color = cc.color(211,211,211);
        }else
        {
            
            lingqu_t.getComponent(cc.Label).string = "领取";
            lingqu_t.color = cc.color(255,255,255);
        }
        
        
        var shungbeilq_gou = cc.find("panel/menu1/shungbeilq/gou",this.node);
     
        if(this.m_b_need_shuangbei_Selected)
        {
            shungbeilq_gou.active = true;
        }else{
            shungbeilq_gou.active = false;
        }

  
        for(var ff=1;ff<=7;ff++)
        {
            var ff_lq = cc.find("panel/days/"+ff+"/lingqu",this.node);

            var ff_u_label = cc.find("panel/days/"+ff+"/u",this.node);


            
            if(ff != this.m_cur_day_sign_day_index)
            {
                ff_u_label.color = cc.color(139,71,46);
            }
            else{
                ff_u_label.color = cc.color(255,0,0);
       
            }

            if(ff< this.m_cur_day_sign_day_index)
            {
                ff_lq.active = true;
            }else if(ff > this.m_cur_day_sign_day_index)
            {
                ff_lq.active = false;
            }else{

                if(this.m_b_cur_day_signed)
                {
                    ff_lq.active = true;
                }else{
                    ff_lq.active = false;
                }
            }

        }




        var menu2_putong = cc.find("panel/menu2/putonglingqu",this.node);
        var menu2_shuangbei = cc.find("panel/menu2/shuangbeilqu",this.node);
        var menu2_yilingqu = cc.find("panel/menu2/yijinglqu",this.node);

        var menu2_zaici_lingqu = cc.find("panel/menu2/zaici_lingqu",this.node);
     


        var menu1_yilingqu = cc.find("panel/menu1/yijinglqu",this.node);
        
        var menu1_lingqu = cc.find("panel/menu1/lingqu",this.node);
        var menu1_shungbeilq = cc.find("panel/menu1/shungbeilq",this.node);
       
      

        
        
        if(this.m_b_cur_day_signed)
        {
           
            if(this.m_cur_day_sign_day_signed_count >= 2)
            {
                menu2_putong.active = false;
                menu2_shuangbei.active = false;
                menu2_yilingqu.active = true;
                menu2_zaici_lingqu.active = false;
    
    
            }
            else{

                menu2_putong.active = false;
                menu2_shuangbei.active = false;
                menu2_yilingqu.active = false;
    
                menu2_zaici_lingqu.active = true;
    
    
            }

         

            menu1_yilingqu.active = true;
            menu1_lingqu.active = false;
            menu1_shungbeilq.active = false;
            
            
        }else{
           
            menu2_putong.active = true;
            menu2_shuangbei.active = true;
            menu2_yilingqu.active = false;
            menu2_zaici_lingqu.active = false;


            menu1_yilingqu.active = false;
            menu1_lingqu.active = true;
            menu1_shungbeilq.active = true;

        
          
        }
    }
    OnBtnExit()
    {
        MiddleGamePlatformAction.GetInstance().Show_Qiandao_Banners(false);
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(15,false);

        
        this.node.destroy();
       if(this.m_callback)
       {
           this.m_callback();
       } 
     
    }
    OnBtn_PutongLignqu()
    {
        if(!this.Check_Btn_Click_Enough())
        {
            return;
        }
       
        this.RealLingqu(1);
        SoundManager.GetInstance().Play_Click_Btn_Effect();
    }
    Check_Btn_Click_Enough()
    {
        if(Date.now() - this.m_last_btn_click_tick < 1000)
        {
            return false;
        }
        this.m_last_btn_click_tick = Date.now() ;

        return true;
    }

    OnBtn_Zaici_Sanbei_Lingqu()
    {
        if(!this.Check_Btn_Click_Enough())
        {
            return;
        }
        if(this.m_b_cur_day_signed && this.m_cur_day_sign_day_signed_count >= 2)
        {
            return;
        }
        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node,
            ()=>
            {
            
            },
            
            "签到再次领取",(bsuc)=>
        {
            if(!bsuc)
            {
                return;
            }


            self.RealLingqu(3);

        });

    }
    OnBtn_Sanbei_Lingqu()
    {
        if(!this.Check_Btn_Click_Enough())
        {
            return;
        }
        if(this.m_b_cur_day_signed && this.m_cur_day_sign_day_signed_count >= 2)
        {
            return;
        }
        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node,
            ()=>
            {
            
            },
            
            "签到双倍",(bsuc)=>
        {
            if(!bsuc)
            {
                return;
            }


            self.RealLingqu(3);

        });

        MiddleGamePlatformAction.GetInstance().Show_Qiandao_Banners(false);

    }


    Get_Day_Sign_Award(iday)
    {
        if(iday == 1)
        {
            return [{"t":6,"c":1}];
            
        }
        else if(iday == 2)
        {
            return [{"t":5,"c":100}];
        }
        else if(iday == 3)
        {
            return [{"t":1,"c":100}];
        } else if(iday == 4)
        {
            return [{"t":5,"c":150}];
        }else if(iday == 5)
        {
            return [{"t":6,"c":2}];
        }else if(iday == 6)
        {
            return [{"t":1,"c":150}];
        }else if(iday == 7)
        {
            return [{"t":1,"c":200},{"t":5,"c":200},{"t":6,"c":3}  ];
        }

        return [{"t":1,"c":100}];
    }

    SetInfo(pinfo)
    {
        this.m_callback = pinfo.callback;
        MiddleGamePlatformAction.GetInstance().Show_Qiandao_Banners(true);
        MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(15,true);
    }
    RealLingqu(ibeishu)
    {
        if(this.m_b_cur_day_signed && this.m_cur_day_sign_day_signed_count >= 2)
        {
            return;
        }
     
        var menu2_putong = cc.find("panel/menu2/putonglingqu",this.node);
        var menu2_shuangbei = cc.find("panel/menu2/shuangbeilqu",this.node);
        var zaici_lingqu = cc.find("panel/menu2/zaici_lingqu",this.node);
 
       /*
        menu2_putong.getComponent(cc.Button).interactable = false;
        menu2_shuangbei.getComponent(cc.Button).interactable = false;
        zaici_lingqu.getComponent(cc.Button).interactable = false;

        */
        
        var awrad = this.Get_Day_Sign_Award(this.m_cur_day_sign_day_index);

        GlobalConfig.GetIns().Common_Add_Award_List(awrad,ibeishu);
    

        this.m_b_cur_day_signed = 1;
        this.m_cur_day_sign_day_signed_count++;
      

        var pobj = {"sign_day_union":Util.GetCurDayUnionD(),"sign_day_index":this.m_cur_day_sign_day_index,
            last_sign_day_signed_count: this.m_cur_day_sign_day_signed_count}
        MyLocalStorge.setItem("huadouxiaoxiao_sign_data",JSON.stringify(pobj));

        

        this.Refresh();
 
        // 领取奖励 
        var self = this;
        ComFunc.Open_Get_Daoju_Award_Dlg(this.node, awrad, ibeishu, null);
          
        /*
         this.scheduleOnce(()=>
         {
            ComFunc.Open_Get_Daoju_Award_Dlg(self.node.parent, awrad, ibeishu,self.m_callback);
            //self.node.destroy();
         },0.05);
         */


         
       MiddleGamePlatformAction.GetInstance().Show_Qiandao_Banners(false);
       MiddleGamePlatformAction.GetInstance().Set_Subgame_Gezi_Dlg_Is_Show(15,false);

 
    }
}
