import ComFunc from "../../comfuncs/ComFunc";
import WatchVideoAdveseMng from "../../comfuncs/WatchVideoAdveseMng";
import tankuang from "../../dlg/tankuang";
import GlobalConfig from "../GlobalConfig";

 
 

const {ccclass, property} = cc._decorator;

@ccclass
export default class xingyunlibao_dlg extends cc.Component {

   
    m_callback = null;
    
    onLoad () 
    {
    
        var mianfeilingqu = cc.find("panel/mianfeilingqu",this.node);
        mianfeilingqu.on("click",this.OnBtnLingqu.bind(this));

        var pseq = cc.sequence(cc.scaleTo(0.5,1.05),cc.scaleTo(0.5,1));
        mianfeilingqu.runAction(cc.repeatForever(pseq))

        var tankuang:tankuang = this.node.getComponent("tankuang");
        tankuang.Set_Close_Lisnter(this);
 
        this.schedule(this.FD_Timer.bind(this),0.5);
        this.Refresh_Info();

     }
     OnBtnLingqu()
     {
        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node,
            ()=>
            {
            
            },
            
            "幸运礼包",(bsuc)=>
        {
            if(!bsuc)
            {
                return;
            }


            self.RealLingqu();

        },"","",null,"大厅首日礼包");
     }
     On_Real_Lignqu_End()
     {
         this.OnBtnExit();
     }
     RealLingqu()
     {
         var self = this;
        var awrad = [{"t":1,"c":200},{"t":21,"c":1} ,{"t":5,"c":200},{"t":24,"c":1} ,{"t":6,"c":3} ];
        GlobalConfig.GetIns().Common_Add_Award_List(awrad,1);

        GlobalConfig.GetIns().m_xingyun_libao_lingqued = 1;
        ComFunc.Open_Get_Daoju_Award_Dlg(this.node, awrad, 1, ()=>
        {
            self.On_Real_Lignqu_End();
        });
        
     }
     FD_Timer()
     {
         this.Refresh_Info();
     }

     Refresh_Info()
     {
        var yilingqu = cc.find("panel/yilingqu",this.node)
        var mianfeilingqu = cc.find("panel/mianfeilingqu",this.node);
  
        if(GlobalConfig.GetIns().m_xingyun_libao_lingqued)
        {
            yilingqu.active = true;
            mianfeilingqu.active = false;
        }else{
            yilingqu.active = false;
            mianfeilingqu.active = true;

        }


        var xingyunlibao_t_label = cc.find("panel/left_t",this.node);

        var ileft_sec = GlobalConfig.GetIns().Get_Xingyun_Libao_Left_Sec();

        if(ileft_sec > 0)
        {
            xingyunlibao_t_label.getComponent(cc.Label).string = "" + ComFunc.FormatLeftSecStr(ileft_sec)

        }else{
            xingyunlibao_t_label.getComponent(cc.Label).string = "" ;

        }
   
          
     }
     OnBtnExit()
     {
         
         this.node.destroy();
        if(this.m_callback)
        {
            this.m_callback();
        } 
      
     }
     On_Tankuang_Real_Exit()
     {
         this.OnBtnExit();
     }
    SetInfo(pinfo)
    {
        this.m_callback = pinfo.callback;

    }
}
