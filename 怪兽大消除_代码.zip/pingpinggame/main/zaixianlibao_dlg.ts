import BundleLoadUtils from "../../comfuncs/BundleLoadUtils";
import ComFunc from "../../comfuncs/ComFunc";
import WatchVideoAdveseMng from "../../comfuncs/WatchVideoAdveseMng";
import GlobalGameMng from "../../Mng/GlobalGameMng";
import BannerGuangaoMng from "../../WDT/BannerGuangaoMng";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class zaixianlibao_dlg extends cc.Component {

    
    m_cb = null;

    onLoad () 
    {
        var exitbtn = cc.find("panel/exitbtn",this.node);
        exitbtn.on("click",this.OnBtnExit.bind(this));


        var shuangbeilqu = cc.find("panel/menu2/shuangbeilqu",this.node);
        shuangbeilqu.on("click",this.OnBtnSanbeiLingqu.bind(this));

        var putonglingqu = cc.find("panel/menu2/putonglingqu",this.node);
        putonglingqu.on("click",this.OnBtnPuTongLingqu.bind(this));


        
        this.Refresh_Online_Libao_Info();
        this.schedule(this.FD_Timer.bind(this),0.3)

        BannerGuangaoMng.GetInstance().CheckShowChaiping(21);

    }


    OnBtnPuTongLingqu()
    {
        var left_info = GlobalGameMng.GetInstance().Get_Cur_Day_OnLine_Libao_Left_Sec_Info();

        if(!left_info[0])
        {
           
            return;
        }

        var ileftsec = left_info[1];

        if(ileftsec > 0)
        {
            return;
        }

        var rewardinfo = left_info[2];
        if(!rewardinfo)
        {
            return;
        }

        this.RealLingqu(1);
    }

    RealLingqu(ibeishu)
    {
        var left_info = GlobalGameMng.GetInstance().Get_Cur_Day_OnLine_Libao_Left_Sec_Info();

        if(!left_info[0])
        {
           
            return;
        }

        var ileftsec = left_info[1];

        if(ileftsec > 0)
        {
            return;
        }

        var rewardinfo = left_info[2];
        if(!rewardinfo)
        {
            return;
        }

        var reward_wuping_jl = rewardinfo.jl;


         GlobalGameMng.GetInstance().Online_Libao_Lingqu(ibeishu); 
       

        var self = this;
        ComFunc.Open_Get_Daoju_Award_Dlg(this.node, reward_wuping_jl, ibeishu,()=>
        {
            
        });

        this.Refresh_Online_Libao_Info();

    }
    OnBtnSanbeiLingqu()
    {
        var left_info = GlobalGameMng.GetInstance().Get_Cur_Day_OnLine_Libao_Left_Sec_Info();

        if(!left_info[0])
        {
           
            return;
        }

        var ileftsec = left_info[1];

        if(ileftsec > 0)
        {
            return;
        }

        var rewardinfo = left_info[2];
        if(!rewardinfo)
        {
            return;
        }

        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node,
            ()=>
            {
            
            },
            
            "三倍领取在线奖励",(bsuc)=>
        {
            if(!bsuc)
            {
                return;
            }


            self.RealLingqu(3);

        });
    }
    FD_Timer()
    {
        this.Refresh_Online_Libao_Info();
    }
    OnBtnExit()
    {
        
        this.node.destroy();

        if(this.m_cb)
        {
            this.m_cb();
        }
    }
    SetInitData(paradata)
    {
        this.m_cb = paradata.cb; 
 
    }
    Refresh_Online_Libao_Info()
    {
        var left_info = GlobalGameMng.GetInstance().Get_Cur_Day_OnLine_Libao_Left_Sec_Info();

        var rewardinfohow = left_info[2];
        var reward_wuping_jl = rewardinfohow.jl;


        for(var ff=1;ff<=5;ff++)
        {
            var ff_ndoe = cc.find("panel/wuping/"+ff,this.node);

            var ff_pos= this.Get_Wuping_Pos(ff,reward_wuping_jl.length);
            ff_ndoe.setPosition(ff_pos);
            if(reward_wuping_jl.length < ff)
            {
                ff_ndoe.active = false;
            }else{

                ff_ndoe.active = true;
                var ff_info  = reward_wuping_jl[ff-1];
                ff_ndoe.getChildByName("c").getComponent(cc.Label).string = "x"+ff_info.c;
    
                var ff_t = ff_info.t;
    
                var ff_icon = ff_ndoe.getChildByName("icon");
    
                BundleLoadUtils.ShowIconNodePicBundle_Show_Fit("resources",ff_icon,"daoju/com/"+ff_t,{width:60,height:60})
            }

          
        }

        var yilingqu = cc.find("panel/yilingqu",this.node);
        var not_im_time = cc.find("panel/not_im_time",this.node);
        var menu2 = cc.find("panel/menu2",this.node);

        if(!left_info[0])
        {
            yilingqu.active = true;
            not_im_time.active = false;
            menu2.active = false;
        }
        else{
            var ileftsec = left_info[1];
            if(ileftsec <= 0)
            {
         
                yilingqu.active = false;
                not_im_time.active = false;
                menu2.active = true;
            }
            else{
                yilingqu.active = false;
                not_im_time.active = true;
                menu2.active = false;

                var leftsec_label = not_im_time.getChildByName("leftsec");
                leftsec_label.getComponent(cc.Label).string = ComFunc.FormatLeftSecStr(ileftsec)
            }

        }

    }

    Get_Wuping_Pos(ff,ilen)
    {
        if(ilen <= 1)
        {
            return new cc.Vec2(0,0);
        }
        if(ilen  ==2)
        {
            var ix = (ff-1)*140 -70;
            return new cc.Vec2(ix,0);
        }
        if(ilen  ==3)
        {
            var ix = (ff-1)*110 -110;
            return new cc.Vec2(ix,0);
        }


        if(ilen  ==4)
        {
            var ix = (ff-1)*100 -150;
            return new cc.Vec2(ix,0);
        }
        if(ilen  ==5)
        {
            var ix = (ff-1)*80 -160;
            return new cc.Vec2(ix,0);
        }
        return new cc.Vec2(0,0);
    }
    
}
