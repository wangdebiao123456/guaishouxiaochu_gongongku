 
import BaseUIUtils from "../../comfuncs/BaseUIUtils";
import SoundManager from "../../comfuncs/SoundManager";
import ZhanghaoMng from "../../PlatForm/ZhanghaoMng";
import Util from "../../utils/Util";
import XSC_Server_Request from "../../utils/XSC_Server_Request";
import WMap from "../../WDT/WMap";
import GlobalConfig from "../GlobalConfig";

 


const {ccclass, property} = cc._decorator;

@ccclass
export default class huaduo_paihangbang_dlg extends cc.Component {

    @property(cc.Prefab)
    paihangbang_list_item:cc.Prefab = null;
  
    m_callback = null;

    m_b_need_refreshed = false;
    
    m_paihangbang_info_list = [];

    m_sguid_posted_map = new WMap();

    m_all_paihangbang_node_item_list = [];
    m_self_score = 0;
    sv_content = null;

    m_self_in_paiming = -1;


    onLoad () 
    {


        var loading_node = cc.find("panel/loadingtip/loading",this.node);
       var pseq = cc.repeatForever(cc.rotateBy(0.1,30))
       loading_node.runAction(pseq);


       this.schedule(this.FD_Check_Need_Refresh.bind(this),1);

        SoundManager.GetInstance().Play_Click_Btn_Effect();

        
       var self = this;

       ZhanghaoMng.GetInstance().Check_Showquan_Get_User_Info()



    }
    

    SetInfo(pinfo)
    {
        
        this.sv_content = cc.find("panel/sc/view/content",this.node)
        this.m_callback = pinfo.callback;


        var loadingtip_node = cc.find("panel/loadingtip",this.node);
        loadingtip_node.active = true;


        this.Post_Get_Paihang_Data(2);
    }
    On_Get_Paihangbang_Failed()
    {

        Util.ShowTipTxtDlg("获取排行数据失败,请稍后再试试!",this.node);
        var loading_node = cc.find("panel/loadingtip/loading",this.node);
        loading_node.active = false;

        var loadingtip_t = cc.find("panel/loadingtip/t",this.node);
        loadingtip_t.getComponent(cc.Label).string = "获取排行榜数据失败,请稍后再来";
        
    }

    On_PaihangBang_Info_Readed(response)
    {

        var obj =  null;
        try{
            obj = JSON.parse(response);
        }catch(e)
        {

        }

        if(!obj || obj.itype == undefined || !obj.objlist)
        {
            Util.ShowTipTxtDlg("获取排行数据数据错误,请稍后再试试!",this.node);
            var loading_node = cc.find("panel/loadingtip/loading",this.node);
            loading_node.active = false;
    
            var loadingtip_t = cc.find("panel/loadingtip/t",this.node);
            loadingtip_t.getComponent(cc.Label).string = "获取排行数据数据错误,请稍后再来";
            return;
        }
        
        var icount = obj.icount;
        if(icount == 0)
        {
            Util.ShowTipTxtDlg("该排行榜暂无数据",this.node);
            var loading_node = cc.find("panel/loadingtip/loading",this.node);
            loading_node.active = false;
    
            var loadingtip_t = cc.find("panel/loadingtip/t",this.node);
            loadingtip_t.getComponent(cc.Label).string = "该排行榜暂无数据";
            return;
        }


        var selfnode = cc.find("panel/selfnode",this.node);
        selfnode.active = true;
        
  
        var loadingtip_node = cc.find("panel/loadingtip",this.node);
        loadingtip_node.active = false;


        this.Refresh_Show_Paihang_List( obj.req_user_score, obj.objlist);

      
    }
    Post_Get_Paihang_Data( iseltype)
    {
        var self = this;
        XSC_Server_Request.GetInstance().Post_Server_Get_PaihangBang_Data(iseltype,
            (bsuc,response)=>
            {
                  
                if(!bsuc)
                {
                    self.On_Get_Paihangbang_Failed();

                    return;
                }

                self.On_PaihangBang_Info_Readed(response);
                //{"itype":1001,"icount":3,"objlist":[{"sguid":"d67e378f-00e4-2bd3-7f21-d2e079d8ea43","imaxscore":160},{"sguid":"280d9b81-136c-5840-beec-d6ba69f8cf4a","imaxscore":120},{"sguid":"738a885f-78f4-ced4-79c9-3a7c7a145277","imaxscore":60}]}
            
        });

    }
    FD_Check_Need_Refresh()
    {
        if(!this.m_b_need_refreshed)
        {
            return;
        }

        this.m_b_need_refreshed = false;
        if(!this.m_paihangbang_info_list)
        {
            return;
        }

        this.Refresh_Show_Paihang_List(this.m_self_score, this.m_paihangbang_info_list);
    }

    Get_Score_Desc(imaxscore)
    {
        return "最高:"+imaxscore+"关";

    }
    Refresh_Show_Paihang_List(self_score, objlist)
    {

        this.m_self_score = self_score;
        var selg_guid = XSC_Server_Request.GetInstance().Get_Saved_GUID();

        var self_in_paiming = -1;

        this.m_paihangbang_info_list = objlist;

        for(var ff=0;ff<this.m_all_paihangbang_node_item_list.length;ff++)
        {
            var ff_node = this.m_all_paihangbang_node_item_list[ff];
            ff_node.active = false;
        }
    
        for(let i=0;i<this.m_paihangbang_info_list.length;i++){
            let periteminfo = this.m_paihangbang_info_list[i];
            var sguid = periteminfo.sguid;
            var imaxscore = periteminfo.imaxscore;
            var imingci = i+1;

            if(selg_guid == sguid)
            {
                this.m_self_score = imaxscore;
                self_in_paiming = imingci;
            }

            var p_i_node = null;
            if(i >= this.m_all_paihangbang_node_item_list.length)
            {
                let pnode= cc.instantiate(this.paihangbang_list_item);
                this.sv_content.addChild(pnode,19);
                this.m_all_paihangbang_node_item_list[i] = pnode;
                p_i_node = pnode;
            }else{
                p_i_node = this.m_all_paihangbang_node_item_list[i];
            }

         
            p_i_node.active = true;
            p_i_node.setPosition(0,-70-130*i);

            var   scoreinfo_node = cc.find("scoreinfo",p_i_node);
            scoreinfo_node.getComponent(cc.Label).string = this.Get_Score_Desc(imaxscore);

            var   top3_node = cc.find("paiming/top3",p_i_node);
            var   mingci_node = cc.find("paiming/mingci",p_i_node);
         
           
            mingci_node.getComponent(cc.Label).string = ""+imingci;

            if(imingci  <= 3)
            {
                top3_node.active = true;
                mingci_node.active = false;

                
                for(var hh=1;hh<=3;hh++)
                {
                    var hh_ndoe = top3_node.getChildByName(""+hh);

                    if(hh_ndoe)
                    {
                        if(hh  == imingci)
                        {
                            hh_ndoe.active = true;
                        }else{

                            hh_ndoe.active = false;
                        }
                    }
                }

               // BaseUIUtils.ShowIconNodePicFilename(top3_node,"dating/paihang/"+imingci,{cx:63,cy:63})
            }else{
                top3_node.active = false;
                mingci_node.active = true;
            }


            var other_user_info = GlobalConfig.GetIns().Query_Other_User_Nick_Touxiang_Info(sguid);

            var bexisted = 0;
            if(other_user_info)
            {
                bexisted = other_user_info.existed;
            }


            var  name_node = cc.find("name",p_i_node);
            var  touxiang_node = cc.find("touxiangkk/icon",p_i_node);
       
            if(!bexisted)
            {
                name_node.getComponent(cc.Label).string = "用户";
                BaseUIUtils.ShowIconNodePicFilename(touxiang_node,"default",{cx:82,cy:82})
       
                this.Check_Post_Request_Other_User_Info(sguid);
            }
            else{
                name_node.getComponent(cc.Label).string =other_user_info.snickname;

                var stouxiangurl = other_user_info.stouxiangurl;

                if(stouxiangurl)
                {   
                    BaseUIUtils.Show_Remote_Touxiang(touxiang_node,stouxiangurl,{cx:82,cy:82});

                   
                }else{
                    BaseUIUtils.ShowIconNodePicFilename(touxiang_node,"default",{cx:82,cy:82})
       
                }
              
            }
            

        }


        this.sv_content.setContentSize(this.sv_content.width,  130*objlist.length+10);


        var self_chengji = cc.find("panel/selfnode/chengji",this.node);
        self_chengji.getComponent(cc.Label).string = this.Get_Score_Desc(this.m_self_score);


        var self_paiming = cc.find("panel/selfnode/paiming/mingci",this.node);

        if(self_in_paiming > 0)
        {
            self_paiming.getComponent(cc.Label).string = ""+self_in_paiming+"";

        }else{
            self_paiming.getComponent(cc.Label).string = "50+";

        }


        this.m_self_in_paiming= self_in_paiming;
   

        var self_nickname = cc.find("panel/selfnode/nickname",this.node);

        var snicnname = ZhanghaoMng.GetInstance().Get_Self_Show_Nickname();
        self_nickname.getComponent(cc.Label).string  = ""+snicnname;
        
        var self_touxiang = cc.find("panel/selfnode/touxiangkk/icon",this.node);

        var self_touxiangurl = ZhanghaoMng.GetInstance().Get_Self_Touxiang_URL();
        if(self_touxiangurl)
        {
            BaseUIUtils.Show_Remote_Touxiang(self_touxiang,self_touxiangurl,{cx:82,cy:82});

              
        }else{
            BaseUIUtils.ShowIconNodePicFilename(touxiang_node,"default",{cx:82,cy:82})
       
        }


        var   self_top3_node = cc.find("panel/selfnode/paiming/top3",this.node);
        var   self_mingci_node = cc.find("panel/selfnode/paiming/mingci",this.node);
      

        if(self_in_paiming  <= 3)
        {
            self_top3_node.active = true;
            self_mingci_node.active = false;

            
            for(var hh=1;hh<=3;hh++)
            {
                var hh_ndoe = self_top3_node.getChildByName(""+hh);

                if(hh_ndoe)
                {
                    if(hh  == self_in_paiming)
                    {
                        hh_ndoe.active = true;
                    }else{

                        hh_ndoe.active = false;
                    }
                }
            }

           // BaseUIUtils.ShowIconNodePicFilename(top3_node,"dating/paihang/"+imingci,{cx:63,cy:63})
        }else{
            self_top3_node.active = false;
            self_mingci_node.active = true;
        }

    }

    Check_Post_Request_Other_User_Info(sguid)
    {
        if(this.m_sguid_posted_map.hasKey(sguid))
        {
            return;
        }

        this.m_sguid_posted_map.putData(sguid,1);

        var self = this;
        XSC_Server_Request.GetInstance().Check_Post_Request_Other_User_Info(sguid,
            (bsuc,response)=>
            {
                if(!bsuc)
                {
                    return;
                }

                 

                var jobj = JSON.parse(response);

                if(!jobj)
                {
                    return;
                }
            
                self.On_Readed_Other_User_Basic_Info(jobj.existed,jobj.sguid,jobj.snickname,jobj.stouxiangurl);
            }
        
        )

    }
    On_Readed_Other_User_Basic_Info( existed, sguid, snickname, stouxiangurl)
    {
        GlobalConfig.GetIns().On_Readed_Other_User_Basic_Info( existed, sguid, snickname, stouxiangurl)

        this.m_b_need_refreshed = true;
        //this.Refresh_Show_Paihang_List(this.m_self_score, this.m_paihangbang_info_list);
    }
 
}
