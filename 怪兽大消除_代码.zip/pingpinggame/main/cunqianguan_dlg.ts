import ComFunc from "../../comfuncs/ComFunc";
import SoundManager from "../../comfuncs/SoundManager";
import WatchVideoAdveseMng from "../../comfuncs/WatchVideoAdveseMng";
import Util from "../../utils/Util";
import GlobalConfig from "../GlobalConfig";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class cunqianguan_dlg extends cc.Component {

  
    m_callback = null;
    
    onLoad () 
    {
 


        var lingqubtn = cc.find("panel/lingqubtn",this.node);
        lingqubtn.on("click",this.OnBtnLingqu.bind(this))

        
        var pseq = cc.sequence(cc.scaleTo(0.5,1.05),cc.scaleTo(0.5,1));
        lingqubtn.runAction(cc.repeatForever(pseq));


        SoundManager.GetInstance().Play_Click_Btn_Effect();

        this.Refresh_Info();
    }

    SetInfo(pinfo)
    {
        this.m_callback = pinfo.callback;

        this.Refresh_Info();
    }
    Refresh_Info()
    {
        var c_label = cc.find("panel/c",this.node);
        c_label.getComponent(cc.Label).string = ""+GlobalConfig.GetIns().m_cunqianguan_monmey+"/600";

        var iprogress = 1;
        if(GlobalConfig.GetIns().m_cunqianguan_monmey < 600)
        {
            iprogress = GlobalConfig.GetIns().m_cunqianguan_monmey/600;
        }


        var jindutiao = cc.find("panel/center/jindu/bar",this.node);
        jindutiao.getComponent(cc.Sprite).fillRange = iprogress;

    }

    OnBtnLingqu()
    {
        if(GlobalConfig.GetIns().m_cunqianguan_monmey < 300)
        {
            Util.ShowTipTxtDlg("金币不足300,通关关卡获得金币",this.node)
            return;
        }
        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node,
            ()=>
            {
            
            },
            
            "存钱罐",(bsuc)=>
        {
            if(!bsuc)
            {
                return;
            }


            self.RealLingqu();

        });
    }
    RealLingqu()
    {
        var im = GlobalConfig.GetIns().m_cunqianguan_monmey;
        var awrad = [{"t":1,"c":im} ];
        GlobalConfig.GetIns().Common_Add_Award_List(awrad,1);

        var self = this;
        GlobalConfig.GetIns().m_cunqianguan_monmey = 0;
        ComFunc.Open_Get_Daoju_Award_Dlg(this.node, awrad, 1, ()=>
        {
            self.On_Real_Lignqu_End();
        });

        GlobalConfig.GetIns().Add_CunqianGuan_QuKuang_Count();

    }
    On_Real_Lignqu_End()
     {
         this.OnBtnExit();
     }
     OnBtnExit()
     {
         
         this.node.destroy();
        if(this.m_callback)
        {
            this.m_callback();
        } 
      
     }


}
