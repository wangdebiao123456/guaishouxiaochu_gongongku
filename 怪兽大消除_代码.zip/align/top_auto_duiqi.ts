 
 

const {ccclass, property} = cc._decorator;

@ccclass
export default class top_auto_duiqi extends cc.Component {

    @property
    algintop: number = 640;

    @property
    heipingalgintop: number = 700;

    Get_Real_Height()
    {
        var winsize = cc.director.getWinSize();
        var cx = winsize.width;
        var cy=  winsize.height;

        let size1 = cc.view.getFrameSize();
        var cx2 = size1.width;
        var cy2=  size1.height;

        
        var icomss = cx/cy;
        var ireals = cx2/cy2;


        var caculate_topy = cy;
        if(ireals > icomss)
        {
            //宽比实际宽
            caculate_topy = cy;
        }
        else if(ireals < icomss)
        {
            //高比实际高

            caculate_topy = cy * icomss/ireals;

        }else
        {
            caculate_topy = cy;
        }

        return caculate_topy;
    }

     ISChaoGaoPing()
    {
        var winsize = cc.director.getWinSize();
        var cx = winsize.width;
        var cy=  winsize.height;

        let size1 = cc.view.getFrameSize();
        var cx2 = size1.width;
        var cy2=  size1.height;

        
        var icomss = cx/cy;
        var ireals = cx2/cy2;


        var caculate_topy = cy/2;
        if(ireals > icomss)
        {
            //宽比实际宽
            caculate_topy = cy/2;
        }
        else if(ireals < icomss)
        {
            //高比实际高

            caculate_topy = cy/2 * icomss/ireals;

        }else
        {
            caculate_topy = cy/2;
        }

       
     //   console.log("cx="+cx+",cy="+cy+",cx2="+cx2+",cy2="+cy2+",caculate_topy="+caculate_topy);
        
        if(caculate_topy >= 760)
        {
            return true;
        }

        return false;
    }
    onLoad () 
    {

         var bchaogaoping = this.ISChaoGaoPing();

         var irealheight = this.Get_Real_Height();

         var cal_top_y = irealheight/2;

         var algint = this.algintop;
         if(bchaogaoping)
         {
            algint = this.heipingalgintop;
         }

         this.node.y = cal_top_y - algint;

/*
        var windows_size = cc.director.getWinSize();
        var cx1 = windows_size.width;
        var cy1 =  windows_size.height;

        let size1 = cc.view.getFrameSize();
        var cx2 = size1.width;
        var cy2=  size1.height;

        
        var icom_sclae = cx1/cy1;
        var ireal_sclae = cx2/cy2;

        var algint = this.algintop;

        var cal_top_y = cy1/2;
        if(ireal_sclae > icom_sclae)
        {
            //宽比实际宽
            cal_top_y = cy1/2;
        }
        else if(ireal_sclae < icom_sclae)
        {
            //高比实际高

            cal_top_y = cy1/2 * icom_sclae/ireal_sclae;

            if(icom_sclae/ireal_sclae > 1.1)
            {
                algint = this.heipingalgintop;
            }


           
        }else
        {
            cal_top_y = cy1/2;
        }

        this.node.y = cal_top_y - algint;

        */


    }
 
}
