 

const {ccclass, property} = cc._decorator;

@ccclass
export default class duiqi_right extends cc.Component {

 
    @property
    alginright: number = 0;

 
    
    onLoad () 
    {

     

        var window_size = cc.director.getWinSize();
        var cx1 = window_size.width;
        var cy1 =  window_size.height;

        let framesize = cc.view.getFrameSize();
        var cx2 = framesize.width;
        var cy2=  framesize.height;

        
        var icomscale = cx1/cy1;
        var ireal_sclae = cx2/cy2;


        var cal_width = cx1/2;
        if(ireal_sclae > icomscale)
        {
            //宽比实际宽
            cal_width = cx1/2 * ireal_sclae/icomscale;;
        }
        else if(ireal_sclae < icomscale)
        {
            //高比实际高

            cal_width =cx1/2;

        }else
        {
            cal_width = cx1/2 ;
        }

        this.node.x =   cal_width   - this.alginright;


    }
 
}
