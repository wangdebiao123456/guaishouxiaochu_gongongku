import MyLocalStorge from "../WDT/MyLocalStorge";
import BundleLoadUtils from "./BundleLoadUtils";
import ClientLogUtils from "./ClientLogUtils";

export default class PreLoadResMng
{
    static _instance:PreLoadResMng = null;
 
    static GetInstance() 
    {
        if (!PreLoadResMng._instance) {
            // doSomething
            PreLoadResMng._instance = new PreLoadResMng();
             
        }
        return PreLoadResMng._instance;
    }


    m_readed_preload_file_config_remote_json = null;
    m_last_save_valid_preload_file_config_remote_json = null;


    m_b_in_bk_loaded = false;

    m_init_load_call_bk = null;
    m_bk_all_need_loaded_res_count = 0;
    m_bk_all_has_loaded_res_count = 0;
    m_dating_scecnce_loaded = false;

    m_orianl_config_json = null;

    m_start_bk_load_tick = 0;

    constructor()
    {

        this.InitRead_Last_Save_Common_Server_Config();
    }

    Set_Origianl_Preload_File(psonobj)
    {
        this.m_orianl_config_json = psonobj;

        //console.log("orianljson = "+JSON.stringify(psonobj))

    }
    Get_Cur_Valid_Server_PreloadFile_Config()
    {
        if(this.m_readed_preload_file_config_remote_json)
        {
            if(this.m_readed_preload_file_config_remote_json.bvalid)
            {
                return this.m_readed_preload_file_config_remote_json;
            }
        }

        if(this.m_last_save_valid_preload_file_config_remote_json)
        {
            if(this.m_last_save_valid_preload_file_config_remote_json.bvalid)
            {
                return this.m_last_save_valid_preload_file_config_remote_json;
            }
        }

        if(this.m_orianl_config_json)
        {
            if(this.m_orianl_config_json.bvalid)
            {
                return this.m_orianl_config_json;
            }
        }
 
        return null;
    }


    InitRead_Last_Save_Common_Server_Config()
    {
        
        var str = MyLocalStorge.getItem("guaishoudaxiaochu_last_save_server_preloadfile_config", "");

        if(!str)
        {
            return;
        }
    
        var basic_obj = JSON.parse(str);
        if(!basic_obj)
        {
            return;
        }

        if(!basic_obj.bvalid)
        {
            return;
        }

        this.m_last_save_valid_preload_file_config_remote_json = basic_obj;
    }
    On_Loaded_Server_Remote_Common_Config(remoteobj)
    {
        if(!remoteobj)
        {
            return;
        }


        var self = this;
        self.m_readed_preload_file_config_remote_json =  remoteobj;

        if(self.m_readed_preload_file_config_remote_json)
        {
            if(self.m_readed_preload_file_config_remote_json.bvalid)
            {
                MyLocalStorge.setItem("guaishoudaxiaochu_last_save_server_preloadfile_config",JSON.stringify(self.m_readed_preload_file_config_remote_json))
            }
        }
    }

    Load_Game_PreloadFile_Config(callback)
    {
       
        var irand11 = Math.floor(Math.random()*1000) ;
        var config_json = "https://outercoms.zfgame123.com/config/guaishou_da_xiaochu/wx/guaishou_da_xiaochu_preload.json?r="+irand11;
 
        var self = this;
 
     
        cc.assetManager.loadRemote(config_json, (err, jobj:cc.JsonAsset) =>  
        {
            if(err)
            {
                self.m_readed_preload_file_config_remote_json = null;
                callback();
                console.log("加载配置错误:"+err)
                return;
            }

            if(jobj.json)
            {
                self.On_Loaded_Server_Remote_Common_Config(jobj.json);

            }
         
         
           
            callback();
        });
      
    }
    On_All_Bk_Res_Load_Finished()
    {
        if(this.m_init_load_call_bk)
        {
            this.m_init_load_call_bk();
            this.m_init_load_call_bk = null;
        }

        var iepalsetick = Date.now() -  this.m_start_bk_load_tick;
        var iepalse_sec = Math.floor(iepalsetick/1000);


        var config_readed = 0;
        var preloadfile_config = PreLoadResMng.GetInstance().Get_Cur_Valid_Server_PreloadFile_Config();

        if(preloadfile_config)
        {
            config_readed = 1;
        }

        ClientLogUtils.GetInstance().Poset_Server_JS_Log(84, "all bk 加载",
        this.m_b_in_bk_loaded,"成功加载:"+this.m_b_in_bk_loaded,iepalse_sec, "用时:"+iepalse_sec+"秒",
            config_readed, "共:"+this.m_bk_all_need_loaded_res_count);
 
        
        
    }

    Bk_Load_All_PreloadFile_Res_List(callback)
    {

        if(this.m_b_in_bk_loaded)
        {
            return;
        }

       

        var preloadfile_config = PreLoadResMng.GetInstance().Get_Cur_Valid_Server_PreloadFile_Config();

        if(!preloadfile_config)
        {
            callback();
            return;
        }


        this.m_start_bk_load_tick = Date.now();

        this.m_b_in_bk_loaded = true;

        this.m_init_load_call_bk = callback;

        var preload_list = preloadfile_config.preload;
        var load_list = preloadfile_config.load;

        var pre_scence = preloadfile_config.pre_scence;
        if(!pre_scence)
        {
            pre_scence = [];
        }

        


        for(var ff=0;ff<preload_list.length;ff++)
        {
            var ff_info  =  preload_list[ff];

            var ff_waitall =  ff_info.waitall;
            var ff_fl =  ff_info.fl;
    
            if(ff_waitall)
            {
                this.m_bk_all_need_loaded_res_count += ff_fl.length;
            }
        }


        for(var ff=0;ff<load_list.length;ff++)
        {
            var ff_info  =  load_list[ff];
            var ff_waitall =  ff_info.waitall;
            var ff_fl =  ff_info.fl;
    
            if(ff_waitall)
            {
                this.m_bk_all_need_loaded_res_count += ff_fl.length;
            }
        }



        for(var ff=0;ff<preload_list.length;ff++)
        {
            var ff_info  =  preload_list[ff];

            this.PreLoad_Info(ff_info);
        }


        for(var gg=0;gg<load_list.length;gg++)
        {
            var gg_info  =  load_list[gg];

            this.Load_Info(gg_info);
        }


        for(var kk=0;kk<pre_scence.length;kk++)
        {
            var kk_scence_name = pre_scence[kk];
            cc.director.preloadScene(kk_scence_name);

          //  console.log("preloadScene :"+kk_scence_name)
        }

        if(this.m_bk_all_need_loaded_res_count == 0)
        {
            this.On_All_Bk_Res_Load_Finished();
        }
 
    }
    Bunble_Load_Info_Perfile(bunblrnmae, bunlde:cc.AssetManager.Bundle, ff_filename_or_path,bdir,bwaitall)
    {
        var self = this;
        if(bdir)
        {
            bunlde.loadDir(ff_filename_or_path, (error: Error, items:[]) =>
            {
               
              // console.log("loaddir filename="+bunblrnmae+"/"+ff_filename_or_path+",error="+error+",items len="+items.length)

                if(bwaitall)
                {
                    self.On_Bk_Loaded_Finish(1);
                }
                

            })
        }else{
            bunlde.load(ff_filename_or_path,(error: Error, items:[]) =>
            {
                
               // console.log("load filename="+bunblrnmae+"/"+ff_filename_or_path+",error="+error+",items len="+items.length)

                if(bwaitall)
                {
                    self.On_Bk_Loaded_Finish(1);
                }
                

            })
        }
    }
    Bunble_Load_Info(bunblrnmae, bunlde:cc.AssetManager.Bundle, file_list,bdir,bwaitall)
    {
        var self = this;
        for(var ff=0;ff<file_list.length;ff++)
        {
            var ff_filename_or_path = file_list[ff];

            this.Bunble_Load_Info_Perfile(bunblrnmae, bunlde , ff_filename_or_path,bdir,bwaitall)

            /*
            if(bdir)
            {
                bunlde.loadDir(ff_filename_or_path, (error: Error, items:[]) =>
                {
                    console.log("loaddir filename="+bunblrnmae+"/"+ff_filename_or_path+",error="+error+",items len="+items.length)

                    if(bwaitall)
                    {
                        self.On_Bk_Loaded_Finish(1);
                    }
                    

                })
            }else{
                bunlde.load(ff_filename_or_path,(error: Error, items:[]) =>
                {
                     console.log("load filename="+bunblrnmae+"/"+ff_filename_or_path+",error="+error+",items len="+items.length)

                    if(bwaitall)
                    {
                        self.On_Bk_Loaded_Finish(1);
                    }
                    

                })
            }
            */
        }
    }

    
    Bunble_Pre_Load_Info_Perfile(bundlename, bunlde:cc.AssetManager.Bundle, ff_filename_or_path,bdir,bwaitall)
    {
        var self = this;
        if(bdir)
        {
            bunlde.preloadDir(ff_filename_or_path, (error: Error, items:cc.AssetManager.RequestItem[]) =>
            {
                
               
              // console.log("preloaddir filename="+bundlename+"/"+ff_filename_or_path+",error="+error+",items len="+items.length)

                
                if(bwaitall)
                {
                    self.On_Bk_Loaded_Finish(1);
                }
                

            })
        }else{
            bunlde.preload(ff_filename_or_path,(error: Error, items:cc.AssetManager.RequestItem[]) =>
            {
             
                
                //console.log("preload filename="+bundlename+"/"+ff_filename_or_path+",error="+error+",items len="+items.length)

                if(bwaitall)
                {
                    self.On_Bk_Loaded_Finish(1);

                }
            })
        }
    }
    Bunble_Pre_Load_Info(bundlename, bunlde:cc.AssetManager.Bundle, file_list,bdir,bwaitall)
    {

        var self = this;
        for(var ff=0;ff<file_list.length;ff++)
        {
            var ff_filename_or_path = file_list[ff];

            this.Bunble_Pre_Load_Info_Perfile(bundlename, bunlde, ff_filename_or_path,bdir,bwaitall)

            /*
            if(bdir)
            {
                bunlde.preloadDir(ff_filename_or_path, (error: Error, items:cc.AssetManager.RequestItem[]) =>
                {
                   // console.log("preloaddir filename="+ff_filename_or_path+",error="+error+",items="+JSON.stringify(items))
                   console.log("preloaddir filename="+bundlename+"/"+ff_filename_or_path+",error="+error+",items len="+items.length)

                    
                    if(bwaitall)
                    {
                        self.On_Bk_Loaded_Finish(1);
                    }
                    

                })
            }else{
                bunlde.preload(ff_filename_or_path,(error: Error, items:cc.AssetManager.RequestItem[]) =>
                {
                   // console.log("preload filename="+ff_filename_or_path+",error="+error+",items=" + JSON.stringify(items) )
                   console.log("preload filename="+bundlename+"/"+ff_filename_or_path+",error="+error+",items len="+items.length)

                    if(bwaitall)
                    {
                        self.On_Bk_Loaded_Finish(1);

                    }
                })
            }
            */
        }
    }

    On_Bk_Loaded_Finish(ilen)
    {

  

        this.m_bk_all_has_loaded_res_count += ilen;

        console.log("On_Bk_Loaded_Finish ilen="+ilen+",all finished="+this.m_bk_all_has_loaded_res_count 
        +",allneed="+this.m_bk_all_need_loaded_res_count);

        if(this.m_bk_all_has_loaded_res_count  >= this.m_bk_all_need_loaded_res_count)
        {
            this.On_All_Bk_Res_Load_Finished();
        }


    }

    Load_Info(ff_info)
    {
        var ff_bundle =  ff_info.bundle;
        var ff_bdir =  ff_info.bdir;
        var ff_waitall =  ff_info.waitall;
        var ff_fl =  ff_info.fl;


       

        var self = this;

        BundleLoadUtils.GetInstance().CheckLoadedBundle(ff_bundle,(error,out_bundle)=>
        {
            if(error)
            {
                if(ff_waitall)
                {
                    self.On_Bk_Loaded_Finish(ff_fl.length);
                }
                
                return;
            }
            if(!out_bundle)
            {
                if(ff_waitall)
                {
                    self.On_Bk_Loaded_Finish(ff_fl.length);
                }
                return;
            }

            self.Bunble_Load_Info(ff_bundle,out_bundle,ff_fl,ff_bdir,ff_waitall);

        })
    }
    PreLoad_Info(ff_info)
    {

        var ff_bundle =  ff_info.bundle;
        var ff_bdir =  ff_info.bdir;
        var ff_waitall =  ff_info.waitall;
        var ff_fl =  ff_info.fl;


  

        var self = this;

        console.log("PreLoad_Info bunlde="+ff_bundle)
        BundleLoadUtils.GetInstance().CheckLoadedBundle(ff_bundle,(error,out_bundle)=>
        {
            if(error)
            {
                if(ff_waitall)
                {
                    self.On_Bk_Loaded_Finish(ff_fl.length);
                }
                
                return;
            }
            if(!out_bundle)
            {
                if(ff_waitall)
                {
                    self.On_Bk_Loaded_Finish(ff_fl.length);
                }
                return;
            }

            self.Bunble_Pre_Load_Info(ff_bundle,out_bundle,ff_fl,ff_bdir,ff_waitall);

        })

    }

    Dating_Check_Preload_File_Bk_Loaded()
    {
        var preloadfile_config = this.Get_Cur_Valid_Server_PreloadFile_Config();

        if(!preloadfile_config)
        {
            this.Load_Game_PreloadFile_Config(()=>{});
            return;
        }


        this.Bk_Load_All_PreloadFile_Res_List(()=>{})

    }

    Dating_Check_Scence_PerLoaded()
    {
        var preloadfile_config = this.Get_Cur_Valid_Server_PreloadFile_Config();

        if(!preloadfile_config)
        {
            return;
        }


        if(this.m_dating_scecnce_loaded)
        {
            return;
        }
        this.m_dating_scecnce_loaded = true;

        var dating_scence = preloadfile_config.dating_scence;
        if(!dating_scence)
        {
            dating_scence = [];
        }


        for(var kk=0;kk<dating_scence.length;kk++)
        {
            var kk_scence_name = dating_scence[kk];
            cc.director.preloadScene(kk_scence_name);

           // console.log("大厅 preloadScene :"+kk_scence_name)
        }

    }

}