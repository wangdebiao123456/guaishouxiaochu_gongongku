import ComFunc from "./ComFunc";

 

export default class BaseUIUtils
{
    constructor() 
    {
    }

    static  NodeWorldPos(pnode,srcpt?){
        let parentnode=  pnode.parent;
        let worldpt = parentnode.convertToWorldSpaceAR(srcpt || pnode.getPosition());
        let newx = worldpt.x - 360;
        let newy = worldpt.y - 640;
        return {x:newx,y:newy};
    }
    static GetRealTopY()
    {
        var winsize = cc.winSize;
        var cx = winsize.width;
        var cy=  winsize.height;

        let size1 = cc.view.getFrameSize();
        var cx2 = size1.width;
        var cy2=  size1.height;

        
        var icomss = cx/cy;
        var ireals = cx2/cy2;


        var caculate_topy = cy/2;
        if(ireals > icomss)
        {
            //宽比实际宽
            caculate_topy = cy/2;
        }
        else if(ireals < icomss)
        {
            //高比实际高

            caculate_topy = cy/2 * icomss/ireals;

        }else
        {
            caculate_topy = cy/2;
        }
        return caculate_topy;
    }
   
    static   MyShowIconNodeSprites(touxiang_node,mytexture)
    {
        var psrite = touxiang_node.getComponent(cc.Sprite);

        if(psrite)
        {
            psrite.spriteFrame = new cc.SpriteFrame(mytexture);
        }
        
    }
    static Show_Remote_Touxiang(touxiang_node,stouxiangurl,size = null)
    {
        cc.assetManager.loadRemote(stouxiangurl,{ext: '.jpg'}, (err, mytexture ) =>  
        {
           // console.log("stouxiangurl="+stouxiangurl+",err="+err+",texture="+mytexture);
            if(err || !mytexture)
            {
                return;
            }

 
            BaseUIUtils.MyShowIconNodeSprites(touxiang_node,mytexture);

         

            if(size)
            {
                //console.log("stouxiangurl size.cx="+size.cx+",size.cy="+size.cy);
          
                 touxiang_node.width = size.cx;
                 touxiang_node.height = size.cy;
    
            }
           
        });
    }

    static ShowIconNodePicFilename(pnode,sfilename,size = null)
    {
        cc.resources.load(sfilename, cc.SpriteFrame, 
            (err, spriteFrame) =>{
                var psrite = pnode.getComponent(cc.Sprite);
    
               psrite.spriteFrame = spriteFrame;

               if(size)
               {
                    pnode.width = size.cx;
                    pnode.height = size.cy;

               }
           });
   
    }
    static arrayContain(list,tg){
        for(let i=0;i<list.length;i++){
            if(tg == list[i]){
                return true;
            }
        }
        return false;
    }
    static  newCreateGuid()
    {
        var guid = "";
        for (var i = 1; i <= 32; i++){
          var n = Math.floor(Math.random()*16.0).toString(16);
          guid +=   n;
          if((i==8)||(i==12)||(i==16)||(i==20))
            guid += "-";
        }
        return guid;    
    } 
    static ChangeIconNodeSprite(pnode,sfilename, size = null){
        cc.resources.load(sfilename, cc.SpriteFrame, (err, spriteFrame)=>{
            if(err){
                // console.log("err:"+err);
                return;
            }
            
            var psrite = pnode.getComponent(cc.Sprite);
            psrite.spriteFrame = spriteFrame;
            // cc.log(psrite);

            if(size){
                pnode.width = size.cx;
                pnode.height = size.cy;
            }
        });
    }  

    
     
    static Get_Screen_Left_Start_X()
    {
        var winsize = cc.director.getWinSize();
        var cx = winsize.width;
        var cy=  winsize.height;

        let size1 = cc.view.getFrameSize();
        var cx2 = size1.width;
        var cy2=  size1.height;

        
        var icomss = cx/cy;
        var ireals = cx2/cy2;


        var caculate_topy = cy/2;
        if(ireals > icomss)
        {
            //宽比实际宽
            caculate_topy = Math.floor(-640*ireals/icomss) ;

            return caculate_topy;
        }
        else if(ireals < icomss)
        {
            //高比实际高

            return -640;

        }else
        {
            
        }

        return -640;
    }
   
    static Get_Cacu_Screen_Top_Y()
    {
        var winsize = cc.director.getWinSize();
        var cx = winsize.width;
        var cy=  winsize.height;

        let size1 = cc.view.getFrameSize();
        var cx2 = size1.width;
        var cy2=  size1.height;

        
        var icomss = cx/cy;
        var ireals = cx2/cy2;


        var caculate_topy = cy/2;
        if(ireals > icomss)
        {
            //宽比实际宽
            caculate_topy = cy/2;
        }
        else if(ireals < icomss)
        {
            //高比实际高

            caculate_topy = cy/2 * icomss/ireals;

        }else
        {
            caculate_topy = cy/2;
        }

        return caculate_topy;
    }

    static ShowTipTxtDlg(str,pnode,pos=null,idisplaytime = 1.2,izorder = 10){

        if(!pos)
        {
             var caculate_topy = BaseUIUtils.Get_Cacu_Screen_Top_Y();

          // pos = new cc.Vec2(0, 20);

             pos = new cc.Vec2(0, 500 );
        }
        


        let self = this;
        let node = pnode ;

        /*
        cc.resources.load("preab/dlg/tipuidlg", function (err, prefab) {
            if (err) { return cc.error(err); }
            let ui = cc.instantiate(prefab);
            node.addChild(ui,izorder);
            BaseUIUtils.onLoadedTxtTipDlgOk(ui,str,pos,idisplaytime);
        });
        */


       ComFunc.CheckFind_Name_Resource("preab/dlg/tipuidlg",(bsuc,preab)=>
        {

            if (!bsuc) { return  ; }
            let ui = cc.instantiate(preab);
            node.addChild(ui,izorder);
            BaseUIUtils.onLoadedTxtTipDlgOk(ui,str,pos,idisplaytime);

            
        })



    }

    static onLoadedTxtTipDlgOk(node,str,pos,idisplaytime){
        let txt = node.getChildByName("txt_info").getComponent(cc.Label);
        txt.string = str;
        node.setPosition(pos.x,pos.y);
      
        node.setScale(cc.v3(0, 0, 0));
        cc.tween(node).to(0.1, { scale: 1.1 }).to(0.1, { scale: 0.9}).to(0.1, { scale:1 }).delay(0.5).by(0.5, { position: cc.v2(0, 100) }).removeSelf().start();

       // node.runAction(cc.sequence(cc.moveBy(0.2,0,-60),cc.delayTime(idisplaytime),cc.moveBy(0.2,0,60),cc.callFunc(function(){ node.destroy(); })));
    }

    static strformat(str, icount){
        let args = Array.prototype.slice.call(arguments, 1);

        function MakePos(chkstr, key, agv){
            let retagv = agv;
            while (true){
                let idx = chkstr.indexOf(key);
                if (idx == -1)
                    break;
                
                let len = key.length;
                let repstr = "";
                for (let i = 0; i < key.length; i++){
                    repstr = repstr + "x";
                }

                chkstr = chkstr.replace(key, repstr);
                retagv.push({"pos":idx, "type":key});
            }

            return retagv;
        }

        let szKey = ["%d", "%02d", "%s", "%.2f", "%.1f"];
        let szPos = [];
        for (let i = 0; i < szKey.length; i++){
            szPos = MakePos(str, szKey[i], szPos);
        }

        function sortpos(obj1, obj2){
            return obj1.pos > obj2.pos ? 1 : -1;
        }

        szPos.sort(sortpos);

        let retstr = str;
        for (let i = 0; i < szPos.length; i++){
            let obj = szPos[i];
            let value = args[i];
            
            if (obj.type == "%02d")
                value = value >= 10 ? value : "0" + value;
            else if (obj.type == "%.2f")
                value = value.toFixed(2);
            else if (obj.type == "%.1f")
                value = value.toFixed(1);
            else if (obj.type == "%d")
                value = BaseUIUtils.GetScoreFomateStr(value);

            retstr = retstr.replace(obj.type, value);
        }

        return retstr;
    }

    static GetScoreFomateStr(icount){
        if(typeof(icount) != "number"){ return icount; }
        if(icount < 1000){
            return icount.toString();
        }else if(icount < 10000){
            return BaseUIUtils.strformat("%.1f千",icount/1000);
        }else if(icount < 10000*100){
            return BaseUIUtils.strformat("%.1f万",icount/10000);
        }else if(icount < 10000*1000){
            return BaseUIUtils.strformat("%.1f百万",icount/1000000);
        }else if(icount < 10000*10000){
            return BaseUIUtils.strformat("%.1f千万",icount/10000000);
        }else if(icount < 10000*100000){
            return BaseUIUtils.strformat("%.1f亿",icount/100000000);
        }else if(icount < 10000*1000000){
            return BaseUIUtils.strformat("%.1f十亿",icount/1000000000);
        }else if(icount < 10000*10000000){
            return BaseUIUtils.strformat("%.1f百亿",icount/10000000000);
        }else if(icount < 10000*100000000){
            return BaseUIUtils.strformat("%.1f千亿",icount/100000000000);
        }else if(icount < 10000*1000000000){
            return BaseUIUtils.strformat("%.1f兆",icount/1000000000000);
        }else if(icount < 10000*10000000000){
            return BaseUIUtils.strformat("%.1f十兆",icount/10000000000000);
        }else if(icount < 10000*100000000000){
            return BaseUIUtils.strformat("%.1f百兆",icount/100000000000000);
        }else{
            return BaseUIUtils.strformat("%.1f千兆",icount/1000000000000000);
        }
    }
}