import PlatFormType from "../PlatForm/PlatFormType";  
import ClientLogUtils from "./ClientLogUtils";
 
import PlatFormMng from "../PlatForm/PlatFormMng";
import SoundManager from "./SoundManager";
import GlobalGameMng from "../Mng/GlobalGameMng";
import ComFunc from "./ComFunc";
import GlobalConfig from "../pingpinggame/GlobalConfig";
import PlatFormParaMng from "../PlatForm/PlatFormParaMng";
import WMap from "../WDT/WMap";

 
 

export default class WatchVideoAdveseMng{

    static _instance:WatchVideoAdveseMng = null;
    static GetInstance() 
    {
        if (!WatchVideoAdveseMng._instance) {
            // doSomething
            WatchVideoAdveseMng._instance = new WatchVideoAdveseMng();
             
        }
        return WatchVideoAdveseMng._instance;
    }

    constructor()
    {

    }

    m_last_video_detail = "";
    m_last_guangao_name=  "";
 
    m_b_playing_video = false;
    m_last_play_video_tick = 0;
    m_video = null;

    m_last_cb = null;
    m_last_arg = null;
    m_last_arg2 = null;

    m_last_video_subtype = 0;

    m_b_reged_event = false;


    m_main_scence_node:cc.Node =  null;
 

    SetMainScenceNode(pnode:cc.Node)
    {
        this.m_main_scence_node = pnode;

    }

    InitRegWXEvent(calback)
    {
        if(this.m_b_reged_event)
        {
            this.m_b_reged_event = true;
        }
        
               
        /*
        wx.onShow(()=>
        {
            if(calback)
            {
                calback(1);
            }

        });

        wx.onHide(()=>
        {
            if(calback)
            {
                calback(0);
            }

        });
        */
    }
    OnVideoSuccessEnd()
    {
      

        if(this.m_last_cb)
        {
            this.m_last_cb(true, this.m_last_arg);

         
 
            ClientLogUtils.GetInstance().Poset_Server_JS_Log( 6244 ,"观看广告成功一次",
                this.m_last_video_subtype,
                this.m_last_guangao_name, 0, this.m_last_arg ? ""+this.m_last_arg:"",0,
                    this.m_last_video_detail
                 );


            this.m_last_cb = null;
            this.m_last_arg = null;
            this.m_last_arg2 = null;
 
        }
        SoundManager.GetInstance().ReStartPlayLastBKMusic();

        GlobalConfig.GetIns().Add_Watch_Success_Count();

    }
    OnVideFailEnd(ierrorcode,errordesc)
    {

        SoundManager.GetInstance().ReStartPlayLastBKMusic();


        if(this.m_last_cb)
        {
            this.m_last_cb(false, this.m_last_arg,ierrorcode,errordesc);

            this.m_last_cb = null;
            this.m_last_arg = null;


            
            if(ierrorcode == 0)
            {
                ClientLogUtils.GetInstance().Poset_Server_JS_Log( 6140 ,"观看广告退出",
                    this.m_last_video_subtype,
                    this.m_last_guangao_name, ierrorcode, "ierrorcode="+ierrorcode,0,""+errordesc);
            }else{
                ClientLogUtils.GetInstance().Poset_Server_JS_Log( 6141 ,"观看广告错误",
                    this.m_last_video_subtype,
                    this.m_last_guangao_name, ierrorcode, "ierrorcode="+ierrorcode,0,""+errordesc);
            }
        } 


    }
    Get_Jiange_Sec_From_Last_Play_Video()
    {
        var ieplasetick = Date.now() - this.m_last_play_video_tick;
        var ierplasec= Math.floor(ieplasetick/1000)  ;
        return ierplasec;
    }

    GetSubTypeByName(sname,agv1,agv2)
    {
        var isubgametype=  agv1;


        if(sname == "三消消复活")
        {
            if(isubgametype == 9)
            {
                return 41;
            }
            return 31;
        }


        if(sname == "购买三消消道具")
        {    
            if(isubgametype == 9)
            {
                return 42;
            }
            return 32;
        }


        if(sname == "三消消使用移除")
        {    
            if(isubgametype == 9)
            {
                return 43;
            }
            return 33;
        }



        if(sname == "俄罗斯方块继续游戏")
        {    
            return 51;
        }


        if(sname == "俄罗斯方块选择类型")
        {    
            return 53;
        }

        if(sname == "购买继续游戏道具")
        {    
            return 54;
        }
        


        if(sname == "普通购买体力")
        {    
            return 55;
        }
        if(sname == "连续购买体力")
        {    
            return 56;
        }
        if(sname == "连续购买48小时体力")
        {    
            return 57;
        }

        if(sname == "领取首看礼包")
        {    
            return 59;
        }

        if(sname == "领取过关礼包")
        {    
            return 60;
        }
        

        if(sname == "视频解锁难度")
        {    
            return 61;
        }
        if(sname == "视频解锁华容道模式")
        {    
            return 62;
        }
        
        if(sname == "过关双倍")
        {    
            return 63;
        }
        if(sname == "解锁合成螺丝栓")
        {    
            return 64;
        }

        if(sname == "螺丝合成洗牌")
        {    
            return 65;
        }
        if(sname == "解锁大厅更多游戏")
        {    
            return 66;
        }

        if(sname == "复活花朵选择")
        {    
            return 67;
        }
        
        if(sname == "过关奖励双倍")
        {    
            return 67;
        }
        if(sname == "获取道具")
        {    
            return 68;
        }
        if(sname == "商城购买")
        {    
            return 69;
        } 
        
        if(sname == "螺丝合成数字双倍奖励")
        {    
            return 70;
        }

        if(sname == "签到再次领取")
        {    
            return 71;
        }

        if(sname == "幸运礼包")
        {    
            return 72;
        }

        
        if(sname == "三倍领取在线奖励")
        {    
            return 73;
        }
        if(sname == "视频开始抽奖")
        {    
            return 74;
        }
        
        if(sname == "抽奖双倍领取")
        {    
            return 75;
        }
        
        
        if(sname == "游戏胜利双倍")
        {
        
            return 5000 + isubgametype;
        }

        if(sname == "跳过关卡")
        {  
            return 200 ;
        }

        if(sname == "购买道具")
        {  
            return 300 ;
        }




        if(sname == "复活")
        {  
            return 400 + isubgametype;
        }

        

        if(sname == "签到双倍")
        {  
            return 11;
        }

 
        return 0;
    }

    
    Watch_Com_Guanggao_IF_Fail_Try_Self(pnode :cc.Node,show_watch_fail_dlg_callback :Function ,guanggaoname:string
        ,cb:Function,agv = null,argv2=null,errorload_cb = null,sdetail="")
    {
       
        if(this.m_b_playing_video && Date.now() - this.m_last_play_video_tick < 1000)
        {
            if(PlatFormParaMng.GetInstance().GetPlatFormType() == PlatFormType.PlatFormType_WX)
            {
                wx.showToast({
                    title: "点击太频繁",
                    icon: "error",
                    duration: 1500
                    });
            }
            return;
        }

        var self = this;
    
        var i_watch_type  = this.GetSubTypeByName(guanggaoname,agv,argv2);

        this.Watch_Com_Guanggao_ID(guanggaoname,
            (bsuc,ret_arg,ierrorcode,errordesc)=>
            {
                if(!bsuc)
                {

                    if(ierrorcode > 0)
                    {

                        var need_show_video_Fail_dlg = GlobalGameMng.GetInstance().IS_Watch_Video_Fail_Need_Show_Error_Lingqu_Dlg(i_watch_type);

                        if(need_show_video_Fail_dlg)
                        {
                            if(show_watch_fail_dlg_callback)
                            {
                                show_watch_fail_dlg_callback();
                            }

                            ComFunc.OpenNewDialog(pnode,"preab/common/watch_video_fail","watch_video_fail",
                                { 
                                    i_watch_type:i_watch_type,
                                    cb:(iret)=>
                                    {
                                        if(iret > 0)
                                        {
                                            cb(1,ret_arg,ierrorcode,errordesc);


                                            ClientLogUtils.GetInstance().Poset_Server_JS_Log( 6139 ,"视频失败处理领取",
                                                self.m_last_video_subtype,
                                                self.m_last_guangao_name, 0, "",0,"");

                                        }else{
                                            cb(bsuc,ret_arg,ierrorcode,errordesc);
                                        }
    
                                    }
    
                                }
                            );
                        }else{

                            cb(bsuc,ret_arg,ierrorcode,errordesc);
                        }

                        
                    }else
                    {
                        cb(bsuc,ret_arg,ierrorcode,errordesc);
                    }


                    return;
                } 


                cb(bsuc,ret_arg,ierrorcode,errordesc);
            },
            agv ,errorload_cb,sdetail )

    }

    Watch_Com_Guanggao_ID(guanggaoname,cb,agv1= null,agv2 = null,sdetail = "")
    {
       
      
     //   var guangaounitid = "adunit-e783038178dc826b";

        
        this.m_last_guangao_name = guanggaoname;

      
        /*
        if(this.m_b_playing_video && Date.now() - this.m_last_play_video_tick < 1*1000)
        { 
            if(PlatFormParaMng.GetInstance().GetPlatFormType() == PlatFormType.PlatFormType_WX)
            {
                wx.showToast({
                    title: "点击太频繁",
                    icon: "error",
                    duration: 1500
                    });
            }
        
            return;
        }
        */
        var isubtype  = this.GetSubTypeByName(guanggaoname,agv1,agv2);


        this.m_last_cb = cb;
        this.m_last_arg = agv1;
        this.m_last_arg2 = agv2;
        this.m_last_video_subtype = isubtype;

        this.m_last_video_detail = sdetail;

        this. m_b_playing_video = true;
        this.m_last_play_video_tick = Date.now();
        var self = this;


        SoundManager.GetInstance().Pause_Background_Music();

        PlatFormMng.GetInstance().Watch_Com_Guanggao_ID(guanggaoname,cb,agv1,
            (bsuc,ierrorcode,errordesc)=>
            {
               

                if(!bsuc)
                {
                    self.OnVideFailEnd(ierrorcode,errordesc);
                    return;
                }

                self.OnVideoSuccessEnd();
                
            });

       
             
    }
    
}