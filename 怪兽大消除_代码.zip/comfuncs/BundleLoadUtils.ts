 
import WMap from "../WDT/WMap";

export default class BundleLoadUtils 
{
    static _instance:BundleLoadUtils = null;
    bundle = null;

    m_b_loading_assert = false;

    m_local_bundle_name_bundle_info_map = new WMap();
  
    constructor() {


    }

    static GetInstance() 
    {
        if (!BundleLoadUtils._instance) {
            // doSomething
            BundleLoadUtils._instance = new BundleLoadUtils();
             
        }
        return BundleLoadUtils._instance;
    }
    static ShowIconNodePicBundle_Show_Fit(localbundlename, pnode,sfilename,fit_size )
    {
        BundleLoadUtils.GetInstance().LoadLocalBundleResource(localbundlename,sfilename,cc.SpriteFrame,(err, spriteFrame  )=>
        {
            if(err)
            {
                console.log("err:"+err);
                return;
            }
            var psrite = pnode.getComponent(cc.Sprite);
            psrite.spriteFrame = spriteFrame;

            var oringsize = spriteFrame.getOriginalSize();

            if(!oringsize.width)
            {
                oringsize.width = 10;
            }
            if(!oringsize.height)
            {
                oringsize.height = 10;
            }
            var picwidth = fit_size.width;
            var picheight= fit_size.height;

            var scale1 = picwidth/oringsize.width
            var scale2 = picheight/oringsize.height;

            var scale = scale1 > scale2 ?  scale2:scale1;

            var w = scale*oringsize.width;
            var h = scale*oringsize.height;
             
            pnode.width = w;
            pnode.height = h;

           
        });
    }
    static ShowIconNodePicBundle(localbundlename, pnode,sfilename,size = null){
        BundleLoadUtils.GetInstance().LoadLocalBundleResource(localbundlename,sfilename,cc.SpriteFrame,(err, spriteFrame  )=>
        {
            if(err)
            {
                console.log("err:"+err);
                return;
            }
            var psrite = pnode.getComponent(cc.Sprite);
            psrite.spriteFrame = spriteFrame;

            if(size){
                pnode.width = size.cx;
                pnode.height = size.cy;
            }
        });

 
    }
    static SetIconNodeBundleResName(node:cc.Node,img:string,sbuldlename:string,scale = null,size=null)
    {
        let spr = node.getComponent(cc.Sprite);
        BundleLoadUtils.GetInstance().LoadLocalBundleResource(sbuldlename,img,cc.SpriteFrame,(err,sprframe)=>
        {
            if(err)
            {
                return;
            }
            spr.spriteFrame = sprframe;

            if(scale)
            {
                node.scale = scale;
            }
            else{
                if(size)
                {
                    node.width = size.cx;
                    node.height = size.cy;
                }
            }

        });
        
    }



    LoadLocalBundleResource(localbundlename,resname,typenname,callback)
    {
        this.CheckLoadedBundle(localbundlename,(err1,lbundle)=>
        {
            if(err1)
            {
                callback(err1);
                return;
            }

            lbundle.load(resname, typenname, (err2,pp)=>
            {
                if(err2)
                {
                    callback(err2);
                    return;
                }

                callback(null,pp);
            });

        });
        
    }
    CheckLoadedBundle(localbundlename,callback)
    {
        if(this.m_local_bundle_name_bundle_info_map.hasKey(localbundlename))
        {
            var lcoalbundle = this.m_local_bundle_name_bundle_info_map.getData(localbundlename);
            callback(null,lcoalbundle)
            return ;
        }

        var self = this;
        cc.assetManager.loadBundle(localbundlename, (err, res) => {
            if (err) {
                callback(err,null);
                return;
            }

            self.m_local_bundle_name_bundle_info_map.putData(localbundlename,res);
            callback(null,res);

        });
    }




    RealDoLoadBundle(callback)
    {
        var self = this;
        if(this.m_b_loading_assert)
        {
            return;
        }

        cc.assetManager.loadBundle('gameani', (err, res) => {

            if (err) {

                callback(err);
                self.m_b_loading_assert = false;
               // self.m_b_loaded_error = true;
               // self.m_last_error_tick = Date.now();

               // var loadertip = self.node.getChildByName("loadertip");
               // loadertip.active = true;
 
                //var jiazaiziyuan = self.node.getChildByName("jiazaiziyuan");
               // jiazaiziyuan.active = false;

                //loadertip.getComponent(cc.Label).string  = "加载错误:"+err;
                
                console.log("loadBundle error:"+err);
                return
            }

            BundleLoadUtils.GetInstance().init(res);
           // self.m_b_inited_bundle = true;
           // self.m_b_loaded_error = false;


            callback(null);
         
            self.m_b_loading_assert = false;

            console.log("loadBundle success");
        });
    }



    init(bundle ) {
        this.bundle = bundle;
        this.m_local_bundle_name_bundle_info_map.putData("gameani",bundle);
        console.log('资源bundle加载完成')
    }
    
    loadRes(path , type , callback) {
        if (!this.bundle) {

            this.RealDoLoadBundle(()=>{});
            console.log('bundle is null');
            return;
        }
        this.bundle.load(path, type, callback)
    }
}