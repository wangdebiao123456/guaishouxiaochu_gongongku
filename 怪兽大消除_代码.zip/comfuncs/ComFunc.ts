import ComDialogMng from "./ComDialogMng";
import MyLocalStorge from "../WDT/MyLocalStorge";
import WMap from "../WDT/WMap";
import GlobalGameMng from "../Mng/GlobalGameMng";

 
export default class ComFunc
{
    static m_resname_preb_node_map = new WMap();
    
    static m_scencename_scenode_node_map = new WMap();
    static  Tranfer_Loading_Scence_Index(loading_scence_name)
    {
        if(loading_scence_name == "main")
        {
            return 0;
        }

        if(loading_scence_name == "game")
        {
            return 1;
        }

        if(loading_scence_name == "pplgame")
        {
            return 2;
        }

        if(loading_scence_name == "mishitaotougame")
        {
            return 3;
        }

        if(loading_scence_name == "xiaomiexingxing")
        {
            return 4;
        }


        if(loading_scence_name == "lianliankangame")
        {
            return 5;
        }

        if(loading_scence_name == "flapybirdgame")
        {
            return 6;
        }



        if(loading_scence_name == "tiaodongfangkuai")
        {
            return 7;
        }


        if(loading_scence_name == "RussinFangkuai")
        {
            return 8;
        }

        if(loading_scence_name == "yidongguaishouxiaochu")
        {
            return 10;
        }
        

      

        if(loading_scence_name == "fanpaixiaoxiaole")
        {
            return 11;
        }

        if(loading_scence_name == "dianjiguaishou")
        {
            return 12;
        }


        if(loading_scence_name == "huamukuai")
        {
            return 131;
        }

        if(loading_scence_name == "shuzihuarongdao")
        {
            return 103;
        }

        if(loading_scence_name == "huaduo_xiaoxiao")
        {
            return 150;
        }



        return 0;
    }
    static RealLoadScence(scename,ifromsubgame = 0,iposindex =0)
    {
       
       // 
      


 
       var enter_scence_index = ComFunc.Tranfer_Loading_Scence_Index(scename);


       var bshowloading = GlobalGameMng.GetInstance().Get_From_Subgame_To_Secene_Show(ifromsubgame,enter_scence_index,iposindex);

       
       if(bshowloading)
       {
            GlobalGameMng.GetInstance().m_loading_to_game_scence_name = scename;
            cc.director.loadScene("loadingtogame");
    
       }
       else{
             cc.director.loadScene(scename);
    
       }
      
      


    }
    static Check_Load_Scence(scenename,callback)
    {
        
         
    
        if(ComFunc.m_scencename_scenode_node_map.hasKey(scenename))
        {
            var pscence  = ComFunc.m_scencename_scenode_node_map.getData(scenename);

            callback(true,pscence);
            return;
        }

         cc.director.loadScene(scenename,(err, pp)=>
            {
                if(err)
                {
                    callback(false);
                    return;
                }
                ComFunc.m_scencename_scenode_node_map.putData(scenename,pp);
             //   callback(true,pp);
            });

            
    }
 
    static Check_Read_Number(num)
    {
        if(!num)
        {
            return 0;
        }
        var imun = Number(num);
        if(isNaN(imun))
        {
            return 0;
        }



        return  imun;
    }

    static CheckFind_Name_Resource2(prebanem,stype,callback)
    {
        var find_info = ComFunc.Find_Preb_Node_By_Name(prebanem);

        if(find_info)
        {
            callback(true,find_info);
            return;
        }
        cc.resources.load(prebanem,stype,
            (err,preb_node)=>
            {
                if(err)
                {
                    callback(false)
                    return;
                }

                ComFunc.Set_Preb_Name_Node(prebanem,preb_node)
                callback(true,preb_node)
                   
            }
          
        );
    }


    static Check_Init_Load_All_Preab()
    {
        ComFunc.CheckFind_Name_Resource("preab/common/show_get_jiangli",()=>{} );

     
        
        ComFunc.CheckFind_Name_Resource("preab/pausedlg",()=>{} );
        ComFunc.CheckFind_Name_Resource("preab/gamesuccess_new",()=>{} );
        ComFunc.CheckFind_Name_Resource("preab/com_fuhuo",()=>{} );
        ComFunc.CheckFind_Name_Resource("preab/game_fail_new",()=>{} );
        ComFunc.CheckFind_Name_Resource("preab/fanhuidating_queren",()=>{} );
        ComFunc.CheckFind_Name_Resource("preab/selectgk",()=>{} );
        ComFunc.CheckFind_Name_Resource("preab/Goumai_Daoju",()=>{} );
        ComFunc.CheckFind_Name_Resource("preab/continue_prev_game_confirm",()=>{} );

        ComFunc.CheckFind_Name_Resource("preab/common/watch_video_fail",()=>{} );
        ComFunc.CheckFind_Name_Resource("preab/common/game_end_lingqu",()=>{} );
        ComFunc.CheckFind_Name_Resource("preab/gamefail_continue_game",()=>{} );
        ComFunc.CheckFind_Name_Resource("preab/common/com_sel_nandu",()=>{} );
   
        

    }


    static CheckFind_Name_Resource(prebanem,callback)
    {
        var find_info = ComFunc.Find_Preb_Node_By_Name(prebanem);

        if(find_info)
        {
            callback(true,find_info);
            return;
        }
        cc.resources.load(prebanem,
            (err,preb_node)=>
            {
                if(err)
                {
                    callback(false)
                    return;
                }

                ComFunc.Set_Preb_Name_Node(prebanem,preb_node)
                callback(true,preb_node)
                   
            }
          
        );
    }

    static Find_Preb_Node_By_Name(prebanem)
    {
        if(ComFunc.m_resname_preb_node_map.hasKey(prebanem))
        {
            var prevnins = ComFunc.m_resname_preb_node_map.getData(prebanem);
            return prevnins;
        }

        return null;
    }
    static Set_Preb_Name_Node(prebanem,preb_node)
    {
        ComFunc.m_resname_preb_node_map.putData(prebanem,preb_node);
    }
    static Real_Open_Get_Daoju_Award_Dlg(preab_node,  partent, hnq, multiple:Number,callback = null)
    {
        var pnode=cc.instantiate(preab_node as cc.Prefab);
        partent.addChild(pnode,60);

        var panel_ndoe = pnode.getChildByName("panel");

        panel_ndoe.scale = 0;
        panel_ndoe.stopAllActions();
        panel_ndoe.runAction(cc.scaleTo(0.2,1,1));

        var get_award = pnode.getComponent("show_get_jiangli");
       
        get_award.SetAward(hnq, multiple);

        if(callback)
        {
            get_award.SetCallbackData(callback);
        }
        return false;
    }
 
    static Open_Get_Daoju_Award_Dlg(partent, hnq, multiple:Number,callback = null)
    {
        var prebanem = "preab/common/show_get_jiangli";

        var prev_preab_node = ComFunc.Find_Preb_Node_By_Name(prebanem);

        if(prev_preab_node)
        {
            ComFunc.Real_Open_Get_Daoju_Award_Dlg(prev_preab_node,  partent, hnq, multiple,callback );   
        }
        else{
            cc.resources.load(prebanem,(err,pp)=>
                {
                    if(err)
                    {
                        return;
                    }
            
                    ComFunc.Set_Preb_Name_Node(prebanem,pp);

                    ComFunc.Real_Open_Get_Daoju_Award_Dlg(pp,  partent, hnq, multiple,callback );   
    
                }
            );

        }


        /*
        cc.resources.load("preab/common/show_get_jiangli",(err,pp)=>{
            var pnode=cc.instantiate(pp as cc.Prefab);
            partent.addChild(pnode,60);

            var panel_ndoe = pnode.getChildByName("panel");

            panel_ndoe.scale = 0;
            panel_ndoe.stopAllActions();
            panel_ndoe.runAction(cc.scaleTo(0.2,1,1));

            var get_award = pnode.getComponent("show_get_jiangli");
           
            get_award.SetAward(hnq, multiple);

            if(callback)
            {
                get_award.SetCallbackData(callback);
            }
            return false;
        })
        */
    }

    
    static Check_Sign_Has_UnLingqued():boolean
    {
        var last_sign_day = 0;
        var last_sign_day_index=  0;
        var br_qd_data_str = ComFunc.ReadSysLocalStorgeStr("guaishoudaxiaochu_sign_data");

        var  bhasdata = false;
        if(br_qd_data_str)
        {
            var br_qd_data = JSON.parse(br_qd_data_str);

            if(br_qd_data)
            {
                bhasdata = true;
                last_sign_day = br_qd_data.sign_day_union;
                last_sign_day_index=  br_qd_data.sign_day_index;
            }
        }


        var curdayunion = ComFunc.GetCurDayUnionD();
        if(bhasdata)
        {
            if(curdayunion == last_sign_day)
            {
               
                return false;
            }else{

               
                return true;
            }
        }
        else
        {
           
            return true;

        }
        return true;

    }
    static  ReadSysLocalStorgeStr(name){

        var str = MyLocalStorge.getItem(name);
        if(str)
        {
            return str;
        }
        return "";
    }
    static WriteSysLocalStorgeStr(name,iv){
        MyLocalStorge.setItem(name,iv);
    }
    static GetSrcreenRealHeight() 
    {

        var winsize = cc.director.getWinSize();
        var cx = winsize.width;
        var cy=  winsize.height;

        let size1 = cc.view.getFrameSize();
        var cx2 = size1.width;
        var cy2=  size1.height;

        
        var icomss = cx/cy;
        var ireals = cx2/cy2;


        var caculate_topy = cy/2;
        if(ireals > icomss)
        {
            //宽比实际宽
            caculate_topy = cy/2;
        }
        else if(ireals < icomss)
        {
            //高比实际高

            caculate_topy = cy/2 * icomss/ireals;

        }else
        {
            caculate_topy = cy/2;
        }

       

        var irealheight = Math.floor(caculate_topy*2); 


        return irealheight;

    }


     

    static ISChaoGaoPing()
    {
        var winsize = cc.director.getWinSize();
        var cx = winsize.width;
        var cy=  winsize.height;

        let size1 = cc.view.getFrameSize();
        var cx2 = size1.width;
        var cy2=  size1.height;

        
        var icomss = cx/cy;
        var ireals = cx2/cy2;


        var caculate_topy = cy/2;
        if(ireals > icomss)
        {
            //宽比实际宽
            caculate_topy = cy/2;
        }
        else if(ireals < icomss)
        {
            //高比实际高

            caculate_topy = cy/2 * icomss/ireals;

        }else
        {
            caculate_topy = cy/2;
        }

       
     //   console.log("cx="+cx+",cy="+cy+",cx2="+cx2+",cy2="+cy2+",caculate_topy="+caculate_topy);
        
        if(caculate_topy >= 760)
        {
            return true;
        }

        return false;
    }
    static Get_Distance_PT(pt1,pt2)
    {
        var imul = (pt1.x-pt2.x)*(pt1.x-pt2.x) + (pt1.y-pt2.y) * (pt1.y-pt2.y);
        return Math.sqrt(imul) ;
    }

  
    static keepTwoDecimalD(num,iweishu) {  
        var mucanshu = 1;
        for(var ff=0;ff<iweishu;ff++)
        {
            mucanshu*=10;
        }



        var result = parseFloat(num);  
        result = Math.round(num * mucanshu) / mucanshu;  
        return result;
    }
 
    static ToFix1F(idihgt)
    {
        var mm = idihgt.toFixed(1);
        var iff = Number(mm);
        var flor_d = Math.floor(iff);

        if(iff == flor_d)
        {
            return ""+flor_d;
        }

        return mm;
    }

    static ToFixF(idihgt,id)
    {
        var mm = idihgt.toFixed(id);
        var iff = Number(mm);
        var flor_d = Math.floor(iff);

        if(iff == flor_d)
        {
            return ""+flor_d;
        }

        return mm;
    }

   
       
    static arrayShuzuContain(list1,tg){
        for(let i=0;i<list1.length;i++){
            if(tg == list1[i]){
                return true;
            }
        }
        return false;
    }
     
    
    static  Random(min:number,max:number){
        return Math.floor(Math.random() * (max-min+1)) + min;
    }
   
    /**
     * 返回子弹类图片的角度
     * @param vector 子弹运动的方向向量
     */
     public static towardAngle(vector: cc.Vec2) {
        let toward: cc.Vec2 = new cc.Vec2(0, 1);
        return 360 - vector.signAngle(toward) * 180 / Math.PI;
    }

    static Clamp(x,minx,maxx)
    {
        if(x> maxx)
        {
            return maxx;
        }

        if(x < minx)
        {
            return minx;
        }

        return x;
    }

    static Real_OpenNewDialog(prev_preab_node:cc.Prefab,parentnode,preabname,scriptename, paradata = {},zorder = 80)
    {
        let pnode :cc.Node = cc.instantiate(prev_preab_node as cc.Prefab);
        parentnode.addChild(pnode,zorder);
        var pscript = pnode.getComponent(""+scriptename);
        if(pscript &&  pscript.SetInitData)
        { 
            pscript.SetInitData(paradata);

        }
       
        ComDialogMng.GetInstance().Set_Preb_Dlg_Opened(preabname);
    }
    static Rand_Digit_List(show_digit_arr)
    {
        var ilen = show_digit_arr.length;

        for(var ff=0;ff<ilen;ff++)
        {
            var ff_rand1 = Math.floor(ilen*Math.random());
            var ff_c1 = show_digit_arr[ff];
            var ff_c2 = show_digit_arr[ff_rand1];

            show_digit_arr[ff] = ff_c2;
            show_digit_arr[ff_rand1] = ff_c1;
            
        }

        return show_digit_arr;
    }
    static OpenNewDialog(parentnode,preabname,scriptename, paradata = {},zorder = 80)
    {
        var bcanopen = ComDialogMng.GetInstance().CheckPrebNameCanOpenNow(preabname);
        if(!bcanopen)
        {
            return;
        }
        ComDialogMng.GetInstance().Set_Preb_Dlg_Clicked(preabname);


        var prev_preab_node = ComFunc.Find_Preb_Node_By_Name(preabname);
        if(prev_preab_node)
        {
            ComFunc.Real_OpenNewDialog(prev_preab_node,parentnode,preabname,scriptename, paradata,zorder );   
        }
        else{
            cc.resources.load(preabname,(err,pp:cc.Prefab)=>
                {
                    if(err)
                    {
                        return;
                    }
            
                    ComFunc.Set_Preb_Name_Node(preabname,pp);
                    ComFunc.Real_OpenNewDialog(pp,parentnode,preabname,scriptename, paradata ,zorder);   
   
                    
    
                }
            );

        }


        /*
        cc.resources.load(preabname,   (err, prefab) =>{
            if (err) { 
                
                console.log("OpenNewDialog 加载 出错:"+err);
                
                return ;
            
            
            }
            let pnode :cc.Node = cc.instantiate(prefab as cc.Prefab);
            parentnode.addChild(pnode,80);
            var pscript = pnode.getComponent(""+scriptename);
            if(pscript &&  pscript.SetInitData)
            { 
                pscript.SetInitData(paradata);

            }
           
            ComDialogMng.GetInstance().Set_Preb_Dlg_Opened(preabname);
            
        });
        */
    }

    static GetCurDayUnionD()
    {
        let date = new Date();
        let y = date.getFullYear();
        let m = date.getMonth() + 1;
        let d = date.getDate();

        return y*10000+m*100+d;
    }
    

    static  Get_Skill_Desc_Str( skill_index,iaddtiondata1)
    {
        var sdesc=  "";
        if(skill_index == 201)
        {
            sdesc=  "对所有敌人造成"+iaddtiondata1+"点伤害";
        } 
        else if(skill_index == 202)
        {
            sdesc=  "召唤三个"+iaddtiondata1+"级士兵支援";
        }else if(skill_index == 203)
        {
            sdesc=  "游戏内获得硬币"+iaddtiondata1+"点";
        }else if(skill_index == 204)
        {
            sdesc=  "全军无敌"+iaddtiondata1+"秒";
        }

        return sdesc;
    }

    static Is_In_Arr_Range_Arr(range_arr_arr,idigit)
    {

        for(var ff=0;ff<range_arr_arr.length;ff++)
        {
            var ff_arr = range_arr_arr[ff];

            if(ff_arr.length == 2)
            {
                var ff_1 = ff_arr[0];
                var ff_2 = ff_arr[1];

                if(ff_1 <= idigit && idigit <= ff_2)
                {
                    return 1;
                }
                
            }
           
        }

        return 0;

    }
    static FormatLeftSecStr(left_sec):string
    {
        if(left_sec < 10)
        {
            return "00:0"+left_sec;
        }
        if(left_sec < 60)
        {
            return "00:"+left_sec;
        }

        if(left_sec >= 3600)
        {
            var ihour = Math.floor(left_sec/3600);
            var ileft_deschor = left_sec - 3600*ihour;
            if(ileft_deschor >= 3600)
            {
                ileft_deschor = 3599;
            }
            var left_timer2 = ComFunc.FormatLeftSecStr(ileft_deschor);
            var strhour = ""+ihour;
            if(ihour < 10)
            {
                strhour = "0"+ihour;
            }

            var strinfo = strhour+":"+left_timer2;
            return strinfo;
        }


        var iminute = Math.floor(left_sec/60) ;

        var isec = left_sec -60 *iminute; 

        var ssec = ""+isec;
        if(isec < 10)
        {
            ssec = "0"+isec;
        }

        if(iminute < 10)
        {
            return "0"+iminute +":"+ssec;
        }

        return ""+iminute +":"+ssec;
    }
    static GetCurDayUnion()
    {
        let date = new Date();
        let y = date.getFullYear();
        let m = date.getMonth() + 1;
        let d = date.getDate();

        return y*10000+m*100+d;
    }
    static Get_Sreen_Real_W()
    {
        
        var winsize = cc.director.getWinSize();
        var cx = winsize.width;
        var cy=  winsize.height;

        let size1 = cc.view.getFrameSize();
        var cx2 = size1.width;
        var cy2=  size1.height;

        
        var icomss = cx/cy;
        var ireals = cx2/cy2;

        var realscale = 1;

        var caculate_topy = cy/2;
        if(ireals > icomss)
        {
            //宽比实际宽
            caculate_topy = cy/2;

            realscale = ireals/icomss;
            
            return cx*realscale;
        }
        else if(ireals < icomss)
        {
            //高比实际高
          
            return cx;

        }else
        {
            //caculate_topy = cy/2;
        }
        return cx;

    }
    static  RandomArray(arr)
    {
        var ilen = arr.length;


        for(var ff=0;ff<ilen;ff++)
        {
            var irand = Math.floor(Math.random()*ilen);

            var temp = arr[ff];
            arr[ff] = arr[irand];
            arr[irand] = temp;
        }

    }
    static PianYiRange(irange)
    {
        var ix = irange/2 - Math.random()*irange;
        ix = Math.floor(ix);
        return ix;
    }
    static Get_Choujiang_Mianfei_Need_Sec()
    {
       

        return 1800;
    }
}