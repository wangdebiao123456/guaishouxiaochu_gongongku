import WMap from "../WDT/WMap";

export default class ComDialogMng 
{

    m_preabname_last_click_tick_map = new WMap();
    m_preabname_last_realopen_tick_map = new WMap();


    static _instance = null;
   
    static GetInstance() 
    {
        if (!ComDialogMng._instance) {
            // doSomething
            ComDialogMng._instance = new ComDialogMng();
             
        }
        return ComDialogMng._instance;
    }
    constructor()
    {

    }

    Set_Preb_Dlg_Clicked(preabname)
    {
        this.m_preabname_last_realopen_tick_map.RemoveKey(preabname);
        this.m_preabname_last_click_tick_map.putData(preabname,Date.now());
    }

    Set_Preb_Dlg_Opened(preabname)
    {
        this.m_preabname_last_realopen_tick_map.putData(preabname,Date.now());
    }
    
    CheckPrebNameCanOpenNow(preabname)
    {

        if(this.m_preabname_last_realopen_tick_map.hasKey(preabname))
        {
            var lasttick = this.m_preabname_last_realopen_tick_map.getData(preabname);

            if( (Date.now() - lasttick < 1000) && lasttick <= Date.now() )
            {
                return false;
            }
        }
        else{
            if(this.m_preabname_last_click_tick_map.hasKey(preabname))
            {
                var lasttick = this.m_preabname_last_click_tick_map.getData(preabname);
    
                if( (Date.now() - lasttick < 5000) &&   lasttick <= Date.now() )
                {
                    return false;
                }
            }

        }

        
        return true;
    }

}