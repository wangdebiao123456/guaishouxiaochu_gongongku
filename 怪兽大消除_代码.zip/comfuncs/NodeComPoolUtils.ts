import WMap from "../WDT/WMap";
import ComFunc from "./ComFunc";

/*
节点池对象
*/

export default class NodeComPoolUtils 
{
    static _instance = null;
    static GetInstance() 
    {
        if (!NodeComPoolUtils._instance) {
            // doSomething
            NodeComPoolUtils._instance = new NodeComPoolUtils();
             
        }
        return NodeComPoolUtils._instance;
    } 

    m_poolname_nodepool_map = new WMap();
    constructor()
    {

    }


    //获得节点池大小
    Get_Pool_Node_Size(poolname:string)
    {
        if(this.m_poolname_nodepool_map.hasKey(poolname))
        {
            var nodepool:cc.NodePool = this.m_poolname_nodepool_map.getData(poolname);
             
            return nodepool.size();
            //var arr= this.m_poolname_nodepool_map.getData(poolname);
             
            //return arr.length;
        }

        return 0;
    }

    //放节点到节点池
    putANode(poolname:string,pnode:cc.Node)
    {
        if(!this.m_poolname_nodepool_map.hasKey(poolname))
        {
           // var arr=[];

            var arr = new cc.NodePool();
            this.m_poolname_nodepool_map.putData(poolname,arr);
        }
        var oldpool:cc.NodePool = this.m_poolname_nodepool_map.getData(poolname);
        oldpool.put(pnode);
    }


    getASpriteNameNode(poolname:string,resourcefiename:string,parentnode:cc.Node,zindex=10)
    {
        var existnode=  this.GetANode(poolname);
        if(existnode)
        {
            parentnode.addChild(existnode,10);
            return existnode;
        }

        var pnode=  new cc.Node();
        var psprite = pnode.addComponent(cc.Sprite);


        /*
        cc.resources.load(resourcefiename,cc.SpriteFrame,(err,sprte:cc.SpriteFrame)=>
        {
            psprite.spriteFrame = sprte;
        });
        */


        ComFunc.CheckFind_Name_Resource2(resourcefiename,cc.Texture2D,(bsuc,sprte1:cc.Texture2D)=>
        {
            if(!bsuc)
            {
                return;
            }

            psprite.spriteFrame = new cc.SpriteFrame(sprte1) ;

        });

        parentnode.addChild(pnode,zindex);



        return pnode;
    }


    //从节点池取一个节点，如果没有就创建一个新节点
    GetPrabbNameNode(poolname:string,preab:cc.Prefab,parentnode:cc.Node = null,zindex=10)
    {
        var existnode=  this.GetANode(poolname);
        if(existnode)
        {
            if(parentnode)
            {
                parentnode.addChild(existnode,zindex);

            }
          
            return existnode;
        }

        var pnode=  cc.instantiate(preab);

        if(parentnode)
        {
            parentnode.addChild(pnode,zindex);
        }
        
        return pnode;
    }

    //从节点池取一个节点
    GetANode(poolname:string)
    {
        if(this.m_poolname_nodepool_map.hasKey(poolname))
        {
            var poolarr:cc.NodePool = this.m_poolname_nodepool_map.getData(poolname);

            if(poolarr.size() > 0)
            { 
                return poolarr.get();
            }
        }

        return null;
    }
    //清空节点池
    clearAll(): void {

        for (var ff=0;ff<this.m_poolname_nodepool_map.size();ff++) 
        {

            var pollar:cc.NodePool = this.m_poolname_nodepool_map.GetEntryByIndex(ff);
            pollar.clear();
          
           
        } 
    }

}