import ClientLogUtils from "../comfuncs/ClientLogUtils";
import SoundManager from "../comfuncs/SoundManager";
import GlobalGameMng from "../Mng/GlobalGameMng";
import TiaozhanChang_Mng from "../Mng/TiaozhanChang_Mng";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class chuangong_fail_dlg extends cc.Component {

    
    
    m_isubgametype = 0;

    onLoad () 
    {
        var quedingbtn = cc.find("panel/quedingbtn",this.node)
        quedingbtn.on("click",this.OnBtnExit.bind(this))


        SoundManager.GetInstance().Play_Effect("com/failed")
        BannerGuangaoMng.GetInstance().CheckShowChaiping(9);

    }

    SetInfo(paradata)
    {
        this.m_isubgametype = paradata.isubgametype;
  

        this.Refresh_Info();
    }
    Refresh_Info()
    {
  
        var addchuizi_c_label = cc.find("panel/top/addchuizi/c",this.node);
        addchuizi_c_label.getComponent(cc.Label).string = ""+GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(6)


        var addzuanshi_label = cc.find("panel/top/addzuanshi/c",this.node);
        addzuanshi_label.getComponent(cc.Label).string = ""+GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(5)

        var gamename_label = cc.find("panel/gamename",this.node);
     
        var sgamename = GlobalGameMng.GetInstance().Get_Game_Type_Name(this.m_isubgametype);

        gamename_label.getComponent(cc.Label).string = sgamename+"挑战失败";  


        var failtip_label = cc.find("panel/failtip",this.node);
        var failtip2_label = cc.find("panel/failtip2",this.node);
    

        var chuangon_suc_c = TiaozhanChang_Mng.GetInstance().Get_TiaozhanChang_Curday_Success_Count(this.m_isubgametype);
        var chuangon_failed_c = TiaozhanChang_Mng.GetInstance().Get_TiaozhanChang_Curday_Failed_Count(this.m_isubgametype);

        var tiaozhaned_c = TiaozhanChang_Mng.GetInstance().Get_SubgameType_CurDay_Tiaozhan_Count(this.m_isubgametype);
     
        failtip_label.getComponent(cc.Label).string = "今日已闯关挑战:"+tiaozhaned_c+"次";
        failtip2_label.getComponent(cc.Label).string = "今日闯关成功:"+chuangon_suc_c+"次";


    }
    OnBtnExit()
    {

        cc.director.loadScene("dating");

        SoundManager.GetInstance().PlayTapButtonEffect();
        
        var isubgametype=  this.m_isubgametype;
        var gametypename= GlobalGameMng.GetInstance().Get_Game_Type_Name(isubgametype);

        ClientLogUtils.GetInstance().Poset_Server_JS_Log(14000+isubgametype, "关卡失败返回大厅", 0,
        "", 0, "", 0, gametypename);
    }

}
