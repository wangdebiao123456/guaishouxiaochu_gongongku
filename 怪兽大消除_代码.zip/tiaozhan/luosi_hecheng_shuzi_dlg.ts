import BaseUIUtils from "../comfuncs/BaseUIUtils";
import SoundManager from "../comfuncs/SoundManager";
import WatchVideoAdveseMng from "../comfuncs/WatchVideoAdveseMng";
import GlobalGameMng from "../Mng/GlobalGameMng";
import Util from "../utils/Util";
import BannerGuangaoMng from "../WDT/BannerGuangaoMng";

 
const {ccclass, property} = cc._decorator;

@ccclass
export default class luosi_hecheng_shuzi_dlg extends cc.Component {


    m_callback = null;
    m_b_selected = 0;
    m_tupo_shuzi = 0;
    m_guoguang_jl = [
        {
            "t":5,
            "c":5
        }
    ];

    

    @property(cc.Node)
    zuanshi:cc.Node = null;
 

    onLoad () {

        var putonglingqubtn = cc.find("panel/menu/putonglingqubtn",this.node);
        putonglingqubtn.on("click",this.OnBtnPutongLignqu.bind(this))
        

        var shuangbeibtn = cc.find("panel/menu/shuangbeibtn",this.node);
        shuangbeibtn.on("click",this.OnBtnShuangbeiLignqu.bind(this))
        


        SoundManager.GetInstance().Play_Effect("com/levelUp");

        BannerGuangaoMng.GetInstance().CheckShowChaiping(9);

    }
    OnBtnPutongLignqu()
    {
        if(this.m_b_selected)
        {
            return;
        }
        this.m_b_selected = 1;
        this.RealLingqu(1);
    }
    OnBtnShuangbeiLignqu()
    {
        if(this.m_b_selected)
        {
            return;
        }
        this.m_b_selected = 1;

        var self = this;
        WatchVideoAdveseMng.GetInstance().Watch_Com_Guanggao_IF_Fail_Try_Self(
            this.node,
            ()=>
            {
            
            },
            
            "螺丝合成数字双倍奖励",(bsuc)=>
        {
            if(!bsuc)
            {
                self.m_b_selected = 0;

                BaseUIUtils.ShowTipTxtDlg("观看视频失败",self.node);
              //  self.RealLingqu(1);
                return;
            }


            self.RealLingqu(2);

        });
    }

    Add_Zuanshi_Move_Anim()
    {
        var putonglingqubtn = cc.find("panel/menu/putonglingqubtn",this.node);
       var from_pos = Util.NodeWorldPos(putonglingqubtn);
       from_pos.x=  0;

        var addchuizi = cc.find("panel/top/addzuanshi",this.node);
        var chuizi_dest_pos = Util.NodeWorldPos(addchuizi);
     
        var ff_node  =cc.instantiate(this.zuanshi);
        this.node.addChild(ff_node,10);

        var ix = Math.random() * 100 - 50+50;
        var iy = Math.random() * 100 - 50;

        var fromx = from_pos.x + ix;
        var fromy = from_pos.y + iy;
        ff_node.setPosition(fromx,fromy);
       

        var pseq = cc.sequence(cc.delayTime(0.2),cc.targetedAction(ff_node,cc.moveTo(0.5,chuizi_dest_pos)) ,
            cc.callFunc(
                ()=>
                {
                    ff_node.destroy();
                }
            )
        );

        this.node.runAction(pseq);
    }
    RealLingqu(ibeishu)
    {
        var awrad = this.m_guoguang_jl;
       

        GlobalGameMng.GetInstance().Add_DaojuType_Count_List(awrad,ibeishu);

        if(ibeishu>1)
        {
            BaseUIUtils.ShowTipTxtDlg("获得"+ibeishu+"倍奖励成功",this.node);
          
        }

        for(var ff=1;ff<=5;ff++)
        {
            this.Add_Zuanshi_Move_Anim();
          
        }

        this.scheduleOnce(this.Refresh_Info.bind(this),1)
        this.scheduleOnce(this.FD_Exit.bind(this),1.5)

        SoundManager.GetInstance().Play_Effect("com/huode_shengji")
      //  GlobalConfig.GetIns().Common_Add_Award_List(awrad,ibeishu);
    
      /*
        var self = this;
        this.node.destroy();

        if(this.m_callback)
        {
            this.m_callback(ibeishu);
        }
        */

      
    }
    FD_Exit()
    {
        var self = this;
        this.node.destroy();

        if(this.m_callback)
        {
            this.m_callback();
        }
    }
    SetInfo(paradata)
    {
        this.m_tupo_shuzi = paradata.tupo_shuzi;
        this.m_callback  = paradata.callback

        var gk_label = cc.find("panel/quan1/gk",this.node);
        gk_label.getComponent(cc.Label).string = ""+this.m_tupo_shuzi;
        
        this.Refresh_Info();
    }
    Refresh_Info()
    {
           
         
        
        var addchuizi_c_label = cc.find("panel/top/addchuizi/c",this.node);
        addchuizi_c_label.getComponent(cc.Label).string = ""+GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(6)


        var addzuanshi_label = cc.find("panel/top/addzuanshi/c",this.node);
        addzuanshi_label.getComponent(cc.Label).string = ""+GlobalGameMng.GetInstance().Get_Self_DestType_Daoju_Count(5)

          

    }
}
