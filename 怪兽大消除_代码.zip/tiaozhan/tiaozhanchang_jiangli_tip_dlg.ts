 

const {ccclass, property} = cc._decorator;

@ccclass
export default class tiaozhanchang_jiangli_tip_dlg extends cc.Component {

    
    
    
    onLoad () 
    {



    }

  
    
}
